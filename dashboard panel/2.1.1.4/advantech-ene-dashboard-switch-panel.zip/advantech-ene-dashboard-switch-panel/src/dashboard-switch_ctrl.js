import {
    MetricsPanelCtrl
} from 'app/plugins/sdk';
import _ from 'lodash';
import $ from 'jquery';
import kbn from 'app/core/utils/kbn';
import TimeSeries from 'app/core/time_series';
import rendering from './rendering';
import { levelConfig } from './config';
import { getMultiLang } from './multilang';
import * as dateMath from './dataMath';
import * as timePicker from './timePicker';
import * as timeCalendar from './timeCalendar';
// import fontSize from 'app/core/utils/fontSize'

export class DashboardSwitchCtrl extends MetricsPanelCtrl {

    constructor($scope, $injector, $rootScope, $window, variableSrv, datasourceSrv, contextSrv) {
        super($scope, $injector);
        this.$rootScope = $rootScope;
        this.windowObj = $window;
        this.hiddenSeries = {};
        this.initDataSourceList = 1;
        this.updateSwitch = 1;
        this.variableSrv = variableSrv;
        this.datasourceSrv = datasourceSrv;
        this.contextSrv = contextSrv;
        // this.templateVariables = this.variableSrv.variables;
        this.deletedDropdowns = [];
        this.deletedParamterDrop = [];
        this.changedVariableIndex = -1;
        this.showDropDown = [false, false, false, false];
        this.checkVaribales = false;
        var panelDefaults = {
            fontSize: '80%',
            dropdowns: [],
            checkboxs: [],
            adjFontSize: true,
            FontSize: '90%',
            hasGroupId: false,
            buttonShow: false,
            buttonShowCtrl: false,
            countButton: 0,
            commonTitle: '',
            commonFontColor: '#d8d9dafff',
            borderStyle: {
                'border': 'solid 2px #464646',
            },
            fontColorStyle: {
                'color': '#d8d9da',
                'width': '100%'
            },
            borderStyle0: null,
            fontColorStyle0: null,
            borderStyle1: null,
            fontColorStyle1: null,
            borderStyle2: null,
            fontColorStyle2: null,
            borderStyle3: null,
            fontColorStyle3: null,
            //variable for templating
            currentList: [],
            variableList: [],
            templatedata: [],
            requestDash: '',
            datasources: [],
            datasource: '',
            levelNumber: 3,
            levelConfig: 1 && levelConfig,
            importLevel: false,
            currLanguge: dateMath.getLangType(this.dashboard.panelLanguage) || 'en',
            onlyShowOrg: true,
            showObject: false,
            showParameter: false,
            showInterval: false,
            selectedItems: '',
            selectedObjItems: [],
            selectedParamItems: [],
            selectedTimeItems: '',
            // showDropDown: false,
            showTimeRange: true,
            showTimeList: false,
            showTimeCalendar: false,
            showTimeInterval: false,
            showUpdatedTime: false,
            timeRange: _.cloneDeep(timePicker.defaultSelectOptions[7]),
            timeInterval: _.cloneDeep(timePicker.defaultIntervalOption),
            customTimeRange: {
                from: _.cloneDeep(timePicker.defaultSelectOptions[7].from),
                to: _.cloneDeep(timePicker.defaultSelectOptions[7].to),
                raw: {
                    from: _.cloneDeep(timePicker.defaultSelectOptions[7].from),
                    to: _.cloneDeep(timePicker.defaultSelectOptions[7].to)
                }
            },
            rangeStr: '',
            lastUpdatedTime: Date.now(),
            carouselInterval: 5000,
            isGeneral: false
        };
        _.defaults(this.panel, panelDefaults);
        !this.panel.levelConfig.datasources && (this.panel.levelConfig.datasources = _.isArray(this.panel.levelConfig.datasource) ? this.panel.levelConfig.datasource : [this.panel.levelConfig.datasource]);
        this.panel.datasources = Object.keys(this.datasourceSrv.datasources);
        this.fontCalc = [
            {
                text: '55%',
                value: '55%',
                vw: '0.5vw',
                px: '10px',
            },
            {
                text: '60%',
                value: '60%',
                vw: '0.6vw',
                px: '12px',
            },
            {
                text: '65%',
                value: '65%',
                vw: '0.7vw',
                px: '14px',
            },
            {
                text: '70%',
                value: '70%',
                vw: '0.8vw',
                px: '15px',
            },
            {
                text: '80%',
                value: '80%',
                vw: '1vw',
                px: '19px',
            },
            {
                text: '90%',
                value: '90%',
                vw: '1.2vw',
                px: '23px',
            },
            {
                text: '100%',
                value: '100%',
                vw: '1.4vw',
                px: '27px',
            },
            {
                text: '110%',
                value: '110%',
                vw: '1.6vw',
                px: '31px',
            },
            {
                text: '120%',
                value: '120%',
                vw: '1.8vw',
                px: '35px',
            },
            {
                text: '130%',
                value: '130%',
                vw: '2vw',
                px: '38px',
            },
            {
                text: '140%',
                value: '140%',
                vw: '2.2vw',
                px: '42px',
            },
            {
                text: '150%',
                value: '150%',
                vw: '2.4vw',
                px: '46px',
            },
            {
                text: '160%',
                value: '160%',
                vw: '2.6vw',
                px: '50px',
            },
            {
                text: '180%',
                value: '180%',
                vw: '3vw',
                px: '58px',
            },
            {
                text: '200%',
                value: '200%',
                vw: '3.4vw',
                px: '65px',
            },
            {
                text: '220%',
                value: '220%',
                vw: '3.8vw',
                px: '73px',
            },
            {
                text: '230%',
                value: '230%',
                vw: '4vw',
                px: '77px',
            },
        ];

        /* add time Range component start */
        this.timeSrv = this.$scope.ctrl.timeSrv;
        this.timeValue = this.timeSrv.timeRange();
        this.timeZoneData = this.dashboard.getTimezone();
        this.dateMath = dateMath;
        this.timePicker = Object.assign({}, timePicker);
        this.timeCalendar = Object.assign({}, timeCalendar);
        this.intervalUnitList = this.getIntervalUnit();
        /* add time Range component end */

        this.renderFlag = false;
        this.titleInvalid = false;
        this.speedInvalid = false;
        this.elem = null;
        this.projectCarousel = null;
        this.paramCarousel = null;
        this.dataRaw = [];
        this.isGeneral = !!this.panel.isGeneral * 1; // portal设置，用于区分是否是general folder，并进行第一个dropdown初始默认值为 第一个非 select group 设定 -- at 2021/07/23 by NH
        // if (this.scope.$$listeners.isWisePaas) {
        // this.events.on('render', this.onRender.bind(this));
        this.events.on('data-received', this.onDataReceived.bind(this));
        this.events.on('data-error', this.onDataError.bind(this));
        this.events.on('data-snapshot-load', this.onDataReceived.bind(this));
        this.events.on('init-edit-mode', this.onInitEditMode.bind(this));
        // }
        this.dashboard.templating.list.forEach(x => {
            if (this.panel.importLevel) {
                if (/Object/i.test(x.name)) {
                    this.panel.showObject = true;
                } else if (/Parameter/i.test(x.name)) {
                    this.panel.showParameter = true;
                } else if (/TimeInterval/i.test(x.name)) {
                    this.panel.showInterval = true;
                }
            }
        });
        this.initConfig(this.panel);
        this.setStyleCSS();
        this.setSelectedItems(this.panel.currentList);
        this.initTimeInvertal();
    }

    onInitEditMode() {
        this.addEditorTab(this.getMultiLang('Options'), 'public/plugins/advantech-ene-dashboard-switch-panel/editor.html', 2);
        this.addEditorTab(this.getMultiLang('List'), 'public/plugins/advantech-ene-dashboard-switch-panel/list.html', 3);
        this.unitFormats = kbn.getUnitFormats();
    }

    editPanel() {
        //get all datasources
        this.datasource.backendSrv.get('/api/datasources').then(all => {
            if (all) {
                this.panel.datasources = all.map(x => x.name);
            }
        }).catch(e => {
            console.log(e);
            this.panel.datasources = [];
        }).finally(() => {
            super.editPanel();
        });
    }

    exportReportCsv() {
        this.panel.exportReportCsv(this.dataRaw); // export report at 2022/03/11 NH
    }

    exitFullscreen() {
        super.exitFullscreen();
    }
    removePanel() {
        // delete variables by this switch panel created
        let names = this.panel.templatedata.map(x => { return x.name });
        if (this.dashboard.templating.list.length > 0) {
            for (let i = 0; i < names.length; i++) {
                let findDeleteIndex = this.dashboard.templating.list.findIndex(deleteIndex => deleteIndex.name === names[i]);
                if (findDeleteIndex !== -1) {
                    this.dashboard.templating.list.splice(findDeleteIndex, 1);
                }
            }
        }
        //invoke parent removePanel function
        super.removePanel();
        //removePanel(this.dashboard, this.panel, true);
    }

    onDataError() {
        this.panel.hasGroupId = false;
        this.panel.buttonShow = false;
        this.panel.buttonShowCtrl = false;
        this.onRender();
    }

    onRender(handler) {
        this.timeValue = this.timeSrv.timeRange();
        let index = this.timePicker.defaultSelectOptions.findIndex(x => { return this.timeValue.raw.from == x.from && this.timeValue.raw.to == x.to });
        if (index !== -1) {
            this.panel.timeRange = this.timePicker.defaultSelectOptions[index];
        } else {
            let from = this.timeValue.raw.from;
            if (typeof from !== 'string') {
                from = new Date(from._d).toISOString();
            }
            let to = this.timeValue.raw.to;
            if (typeof to !== 'string') {
                to = new Date(to._d).toISOString();
            }
            this.panel.timeRange = {
                from,
                to,
                id: 0
            };
        }
        if (this.panel.dropdowns.length > 0 && this.panel.countButton === 0) {
            this.panel.buttonShow = true;
            this.panel.buttonShowCtrl = true;
        }
        if (this.elem) {
            const panelCententElem = this.elem.find('.dashboard-switch-panel').parent().parent();
            panelCententElem.css({ overflow: 'visible' });
        }
        this.renderFlag = true;
        this.render();
    }

    getMultiLang(key) {
        return getMultiLang(key, this.panel.currLanguge);
    }
    initSet(index) {
        if (this.dashboard.templating.list.length) {
            var varInitIndex = this.dashboard.templating.list.findIndex(IndexVar => IndexVar.name === this.panel.dropdowns[index].title);
            if (varInitIndex !== -1) {
                let modelList = this.panel.dropdowns[index].itemList.filter(x => {
                    let index = _.isArray(this.dashboard.templating.list[varInitIndex].current.value) ?
                        this.dashboard.templating.list[varInitIndex].current.value.indexOf(x.value) :
                        this.dashboard.templating.list[varInitIndex].current.value == x.value ? 0 : -1;
                    if (-1 !== index) {
                        return x;
                    }
                });
                if (_.isEmpty(modelList)) {
                    if (this.panel.dropdowns[index].type == 'query' || this.panel.dropdowns[index].type == 'custom' && index == 0) {
                        this.panel.dropdowns[index].model = [this.panel.dropdowns[index].itemList[this.panel.dropdowns[index].includeAll && this.panel.dropdowns[index].itemList.length > 1 ? 1 : 0]];
                    }
                } else {
                    this.panel.dropdowns[index].model = _.cloneDeep(modelList);
                }
            } else {//new add
                if (_.isEmpty(this.panel.dropdowns[index].model)) {
                    this.panel.dropdowns[index].model = [this.panel.dropdowns[index].itemList[this.panel.dropdowns[index].includeAll && this.panel.dropdowns[index].itemList.length > 1 ? 1 : 0]];
                }
            }
            this.selectOption(index, index, 'init');
        } else {
            if (_.isEmpty(this.panel.dropdowns[index].model)) {
                this.panel.dropdowns[index].model = [this.panel.dropdowns[index].itemList[this.panel.dropdowns[index].includeAll && this.panel.dropdowns[index].itemList.length > 1 ? 1 : 0]];
                this.selectOption(index, index, 'init');
            }
        }
        // }
    }

    buttonChange() { // to del
        if (this.panel.buttonShowCtrl === true) {
            this.panel.buttonShow = true;
            this.panel.countButton = 0;
        } else if (this.panel.buttonShowCtrl === false) {
            this.panel.buttonShow = false;
            this.panel.countButton = 1;
        }
    }

    getFontSize(fontSize) {
        if (this.panel.adjFontSize) {
            for (let i = 0; i < this.fontCalc.length; i++) {
                if (this.fontCalc[i].text === fontSize) {
                    if (this.panel.adjFontSize) {
                        fontSize = this.fontCalc[i].vw;
                    } else {
                        fontSize = this.fontCalc[i].px;
                    }
                }
            }
        }
        return fontSize;
    }

    addDropdown() {
        let querylist = this.panel.levelConfig.dropdowns.levels.map(x => { return x.title });
        let index, title, query;
        let delDropLen = this.deletedDropdowns.length;
        if (!this.panel.importLevel) {
            let dlen = this.panel.dropdowns.filter(x => {
                let index = this.panel.levelConfig.dropdowns.params.findIndex(y => {
                    if (y.title) {
                        return y.title == x.title;
                    } else {
                        return false;
                    }
                })
                return -1 == index;
            })
            index = dlen.length + delDropLen;
            title = 'Organization' + index;
            query = !dlen.length ? '"func":"searchGroup"' : '"func":"searchGroup","parentGroup":"$' + dlen.concat(this.deletedDropdowns).map(x => { return x.title }).reverse()[0] + '"';
        } else {
            index = querylist.length;
            title = 'Organization' + index;
            query = '"func":"searchGroup","parentGroup":"$' + querylist.reverse()[0] + '"';
        }
        var newDropdown = {
            title: title,
            label: {
                'en': 'default' + index,
                'zh_cn': '默认' + index,
                'zh_tw': '默認' + index
            },
            model: [{
                name: "select group",
                value: "select group",
                dependentList: ""
            }],
            display: 'select group',
            filter: '', // 输入事件时赋值，输入过滤使用，需要支持特殊字符*
            type: 'custom',
            datasource: this.panel.datasource || '',
            query,
            itemList: [{
                name: "select group",
                value: "select group",
                dependentList: ""
            }],
        }
        this.panel.dropdowns.splice(index, 0, newDropdown);

        this.panel.levelConfig.dropdowns.levels.push(newDropdown);
        this.updateVariableQuery();
        this.refresh();
    }

    deleteDropdown($index) {
        let title = this.panel.dropdowns[$index].title;
        let cfgindex = this.panel.levelConfig.dropdowns.levels.findIndex(x => { return x.title == title && !x.blocked });
        if (cfgindex !== -1) {
            this.panel.levelConfig.dropdowns.levels.splice(cfgindex, 1);
        }
        for (let i = 0; i < this.panel.dropdowns.length; i++) {
            this.panel.dropdowns[i].query.replace('/$' + title, '');
        }
        if (this.dashboard.templating.list.length > 0) {
            var findDeleteIndex = this.dashboard.templating.list.findIndex(deleteIndex => deleteIndex.name === this.panel.dropdowns[$index].title);
            if (findDeleteIndex) {
                this.dashboard.templating.list.splice(findDeleteIndex, 1);
            }
        }
        this.panel.currentList.splice($index, 1);
        this.panel.variableList.splice($index, 1);
        this.panel.templatedata.splice($index, 1);
        this.panel.dropdowns.splice($index, 1);
        this.updateVariableQuery();
        if ($index === 0) {
            this.panel.buttonShow = false;
            this.panel.buttonShowCtrl = false;
            this.panel.countButton = 0;
            this.deletedDropdowns = [];
        }
        this.refresh();
    }

    addDropdownItem($index) {
        var newDropdownItem = {
            name: "select group",
            value: "select group",
            dependentList: ""
        };
        this.panel.dropdowns[$index].itemList.push(newDropdownItem);
        this.selectOption($index, $index, 'change');
        this.refresh();
    }

    deleteDropdownItem(pindex, index) {
        this.panel.dropdowns[pindex].itemList.splice(index, 1);
        this.panel.dropdowns[pindex].model = [this.panel.dropdowns[pindex].itemList[this.panel.dropdowns[pindex].includeAll && this.panel.dropdowns[pindex].itemList.length > 1 ? 1 : 0]];
        this.selectOption(pindex, pindex, 'change');
        this.refresh();
    }

    addCheckBox() {
        var newCheckbox = {
            title: "default",
            value: true
        }
        this.panel.checkboxs.push(newCheckbox);
        this.refresh();
    }

    deleteCheckBox(index) {
        this.panel.checkboxs.splice(index, 1);
        this.refresh();
    }
    checkboxChange(index) {
        this.panel.checkboxs[index].value = !this.panel.checkboxs[index].value;
        this.render(false);
    }
    updateVariable(type, index) {
        this.panel.dropdowns.forEach((x, i) => {
            if (!x.model.length || type === 'clear' && i >= index) x.model = [x.itemList[x.includeAll && x.itemList.length > 1 ? 1 : 0]];
            if (type === 'general') {
                if (i == 0) {
                    if (x.includeAll && x.itemList.length > 2) {
                        x.model = [x.itemList[2]]
                    } else {
                        x.model = [x.itemList[1]]
                    }
                } else {
                    if (x.includeAll && x.itemList.length > 1) {
                        x.model = [x.itemList[1]]
                    } else {
                        x.model = [x.itemList[0]]
                    }
                }
            }
            this.selectOption(i, i, type);
        });
        if (type === 'select' || type === 'clear' || type === 'general') {
            index = this.panel.currentList.findIndex(x => { return x.tag == this.panel.dropdowns[index].title });
            this.changedVariableIndex = index;
            this.updateTemplate(type);
        }
    }
    selectOption(pindex, index, type) {
        let dropdown = this.panel.dropdowns[index];
        if (this.panel.dropdowns.length > 0) {
            var itemValue = [];
            if (_.isEmpty(dropdown.model)) {
                if (!dropdown.itemList.length) return;
                let currIndex = this.panel.currentList.findIndex(x => x.tag === dropdown.title);
                if (currIndex !== -1) {
                    if (dropdown.isMulti !== undefined) {
                        let curr = this.panel.currentList[currIndex].current.value;
                        if (_.isArray(curr)) {
                            let modelList = dropdown.itemList.map(x => {
                                let i = curr.findIndex(y => y == x.value);
                                if (i !== -1) return x;
                            });
                            if (_.isEmpty(modelList)) {
                                dropdown.model = [dropdown.itemList[dropdown.includeAll && dropdown.itemList.length > 1 ? 1 : 0]];
                            } else {
                                dropdown.model = _.cloneDeep(modelList);
                            }
                        } else {
                            let moindex = dropdown.itemList.findIndex(x => x.value == curr);
                            if (moindex !== -1) {
                                dropdown.model = [dropdown.itemList[moindex]];
                            } else {
                                dropdown.model = [dropdown.itemList[dropdown.includeAll && dropdown.itemList.length > 1 ? 1 : 0]];
                            }
                        }
                    }
                }
            }
            var nowDepen = '';
            if (dropdown.isMulti === undefined) {
                nowDepen = this.filterDependentItem(dropdown)//.model['dependentList'];
            }
            itemValue = dropdown['itemList'].filter(x => x.dependentList === nowDepen).map(x => { return { name: x.name, value: x.value } });
            if (nowDepen) {
                if (dropdown.model) {
                    let modelValue = dropdown.model.value;
                    if (itemValue.findIndex(x => { return x.value == modelValue }) === -1) {
                        let model = dropdown.itemList.find(x => x.value === itemValue[0].value);
                        dropdown.model = [model];
                    }
                } else {
                    let model = dropdown.itemList.find(x => x.value === itemValue[0].value);
                    dropdown.model = [model];
                }
            }
            if (type === 'change' || type === 'changeType') {
                dropdown.model = [dropdown.itemList[dropdown.includeAll && dropdown.itemList.length > 1 ? 1 : 0]];
                if (this.dashboard.templating.list.length > 0 && type == 'changeType') {
                    var findDeleteIndex = this.dashboard.templating.list.findIndex(deleteIndex => deleteIndex.name === dropdown.title);
                    if (findDeleteIndex !== -1) {
                        this.dashboard.templating.list.splice(findDeleteIndex, 1); this.refresh();
                    }
                }
            }
            var nowitemTitle = dropdown.title;
            var nowItemName = {
                text: dropdown.model.map(x => x.name).join(' + '),
                value: dropdown.model.length > 1 ? dropdown.model.map(x => x.value) : dropdown.model[0].value
            };
            dropdown.display = dropdown.model.map(x => { return x.name }).join(' + '); // add filter
            this.currentChange(nowitemTitle, nowItemName);
            this.setSelectedItems(this.panel.currentList);
            this.saveVariable(nowitemTitle, itemValue);
        }
    }
    setValueToCookie(name, value) {
        let date = new Date(); //获取当前时间
        let expiresDays = 30;  //将date设置为n天以后的时间
        date.setTime(date.getTime() + expiresDays * 24 * 3600 * 1000); //格式化为cookie识别的时间
        let cookies = name + '=' + value + ";expires=" + date.toGMTString();

        document.cookie = cookies;
    }
    saveVariable(itemTitle, itemName) {
        if (this.panel.variableList.length === 0) {
            this.panel.variableList.push({
                title: itemTitle,
                content: itemName
            });
        } else {
            let oldItem = this.panel.variableList.findIndex(item => item.title === itemTitle);
            if (oldItem === -1) {
                this.panel.variableList.push({
                    title: itemTitle,
                    content: itemName
                });
            } else {
                this.panel.variableList[oldItem].content = itemName;
            }
        }
        this.templateSet(this.panel.variableList);
    }

    templateSet(variableList) {
        var templatedata = [];
        if (variableList.length > 0) {
            for (let i = 0; i < variableList.length; i++) {
                let dropdown = this.panel.dropdowns.filter(x => x.title === variableList[i].title)[0];
                if (!dropdown) continue;
                if (dropdown.type === 'custom') {
                    var optionSet = [];
                    for (let m = 0; m < variableList[i].content.length; m++) {
                        optionSet.push({
                            text: variableList[i].content[m].text,
                            value: variableList[i].content[m].value
                        });
                    }
                    var querySet = variableList[i].content.map(x => { return x.value }).join(',');
                    templatedata.push({
                        allValue: null,
                        current: {
                            text: this.panel.currentList[i].current.text,
                            value: this.panel.currentList[i].current.value
                        },
                        hide: 2,
                        includeAll: dropdown.includeAll || false,
                        label: null,
                        multi: dropdown.isMulti ? true : false,
                        name: variableList[i]['title'],
                        options: optionSet,
                        query: querySet,
                        type: 'custom'
                    });
                } else if (dropdown.type === 'query') {
                    templatedata.push({
                        allValue: null,
                        current: {
                            text: this.panel.currentList[i].current.text,
                            value: this.panel.currentList[i].current.value
                        },
                        datasource: dropdown.datasource,
                        definition: dropdown.query,
                        hide: 2,
                        includeAll: dropdown.includeAll || false,
                        label: null,
                        multi: dropdown.isMulti ? true : false,
                        name: dropdown.title,
                        options: [],
                        query: dropdown.query,
                        refresh: 1,
                        regex: "",
                        type: "query",
                        useTags: false
                    });
                }
            }
        }
        if (this.dashboard.templating.list.length > 0) {
            for (let m = 0; m < this.dashboard.templating.list.length; m++) {
                let oldTempName = this.dashboard.templating.list[m].name;
                let compareIndex = templatedata.findIndex(obj => obj.name === oldTempName);
                if (compareIndex === -1) {
                } else {
                    if (templatedata[compareIndex].type === 'query') {
                        let dropdown = this.panel.dropdowns.filter(x => x.title === templatedata[compareIndex].name)[0];
                        templatedata[compareIndex] = {
                            allValue: null,
                            current: templatedata[compareIndex].current,
                            datasource: templatedata[compareIndex].datasource,
                            definition: templatedata[compareIndex].definition,
                            hide: this.dashboard.templating.list[m].hide,
                            includeAll: templatedata[compareIndex].includeAll,
                            label: this.dashboard.templating.list[m].label,
                            multi: templatedata[compareIndex].multi,
                            name: this.dashboard.templating.list[m].name,
                            options: this.dashboard.templating.list[m].options,
                            query: dropdown.query,
                            refresh: templatedata[compareIndex].refresh,
                            regex: templatedata[compareIndex].regex,
                            type: templatedata[compareIndex].type,
                            useTags: templatedata[compareIndex].useTags
                        };
                    } else {
                        let query = [];
                        this.dashboard.templating.list[m].options.forEach(x => {
                            query.push(x.value);
                        })
                        templatedata[compareIndex] = {
                            allValue: null,
                            current: templatedata[compareIndex].current,
                            hide: this.dashboard.templating.list[m].hide,
                            includeAll: templatedata[compareIndex].includeAll,
                            label: this.dashboard.templating.list[m].label,
                            multi: this.dashboard.templating.list[m].multi,
                            name: this.dashboard.templating.list[m].name,
                            options: this.dashboard.templating.list[m].options,
                            query: query.join(','),
                            type: 'custom'
                        }
                    }
                }
            }
        }
        this.panel.templatedata = templatedata;
    }

    currentChange(currentTitle, currentName) {
        if (this.panel.currentList.length === 0) {
            this.panel.currentList.push({
                tag: currentTitle,
                current: currentName
            });
        } else {
            let oldIndex = this.panel.currentList.findIndex(obj => obj.tag === currentTitle);
            if (oldIndex === -1) {
                this.panel.currentList.push({
                    tag: currentTitle,
                    current: currentName
                });
            } else {
                this.panel.currentList[oldIndex].current = currentName;
            }
        }
    }
    changeGeneralBtn() {
        this.isGeneral = !!this.panel.isGeneral * 1;
        if (this.isGeneral == 1) {
            this.isGeneral += 1;
            this.updateVariable('general', 0);
        }
    }
    updateTemplate(type) {
        let nameList = this.panel.dropdowns.map(x => x.title);
        this.panel.lastUpdatedTime = Date.now();
        this.panel.currentList = this.panel.currentList.filter(x => nameList.indexOf(x.tag) !== -1);
        this.panel.templatedata = this.panel.templatedata.filter(x => nameList.indexOf(x.name) !== -1);
        this.panel.variableList = this.panel.variableList.filter(x => nameList.indexOf(x.title) !== -1);
        if (this.panel.currentList.length > 0) {
            for (let i = 0; i < this.panel.currentList.length; i++) {
                let findtag = this.panel.templatedata.findIndex(obj => obj.name === this.panel.currentList[i].tag);
                if (findtag === -1) {
                    continue;
                } else {
                    this.panel.templatedata[findtag].current = this.panel.currentList[i].current;
                }
            }
        }
        if (this.panel.templatedata) {
            this.initDataSourceList = 1;
            let changeVar = this.changedVariableIndex != -1 ? this.panel.currentList[this.changedVariableIndex] : null;
            let index = changeVar ? this.variableSrv.variables.findIndex(x => { return x.name == changeVar.tag }) : -1;
            if (!this.dashboard.templating.list.length || this.dashboard.templating.list.length !== this.panel.templatedata.length || index == -1) {
                if (type == 'select' && this.variableSrv.variables.length) {
                    // if (this.variableSrv.variables[0].datasource != this.panel.datasource) {
                    for (let i = 0; i < this.variableSrv.variables.length; i++) {
                        this.variableSrv.variables[i].datasource = this.panel.datasource;
                        this.variableSrv.variableUpdated(this.variableSrv.variables[i], true);
                    }
                    let panels = this.dashboard.panels.map(x => {
                        delete x.events;
                        delete x.plugin;
                        delete x.queryRunner;
                        delete x.requestDash;
                        x.datasource = this.panel.datasource; // 同步更新每个panel的datasource at 2021/06/09 by NH 
                        return x;
                    });
                    this.datasource.backendSrv.post('/api/dashboards/db/', {
                        dashboard: {
                            annotations: this.dashboard.annotations,
                            editable: this.dashboard.editable,
                            gnetId: this.dashboard.gnetId,
                            graphTooltip: this.dashboard.graphTooltip,
                            id: this.dashboard.id,
                            iteration: Date.now(),
                            links: this.dashboard.links,
                            panels,
                            schemaVersion: this.dashboard.schemaVersion,
                            style: this.dashboard.style,
                            tags: this.dashboard.tags,
                            templating: { list: this.panel.templatedata },
                            time: this.dashboard.time,
                            timepicker: this.dashboard.timepicker,
                            timezone: this.dashboard.timezone,
                            title: this.dashboard.title,
                            uid: this.dashboard.uid,
                            version: this.dashboard.version,
                        },
                        message: '',
                        overwrite: false,
                        folderId: this.dashboard.meta.folderId
                    }).then(res => {
                        console.log(res);
                        window.onbeforeunload = null;
                        window.location = window.location;
                    }).catch(err => {
                        console.log(err);
                    });
                    // }
                } else {
                    this.getDashboard();
                }
            } else {
                if (type == 'select') {
                    this.variableSrv.variables[index].current = changeVar.current;
                    this.variableSrv.variableUpdated(this.variableSrv.variables[index], true);
                } else if (type == 'clear' || type == 'general') {
                    this.panel.currentList.forEach((x, index) => {
                        let i = this.variableSrv.variables.findIndex(y => { return y.name == x.tag });
                        if (i !== -1) {
                            this.variableSrv.variables[i].current = x.current;
                        }
                    });
                    if (type == 'general') {
                        this.exitFullscreen();
                    }
                    this.variableSrv.variableUpdated(this.variableSrv.variables[0], true);
                }

                // this.onRender();
            }
        }
    }

    getDashboard() {
        var uid = this.dashboard.uid;
        var apiurl = '/api/dashboards/uid/' + uid;
        try {
            this.datasource.backendSrv.get(apiurl).then(gotDash => {
                if (gotDash) {
                    let content = gotDash;
                    this.panel.requestDash = content;
                    this.refreshDash(this.panel.requestDash);
                }
            });
        } catch (error) {
            console.log('This error occurs when get dashboard', error);
            return;
        }
    }

    refreshDash(requestDash) {

        if (requestDash) {
            var variableData = {
                list: []
            };
            //需要修改，已有panel变量追加
            let panels = this.dashboard.panels.filter(x => x.type == this.panel.type);
            let currentList = [];
            for (let i = 0; i < panels.length; i++) {
                let templatings = panels[i].templatedata;
                currentList = currentList.concat(panels[i].currentList);
                for (let j = 0; j < templatings.length; j++) {
                    !variableData.list.length && (variableData.list[0] = _.cloneDeep(templatings[0]));
                    let varIndex = variableData.list.findIndex(x => x.name == templatings[j].name);
                    if (varIndex === -1) {
                        variableData.list.push(templatings[j]);
                    } else {
                        variableData.list[varIndex] = _.cloneDeep(templatings[j]);
                    }
                }

                for (let k = 0; k < this.panel.templatedata.length; k++) {
                    let localIndex = variableData.list.findIndex(x => {
                        return x.name == this.panel.templatedata[k].name
                    });
                    if (localIndex !== -1) {
                        variableData.list[localIndex] = _.cloneDeep(this.panel.templatedata[k]);
                    }
                }
                var findPanelID = requestDash.dashboard.panels.findIndex(z => z.id === panels[i].id);
                if (findPanelID >= 0) {
                    requestDash.dashboard.panels[findPanelID].dropdowns = panels[i].dropdowns;
                    requestDash.dashboard.panels[findPanelID].currentList = panels[i].currentList;
                    requestDash.dashboard.panels[findPanelID].variableList = panels[i].variableList;
                    requestDash.dashboard.panels[findPanelID].templatedata = panels[i].templatedata;
                }
            }
            requestDash.dashboard.templating = variableData;
            requestDash.meta = this.dashboard.meta;
            //this.datasource.backendSrv.saveDashboard(requestDash.dashboard,requestDash.meta);
            //window.onbeforeunload = null;
            let _this = this;
            if (this.dashboard.templating.list.length) {
                for (let currentIndex = 0; currentIndex < currentList.length; currentIndex++) {
                    var findVariable = this.dashboard.templating.list.findIndex(x => x.name === currentList[currentIndex].tag);
                    let templateIndex = variableData.list.findIndex(x => x.name == currentList[currentIndex].tag);
                    if (findVariable !== -1) {
                        this.dashboard.templating.list[findVariable].current = currentList[currentIndex].current;
                        _.assign(this.dashboard.templating.list[findVariable], variableData.list[templateIndex]);
                    } else {
                        this.datasource.backendSrv.saveDashboard(requestDash.dashboard).then(res => {
                            console.log(res);
                            // window.onbeforeunload = null;
                            // window.location = window.location;
                        });
                        // this.timeSrv.refreshDashboard();
                    }
                }
                let changeVarTag = null;
                if (this.changedVariableIndex != -1) {
                    changeVarTag = this.panel.currentList[this.changedVariableIndex].tag;
                } else {
                    let queryVar = this.dashboard.templating.list.filter(x => { return x.type === 'query' });
                    if (_.isEmpty(queryVar)) {
                        changeVarTag = this.dashboard.templating.list[0].name;
                    } else {
                        changeVarTag = queryVar[0].name;
                    }
                }
                findVariable = this.dashboard.templating.list.findIndex(x => x.name === changeVarTag);
                this.changedVariableIndex = -1;
                if (findVariable != -1 && this.dashboard.templating.list[findVariable]) {
                    this.variableSrv.updateOptions(this.dashboard.templating.list[findVariable]).then(() => {
                        this.variableSrv.variableUpdated(this.dashboard.templating.list[findVariable]).then(() => {
                            this.$scope.$emit('template-variable-value-updated');
                            this.$scope.$root.$broadcast('refresh');
                            this.timeSrv.refreshDashboard();
                        });
                    });
                }
            } else {
                this.datasource.backendSrv.saveDashboard(requestDash.dashboard, requestDash.meta).then(async res => {
                    console.log(res);
                    window.onbeforeunload = null;
                    window.location = window.location;
                });
                // this.timeSrv.refreshDashboard();
            }
        }
    }

    async onDataReceived(dataList) {
        this.timeValue = this.timeSrv.timeRange();
        this.panel.lastUpdatedTime = Date.now();
        if (dataList.length) {
            this.panel.currLanguge = this.dateMath.getLangType(dataList[0].langType || this.dashboard.panelLanguage);
            this.dataRaw = dataList;
        }
        await this.initDataSource();
        if (this.initDataSourceList) {
            // this.initDataSourceList = 0;
            let len = this.panel.dropdowns//.filter(x => x.type === 'query');
            let queryVarList = this.dashboard.templating.list//.filter(x => x.type === 'query');

            if (queryVarList.length && len.length) {
                this.downloadData(queryVarList, len);
            }

            let firstModel = '';
            let urlParams = window.location.search.match(/[?&]var1=([^&#?]*)/i);
            if (_.isArray(urlParams) && urlParams.length && urlParams[1]) firstModel = urlParams[1];
            if (this.panel.levelConfig.firstModel) firstModel = {
                text: this.panel.levelConfig.firstModel.name[this.panel.currLanguge],
                value: this.panel.levelConfig.firstModel.value
            };
            if (firstModel && this.panel.dropdowns[0].type === 'custom' && this.panel.importLevel) {
                this.panel.dropdowns[0].itemList = [{
                    name: firstModel.text,
                    value: firstModel.value,
                    dependentList: ""
                }];
                this.panel.dropdowns[0].model = [this.panel.dropdowns[0].itemList[this.panel.dropdowns[0].includeAll && this.panel.dropdowns[0].itemList.length > 1 ? 1 : 0]];
                this.currentChange(this.panel.dropdowns[0].title, firstModel);
                this.setSelectedItems(this.panel.currentList);
            }


            for (let j = 0; j < this.panel.dropdowns.length; j++) {
                this.initSet(j);
            }
            if (this.checkVaribales) {
                this.updateTemplate('select');
            } else if (this.isGeneral == 1) {
                this.isGeneral += 1;
                this.updateVariable('general', 0);
            } else {
                this.onRender(false);
                this.render();
            }
        }
    }

    link(scope, elem, attrs, ctrl) {
        this.elem = elem;
        rendering(scope, elem, attrs, ctrl);
    }

    getDefaultMultiLang(key) {
        const defaultMultiList = ['select group', 'select object', 'select parameter'];
        if(defaultMultiList.indexOf(key) !== -1) {
            return this.getMultiLang(key) || '';
        } else {
            return ''
        }
    }
    downloadData(queryVarList, dropdownsQuery) {
        //1.sync dropdowns
        //2.sync currentList
        //3.sync templatedata

        for (let i = 0; i < queryVarList.length; i++) {
            let dropIndex = dropdownsQuery.findIndex(x => x.title === queryVarList[i].name);
            let currIndex = dropdownsQuery.findIndex(x => x.title === queryVarList[i].name);
            let options = queryVarList[i].options;
            if (dropIndex !== -1 && options.length) {
                // let name = dropdownsQuery[dropIndex].title;
                // let dropIndex1 = this.panel.dropdowns.findIndex(x => x.title === name);
                // this.panel.dropdowns[dropIndex1].itemList = options.map(x => {
                //     return {
                //         name: x.text,
                //         value: x.value,
                //         dependentList: ""
                //     }
                // });
                dropdownsQuery[dropIndex].itemList = options.map(x => {
                    return {
                        name: this.getDefaultMultiLang(x.value) || x.text,
                        value: x.value,
                        dependentList: ""
                    }
                });
            }
            if (currIndex !== -1 && options.length) {
                if (queryVarList[i].current.text != queryVarList[i].model.current.text && /\S+#\d+#/.test(queryVarList[i].model.current.text)) {
                    let current = queryVarList[i].model.current.text.split('#').filter(x => { return !!x });
                    queryVarList[i].model.current = queryVarList[i].current = {
                        text: current[0],
                        value: current[1]
                    }
                    this.checkVaribales = true;
                } else if (this.isGeneral == 1) {
                    queryVarList[i].model.current = queryVarList[i].current = {
                        text: !dropdownsQuery[currIndex].includeAll ?
                            (options[1] && i == 0 ? options[1].text : this.getDefaultMultiLang(options[0].value) || options[0].text) :
                            (options[2] && i == 0 ? options[2].text : this.getDefaultMultiLang(options[1].value) || options[1].text),
                        value: !dropdownsQuery[currIndex].includeAll ?
                            (options[1] && i == 0 ? options[1].value : options[0].value) :
                            (options[2] && i == 0 ? options[2].value : options[1].value),
                    }
                } else {
                    let models = [...dropdownsQuery[currIndex].model];
                    if (models.length == 1) {
                        let index = queryVarList[i].options.findIndex(x => { return x.value == models[0].value });
                        if (index == -1) {
                            queryVarList[i].model.current = queryVarList[i].current = {
                                text: !dropdownsQuery[currIndex].includeAll ?
                                    (options[1] && i == 0 ? options[1].text : this.getDefaultMultiLang(options[0].value) || options[0].text) :
                                    (options[2] && i == 0 ? options[2].text : this.getDefaultMultiLang(options[1].value) || options[1].text),
                                value: !dropdownsQuery[currIndex].includeAll ?
                                    (options[1] && i == 0 ? options[1].value : options[0].value) :
                                    (options[2] && i == 0 ? options[2].value : options[1].value),
                            }
                        }
                    }
                }
                this.currentChange(queryVarList[i].name, queryVarList[i].current);
            }
        }
        this.setSelectedItems(this.panel.currentList);
    }
    async initDataSource() {
        if (this.datasource && -1 == this.panel.datasources.indexOf(this.panel.datasource)) {
            let all = this.contextSrv.user.orgRole == 'Viewer' ? [] : await this.datasource.backendSrv.get('/api/datasources').catch(e => { console.log(e); return [] });
            if (all.length) {
                let defaultDS = [];
                this.panel.datasources = all.map(x => { x.isDefault && defaultDS.push(x.name); return x.name });
                if (defaultDS.length) {
                    let ds = _.intersection(defaultDS, this.panel.levelConfig.datasources);
                    this.panel.datasource = ds.length ? ds[0] : defaultDS[0];
                } else {
                    let ds = _.intersection(this.panel.datasources, this.panel.levelConfig.datasources);
                    this.panel.datasource = ds.length ? ds[0] : 'default';
                }
            } else {
                this.panel.datasource = 'default';
            }
        } else if (-1 == this.panel.datasources.indexOf(this.panel.datasource)) {
            this.panel.datasource = 'default';
            !this.panel.datasources.length && (this.panel.datasources = [].concat(this.panel.levelConfig.datasources));
        }
        // update datasource
        this.panel.levelConfig.dropdowns.levels.forEach(x => { x.datasource = this.panel.datasource });
        this.panel.levelConfig.dropdowns.params.forEach(x => { x.datasource = this.panel.datasource });
        this.panel.dropdowns.forEach(x => { x.datasource = this.panel.datasource });
    }
    async initConfig(panelDefaults) {
        if (!panelDefaults.levelConfig || !panelDefaults.importLevel) return;
        this.panel.currLanguge = dateMath.getLangType(this.dashboard.panelLanguage) || 'en';
        await this.initDataSource();
        let cfDropdowns = panelDefaults.levelConfig.dropdowns;
        let cfCheckboxs = panelDefaults.levelConfig.checkboxs;
        let dropdowns = [];
        let checkboxs = [];


        // panelDefaults.levelNumber = cfDropdowns.levels.length;
        if (panelDefaults.levelNumber >= 0 && panelDefaults.levelNumber <= cfDropdowns.levels.length) {
            //dropdowns = cfDropdowns.levels.slice(0, panelDefaults.levelNumber);
            dropdowns = cfDropdowns.levels.slice(0, cfDropdowns.levels.length);
            this.deletedDropdowns = cfDropdowns.levels.slice(panelDefaults.levelNumber).concat(this.deletedDropdowns);
        } else {
            dropdowns = cfDropdowns.levels.slice(0, cfDropdowns.levels.length);
            panelDefaults.levelNumber = cfDropdowns.levels.length;
        }
        let orgvars, orgnames;
        if (this.dashboard.templating.list.length) {
            orgnames = this.dashboard.templating.list.filter(x => { return /Organization\d+/i.test(x.name) });
        }
        if (!_.isEmpty(orgnames)) {
            orgvars = 'area":"' + orgnames.sort().map(x => { return '$' + x.name }).join('/');
        } else {
            orgvars = 'area":"' + dropdowns.map(x => { return '$' + x.title }).join('/');
        }

        for (let i = 0; i < cfDropdowns.params.length; i++) {
            cfDropdowns.params[i].query = cfDropdowns.params[i].query.replace(/area":"([^"]+)/i, orgvars);
            dropdowns.push(cfDropdowns.params[i]);
        }

        for (let k = 0; k < dropdowns.length; k++) {
            dropdowns[k]['datasource'] = this.panel.datasource;
        }

        panelDefaults.dropdowns = dropdowns;
        this.toggleParamDrop('import');

        for (let j = 0; j < cfCheckboxs.length; j++) {
            checkboxs.push(cfCheckboxs[j]);
        }

        panelDefaults.checkboxs = checkboxs;

    }

    checkImportLevel() {
        console.log('change import button');
        if (this.dashboard.templating.list.length > 0) {
            this.dashboard.templating.list = [];
        }
        this.panel.currentList = [];
        this.panel.variableList = [];
        this.panel.templatedata = [];
        this.panel.dropdowns = [];
        this.panel.checkboxs = [];
        this.deletedDropdowns = [];
        this.panel.selectedItems = '';
        this.panel.selectedObjItems = [];
        this.panel.selectedParamItems = [];
        this.panel.selectedTimeItems = '';
        this.panel.showObject = false;
        this.panel.showParameter = false;
        this.panel.showInterval = false;
        this.deletedParamterDrop = [];
        if (this.panel.importLevel) {
            this.panel.dropdowns = [];
            this.panel.checkboxs = [];
            this.initConfig(this.panel);
            for (let j = 0; j < this.panel.dropdowns.length; j++) {
                this.initSet(j);
            }
            this.onRender();
        } else {
            this.panel.buttonShow = false;
            this.panel.buttonShowCtrl = false;
            this.panel.countButton = 0;
            // this.toggleParamDrop();
            this.onRender();
        }
    }
    /**
     * @name: removeItemsFromArray
     * @description: 从数组中删除符合正则表达式的多个元素
     * @param {*} array
     * @param {*} attr ：数组对象属性，为空则是普通数组元素
     * @param {*} reg
     * @return {array} arr: delete items
     */
    removeItemsFromArray(array, attr, reg) {
        let arr = [];
        array.forEach((x, i, list) => {
            if (reg.test(attr ? x[attr] : x)) {
                arr.push(...list.splice(i, 1));
            }
        });
        return arr;
    }
    /**
     * @name: getLastIndexFromArray
     * @description: 获取数组中匹配正则表达式的最后一项元素index
     * @param {*} array
     * @param {*} attr ：数组对象属性，为空则是普通数组元素
     * @param {*} reg
     * @param {boolean} isLast : default = true
     * @return {number} index
     */
    getLastIndexFromArray(array, attr, reg, isLast = true) {
        let index = -1;
        if (typeof reg == 'string') {
            let t = reg.split('/');
            reg = new RegExp(t[0], t[1] || '');
        }
        for (let i = 0; i < array.length; i++) {
            if (reg.test(attr ? array[i][attr] : array[i])) {
                index = i;
                if (!isLast) break;
            }
        }
        return index;
    }
    toggleParamDrop(type) {
        let plen = this.panel.levelConfig.dropdowns.params.length;
        if (!plen) return '';
        let flag = false;
        let lastGroupIndex = -1;
        let lastObjIndex = -1;
        let index = -1;
        if (type == 'object' || type == 'import') {
            flag = this.panel.showObject;
            if (flag) {
                index = this.getLastIndexFromArray(this.panel.dropdowns, 'title', /Object/i);
                if (index == -1) {
                    let arr = this.removeItemsFromArray(this.deletedParamterDrop, 'title', /Object/i);
                    if (!arr.length) {
                        arr = this.panel.levelConfig.dropdowns.params.filter(x => { return /Object/i.test(x.title) });
                    }
                    arr.forEach(x => { if (!x.model.length) { x.model = [x.itemList[x.includeAll && x.itemList.length > 1 ? 1 : 0]] } x.datasource = this.panel.datasource; });
                    arr.sort((a, b) => { return a.title > b.title ? 1 : a.title < b.title ? -1 : 0 });
                    lastGroupIndex = this.getLastIndexFromArray(this.panel.dropdowns, 'title', /Organization\d+/i);
                    this.panel.dropdowns.splice(lastGroupIndex !== -1 ? lastGroupIndex + 1 : 0, 0, ...arr);
                }
            } else {
                let arr = this.removeItemsFromArray(this.panel.dropdowns, 'title', /Object/i);
                if (arr.length) {
                    lastGroupIndex = this.getLastIndexFromArray(this.deletedParamterDrop, 'title', /Organization\d+/i);
                    this.deletedParamterDrop.splice(lastGroupIndex !== -1 ? lastGroupIndex + 1 : 0, 0, ...arr);
                }
            }
        }
        if (type == 'parameter' || type == 'import') {
            flag = this.panel.showParameter;
            if (flag) {
                index = this.getLastIndexFromArray(this.panel.dropdowns, 'title', /Parameter/i);
                if (index == -1) {
                    let arr = this.removeItemsFromArray(this.deletedParamterDrop, 'title', /Parameter/i);
                    if (!arr.length) {
                        arr = this.panel.levelConfig.dropdowns.params.filter(x => { return /Parameter/i.test(x.title) });
                    }
                    arr.forEach(x => { if (!x.model.length) { x.model = [x.itemList[x.includeAll && x.itemList.length > 1 ? 1 : 0]] } x.datasource = this.panel.datasource; });
                    arr.sort((a, b) => { return a.title > b.title ? 1 : a.title < b.title ? -1 : 0 });
                    lastGroupIndex = this.getLastIndexFromArray(this.panel.dropdowns, 'title', /Organization\d+/i);
                    lastObjIndex = this.getLastIndexFromArray(this.panel.dropdowns, 'title', /Object/i);
                    this.panel.dropdowns.splice(lastObjIndex !== -1 ? lastObjIndex + 1 : lastGroupIndex !== -1 ? lastGroupIndex + 1 : 0, 0, ...arr);
                }
            } else {
                let arr = this.removeItemsFromArray(this.panel.dropdowns, 'title', /Parameter/i);
                if (arr.length) {
                    lastGroupIndex = this.getLastIndexFromArray(this.deletedParamterDrop, 'title', /Organization\d+/i);
                    lastObjIndex = this.getLastIndexFromArray(this.panel.dropdowns, 'title', /Object/i);
                    this.deletedParamterDrop.splice(lastObjIndex !== -1 ? lastObjIndex + 1 : lastGroupIndex !== -1 ? lastGroupIndex + 1 : 0, 0, ...arr);
                }
            }
        }
        if (type == 'timeinterval' || type == 'import') {
            flag = this.panel.showInterval;
            if (flag) {
                index = this.getLastIndexFromArray(this.panel.dropdowns, 'title', /TimeInterval/i);
                if (index == -1) {
                    let arr = this.removeItemsFromArray(this.deletedParamterDrop, 'title', /TimeInterval/i);
                    if (!arr.length) {
                        arr = this.panel.levelConfig.dropdowns.params.filter(x => { return /TimeInterval/i.test(x.title) });
                    }
                    arr.forEach(x => { if (!x.model.length) { x.model = [x.itemList[x.includeAll && x.itemList.length > 1 ? 1 : 0]] } x.datasource = this.panel.datasource; });
                    arr.sort((a, b) => { return a.title > b.title ? 1 : a.title < b.title ? -1 : 0 });
                    this.panel.dropdowns.splice(this.panel.dropdowns.length, 0, ...arr);
                }
            } else {
                let arr = this.removeItemsFromArray(this.panel.dropdowns, 'title', /TimeInterval/i);
                if (arr.length) {
                    this.deletedParamterDrop.splice(this.deletedParamterDrop.length, 0, ...arr);
                }
            }
        }
        // else {
        //   let arr = this.removeItemsFromArray(this.deletedParamterDrop, 'title', /\w+/i);
        //   if (!arr.length) {
        //     arr = this.panel.levelConfig.dropdowns.params.filter(x => { return /\w+/i.test(x.title) });
        //   }
        //   arr.forEach(x => { if (!x.model.length) { x.model = [x.itemList[0]] } x.datasource = this.panel.datasource; });
        //   // this.panel.dropdowns.splice(this.panel.dropdowns.length, 0, ...arr);
        // }
        this.updateVariable('import');
        this.updateVariableQuery();
    }
    updateVariableQuery() {
        let orgvars, orgnames;
        if (this.dashboard.templating.list.length) {
            orgnames = this.dashboard.templating.list.filter(x => { return /Organization\d+/i.test(x.name) });
        }
        if (!_.isEmpty(orgnames)) {
            orgvars = 'area":"' + orgnames.sort().map(x => { return '$' + x.name }).join('/');
        } else {
            orgvars = 'area":"' + this.panel.levelConfig.dropdowns.levels.map(x => { return '$' + x.title }).join('/');
        }
        this.panel.dropdowns.forEach((element, i) => {
            let index = this.panel.levelConfig.dropdowns.params.findIndex(x => { return x.title === element.title });
            if (index !== -1) {
                element.query = element.query.replace(/area":"([^"]+)/i, orgvars);
            }
        });
        this.templateSet(this.panel.variableList);
    }
    changeLevel() {
        console.log(this.panel.levelNumber);
        let levelNumber = Math.floor(this.panel.levelNumber);
        let dropLen = this.getLevel() - this.deletedDropdowns.length;
        if (levelNumber && levelNumber > 0 && levelNumber <= dropLen) {
            // let len = dropLen - levelNumber;
            let startIndex = levelNumber;
            // this.deletedDropdowns = this.panel.dropdowns.splice(startIndex, len).concat(this.deletedDropdowns);
            this.deletedDropdowns = this.panel.dropdowns.slice(startIndex, dropLen).concat(this.deletedDropdowns);
        } else if (levelNumber > dropLen) {
            if (this.deletedDropdowns.length) {
                let len = levelNumber - dropLen;
                let tempArr = this.deletedDropdowns.splice(0, len);
                // this.panel.dropdowns.splice(dropLen, 0, ...tempArr);
            }
        }
        this.setSelectedItems(this.panel.currentList);
        this.render(false);
    }
    changeMultiDropdown($pindex, item, dropdown, $event) {
        $event.stopPropagation();
        let index = dropdown.model.findIndex(x => { return x.value === item.value });
        if (index !== -1) {
            dropdown.isMulti && dropdown.model.splice(index, 1);
            if (_.isEmpty(dropdown.model)) {
                dropdown.model.push(_.cloneDeep(dropdown.itemList[dropdown.includeAll && dropdown.itemList.length > 1 ? 1 : 0]));
            }
        } else {
            if (dropdown.isMulti) {
                if (('' + item.value).indexOf('$__all') !== -1) {
                    dropdown.model = [item];
                } else {
                    dropdown.model.push(_.cloneDeep(item));
                    let defaultIndex = dropdown.model.findIndex(x => { return ('' + x.value).indexOf('select ') !== -1 });
                    ('' + item.value).indexOf('select ') === -1 && defaultIndex !== -1 && dropdown.model.splice(defaultIndex, 1);
                    let allIndex = dropdown.model.findIndex(x => { return ('' + x.value).indexOf('$__all') !== -1 });
                    ('' + item.value).indexOf('$__all') === -1 && allIndex !== -1 && dropdown.includeAll && dropdown.model.splice(allIndex, 1);
                }
            } else {
                dropdown.model = [item];
            }
        }
        if (!dropdown.isMulti) dropdown.showMultiList = false;
        // if (/timeinterval/i.test(dropdown.title)) this.showDropDown[3] = false;
        dropdown.display = dropdown.model.map(x => { return x.name }).join(' + ');
        let $index = dropdown.itemList.findIndex(x => { return x.value === item.value });
        this.closeMultiList();
        // this.selectOption($index, $pindex, 'select');
        $pindex = this.panel.dropdowns.findIndex(x => { return x.title == dropdown.title });
        this.updateVariable('select', $pindex);
    }
    closeMultiList() {
        let _this = this;
        $(document).one('click', function (e) {
            e.stopPropagation();
            if (e.target.className.indexOf('multi-') === -1) {
                for (let i = 0; i < _this.panel.dropdowns.length; i++) {
                    _this.panel.dropdowns[i].filter = '';
                    _this.panel.dropdowns[i].display = _this.panel.dropdowns[i].model.map(x => { return x.name }).join(' + ');
                    if (_this.panel.dropdowns[i].showMultiList !== undefined) {
                        _this.$scope.$apply(function () {
                            _this.panel.dropdowns[i].showMultiList = false;
                            _this.onRender();
                        })
                    }
                }
            } else {
                _this.closeMultiList();
            }
        })
    }
    showMultiValue(dropdown) {
        if (!_.isArray(dropdown.model) || _.isEmpty(dropdown.model)) {
            dropdown.model = [dropdown.itemList[dropdown.includeAll && dropdown.itemList.length > 1 ? 1 : 0]];
        }
        return dropdown.model.map(x => { return x.name }).join('+');
    }
    toggleMultiList(dropdown, $event) {
        $event.stopPropagation();
        this.panel.dropdowns.forEach(e => {
            e.showMultiList = false;
        });
        if (dropdown.showMultiList == undefined || !dropdown.showMultiList) {
            dropdown.showMultiList = true;
            this.closeMultiList();
        } else {
            dropdown.showMultiList = false;
        }
    }
    toggleMulti(dropdown) {
        if (!dropdown.isMulti) {
            dropdown.model = [dropdown.itemList[0]];
            delete dropdown.isMulti;
        }
    }
    checkedActive(item, dropdown) {
        let bool = false;
        if (!_.isArray(dropdown.model)) return bool;
        let index = dropdown.model.findIndex(x => x.value === item.value);
        bool = -1 !== index ? true : false;
        return bool;
    }
    showLevel(index) {
        if (!this.deletedDropdowns.length) return true;

        let dropIndex = this.deletedDropdowns.findIndex(x => x.title === this.panel.dropdowns[index].title);
        if (dropIndex !== -1) {
            return false;
        }
        return true;
    }

    getLevel() {
        let count = 0;
        for (let i = 0; i < this.panel.dropdowns.length; i++) {
            let levelIndex = this.panel.levelConfig.dropdowns.levels.findIndex(x => x.title === this.panel.dropdowns[i].title);
            if (levelIndex !== -1) {
                count++;
            }
        }
        return count;
    }

    filterDependentItem(dropdown) {
        if (dropdown.type && dropdown.type === 'query') return '';
        let customList = this.panel.dropdowns.filter(x => x.type === 'custom');
        if (customList.length <= 1) return '';
        let dependent = dropdown.itemList[dropdown.includeAll && dropdown.itemList.length > 1 ? 1 : 0].dependentList;
        let drop = customList.find(x => {
            let dindex = x.itemList.findIndex(y => y.value === dependent);
            if (dindex !== -1) {
                return x
            }
        });
        if (drop) {
            return drop.model.value;
        } else {
            return '';
        }
    }

    // -------------------- time range start-----------------------------------
    onChangeTimePicker(timeRange) {
        const panel = this.dashboard.timepicker;
        const hasDelay = panel.nowDelay && timeRange.raw.to === 'now';
        const adjustedFrom = this.dateMath.isMathString(timeRange.raw.from) ? timeRange.raw.from : timeRange.from;
        const adjustedTo = this.dateMath.isMathString(timeRange.raw.to) ? timeRange.raw.to : timeRange.to;
        const nextRange = {
            from: adjustedFrom,
            to: hasDelay ? 'now-' + panel.nowDelay : adjustedTo,
        };
        this.timeSrv.setTime(nextRange);
        this.onRender();
    }
    showTimeRange() {
        if (this.panel.timeRange.id) {
            return this.panel.timeRange.display[this.panel.currLanguge];
        } else {
            this.panel.timeRange.id = 0;
            return `${this.isDate(this.panel.timeRange.from) ? this.formatDate(this.panel.timeRange.from) : this.panel.timeRange.from} To ${this.isDate(this.panel.timeRange.to) ? this.formatDate(this.panel.timeRange.to) : this.panel.timeRange.to}`;
        }
    }
    toggleTimeRange() {
        this.panel.showTimeList = !this.panel.showTimeList;
        this.panel.showTimeInterval = false;
        this.panel.showTimeCalendar = false;
        this.showDropDown = [false, false, false, false];
        this.setStyleCSS();
        this.closeTimeInterval();
    }
    changeTimeRange(item, $index, $event) {
        $event.stopPropagation();
        this.toggleTimeRange();
        if (item.id === 0) {
            this.panel.customTimeRange = {
                from: this.panel.timeRange.from,
                to: this.panel.timeRange.to,
                raw: {
                    from: this.panel.timeRange.from,
                    to: this.panel.timeRange.to,
                }
            };
            this.timeCalendar.defaultOptions.from.level = 1;
            this.timeCalendar.defaultOptions.to.level = 1;
            this.changeCustomRange(0); // init custom time range.from
            this.changeCustomRange(1); // init custom time range.to
            this.panel.showTimeCalendar = !this.panel.showTimeCalendar;
            this.onRender();
        } else if (item.id === 1) {
            this.initTimeInvertal();
            this.panel.showTimeInterval = !this.panel.showTimeInterval;
        } else {
            this.panel.timeRange = item;
            let tr = {
                raw: {
                    from: item.from,
                    to: item.to
                },
                from: item.from,
                to: item.to,
            }
            this.onChangeTimePicker(tr);
        }
    }
    checkedActiveTimeRange(item) {
        return this.panel.timeRange.id == item.id;
    }
    getIntervalUnit() {
        let lang = this.panel.currLanguge || 'en';
        return this.timePicker.defaultOptions.interval.list.map(x => { return { value: x.unit, text: x.display[lang] } });
    }
    getTimeIntervalFormatString() {
        let str = [];
        let timerange = this.panel.timeRange;
        let from = this.parseDate(timerange.from);
        let to = this.parseDate(timerange.to);
        let ftime = new Date(from.date).getTime();
        let ttime = new Date(to.date).getTime();
        let num = Math.abs(ftime - ttime);
        let arr = [];
        let t1 = 0;
        t1 = parseInt(num / (1000 * 60 * 60 * 24 * 365));
        arr.push(t1);
        num = num - t1 * 1000 * 60 * 60 * 24 * 365;

        t1 = parseInt(num / (1000 * 60 * 60 * 24 * 30));
        arr.push(t1);
        num = num - t1 * 1000 * 60 * 60 * 24 * 30;

        t1 = parseInt(num / (1000 * 60 * 60 * 24 * 7));
        arr.push(t1);
        num = num - t1 * 1000 * 60 * 60 * 24 * 7;

        t1 = parseInt(num / (1000 * 60 * 60 * 24));
        arr.push(t1);
        num = num - t1 * 1000 * 60 * 60 * 24;

        t1 = parseInt(num / (1000 * 60 * 60));
        arr.push(t1);
        num = num - t1 * 1000 * 60 * 60;

        t1 = parseInt(num / (1000 * 60));
        arr.push(t1);
        num = num - t1 * 1000 * 60;

        arr.push(parseInt(num / 1000));
        let lang = this.panel.currLanguge || 'en';
        arr.forEach((x, i) => {
            !!x && str.push(x + ' ' + this.timePicker.defaultOptions.interval.list[i].display[lang] + (x > 1 && lang == 'en' ? 's' : ''));
        });
        return str.join(' ');
    }
    changeTimenInterval(direction) {
        let timerange = this.panel.timeRange;
        let from = this.parseDate(timerange.from);
        let to = this.parseDate(timerange.to);
        let isDate = from.isDate || to.isDate;
        let tr;
        let sub = 0;
        let fnum = 0;
        let tnum = 0;
        if (!isDate) {
            sub = Math.abs((from.symbol + from.number) - (to.symbol + to.number));
            fnum = Number(from.symbol + from.number);
            fnum = fnum + sub * Number(this.panel.timeInterval.number) * direction;
            tnum = Number(to.symbol + to.number);
            tnum = tnum + sub * Number(this.panel.timeInterval.number) * direction
        } else {
            fnum = new Date(from.date).getTime();
            tnum = new Date(to.date).getTime()
            sub = Math.abs(fnum - tnum);
            fnum = fnum + sub * Number(this.panel.timeInterval.number) * direction;
            tnum = tnum + sub * Number(this.panel.timeInterval.number) * direction;
            fnum = new Date(fnum).toISOString();
            tnum = new Date(tnum).toISOString();
        }
        if (!isDate) {
            tr = {
                from: `${from.range}${fnum < 0 ? '' + fnum : fnum > 0 ? '+' + fnum : ''}${fnum ? from.unit || to.unit : ''}${from.type ? from.type + from.unit : ''}`,
                to: `${to.range}${tnum < 0 ? '' + tnum : tnum > 0 ? '+' + tnum : ''}${tnum ? to.unit || from.unit : ''}${to.type ? to.type + to.unit : ''}`,
                raw: {
                    from: `${from.range}${fnum < 0 ? '' + fnum : fnum > 0 ? '+' + fnum : ''}${fnum ? from.unit || to.unit : ''}${from.type ? from.type + from.unit : ''}`,
                    to: `${to.range}${tnum < 0 ? '' + tnum : tnum > 0 ? '+' + tnum : ''}${tnum ? to.unit || from.unit : ''}${to.type ? to.type + to.unit : ''}`
                }
            }
        } else {
            tr = {
                from: this.formatDate(fnum),
                to: this.formatDate(tnum),
                raw: {
                    from: fnum,
                    to: tnum
                }
            }
        }

        this.onChangeTimePicker(tr);
    }
    initTimeInvertal() {
        this.panel.rangeStr = this.getTimeIntervalFormatString();
        this.panel.timeInterval = this.transformTimeRange(this.panel.timeRange);
    }
    transformTimeRange(timerange) {
        let from = this.parseDate(timerange.from);
        let to = this.parseDate(timerange.to);
        let isDate = from.isDate || to.isDate;
        let unit = 'm';
        if (!isDate) {
            unit = from.unit;
        } else {
            let t1 = new Date(from.date).getTime();
            let t2 = new Date(to.date).getTime();
            let t = Math.abs(t2 - t1);
            if (t < 1000 * 60 * 60) {
                unit = 'm';
            } else if (t < 1000 * 60 * 60 * 24) {
                unit = 'h';
            } else if (t < 1000 * 60 * 60 * 24 * 7) {
                unit = 'd';
            } else if (t < 1000 * 60 * 60 * 24 * 30) {
                unit = 'W';
            } else if (t < 1000 * 60 * 60 * 24 * 365) {
                unit = 'd';
            } else {
                unit = 'y';
            }
        }
        return {
            number: this.panel.timeInterval.number || 1,
            unit,
            raw: {
                from: isDate ? from.date : `${from.range}${from.symbol}${from.number}${from.unit}${from.type ? from.type + from.unit : ''}`,
                to: isDate ? to.date : `${to.range}${to.symbol}${to.number}${to.unit}${to.type ? to.type + to.unit : ''}`
            }
        }
    }
    parseDate(time) {
        let obj = null;
        if (!(typeof (time) === 'string' && time.substring(0, 3) === 'now' || typeof (time) === 'string' && this.isDate(new Date(time)))) return undefined;
        let t, mathString;
        if (time.substring(0, 3) === 'now') {
            mathString = time.substring('now'.length);
            if (!mathString.length) {
                obj = {
                    unit: '',
                    number: 0,
                    type: '',
                    range: 'now',
                    date: new Date().toISOString(),
                    symbol: '',
                    isDate: false
                }
            } else {
                var i = 0;
                var len = mathString.length;
                var symbol = '';
                var number;
                while (i < len) {
                    var c = mathString.charAt(i++);
                    var type;
                    var num;
                    var unit;
                    var units = ['y', 'M', 'w', 'd', 'h', 'm', 's'];

                    if (c === '/') {
                        type = 0;
                    } else if (c === '+') {
                        type = 1;
                        symbol = '+';
                    } else if (c === '-') {
                        type = 2;
                        symbol = '-';
                    } else {
                        return undefined;
                    }

                    if (isNaN(mathString.charAt(i))) {
                        num = 1;
                    } else if (mathString.length === 2) {
                        num = mathString.charAt(i);
                    } else {
                        var numFrom = i;
                        while (!isNaN(mathString.charAt(i))) {
                            i++;
                            if (i > 10) { return undefined; }
                        }
                        number = num = parseInt(mathString.substring(numFrom, i), 10);
                    }

                    if (type === 0) {
                        if (num !== 1) {
                            return undefined;
                        }
                    }
                    unit = mathString.charAt(i++);
                    if (symbol && !number) number = 1;
                    if (!_.includes(units, unit)) {
                        return undefined;
                    } else {
                        let date = this.dateMath.parse(time);
                        obj = {
                            unit,
                            number,
                            type: type == 0 ? '/' : '',
                            range: 'now',
                            date: new Date(date._d).toISOString(),
                            symbol,
                            isDate: false
                        }
                    }
                }
            }
        } else { // 2021-05-18T00:00:00Z || 2021-05-18 00:00:00
            let date = this.dateMath.parse(time);
            obj = {
                unit: '',
                number: 0,
                type: '',
                date: new Date(date._d).toISOString(),
                range: '',
                symbol: '',
                isDate: true
            }
        }

        return obj;
    }
    formatDate(time) {
        let date = new Date(time);
        let sec = date.getSeconds() < 10 ? '0' + date.getSeconds() : date.getSeconds();
        let min = date.getMinutes() < 10 ? '0' + date.getMinutes() : date.getMinutes();
        let hour = date.getHours() < 10 ? '0' + date.getHours() : date.getHours();
        let day = date.getDate() < 10 ? '0' + date.getDate() : date.getDate();
        let mon = date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1;
        let y = date.getFullYear();
        return `${y}/${mon}/${day} ${hour}:${min}:${sec}`;
    }
    isDate(str) {
        let bool = false;
        try {
            let date = new Date(str);
            _.isDate(date) && !isNaN(date.getTime()) && (bool = true);
        } catch (e) {
            bool = false;
        }
        return bool;
    }
    closeTimeInterval() {
        let _this = this;
        $(document).on('click', function (e) {
            e.stopPropagation();
            if (e.target.className.indexOf('time-range-') === -1 && e.target.className.indexOf('react-calendar') === -1 && e.target.className.indexOf('time-picker-') === -1) {
                _this.$scope.$apply(function () {
                    _this.panel.showTimeList = false;
                    _this.panel.showTimeInterval = false;
                    _this.panel.showTimeCalendar = false;
                    _this.onRender();
                })
            }
        });
    }
    changeCustomRange(dir) {
        // 需要check 输入格式是否正确，错误返回error
        console.log('set custom range');
        let date = this.dateMath.parse(this.panel.customTimeRange[!dir ? 'from' : 'to']);
        let isErr = !this.isDate(date);
        this.timeCalendar.defaultOptions[!dir ? 'from' : 'to'].isErr = isErr;
        if (!isErr) {
            this.panel.customTimeRange.raw[!dir ? 'from' : 'to'] = this.panel.customTimeRange[!dir ? 'from' : 'to'];
            this.setCalendarOptions(this.timeCalendar.defaultOptions[!dir ? 'from' : 'to'], new Date(date._d).toISOString());
            this.timeCalendar[!dir ? 'fromList' : 'toList'].dates = this.getDateList(date, this.panel.customTimeRange[!dir ? 'from' : 'to']);
        }
    }
    setCustomRange() {
        // 
        this.panel.timeRange = _.cloneDeep(this.panel.customTimeRange);
        this.onChangeTimePicker(this.panel.customTimeRange);
    }
    setCalendarOptions(obj, data) {
        // 需要查看level ，lang 显示
        let dateObj = this.dateMath.parse('' + data);
        let level = obj.level;
        let index = -1;
        let lang = this.panel.currLanguge;
        if (dateObj && dateObj._d && this.isDate(dateObj._d)) {
            let date = new Date(dateObj._d);
            let year = date.getFullYear();
            let month = date.getMonth();
            let day = date.getDate();
            let hour = date.getHours();
            let min = date.getMinutes();
            let sec = date.getSeconds();
            let title = '';

            index = this.timeCalendar.defaultDisplayOptions.months.findIndex(x => { return x.id == month });
            let m = this.timeCalendar.defaultDisplayOptions.months[index];
            if (level == 1) {
                title = lang == 'en' ? m.display[lang] + ' ' + year : year + this.timeCalendar.defaultDisplayOptions.year[lang] + m.display[lang];
            } else if (level == 2) {
                title = year;
            } else if (level == 3) {
                let s = parseInt(year / 10) * 10 + 1;
                let e = s + 9;
                title = s + ' - ' + e;
            } else if (level == 4) {
                let s = parseInt(year / 100) * 100 + 1;
                let e = s + 99;
                title = s + ' - ' + e;
            }
            obj.date = date.toISOString();
            obj.title = title;
            obj.year = year;
            obj.month = month;
            obj.day = day;
            obj.hour = hour;
            obj.min = min;
            obj.sec = sec;
        } else { // 从 list item 点击进入
            if (level == 1) {
                index = this.timeCalendar.defaultDisplayOptions.months.findIndex(x => { return x.id == data });
                let m = this.timeCalendar.defaultDisplayOptions.months[index];
                obj.title = lang == 'en' ? m.display[lang] + ' ' + obj.year : obj.year + this.timeCalendar.defaultDisplayOptions.year[lang] + m.display[lang];
                obj.month = data;
            } else if (level == 2) {
                obj.title = data;
                obj.year = data;
            } else if (level == 3) {
                obj.title = data;
            } else if (level == 4) {

            }
            obj.date = new Date(obj.year, obj.month, obj.day).toISOString();
        }
    }
    setCalendarData(calendar, dir) {
        let now = new Date();
        let str = `${calendar.year || now.getFullYear()}-${calendar.month !== '' ? this.getDoubleDigit(calendar.month + 1) : this.getDoubleDigit(now.getMonth() + 1)}-${this.getDoubleDigit(calendar.day || now.getDate())} ${!dir ? '00:00:00' : '23:59:59'}`;
        let date = new Date(str);
        if (!dir) {
            this.panel.customTimeRange.from = str;
            this.panel.customTimeRange.raw.from = date.toISOString();
            // this.panel.timeRange.from = date.toISOString();
        } else {
            this.panel.customTimeRange.to = str;
            this.panel.customTimeRange.raw.to = date.toISOString();
            // this.panel.timeRange.to = date.toISOString();
        }

    }
    previousBtnHandler(dir, $event) {
        let level = this.timeCalendar.defaultOptions.from.level;
        let date = null;
        let parent = $($event.target).closest('div');
        parent.siblings('.react-calendar__month-view').find('button').removeClass('react-calendar__tile--active');
        if (!dir) { // from
            date = new Date(this.timeCalendar.defaultOptions.from.date);
            if (level == 1) {
                date.setMonth(date.getMonth() - 1, 1);
                this.setCalendarOptions(this.timeCalendar.defaultOptions.from, date.toISOString());
                this.timeCalendar.fromList.dates = this.getDateList(date, this.panel.customTimeRange.from);
            } else if (level == 2) {
                date.setFullYear(date.getFullYear() - 1);
                this.setCalendarOptions(this.timeCalendar.defaultOptions.from, date.toISOString());
            } else if (level == 3) {
                date.setFullYear(date.getFullYear() - this.timeCalendar.defaultOptions.decade);
                this.setCalendarOptions(this.timeCalendar.defaultOptions.from, date.toISOString());
                this.timeCalendar.fromList.decade = this.getDecadeList(this.timeCalendar.defaultOptions.from.year, this.panel.customTimeRange.from);
            } else if (level == 4) {
                date.setFullYear(date.getFullYear() - this.timeCalendar.defaultOptions.century);
                this.setCalendarOptions(this.timeCalendar.defaultOptions.from, date.toISOString());
                this.timeCalendar.fromList.century = this.getCenturyList(this.timeCalendar.defaultOptions.from.year, this.panel.customTimeRange.from);
            }
        } else {
            date = new Date(this.timeCalendar.defaultOptions.to.date);
            if (level == 1) {
                date.setMonth(date.getMonth() - 1, 1);
                this.setCalendarOptions(this.timeCalendar.defaultOptions.to, date.toISOString());
                this.timeCalendar.toList.dates = this.getDateList(date, this.panel.customTimeRange.to);
            } else if (level == 2) {
                date.setFullYear(date.getFullYear() - 1);
                this.setCalendarOptions(this.timeCalendar.defaultOptions.to, date.toISOString());
            } else if (level == 3) {
                date.setFullYear(date.getFullYear() - this.timeCalendar.defaultOptions.decade);
                this.setCalendarOptions(this.timeCalendar.defaultOptions.to, date.toISOString());
                this.timeCalendar.toList.decade = this.getDecadeList(this.timeCalendar.defaultOptions.to.year, this.panel.customTimeRange.to);
            } else if (level == 4) {
                date.setFullYear(date.getFullYear() - this.timeCalendar.defaultOptions.century);
                this.setCalendarOptions(this.timeCalendar.defaultOptions.to, date.toISOString());
                this.timeCalendar.toList.century = this.getCenturyList(this.timeCalendar.defaultOptions.to.year, this.panel.customTimeRange.to);
            }
        }
    }
    middleBtnHandler(dir) {
        console.log(this.panel.customTimeRange);
        console.log(this.timeCalendar.defaultOptions);
        if (!dir) { // from
            if (this.timeCalendar.defaultOptions.from.level !== 4) {
                this.timeCalendar.defaultOptions.from.level += 1;
                this.setCalendarOptions(this.timeCalendar.defaultOptions.from, this.panel.customTimeRange.raw.from);
                if (this.timeCalendar.defaultOptions.from.level == 3) {
                    this.timeCalendar.fromList.decade = this.getDecadeList(this.timeCalendar.defaultOptions.from.year, this.panel.customTimeRange.from);
                } else if (this.timeCalendar.defaultOptions.from.level == 4) {
                    this.timeCalendar.fromList.century = this.getCenturyList(this.timeCalendar.defaultOptions.from.year, this.panel.customTimeRange.from);
                }
            }
        } else {
            if (this.timeCalendar.defaultOptions.to.level !== 4) {
                this.timeCalendar.defaultOptions.to.level += 1;
                this.setCalendarOptions(this.timeCalendar.defaultOptions.to, this.panel.customTimeRange.raw.to);
                if (this.timeCalendar.defaultOptions.to.level == 3) {
                    this.timeCalendar.toList.decade = this.getDecadeList(this.timeCalendar.defaultOptions.to.year, this.panel.customTimeRange.to);
                } else if (this.timeCalendar.defaultOptions.to.level == 4) {
                    this.timeCalendar.toList.century = this.getCenturyList(this.timeCalendar.defaultOptions.to.year, this.panel.customTimeRange.to);
                }
            }
        }
    }
    nextBtnHandler(dir, $event) {
        let level = this.timeCalendar.defaultOptions.from.level;
        let date = null;
        let parent = $($event.target).closest('div');
        parent.siblings('.react-calendar__month-view').find('button').removeClass('react-calendar__tile--active');
        if (!dir) { // from
            date = new Date(this.timeCalendar.defaultOptions.from.date);
            if (level == 1) {
                date.setMonth(date.getMonth() + 1, 1);
                this.setCalendarOptions(this.timeCalendar.defaultOptions.from, date.toISOString());
                this.timeCalendar.fromList.dates = this.getDateList(date, this.panel.customTimeRange.from);
            } else if (level == 2) {
                date.setFullYear(date.getFullYear() + 1);
                this.setCalendarOptions(this.timeCalendar.defaultOptions.from, date.toISOString());
            } else if (level == 3) {
                date.setFullYear(date.getFullYear() + this.timeCalendar.defaultOptions.decade);
                this.setCalendarOptions(this.timeCalendar.defaultOptions.from, date.toISOString());
                this.timeCalendar.fromList.decade = this.getDecadeList(this.timeCalendar.defaultOptions.from.year, this.panel.customTimeRange.from);
            } else if (level == 4) {
                date.setFullYear(date.getFullYear() + this.timeCalendar.defaultOptions.century);
                this.setCalendarOptions(this.timeCalendar.defaultOptions.from, date.toISOString());
                this.timeCalendar.fromList.century = this.getCenturyList(this.timeCalendar.defaultOptions.from.year, this.panel.customTimeRange.from);
            }
        } else {
            date = new Date(this.timeCalendar.defaultOptions.to.date);
            if (level == 1) {
                date.setMonth(date.getMonth() + 1, 1);
                this.setCalendarOptions(this.timeCalendar.defaultOptions.to, date.toISOString());
                this.timeCalendar.toList.dates = this.getDateList(date, this.panel.customTimeRange.to);
            } else if (level == 2) {
                date.setFullYear(date.getFullYear() + 1);
                this.setCalendarOptions(this.timeCalendar.defaultOptions.to, date.toISOString());
            } else if (level == 3) {
                date.setFullYear(date.getFullYear() + this.timeCalendar.defaultOptions.decade);
                this.setCalendarOptions(this.timeCalendar.defaultOptions.to, date.toISOString());
                this.timeCalendar.toList.decade = this.getDecadeList(this.timeCalendar.defaultOptions.to.year, this.panel.customTimeRange.to);
            } else if (level == 4) {
                date.setFullYear(date.getFullYear() + this.timeCalendar.defaultOptions.century);
                this.setCalendarOptions(this.timeCalendar.defaultOptions.to, date.toISOString());
                this.timeCalendar.toList.century = this.getCenturyList(this.timeCalendar.defaultOptions.to.year, this.panel.customTimeRange.to);
            }
        }
    }
    itemBtnHandler(dir, item, $index, $event) {
        let date = null;
        let parent = $($event.target).closest('div');
        parent.find('button').removeClass('react-calendar__tile--active');
        if (!dir) { // from
            if (this.timeCalendar.defaultOptions.from.level == 1) {
                date = new Date(new Date(this.timeCalendar.defaultOptions.to.date).toLocaleDateString() > item.time || item.type == 3 ? item.time : new Date(this.timeCalendar.defaultOptions.to.date).toLocaleDateString()).toISOString();
                this.setCalendarOptions(this.timeCalendar.defaultOptions.from, date);
                if (item.type == 1 || item.type == 3) {
                    this.timeCalendar.fromList.dates = this.getDateList(date, date);
                } else {
                    let dateStr = new Date(date).getFullYear() + '/' + this.getDoubleDigit(new Date(date).getMonth() + 1) + '/' + this.getDoubleDigit(new Date(date).getDate());
                    parent.find(`button[title="${dateStr}"]`).addClass('react-calendar__tile--active').siblings('button');
                }
                this.setCalendarData(this.timeCalendar.defaultOptions.from, dir);
            } else {
                date = item;
                this.timeCalendar.defaultOptions.from.level -= 1;
                if (this.timeCalendar.defaultOptions.from.level == 1) {
                    // let obj = Object.assign({}, this.timeCalendar.defaultOptions.from);
                    this.setCalendarOptions(this.timeCalendar.defaultOptions.from, date);
                    this.timeCalendar.fromList.dates = this.getDateList(this.timeCalendar.defaultOptions.from.date, this.panel.customTimeRange.from);
                } else if (this.timeCalendar.defaultOptions.from.level == 2) {
                    this.setCalendarOptions(this.timeCalendar.defaultOptions.from, date);
                    this.timeCalendar.defaultOptions.from.month = date;
                } else if (this.timeCalendar.defaultOptions.from.level == 3) {
                    this.setCalendarOptions(this.timeCalendar.defaultOptions.from, date);
                    this.timeCalendar.fromList.decade = this.getDecadeList(date.split(/\s+/g).filter(x => { return !isNaN(x) })[0], this.panel.customTimeRange.from, false);
                }
            }
        } else {
            if (this.timeCalendar.defaultOptions.to.level == 1) {
                date = new Date(new Date(this.timeCalendar.defaultOptions.from.date).toLocaleDateString() < item.time || item.type == 1 ? item.time : new Date(this.timeCalendar.defaultOptions.from.date).toLocaleDateString()).toISOString();
                this.setCalendarOptions(this.timeCalendar.defaultOptions.to, date);
                if (item.type == 1 || item.type == 3) {
                    this.timeCalendar.toList.dates = this.getDateList(date, date);
                } else {
                    let dateStr = new Date(date).getFullYear() + '/' + this.getDoubleDigit(new Date(date).getMonth() + 1) + '/' + this.getDoubleDigit(new Date(date).getDate());
                    parent.find(`button[title="${dateStr}"]`).addClass('react-calendar__tile--active').siblings('button');
                }
                this.setCalendarData(this.timeCalendar.defaultOptions.to, dir);
            } else {
                date = item;
                this.timeCalendar.defaultOptions.to.level -= 1;
                if (this.timeCalendar.defaultOptions.to.level == 1) {
                    this.setCalendarOptions(this.timeCalendar.defaultOptions.to, date);
                    this.timeCalendar.toList.dates = this.getDateList(this.timeCalendar.defaultOptions.to.date, this.panel.customTimeRange.to);
                } else if (this.timeCalendar.defaultOptions.to.level == 2) {
                    this.setCalendarOptions(this.timeCalendar.defaultOptions.to, date);
                    this.timeCalendar.defaultOptions.to.month = date;
                } else if (this.timeCalendar.defaultOptions.to.level == 3) {
                    this.setCalendarOptions(this.timeCalendar.defaultOptions.to, date);
                    this.timeCalendar.toList.decade = this.getDecadeList(date.split(/\s+/g).filter(x => { return !isNaN(x) })[0], this.panel.customTimeRange.to, false);
                }
            }
        }
    }
    getDateList(date, pickerDate, current = true) {
        date = new Date(this.dateMath.parse(date)._d);
        pickerDate = new Date(this.dateMath.parse(pickerDate)._d);
        let now = new Date();
        if (date.getFullYear() <= this.timeCalendar.defaultOptions.maxYear && date.getFullYear() >= this.timeCalendar.defaultOptions.minYear) {
            let dateList = [],//属性type：1 表示上月的日期 2表示当月日期 3表示下月日期, 属性date：当天是几号
                weekOfFirstDay, // 当月第一天是周几
                endDayOfMonth, // 当前月份最后一天
                endDayOfLastMonth;// 上月最后一天
            let lastMonth = new Date(date.getFullYear(), date.getMonth(), 0);
            let nextMonth = new Date(date.getFullYear(), date.getMonth() + 1, 1);
            weekOfFirstDay = new Date(date.getFullYear(), date.getMonth(), 1).getDay();
            endDayOfMonth = new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate();
            endDayOfLastMonth = lastMonth.getDate();

            for (let i = 1; i <= endDayOfMonth; i++) {
                let dateObj = {
                    type: 2,
                    date: i,
                    time: `${date.getFullYear()}/${this.getDoubleDigit(date.getMonth() + 1)}/${this.getDoubleDigit(i)}`,
                    current: pickerDate.getFullYear() == date.getFullYear() && pickerDate.getMonth() == date.getMonth() && pickerDate.getDate() == i && current, //面板显示日期与输入框日期相同返回 true
                    today: now.getFullYear() == date.getFullYear() && now.getMonth() == date.getMonth() && now.getDate() == i//面板日期为系统当天日期返回 true
                }
                dateList.push(dateObj);
            }

            // 根据week生成填充上月日期
            let prevLen = 0;
            prevLen = weekOfFirstDay ? weekOfFirstDay - 1 : 6;
            for (let i = 0; i < prevLen; i++) {
                dateList.unshift({
                    type: 1,
                    date: endDayOfLastMonth,
                    time: `${lastMonth.getFullYear()}/${this.getDoubleDigit(lastMonth.getMonth() + 1)}/${this.getDoubleDigit(endDayOfLastMonth)}`,
                });
                --endDayOfLastMonth;
            }

            // 每个面板最多显示42天  计算剩余下月显示的天数
            let totalDays = Math.ceil((prevLen + endDayOfMonth) / 7) * 7;
            let nextLen = totalDays - prevLen - endDayOfMonth;
            for (let i = 1; i <= nextLen; i++) {
                dateList.push({
                    type: 3,
                    date: i,
                    time: `${nextMonth.getFullYear()}/${this.getDoubleDigit(nextMonth.getMonth() + 1)}/${this.getDoubleDigit(i)}`,
                });
            }
            dateList.forEach((x, i) => {
                if (i % 5 == 0 || i % 6 == 0) {
                    x.weekend = true;
                }
            });
            return dateList;
        }
    }
    getDecadeList(year, pickerDate, current = true) {
        let yearList = [];
        let s = parseInt(year / 10) * 10 + 1;
        pickerDate = new Date(this.dateMath.parse(pickerDate)._d);
        for (let i = 0; i < this.timeCalendar.defaultOptions.decade; i++) {
            let y = s + i;
            yearList.push({
                year: y,
                current: y == pickerDate.getFullYear() && current
            });
        }
        return yearList;
    }
    getCenturyList(year, pickerDate, current = true) {
        let yearList = [];
        let s = parseInt(year / 100) * 100 + 1;
        pickerDate = new Date(this.dateMath.parse(pickerDate)._d);
        let times = Math.ceil(this.timeCalendar.defaultOptions.century / this.timeCalendar.defaultOptions.decade);
        for (let i = 1; i <= times; i++) {
            let e = s + this.timeCalendar.defaultOptions.decade - 1;
            yearList.push({
                year: `${s} - ${e}`,
                current: pickerDate.getFullYear() >= s && pickerDate.getFullYear() <= e && current
            });
            s = e + 1;
        }
        return yearList;
    }
    getDoubleDigit(num) {
        num = '0' + num;
        return num.slice(-2);
    }
    // -------------------- time range end -----------------------------------
    // -------------------- new UI start ----------------------------
    validTitleFun() {
        this.titleInvalid = false;
        return
        if (this.panel.commonTitle.length > 12) {
            this.titleInvalid = true;
            this.panel.commonTitle = '';
        }
    }
    validNumberFun() {
        this.speedInvalid = false;
        if (this.panel.carouselInterval * 1 <= 0 || /\D/g.test(this.panel.carouselInterval)) {
            this.speedInvalid = true;
            this.panel.carouselInterval = 5000;
        }
    }
    onColorChange() {
        return newColor => {
            this.panel.commonFontColor = newColor;
            this.onRender();
        };
    }
    setStyleCSS(index = null, borderStyle = {}, fontColorStyle = {}) {
        let defaultCSS = {
            borderStyle: {
                'border': 'solid 1px #464646',
            },
            fontColorStyle: {
                'color': '#d8d9da',
                'width': '100%'
            }
        };
        for (let i = 0; i < 4; i++) {
            this.panel['borderStyle' + i] = Object.assign({}, i === index ? borderStyle : defaultCSS.borderStyle);
            this.panel['fontColorStyle' + i] = Object.assign({}, i === index ? fontColorStyle : defaultCSS.fontColorStyle);
        }
    }
    toggleDropdownDialog(index = null) {
        let flag = index !== null ? !this.showDropDown[index] : false;
        this.showDropDown = [false, false, false, false];
        index !== null && (this.showDropDown[index] = flag);
        this.panel.showTimeList = false;
        this.panel.showTimeInterval = false;
        this.panel.showTimeCalendar = false;
        this.setStyleCSS(index,
            index !== null ? { 'border': this.showDropDown[index] ? 'solid 1px #5ac8fa' : 'solid 1px #464646' } : null,
            index !== null ? { 'color': this.showDropDown[index] ? '#5ac8fa' : '#d8d9da' } : null);
    }
    clearFilterFun(type) {
        // 初始化 drop down list current
        let index = this.panel.dropdowns.findIndex(x => { return x.title.indexOf(type) !== -1 });
        index == -1 && (index = 0);
        this.toggleDropdownDialog();
        this.updateVariable('clear', index);
    }
    setSelectedItems(currentList) {
        let items = [];
        let orgList = [];
        let objList = [];
        let paramList = [];
        let timeList = [];
        let currList = [];
        let temp = null;
        currentList.forEach(x => {
            if (/Organization\d+/i.test(x.tag)) {
                orgList.push(x);
            } else if (/Object/i.test(x.tag)) {
                objList.push(x);
            } else if (/Parameter/i.test(x.tag)) {
                paramList.push(x);
            } else if (/TimeInterval/i.test(x.tag)) {
                timeList.push(x);
            }
        });
        let levelNum = Math.floor(this.panel.levelNumber)
        if (levelNum <= orgList.length) {
            orgList.sort((a, b) => { return a.tag > b.tag ? 1 : a.tag < b.tag ? -1 : 0 });
            orgList = orgList.slice(0, levelNum);
        }
        currList = [].concat(orgList);
        for (let i = 0; i < currList.length; i++) {
            items.push(currList[i].current.text || currList[i].current);
        }
        this.panel.selectedItems = items.join(' / ');

        temp = objList.map(x => { return (x.current.text || x.current).split(' + ') });
        objList = [];
        temp.forEach(x => {
            objList = objList.concat(x);
        });
        this.panel.selectedObjItems = [... new Set(objList)].sort();

        temp = paramList.map(x => { return (x.current.text || x.current).split(' + ') });
        paramList = [];
        temp.forEach(x => {
            paramList = paramList.concat(x);
        });
        this.panel.selectedParamItems = [... new Set(paramList)].sort();
        // this.panel.fontColorStyle2['width'] = this.panel.selectedParamItems.length * 8.91 + 52.89 + 'px';

        timeList.sort((a, b) => { return a.tag > b.tag ? 1 : a.tag < b.tag ? -1 : 0 });
        this.panel.selectedTimeItems = timeList.map(x => { return x.current.text || x.current }).join(',');
        // this.panel.fontColorStyle3['width'] = this.panel.selectedTimeItems.length * 8.91 + 52.89 + 'px';
        this.render();
    }
    getLastGroup() {
        let def = 'select group';
        let items = this.panel.selectedItems.split(' / ');
        let group = '';
        let groupPath = '';
        let list = items.filter(x => { return !new RegExp(def, 'i').test(x) });
        if (list.length < 2) {
            groupPath = '';
            group = list[0] || def;
        } else {
            group = list[list.length - 1];
            let temp = list.slice(0, list.length - 1);
            let len = temp.join(' / ').length;
            if ((len + 2) * 5.4 > 190) {
                temp = [temp[0], temp[temp.length - 1]];
                len = temp.join(' / ... / ').length;
                if ((len + 2) * 5.4 > 190) {
                    temp = [temp[0].substr(0, 10) + '...', temp[temp.length - 1].substr(0, 10) + '...'];
                }
                groupPath = temp.join(' / ... / ') + ' /';
            } else {
                groupPath = temp.join(' / ') + ' /';
            }
        }
        return {
            group,
            groupPath
        };
    }
    getLastObject() {
        let def = 'select object';
        let items = this.panel.selectedObjItems[0].split('/');
        let group = '';
        let object = '';

        let list = items.filter(x => { return !new RegExp(def, 'i').test(x) });
        if (list.length < 2) {
            group = '';
            object = list[0] || def;
        } else {
            object = list[list.length - 1];
            let temp = list.slice(0, list.length - 1);
            let len = temp.join(' / ').length;
            if ((len + 2) * 5.4 > 190) {
                temp = [temp[0], temp[temp.length - 1]];
                len = temp.join(' / ... / ').length;
                if ((len + 2) * 5.4 > 190) {
                    temp = [temp[0].substr(0, 10) + '...', temp[temp.length - 1].substr(0, 10) + '...'];
                }
                group = temp.join(' / ... / ') + ' /';
            } else {
                group = temp.join(' / ') + ' /';
            }
        }
        return {
            group,
            object
        };
    }
    itemKeyDownHandler($event) {
    }
    changeDropdownFilter(dropdown, $index) {
        dropdown.filter = dropdown.display;
    }
    removeMultiItemHandler(item, dropdown, $event) {
        $event.stopPropagation();
        // this.changeMultiDropdown()
    }
    filterItemList(dropdown) {
        let f = dropdown.filter ? dropdown.filter.trim() : (dropdown.filter = '') && '';
        let res = null;
        try {
            if (!f) { res = ''; } else {
                res = f.replace(/\*.*/g, '');
            }
        } catch (e) {
            console.log(e);
        }
        return res;
    }

    filterDropdown(dropdown, condition) {
        let f = dropdown.title;
        let res = null;
        try {
            let regx = new RegExp(condition, 'i');
            if (!f) { res = ''; } else if (regx.test(f)) {
                res = f;
            }
        } catch (e) {
            console.log(e);
        }
        return res;
    }
    // -------------------- new UI end ----------------------------
}


DashboardSwitchCtrl.templateUrl = 'module.html';