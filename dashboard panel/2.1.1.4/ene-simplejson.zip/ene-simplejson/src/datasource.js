import _ from "lodash";

export class GenericDatasource {
  constructor(instanceSettings, $q, backendSrv, templateSrv) {
    this.type = instanceSettings.type;
    this.url = instanceSettings.url;
    this.name = instanceSettings.name;
    this.q = $q;
    this.backendSrv = backendSrv;
    this.templateSrv = templateSrv;
    this.withCredentials = instanceSettings.withCredentials;
    this.headers = { "Content-Type": "application/json" };
    if (
      typeof instanceSettings.basicAuth === "string" &&
      instanceSettings.basicAuth.length > 0
    ) {
      this.headers["Authorization"] = instanceSettings.basicAuth;
    }
    this.anonymousAccount = instanceSettings.jsonData.anonymousAccount;
    this.anonymousId = instanceSettings.jsonData.anonymousId;
    this.anonymousPW = instanceSettings.jsonData.anonymousPW;
    this.targets = null;
  }

  async query(options) {
    var query = this.buildQueryParameters(options);
    query.targets = query.targets.filter((t) => !t.hide);

    if (query.targets.length <= 0) {
      return this.q.when({ data: [] });
    }
    return this.doRequest({
      url: this.url + "/query",
      data: query,
      method: "POST",
    });
  }

  async testDatasource() {
    return this.doRequest({
      url: this.url + "/",
      method: "GET",
    }).then((response) => {
      if (response.status === 200) {
        return {
          status: "success",
          message: "Data source is working",
          title: "Success",
        };
      }
    });
  }

  annotationQuery(options) {
    var query = this.templateSrv.replace(options.annotation.query, {}, "glob");
    var annotationQuery = {
      range: options.range,
      annotation: {
        name: options.annotation.name,
        datasource: options.annotation.datasource,
        enable: options.annotation.enable,
        iconColor: options.annotation.iconColor,
        query: query,
      },
      rangeRaw: options.rangeRaw,
    };

    return this.doRequest({
      url: this.url + "/annotations",
      method: "POST",
      data: annotationQuery,
    }).then((result) => {
      return result.data;
    });
  }

  metricFindExecutQuery(interpolated, search) {
    interpolated = this.templateSrv.replace(interpolated, null, "regex");
    return this.doRequest({
      url: this.url + search,
      data: interpolated,
      method: "POST",
    }).then(this.mapToTextValue);
  }

  metricFindQuery(query) {
    var interpolated =
      "{" + this.templateSrv.replace(query, null, "regex") + "}";

    if (query.indexOf(`"searchDatasourceList"`) >= 0) {
      return this.metricFindExecutQuery(interpolated, "/searchDatasourceList");
    } else if (query.indexOf(`"searchDeviceParam"`) >= 0) {
      return this.metricFindExecutQuery(interpolated, "/searchDeviceParam");
    } else if (query.indexOf(`"searchDevice"`) >= 0) {
      return this.metricFindExecutQuery(interpolated, "/searchDevice");
    } else if (query.indexOf(`"searchDeviceType"`) >= 0) {
      return this.metricFindExecutQuery(interpolated, "/searchDeviceType");
    } else if (query.indexOf(`"searchGroup"`) >= 0) {
      return this.metricFindExecutQuery(interpolated, "/searchGroup");
    } else if (query.indexOf(`"searchTimeInterval"`) >= 0) {
      return this.metricFindExecutQuery(interpolated, "/searchTimeInterval");
    } else if (query.indexOf(`"searchFunctionType"`) >= 0) {
      return this.metricFindExecutQuery(interpolated, "/searchFunctionType");
    } else if (query.indexOf(`"searchDiscreteState"`) >= 0) {
      return this.metricFindExecutQuery(interpolated, "/searchDiscreteState");
    } else if (query.indexOf(`"searchDataType"`) >= 0) {
      return this.metricFindExecutQuery(interpolated, "/searchDataType");
    } else if (query.indexOf(`"searchSimulateData"`) >= 0) {
      return this.metricFindExecutQuery(interpolated, "/searchSimulateData");
    } else if (query.indexOf(`"searchSimulateType"`) >= 0) {
      return this.metricFindExecutQuery(interpolated, "/searchSimulateType");
    } else if (query.indexOf(`"searchParamProperty"`) >= 0) {
      return this.metricFindExecutQuery(interpolated, "/searchParamProperty");
    } else if (query.indexOf(`"searchPanelName"`) >= 0) {
      return this.metricFindExecutQuery(interpolated, "/searchPanelName");
    } else if (query.indexOf(`"searchInspectionStation"`) >= 0) {
      return this.metricFindExecutQuery(
        interpolated,
        "/searchInspectionStation"
      );
    } else if (query.indexOf(`"searchInspectionArea"`) >= 0) {
      return this.metricFindExecutQuery(interpolated, "/searchInspectionArea");
    }
  }

  metricFindQuery_datasource(query) {
    var interpolated = {
      datasource: this.templateSrv.replace(query, null, "regex"),
    };

    return this.doRequest({
      url: this.url + "/searchDatasourceList",
      data: interpolated,
      method: "POST",
    }).then(this.mapToTextValue);
  }

  metricFindQuery_functionList(sourceId, options) {
    var interpolated = {
      options,
      sourceId,
    };

    return this.doRequest({
      url: this.url + "/searchFunctionList",
      data: interpolated,
      method: "POST",
    }).then((x) => {
      return x.data;
    });
  }

  //选择区域
  metricFindQuery_area(query, parent, isKPIDatasource) {
    var interpolated = {
      target: this.templateSrv.replace(query, null, "regex"),
      type: isKPIDatasource, // 区分是否使用id 或是 namelangid
    };
    if (parent) {
      interpolated["parentGroup"] = this.templateSrv.replace(
        parent,
        null,
        "regex"
      );
    }
    return this.doRequest({
      url: this.url + "/searchGroup",
      data: interpolated,
      method: "POST",
    }).then(this.mapToTextValue);
  }

  //选择设备类型
  metricFindQuery_devicetype(selArea, isKPIDatasource) {
    //不一定非要选择了站点之后再选设备类型
    var interpolated = {
      area: this.templateSrv.replace(selArea, null, "regex"),
      //station: this.templateSrv.replace(selStation, null, 'regex')
      type: isKPIDatasource, // 区分是否使用id 或是 namelangid
    };
    return this.doRequest({
      url: this.url + "/searchDeviceType",
      data: interpolated,
      method: "POST",
    }).then(this.mapToTextValue);
  }

  //选择设备
  metricFindQuery_device(selArea, selDeviceType, isKPIDatasource) {
    var interpolated = {
      area: this.templateSrv.replace(selArea, null, "regex"),
      type: isKPIDatasource, // 区分是否使用id 或是 namelangid
      //station: this.templateSrv.replace(selStation, null, 'regex'),
      devicetype: this.templateSrv.replace(selDeviceType, null, "regex"),
    };

    return this.doRequest({
      url: this.url + "/searchDevice",
      data: interpolated,
      method: "POST",
    }).then(this.mapToTextValue);
  }

  //选择设备参数
  metricFindQuery_deviceparam(
    selArea,
    selDeviceType,
    selDevice,
    isKPIDatasource
  ) {
    var interpolated = {
      area: this.templateSrv.replace(selArea, null, "regex"),
      //station: this.templateSrv.replace(selStation, null, 'regex'),
      devicetype: this.templateSrv.replace(selDeviceType, null, "regex"),
      device: this.templateSrv.replace(selDevice, null, "regex"),
      type: isKPIDatasource,
    };

    return this.doRequest({
      url: this.url + "/searchDeviceParam",
      data: interpolated,
      method: "POST",
    }).then(this.mapToTextValue);
  }

  //选择时间间隔
  metricFindQuery_timeinterval(query) {
    var interpolated = {
      timeinterval: this.templateSrv.replace(query, null, "regex"),
    };

    return this.doRequest({
      url: this.url + "/searchTimeInterval",
      data: interpolated,
      method: "POST",
    }).then(this.mapToTextValue);
  }

  //选择数据类型
  metricFindQuery_datatype(query) {
    var interpolated = {
      datatype: this.templateSrv.replace(query, null, "regex"),
    };

    return this.doRequest({
      url: this.url + "/searchDataType",
      data: interpolated,
      method: "POST",
    }).then(this.mapToTextValue);
  }

  // 检查parameter是否支持 模拟数据
  metricFindQuery_simulatedata(selArea, selDeviceType, selDevice, selParam) {
    let interpolated = {
      area: this.templateSrv.replace(selArea, null, "regex"),
      devicetype: this.templateSrv.replace(selDeviceType, null, "regex"),
      device: this.templateSrv.replace(selDevice, null, "regex"),
      deviceparam: this.templateSrv.replace(selParam, null, "regex"),
    };

    return this.doRequest({
      url: this.url + "/searchSimulateData",
      data: interpolated,
      method: "POST",
    });
  }

  // 获取parameter支持的property
  metricFindQuery_property(selArea, selDeviceType, selDevice, selParam) {
    let interpolated = {
      area: this.templateSrv.replace(selArea, null, "regex"),
      devicetype: this.templateSrv.replace(selDeviceType, null, "regex"),
      device: this.templateSrv.replace(selDevice, null, "regex"),
      deviceparam: this.templateSrv.replace(selParam, null, "regex"),
    };

    return this.doRequest({
      url: this.url + "/searchParamProperty",
      data: interpolated,
      method: "POST",
    }).then(this.mapToTextValue);
  }

  // 获取模拟数据处理方式
  metricFindQuery_simulatetype(query) {
    var interpolated = {
      simulatetype: this.templateSrv.replace(query, null, "regex"),
    };

    return this.doRequest({
      url: this.url + "/searchSimulateType",
      data: interpolated,
      method: "POST",
    }).then(this.mapToTextValue);
  }

  //选择Function接口类型
  metricFindQuery_functiontype(query) {
    let interpolated = {
      functiontype: this.templateSrv.replace(query, null, "regex"),
    };

    return this.doRequest({
      url: this.url + "/searchFunctionType",
      data: interpolated,
      method: "POST",
    }).then(this.mapToTextValue);
  }

  //检测panel是否支持functiontype功能
  metricFindQuery_panelname(query) {
    let interpolated = {
      panelname: this.templateSrv.replace(query, null, "regex"),
    };

    return this.doRequest({
      url: this.url + "/searchPanelName",
      data: interpolated,
      method: "POST",
    });
  }

  metricFindQuery_statetype(selArea, selDeviceType, selDevice, selParam) {
    let interpolated = {
      area: this.templateSrv.replace(selArea, null, "regex"),
      devicetype: this.templateSrv.replace(selDeviceType, null, "regex"),
      device: this.templateSrv.replace(selDevice, null, "regex"),
      deviceparam: this.templateSrv.replace(selParam, null, "regex"),
    };
    return this.doRequest({
      url: this.url + "/searchDiscreteState",
      data: interpolated,
      method: "POST",
    }).then(this.mapToTextValue);
  }

  //发送mqtt，修改tagvalue
  metricFindQuery_setvalue(targets, tagvalues) {
    console.log(targets);
    let query = {
      targets,
      tagvalues,
    };

    return this.doRequest({
      url: this.url + "/searchSetValue",
      data: query,
      method: "POST",
      withCredentials: true,
    });
  }

  metricUpdate_setValue(interpolatedArray) {
    let query = {
      interpolatedArray,
    };

    return this.doRequest({
      url: this.url + "/searchSetValueScada",
      data: query,
      method: "POST",
      withCredentials: true,
    });
  }

  metricUpdate_setValueKPI(sourceId, targets, tagvalues) {
    let options = [];
    for (let i = 0; i < targets.length; i++) {
      if (targets[i].configs) {
        let models = [];
        let model = targets[i].configs.map((x) => {
          return x.model;
        });
        models = models.concat(...model);
        options.push({
          value: tagvalues[i],
          options: models,
        });
      }
    }
    let query = {
      sourceId,
      options,
    };

    return this.doRequest({
      url: this.url + "/searchSetValueKPI",
      data: query,
      method: "POST",
      withCredentials: true,
    });
  }

  //search almrecord info  by almid -- hao.ning at 2019.12.12
  metricFindQuery_almrecord(almid) {
    let query = {
      almid,
    };

    return this.doRequest({
      url: this.url + "/searchAlmRecord",
      data: query,
      method: "POST",
      withCredentials: true,
    });
  }

  //update almrecord info -- hao.ning at 2019.12.12
  metricUpdate_almrecord(data) {
    let query = {
      data,
    };

    return this.doRequest({
      url: this.url + "/updateAlmRecord",
      data: query,
      method: "POST",
      withCredentials: true,
    });
  }

  //search SOE Rule List  by almid -- hao.ning at 2022.02.25
  metricFindQuery_soerulelist(options) {
    let query = {
      almid: options.almid,
      lang: options.lang,
    };

    return this.doRequest({
      url: this.url + "/searchSOEList",
      data: query,
      method: "POST",
      withCredentials: true,
    });
  }

  //search SOE history data  by soeid -- hao.ning at 2022.02.25
  metricFindQuery_soehisdata(options) {
    let query = {
      soeid: options.soeid,
      params: options.params,
      lang: options.lang,
    };

    return this.doRequest({
      url: this.url + "/searchSOEHisData",
      data: query,
      method: "POST",
      withCredentials: true,
    });
  }

  //search event detail data  by eventid -- hao.ning at 2022.03.23
  metricFindQuery_eventdetail(options) {
    let query = {
      eventid: options.eventid,
      functiontype: options.functiontype,
      type: options.type,
      lang: options.lang,
    };

    return this.doRequest({
      url: this.url + "/searchEventLogById",
      data: query,
      method: "POST",
      withCredentials: true,
    });
  }

  //search inspection area info by groupid -- hao.ing at 2022.11.02
  metricFindQuery_inspectionarea(selArea, isKPIDatasource) {
    var interpolated = {
      area: this.templateSrv.replace(selArea, null, "regex"),
      type: isKPIDatasource, // 区分是否使用id 或是 namelangid
    };

    return this.doRequest({
      url: this.url + "/searchInspectionArea",
      data: interpolated,
      method: "POST",
    }).then(this.mapToTextValue);
  }

  //search inspection station info by groupid and fieldid -- hao.ing at 2022.11.02
  metricFindQuery_inspectionstation(selArea, fieldId, isKPIDatasource) {
    var interpolated = {
      area: this.templateSrv.replace(selArea, null, "regex"),
      type: isKPIDatasource, // 区分是否使用id 或是 namelangid
      fieldId,
    };

    return this.doRequest({
      url: this.url + "/searchInspectionStation",
      data: interpolated,
      method: "POST",
    }).then(this.mapToTextValue);
  }

  mapToTextValue(result) {
    return _.map(result.data, (d, i) => {
      if (d && d.text != undefined && d.value != undefined) {
        return { text: d.text, value: d.value, id: d.id };
      } else if (_.isObject(d)) {
        return { text: d, value: i, id: i };
      }
      return { text: d, value: d, id: d };
    });
  }

  async doRequest(options) {
    options.withCredentials = this.withCredentials;
    ///////////支持匿名用户登录
    if (this.withCredentials) {
      this.anonymousAccount = false;
    }
    if (this.anonymousAccount) {
      var datasourceid = this.id;
      var storage = window.localStorage;
      var date = new Date();
      var tokenTimeOut = true; //默认过期
      var dateTimeOut = storage.getItem("ExpiresIn" + datasourceid);
      var tokenKey = storage.getItem("authHeader" + datasourceid);
      if (dateTimeOut) {
        Number(dateTimeOut) > Number(date)
          ? (tokenTimeOut = false)
          : (tokenTimeOut = true);
      }
      if (tokenKey && !tokenTimeOut) {
        this.headers["Authorization"] = tokenKey;
      } else {
        let result = await this.backendSrv
          .post("/api/checkLogin", { DS: this.type, DSName: this.name })
          .catch((err) => {
            return this.q.when({ data: [] });
          });
        if (result.tokenType && result.accessToken && result.name) {
          tokenKey = result.tokenType + " " + result.accessToken;
          this.headers["Authorization"] = tokenKey;
          storage.setItem("ExpiresIn" + datasourceid, result.expiresIn);
          storage.setItem("authHeader" + datasourceid, tokenKey);
        } else {
          return this.q.when({ data: [] });
        }
      }
    }
    options.headers = this.headers;
    if (options.url.indexOf("searchGroup") !== -1) {
      try {
        let data = null;
        if (typeof options.data == "string") {
          data = JSON.parse(options.data);
        } else {
          data = options.data;
        }
        if (!data.parentGroup) {
          let orgId = await this.getCurrentOrgId();
          if (orgId) {
            options.headers["X-Source-Org-Id"] = this.base64url_graphql(
              "Dashboard",
              orgId
            );
          }
        }
      } catch (error) {
        console.log(error);
      }
    }
    return this.backendSrv.datasourceRequest(options);
  }

  buildQueryParameters(options) {
    var targets = _.map(options.targets, (target) => {
      var areaName = this.templateSrv.replace(
        "" + target.area,
        options.scopedVars,
        "regex"
      );
      //var stationName = this.templateSrv.replace(target.station, options.scopedVars, 'regex');
      var devicetypeName = this.templateSrv.replace(
        "" + target.devicetype,
        options.scopedVars,
        "regex"
      );
      var deviceName = this.templateSrv.replace(
        "" + target.device,
        options.scopedVars,
        "regex"
      );
      var deviceparamName = this.templateSrv.replace(
        target.deviceparam,
        options.scopedVars,
        ""
      );
      var timeintervalName = this.templateSrv.replace(
        target.timeinterval,
        options.scopedVars,
        "regex"
      );
      var datatypeName = this.templateSrv.replace(
        target.dataType,
        options.scopedVars,
        "regex"
      );
      //var targetName = areaName + '#' + stationName + '#' + devicetypeName + '#' + deviceName + '#' + deviceparamName;
      var targetName =
        areaName +
        "#" +
        devicetypeName +
        "#" +
        deviceName +
        "#" +
        deviceparamName;
      var functionType = this.templateSrv.replace(
        target.functiontype,
        options.scopedVars,
        "regex"
      );
      var statetype = this.templateSrv.replace(
        "" + target.statetype,
        options.scopedVars,
        "regex"
      );
      var simulatetype = this.templateSrv.replace(
        "" + target.simulatetype,
        options.scopedVars,
        "regex"
      );
      var displayname = this.templateSrv.replace(
        "" + target.displayname,
        options.scopedVars,
        "regex"
      );
      var property = this.templateSrv.replace(
        target.property,
        options.scopedVars,
        ""
      );
      var paneltype = this.templateSrv.replace(
        target.paneltype,
        options.scopedVars,
        ""
      );

      var size = target.size;
      var mapCardJson = target.mapCardJson;
      var simulate = target.simulate || false;
      var markexception = target.markException || false;
      var markalarm = target.markAlarm || false;
      var marktimerange = target.markTimeRange || false;
      var marksubgroup = target.markSubGroup || false;
      var expression =
        functionType == "transformation" ? target.expression : "";
      var configs = target.configs;
      var source = target.source;
      var intervaltype = target.intervaltype;
      var fieldId = target.fieldId;
      var stationId = target.stationId;
      var markratetimes = target.markRateTimes || false;
      return {
        target: targetName,
        refId: target.refId,
        hide: target.hide,
        type: target.type || "timeseries",
        area: areaName,
        //station: stationName,
        devicetype: devicetypeName,
        device: deviceName,
        deviceparam: deviceparamName,
        timeinterval: timeintervalName,
        datatype: datatypeName,
        functiontype: functionType,
        state: statetype,
        displayname: displayname,
        mapCardJson,
        property,
        paneltype,
        size,
        simulate,
        markexception,
        markalarm,
        marktimerange,
        marksubgroup,
        expression,
        intervaltype,
        simulatetype,
        configs,
        source,
        fieldId,
        stationId,
        markratetimes,
      };
    });

    options.targets = targets;

    return options;
  }

  async getCurrentOrgId() {
    let result = await this.backendSrv.get("/api/org").catch((err) => {
      return this.q.when({ data: [] });
    });
    return result.id || null;
  }

  base64url_graphql(type, input) {
    return (window.btoa(type) + "." + window.btoa("" + input)).replace(
      /=/g,
      ""
    );
  }
}
