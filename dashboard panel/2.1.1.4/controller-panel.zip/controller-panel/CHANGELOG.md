# Changelog
This changelog is for the controller-panel.
All notable changes to this project will be documented in this file.

## [1.0.0] - Sep 06, 2021
### New Feature
- First version
- Panel Logo
- Button Size
- Horizontal & Vertical styles
- Light color (On/Off)
- Dynamic table maker
- Data mapping
- Header show/hide
- Font Size & Color
- Button switch animation smooth
