import { ControllerCtrl } from './controller_ctrl';
import { loadPluginCss } from 'app/plugins/sdk';

loadPluginCss({
  dark: 'plugins/controller-panel/styles/dark.css',
  light: 'plugins/controller-panel/styles/light.css',
});

export { ControllerCtrl as PanelCtrl };