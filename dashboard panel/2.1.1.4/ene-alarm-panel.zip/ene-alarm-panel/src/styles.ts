const styles: any[] = [
    {
        "unit": "short",
        "type": "hidden",
        "alias": "",
        "decimals": 2,
        "colors": [
            "rgba(245, 54, 54, 0.9)",
            "rgba(237, 129, 40, 0.89)",
            "rgba(50, 172, 45, 0.97)",
            "rgba(45, 91, 172, 0.9)",
            "rgba(247, 243, 27, 0.9)",
            "rgba(184, 27, 247, 0.9)"
        ],
        "colorMode": null,
        "pattern": "almid",
        "dateFormat": "YYYY-MM-DD HH:mm:ss",
        "thresholds": [],
        "mappingType": 1,
        "align": "left",
        "thresholdsDisplay": [],
        "arraycolors": [
            "rgb(23, 180, 16)",
            "rgb(255, 197, 0)",
            "rgb(210, 30, 0)"
        ],
        "bar": false,
        "url": false,
        "icon": false,
        "handler": "Ack",
        "icontype": "tracking",
        "hrefTarget": "_blank",
        "operNum": 1,
        "operationList": [
            {
                "type": "edit",
                "handler": "Detail"
            }
        ]
    },
    {
        "unit": "short",
        "type": "number",
        "alias": "",
        "decimals": 0,
        "colors": [
            "rgba(245, 54, 54, 0.9)",
            "rgba(237, 129, 40, 0.89)",
            "rgba(50, 172, 45, 0.97)",
            "rgba(45, 91, 172, 0.9)",
            "rgba(247, 243, 27, 0.9)",
            "rgba(184, 27, 247, 0.9)"
        ],
        "colorMode": null,
        "pattern": "level",
        "dateFormat": "YYYY-MM-DD HH:mm:ss",
        "thresholds": [],
        "mappingType": 1,
        "align": "center",
        "thresholdsDisplay": [],
        "arraycolors": [
            "rgb(23, 180, 16)",
            "rgb(255, 197, 0)",
            "rgb(210, 30, 0)"
        ],
        "bar": false,
        "url": false,
        "icon": false,
        "handler": "Ack",
        "icontype": "tracking",
        "hrefTarget": "_blank",
        "operNum": 1,
        "operationList": [
            {
                "type": "edit",
                "handler": "Detail"
            }
        ],
        "bold": true
    },
    {
        "unit": "short",
        "type": "date",
        "alias": "",
        "decimals": 2,
        "colors": [
            "rgba(245, 54, 54, 0.9)",
            "rgba(237, 129, 40, 0.89)",
            "rgba(50, 172, 45, 0.97)",
            "rgba(45, 91, 172, 0.9)",
            "rgba(247, 243, 27, 0.9)",
            "rgba(184, 27, 247, 0.9)"
        ],
        "colorMode": null,
        "pattern": "almbegintime",
        "dateFormat": "YYYY-MM-DD HH:mm:ss",
        "thresholds": [],
        "mappingType": 1,
        "align": "left",
        "thresholdsDisplay": [],
        "arraycolors": [
            "rgb(23, 180, 16)",
            "rgb(255, 197, 0)",
            "rgb(210, 30, 0)"
        ],
        "bar": false,
        "url": false,
        "icon": false,
        "handler": "Ack",
        "icontype": "tracking",
        "hrefTarget": "_blank",
        "operNum": 1,
        "operationList": [
            {
                "type": "edit",
                "handler": "Detail"
            }
        ]
    },
    {
        "unit": "short",
        "type": "string",
        "alias": " ",
        "decimals": 2,
        "colors": [
            "#0cc90c",
            "#ff231e",
            "#6666cc",
            "#b2e300",
            "#fdfd37",
            "#ffb700",
            "#ff231e"
        ],
        "colorMode": null,
        "pattern": "additionmsgurl",
        "dateFormat": "YYYY-MM-DD HH:mm:ss",
        "thresholds": [],
        "mappingType": 1,
        "align": "center",
        "thresholdsDisplay": [],
        "arraycolors": [
            "rgb(23, 180, 16)",
            "rgb(255, 197, 0)",
            "rgb(210, 30, 0)"
        ],
        "bar": false,
        "url": true,
        "icon": true,
        "handler": "Ack",
        "icontype": "suggestion",
        "hrefTarget": "_blank",
        "operNum": 1,
        "operationList": [
            {
                "type": "edit",
                "handler": "Detail"
            }
        ],
        "link": false
    },
    {
        "unit": "short",
        "type": "button",
        "alias": "",
        "decimals": 2,
        "colors": [
            "#0cc90c",
            "#0cc90c",
            "#ff231e",
            "#ffb700",
            "#fdfd37",
            "#6666cc",
            "#b2e300"
        ],
        "fontColors": [
            "#000",
            "#000",
            "#000",
            "#000",
            "#000",
            "#000",
            "#000"
        ],
        "colorMode": "status",
        "pattern": "almstat",
        "dateFormat": "YYYY-MM-DD HH:mm:ss",
        "thresholds": [
            0,
            1,
            5,
            10,
            15,
            20,
            25
        ],
        "mappingType": 1,
        "align": "left",
        "thresholdsDisplay": [
            "Closed",
            "Closed",
            "Open",
            "Ack'ed",
            "In Process",
            "Locked",
            "Processed"
        ],
        "arraycolors": [
            "rgb(23, 180, 16)",
            "rgb(255, 197, 0)",
            "rgb(210, 30, 0)"
        ],
        "bar": false,
        "url": false,
        "icon": false,
        "handler": "Ack",
        "icontype": "tracking",
        "hrefTarget": "_blank",
        "operNum": 1,
        "operationList": [
            {
                "type": "edit",
                "handler": "Ack"
            }
        ],
        "next": [
            {
                "text": "Closed",
                "value": 0,
                "color": "#0cc90c",
                "nextProccess": []
            },
            {
                "text": "Closed",
                "value": 1,
                "color": "#0cc90c",
                "nextProccess": []
            },
            {
                "text": "Open",
                "value": 5,
                "color": "#ff231e",
                "nextProccess": [
                    10,
                    15,
                    25
                ]
            },
            {
                "text": "Ack'ed",
                "value": 10,
                "color": "#ffb700",
                "nextProccess": [
                    15,
                    20
                ]
            },
            {
                "text": "In Process",
                "value": 15,
                "color": "#fdfd37",
                "nextProccess": [
                    20,
                    25
                ]
            },
            {
                "text": "Locked",
                "value": 20,
                "color": "#6666cc",
                "nextProccess": [
                    15
                ]
            },
            {
                "text": "Processed",
                "value": 25,
                "color": "#b2e300",
                "nextProccess": [
                    15,
                    20
                ]
            }
        ]
    },
    {
        "unit": "short",
        "type": "operation",
        "alias": "",
        "decimals": 2,
        "colors": [
            "rgba(245, 54, 54, 0.9)",
            "rgba(237, 129, 40, 0.89)",
            "rgba(50, 172, 45, 0.97)",
            "rgba(45, 91, 172, 0.9)",
            "rgba(247, 243, 27, 0.9)",
            "rgba(184, 27, 247, 0.9)"
        ],
        "colorMode": null,
        "pattern": "action",
        "dateFormat": "YYYY-MM-DD HH:mm:ss",
        "thresholds": [],
        "mappingType": 1,
        "align": "center",
        "thresholdsDisplay": [],
        "arraycolors": [
            "rgb(23, 180, 16)",
            "rgb(255, 197, 0)",
            "rgb(210, 30, 0)"
        ],
        "bar": false,
        "url": false,
        "icon": false,
        "handler": "Ack",
        "icontype": "tracking",
        "hrefTarget": "_blank",
        "operNum": 3,
        "operationList": [
            {
                "type": "edit",
                "handler": "Ack"
            },
            {
                "type": "tracking",
                "handler": "Detail"
            },
            {
                "type": "soe",
                "handler": "SOE"
            }
        ],
        "colwidth": "3%"
    },
    {
        "unit": "short",
        "type": "date",
        "alias": "",
        "decimals": 2,
        "colors": [
            "rgba(245, 54, 54, 0.9)",
            "rgba(237, 129, 40, 0.89)",
            "rgba(50, 172, 45, 0.97)",
            "rgba(45, 91, 172, 0.9)",
            "rgba(247, 243, 27, 0.9)",
            "rgba(184, 27, 247, 0.9)"
        ],
        "colorMode": null,
        "pattern": "almcompletetime",
        "dateFormat": "YYYY-MM-DD HH:mm:ss",
        "thresholds": [],
        "mappingType": 1,
        "align": "left",
        "thresholdsDisplay": [],
        "arraycolors": [
            "rgb(23, 180, 16)",
            "rgb(255, 197, 0)",
            "rgb(210, 30, 0)"
        ],
        "bar": false,
        "url": false,
        "icon": false,
        "handler": "Ack",
        "icontype": "tracking",
        "hrefTarget": "_blank",
        "operNum": 1,
        "operationList": [
            {
                "type": "edit",
                "handler": "Detail"
            }
        ]
    },
    {
        "unit": "short",
        "type": "hidden",
        "alias": "",
        "decimals": 2,
        "colors": [
            "rgba(245, 54, 54, 0.9)",
            "rgba(237, 129, 40, 0.89)",
            "rgba(50, 172, 45, 0.97)",
            "rgba(45, 91, 172, 0.9)",
            "rgba(247, 243, 27, 0.9)",
            "rgba(184, 27, 247, 0.9)"
        ],
        "colorMode": null,
        "pattern": "soe",
        "dateFormat": "YYYY-MM-DD HH:mm:ss",
        "thresholds": [],
        "mappingType": 1,
        "align": "left",
        "thresholdsDisplay": [],
        "arraycolors": [
            "rgb(23, 180, 16)",
            "rgb(255, 197, 0)",
            "rgb(210, 30, 0)"
        ],
        "bar": false,
        "url": false,
        "icon": false,
        "handler": "Ack",
        "icontype": "tracking",
        "hrefTarget": "_blank",
        "operNum": 1,
        "operationList": [
            {
                "type": "edit",
                "handler": "Detail"
            }
        ]
    },
    {
        "unit": "short",
        "type": "number",
        "alias": "",
        "decimals": null,
        "colors": [
            "rgba(245, 54, 54, 0.9)",
            "rgba(237, 129, 40, 0.89)",
            "rgba(50, 172, 45, 0.97)",
            "rgba(45, 91, 172, 0.9)",
            "rgba(247, 243, 27, 0.9)",
            "rgba(184, 27, 247, 0.9)"
        ],
        "colorMode": null,
        "pattern": "almoccurrence",
        "dateFormat": "YYYY-MM-DD HH:mm:ss",
        "thresholds": [],
        "mappingType": 1,
        "align": "left",
        "thresholdsDisplay": [],
        "arraycolors": [
            "rgb(23, 180, 16)",
            "rgb(255, 197, 0)",
            "rgb(210, 30, 0)"
        ],
        "bar": false,
        "url": false,
        "icon": false,
        "handler": "Ack",
        "icontype": "tracking",
        "hrefTarget": "_blank",
        "operNum": 1,
        "operationList": [
            {
                "type": "edit",
                "handler": "Detail"
            }
        ]
    },
];

export default styles;