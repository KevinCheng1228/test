# Circuit Status Panel v1.0.4

## Introduction
This panel is a simple application for showing a machine picture with its information.
 Two queries are for the Circuit Status, and if the value of query is zero, the color of  circuit will be red.
 There are three columns to upload the pictures with URL, and modify the position of pictures.
 
## Data Source of Machine Temperature Panel:
  - Simple SQL data source

## Query Data format:
  - table

## Query time type:
  - utc

## Query example:
Query example:

Queries  for the Circuit Status:
```
select the datasource from two of queries
input the URL of pictures to upload them and click the button called "show" 
```
The setting divided into two parts (left & right), which have four values.
If set value mapping & color mapping the value will be rendering.

### Authors
1. Advantech
2. Tsung-Yu, Chen
3. Chih-Chun, Yeh
4. Wei-Hsuan, Wong

Copyright 2020 © Alisa, ITsung, Tom, Linda, Wesley / Advantech.