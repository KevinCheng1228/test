const styles: any[] = [
    {
        "alias": "Time",
        "align": "left",
        "colorMode": null,
        "colors": [
            "#FF231E",
            "#ffb700",
            "#fdfd37",
            "#b2e300",
            "#0CC90C",
            "#1AE986",
            "#5AC8FA",
            "#007AFF",
            "#6666CC",
            "#D700F9",
            "#FF80AB"
        ],
        "dateFormat": "YYYY-MM-DD HH:mm:ss",
        "handler": "Detail",
        "hrefTarget": "_self",
        "icontype": "tracking",
        "pattern": "Time",
        "type": "date",
        "unit": "none"
    },
    {
        "alias": "",
        "align": "left",
        "arraycolors": [
            "#FF231E",
            "#ffb700",
            "#fdfd37",
            "#b2e300",
            "#0CC90C",
            "#1AE986",
            "#5AC8FA",
            "#007AFF",
            "#6666CC",
            "#D700F9",
            "#FF80AB"
        ],
        "bar": false,
        "colorMode": null,
        "colors": [
            "#FF231E",
            "#ffb700",
            "#fdfd37",
            "#b2e300",
            "#0CC90C",
            "#1AE986",
            "#5AC8FA",
            "#007AFF",
            "#6666CC",
            "#D700F9",
            "#FF80AB"
        ],
        "dateFormat": "YYYY-MM-DD HH:mm:ss",
        "decimals": 2,
        "handler": "Detail",
        "hrefTarget": "_self",
        "icon": false,
        "icontype": "tracking",
        "mappingType": 1,
        "operNum": 1,
        "operationList": [
            {
                "handler": "Detail",
                "type": "Detail"
            }
        ],
        "pattern": "logid",
        "statusStyle": [],
        "thresholds": [],
        "thresholdsDisplay": [],
        "type": "hidden",
        "unit": "short",
        "url": false
    },
    {
        "alias": "",
        "align": "left",
        "arraycolors": [
            "#FF231E",
            "#ffb700",
            "#fdfd37",
            "#b2e300",
            "#0CC90C",
            "#1AE986",
            "#5AC8FA",
            "#007AFF",
            "#6666CC",
            "#D700F9",
            "#FF80AB"
        ],
        "bar": false,
        "colorMode": null,
        "colors": [
            "#FF231E",
            "#ffb700",
            "#fdfd37",
            "#b2e300",
            "#0CC90C",
            "#1AE986",
            "#5AC8FA",
            "#007AFF",
            "#6666CC",
            "#D700F9",
            "#FF80AB"
        ],
        "dateFormat": "YYYY-MM-DD HH:mm:ss",
        "decimals": 2,
        "handler": "Detail",
        "hrefTarget": "_self",
        "icon": false,
        "icontype": "tracking",
        "mappingType": 1,
        "operNum": 1,
        "operationList": [
            {
                "handler": "Detail",
                "type": "Detail"
            }
        ],
        "pattern": "type",
        "statusStyle": [
            {
                "name": "Set-Value",
                "bgColor": "#007AFF",
                "color": "#000",
                "bold": "bold",
                "show": false
            },
            {
                "bgColor": "#0CC90C",
                "bold": "bold",
                "color": "#000",
                "name": "GET",
                "show": false
            },
            {
                "bgColor": "#5AC8FA",
                "bold": "bold",
                "color": "#000",
                "name": "UPDATE",
                "show": false
            },
            {
                "bgColor": "#fdfd37",
                "bold": "bold",
                "color": "#000",
                "name": "ADD",
                "show": false
            },
            {
                "bgColor": "#D700F9",
                "bold": "bold",
                "color": "#000",
                "name": "DELETE",
                "show": false
            },
            {
                "bgColor": "#b2e300",
                "bold": "bold",
                "color": "#000",
                "name": "Login",
                "show": false
            },
            {
                "bgColor": "#5AC8FA",
                "bold": "bold",
                "color": "#000",
                "name": "Logout",
                "show": false
            },
            {
                "bgColor": "#0CC90C",
                "bold": "bold",
                "color": "#000",
                "name": "Online",
                "show": false
            },
            {
                "bgColor": "#FF231E",
                "bold": "bold",
                "color": "#000",
                "name": "Offline",
                "show": false
            }
        ],
        "thresholds": [],
        "thresholdsDisplay": [],
        "type": "status",
        "unit": "short",
        "url": false
    },
    {
        "alias": "",
        "align": "left",
        "arraycolors": [
            "#FF231E",
            "#ffb700",
            "#fdfd37",
            "#b2e300",
            "#0CC90C",
            "#1AE986",
            "#5AC8FA",
            "#007AFF",
            "#6666CC",
            "#D700F9",
            "#FF80AB"
        ],
        "bar": false,
        "colorMode": null,
        "colors": [
            "#FF231E",
            "#ffb700",
            "#fdfd37",
            "#b2e300",
            "#0CC90C",
            "#1AE986",
            "#5AC8FA",
            "#007AFF",
            "#6666CC",
            "#D700F9",
            "#FF80AB"
        ],
        "dateFormat": "YYYY-MM-DD HH:mm:ss",
        "decimals": 2,
        "handler": "Detail",
        "hrefTarget": "_self",
        "icon": false,
        "icontype": "tracking",
        "mappingType": 1,
        "operNum": 1,
        "operationList": [
            {
                "handler": "Detail",
                "type": "Detail"
            }
        ],
        "pattern": "datatime",
        "statusStyle": [],
        "thresholds": [],
        "thresholdsDisplay": [],
        "type": "date",
        "unit": "short",
        "url": false
    },
    {
        "alias": "",
        "align": "left",
        "arraycolors": [
            "#FF231E",
            "#ffb700",
            "#fdfd37",
            "#b2e300",
            "#0CC90C",
            "#1AE986",
            "#5AC8FA",
            "#007AFF",
            "#6666CC",
            "#D700F9",
            "#FF80AB"
        ],
        "bar": false,
        "colorMode": null,
        "colors": [
            "#FF231E",
            "#ffb700",
            "#fdfd37",
            "#b2e300",
            "#0CC90C",
            "#1AE986",
            "#5AC8FA",
            "#007AFF",
            "#6666CC",
            "#D700F9",
            "#FF80AB"
        ],
        "dateFormat": "YYYY-MM-DD HH:mm:ss",
        "decimals": 2,
        "handler": "Detail",
        "hrefTarget": "_self",
        "icon": false,
        "icontype": "tracking",
        "mappingType": 1,
        "operNum": 1,
        "operationList": [
            {
                "handler": "Detail",
                "type": "tracking"
            }
        ],
        "pattern": "detail",
        "statusStyle": [],
        "thresholds": [],
        "thresholdsDisplay": [],
        "type": "operation",
        "unit": "short",
        "url": false
    },
    {
        "alias": "",
        "align": "left",
        "arraycolors": [],
        "bar": false,
        "colorMode": null,
        "colors": [
            "#FF231E",
            "#ffb700",
            "#fdfd37",
            "#b2e300",
            "#0CC90C",
            "#1AE986",
            "#5AC8FA",
            "#007AFF",
            "#6666CC",
            "#D700F9",
            "#FF80AB"
        ],
        "decimals": 2,
        "handler": "Detail",
        "hrefTarget": "_self",
        "icon": false,
        "icontype": "tracking",
        "pattern": "devid",
        "thresholds": [],
        "thresholdsDisplay": [],
        "type": "hidden",
        "unit": "short",
        "url": false
    },
    {
        "alias": "Time",
        "align": "left",
        "colorMode": null,
        "colors": [
            "#FF231E",
            "#ffb700",
            "#fdfd37",
            "#b2e300",
            "#0CC90C",
            "#1AE986",
            "#5AC8FA",
            "#007AFF",
            "#6666CC",
            "#D700F9",
            "#FF80AB"
        ],
        "dateFormat": "YYYY-MM-DD HH:mm:ss",
        "handler": "Detail",
        "hrefTarget": "_self",
        "icontype": "tracking",
        "pattern": "Time",
        "type": "date",
        "unit": "none"
    },
    {
        "alias": "",
        "align": "left",
        "arraycolors": [],
        "bar": false,
        "colorMode": null,
        "colors": [
            "#FF231E",
            "#ffb700",
            "#fdfd37",
            "#b2e300",
            "#0CC90C",
            "#1AE986",
            "#5AC8FA",
            "#007AFF",
            "#6666CC",
            "#D700F9",
            "#FF80AB"
        ],
        "decimals": 2,
        "handler": "Detail",
        "hrefTarget": "_self",
        "icon": false,
        "icontype": "tracking",
        "pattern": "/.*/",
        "thresholds": [],
        "thresholdsDisplay": [],
        "type": "number",
        "unit": "short",
        "url": false
    }
];

export default styles;