import { MetricsPanelCtrl } from 'app/plugins/sdk';
import _ from 'lodash';
import kbn from 'app/core/utils/kbn';
import TimeSeries from 'app/core/time_series';
import rendering from './rendering';
import legend from './legend';
// import ChangeFont from './fontsize'
import ChangeFont from 'app/core/utils/fontsize';

export class MachineInfo extends MetricsPanelCtrl {

  constructor($scope, $injector, $rootScope) {
    super($scope, $injector);
    this.$rootScope = $rootScope;
    this.hiddenSeries = {};
    this.dictFontCalc = {};
    this.resultData = [];
    this.ifDataEmpty = true;
    this.targetDiscreteDict = {}
    this.leftDescriptor = []
    this.rightDescriptor = []

    var panelDefaults = {
      lang: 'en',//Default
      bgimage1: '',//left
      bgimageURL1: '',
      bgimage2: '',//center
      bgimageURL2: '',
      bgimage3: '',//right
      bgimageURL3: '',
      showURL: false,
      adjustableSize: true,
      adjustImage1: false,
      adjustImage2: false,
      adjustImage3: false,
      machineName: '',
      machineNameTitile: '',
      machineID: '',
      machineIDTitle: '',
      machineInfomation: '',
      machineInfomationTitle: '',
      contentWeight: 'normal',
      leftDivColor: 'rgb(47, 182, 230)',

      dataArr: [],
      unitarr: [
          { uni: 'desc' },
          { uni: 'spanhi' },
          { uni: 'spanlo' },
          { uni: 'target' },
          { uni: 'unit' },
      ],

      picSize1: 100,
      picSize2: 100,
      picSize3: 100,

      xPosition1: 0,
      yPosition1: 0,
      xPosition2: 0,
      yPosition2: 0,
      xPosition3: 0,
      yPosition3: 0,

      fontSize1: '130%',
      fontSize2: '130%',
      cssFontSize1: {
        text: '130%',
        value: '130%',
        vw: '2vw',
        px: '38px',
      },
      cssFontSize2: {
        text: '130%',
        value: '130%',
        vw: '2vw',
        px: '38px',
      },
      isTextBold1: true,
      isTextBold2: true,

      LeftValue: null,
      RightValue: null,
      LeftVal: null,
      RightVal: null,
      coColorleft1: "#ff1330",//red
      coColorleft2: "#64bb01",//green
      coColorright1: "#ff1330",
      coColorright2: "#64bb01",
      coLineleft1:"url(#bg6)",//red
      coLineleft2:'url(#bg7)',//green
      coLineright1:'url(#bg6)',
      coLineright2:'url(#bg7)',
      coColor1: "#1e1e1e",//black
      coColor2: "#1e1e1e",
      coLine1:"url(#bg5)",//black
      coLine2:"url(#bg5)",
      
      coBold1:'',
      coBold2:'',
      co1: null,//text
      co2: null,

      left1: null,
      left2: null,
      right1: null,
      right2: null,
      isUseDescriptorLeft: false,
      isUseDescriptorRight: false,
      left1_en: "Closing",
      left1_tw: "合閘",
      left1_cn: "合闸",
      left2_en: "Opening",
      left2_tw: "開閘",
      left2_cn: "开闸",
      right1_en: "Closing",
      right1_tw: "合閘",
      right1_cn: "合闸",
      right2_en: "Opening",
      right2_tw: "開閘",
      right2_cn: "开闸",

      lineleft1: null,
      lineleft2: null,
      lineright1: null,
      lineright2: null
    };
 
    //new font size setting
    this.fontCalc = ChangeFont.defaultValues;
    this.fontCalc.forEach((item, index) => {
      this.dictFontCalc[this.fontCalc[index].text] = this.fontCalc[index];
    })

    //支持多語言
    if (this.dashboard.meta.language) {
      this.panel.lang = this.dashboard.meta.language;
    } else {
      this.panel.lang = 'en';
    }

    if (this.scope.$$listeners.isWisePaas) {
      _.defaults(this.panel, panelDefaults);
      _.defaults(this.panel.legend, panelDefaults.legend);
      this.mobileFont();
      this.events.on('render', this.onRender.bind(this));
      this.events.on('data-received', this.onDataReceived.bind(this));
      this.events.on('init-edit-mode', this.onInitEditMode.bind(this));
    }
  }

  onInitEditMode() {
    this.addEditorTab('Display', 'public/plugins/ene-circuit-status-panel/partials/editor.html', 2);
    this.unitFormats = kbn.getUnitFormats();
  }

  onRender() { }

  onDataReceived(dataList) {
    // dataList = [{"target":"DO0","unit":"","spanhi":"1.00000000","spanlo":"0.00000000","desc":"","devid":443,"tagname":"DO0","datapoints":[[0,1578282866784]],"discrete":[[0,"Manual"],[1,"Auto"]],"time":"11ms"},{"target":"DO1","unit":"","spanhi":"1.00000000","spanlo":"0.00000000","desc":"","devid":443,"tagname":"DO1","datapoints":[[0,1578282866784]],"discrete":[[0,"OFF"],[1,"ON"]]}]
    this.initDataTable();
    if (this.panel.showURL1) {
      this.panel.bgimage1 = this.panel.bgimageURL1
    } else {
      this.panel.bgimage1 = '';
    }
    if (this.panel.showURL2) {
      this.panel.bgimage2 = this.panel.bgimageURL2
    } else {
      this.panel.bgimage2 = '';
    }
    if (this.panel.showURL3) {
      this.panel.bgimage3 = this.panel.bgimageURL3
    } else {
      this.panel.bgimage3 = '';
    }

    //資料來源
    this.panel.dataArr = [];
    // console.log(dataList);
    if (_.isEmpty(dataList)) {
      // console.log('isEmpty return');
      return;
    }

    let data = dataList;
    if (dataList.length > 0 && dataList[0].target) {
        for (let i = 0; i < data.length; i++) {
            this.panel.dataArr.push({
                desc: data[i].desc,
                spanhi: data[i].spanhi,
                spanlo: data[i].spanlo,
                target: data[i].target,
                unit: data[i].unit
            })
        }
        this.resultData = dataList;
        this.resultData.forEach(element => {
          if (element.discrete && element.discrete.length > 0) { 
            this.targetDiscreteDict[element.target] = element.discrete
          }
        })
        if (!_.isNil(this.panel.LeftValue) || !_.isNil(this.panel.RightValue) ) {
          this.makeDescriptorList();
          this.drawleft();
          this.drawright();
          // console.log('this.ifDataEmpty',this.ifDataEmpty);
        } else {
          this.ifDataEmpty = true;
          // console.log('this.ifDataEmpty',this.ifDataEmpty);
        }
    }
    this.fontsizeChange();
  }

  mobileFont() {
    //yongxin add
    if (this.dashboard.meta) {
      if (this.dashboard.meta.isPc === false) {
        this.panel.adjustableSize = false;
      }
    }
  }

  //fontsize
  fontsizeChange() {
    // console.log('fontsizeChange');
    this.panel.cssFontSize1 = _.find(this.fontCalc, (o) => { return o.text == this.panel.fontSize1 })
    this.panel.cssFontSize2 = _.find(this.fontCalc, (o) => { return o.text == this.panel.fontSize2 })
  }

  initDataTable() {
    this.panel.machineName = '';
    this.panel.machineID = '';
    this.panel.machineInfomation = '';
    this.panel.bgimage1 = '';
    this.panel.bgimage2 = '';
    this.panel.bgimage3 = '';
  }

  link(scope, elem, attrs, ctrl) {
    rendering(scope, elem, attrs, ctrl);
    const $panelContainer = elem.find('.panel-content');
    const panel = ctrl.panel;

    ctrl.events.on('data-received', () => {
      $panelContainer.css('padding', '0');      
    })
  }

  //左半畫布
  drawleft() {
    let LeftValue = this.panel.LeftValue;
    //選哪筆資料做判斷
    this.resultData.forEach(element => {
      if (element.target == LeftValue) {
        this.panel.LeftVal = element.datapoints;
        this.panel.LeftValue = element.target;
      }
    })
    // console.log("this.panel", _.cloneDeep(this.panel));
    if (_.isNil(this.panel.LeftVal) || _.isEmpty(this.panel.LeftVal)) {
      // console.log('LeftVal Nil return');
      return;
    }
    this.ifDataEmpty = false;
    let LeftUnit = this.panel.LeftVal;
    // console.log('LeftUnit = this.panel.LeftVal , LeftUnit[0][0]',this.panel.LeftVal, LeftUnit[0][0]);
    let Left = LeftUnit[0][0];

    //font bold
    let isTextBold1 = this.panel.isTextBold1;
    if(isTextBold1== true){
      this.panel.coBold1 = 'bold'
    }else{
      this.panel.coBold1 = 'normal'
    }

    //language & color
    let lang = this.panel.lang;
    //左邊方塊的判斷式
    let left1 = this.panel.left1; //value1
    let left1_en = this.panel.left1_en; //language
    let left1_tw = this.panel.left1_tw;
    let left1_cn = this.panel.left1_cn;
    let left2 = this.panel.left2; //value2
    let left2_en = this.panel.left2_en;
    let left2_tw = this.panel.left2_tw;
    let left2_cn = this.panel.left2_cn;
    let coColorleft1 = this.panel.coColorleft1;
    let coColorleft2 = this.panel.coColorleft2;
    
    if(Left.toString() == left1){ //左1
      if (this.leftDescriptor.length === 0) {
        this.panel.isUseDescriptorLeft = false
      }
      if (this.panel.isUseDescriptorLeft) {
        console.log('this.leftDescriptor---left1', this.leftDescriptor)
        this.panel.co1 =  this.panel.left1 !== null ? (this.leftDescriptor.find(elem => { return elem.id == this.panel.left1 }).text) : ''
      } else {
        switch(lang){
          case 'en' :
            this.panel.co1 = left1_en
            break;
          case 'zh_tw' :
            this.panel.co1 = left1_tw
            break;
          case 'zh_cn' :
            this.panel.co1 = left1_cn
            break;
          default:
            this.panel.co1 = left1_en
        }
      }
      this.panel.coColor1 = coColorleft1 //方塊的顏色
      this.panel.lineleft1 = this.hexRgbRgba(coColorleft1)//hexRgbRgba
      this.panel.coLine1 = "url(#bg1)"//線的顏色
    } else if (Left.toString() == left2){ //左2
      if (this.leftDescriptor.length === 0) {
        this.panel.isUseDescriptorLeft = false
      }
      if (this.panel.isUseDescriptorLeft) {
        this.panel.co1 =  this.panel.left2 !== null ? (this.leftDescriptor.find(elem => { return elem.id == this.panel.left2 }).text) : ''
      } else {
        switch(lang){
          case 'en' :
            this.panel.co1 = left2_en
            break;
          case 'zh_tw' :
            this.panel.co1 = left2_tw
            break;
          case 'zh_cn' :
            this.panel.co1 = left2_cn
            break;
          default:
            this.panel.co1 = left2_en
        }
      }
      this.panel.coColor1 = coColorleft2 //方塊的顏色
      this.panel.lineleft2 = this.hexRgbRgba(coColorleft2)//hexRgbRgba
      this.panel.coLine1 = "url(#bg2)"//線的顏色
    }else{ //黑色
      this.panel.co1 = Left
      this.panel.coColor1 = "#1e1e1e"
      this.panel.coLine1 = "url(#bg5)"
    }
  }

  //右半畫布
  drawright() {
    let RightValue = this.panel.RightValue;
    //選哪筆資料做判斷
    this.resultData.forEach(element => {
      if (element.target == RightValue) {
        this.panel.RightVal = element.datapoints;
        this.panel.RightValue = element.target;
      }
    })

    if (_.isNil(this.panel.RightVal) || _.isEmpty(this.panel.RightVal)) {
      // console.log('RightVal Nil return');
      return;
    }
    this.ifDataEmpty = false;
    let RightUnit = this.panel.RightVal;
    // console.log('RightUnit = this.panel.RightVal , RightUnit[0][0]',this.panel.RightVal, RightUnit[0][0]);
    let Right = RightUnit[0][0];

    //font bold
    let isTextBold2 = this.panel.isTextBold2;
    if(isTextBold2== true){
      this.panel.coBold2 = 'bold'
    }else{
      this.panel.coBold2 = 'normal'
    }

    //language & color
    let lang = this.panel.lang;
    //右邊方塊的判斷式
    let right1 = this.panel.right1; //value1
    let right1_en = this.panel.right1_en; //language
    let right1_tw = this.panel.right1_tw;
    let right1_cn = this.panel.right1_cn;
    let right2 = this.panel.right2; //value2
    let right2_en = this.panel.right2_en;
    let right2_tw = this.panel.right2_tw;
    let right2_cn = this.panel.right2_cn;
    let coColorright1 = this.panel.coColorright1;
    let coColorright2 = this.panel.coColorright2;

    if(Right.toString() == right1){ //右1
      if (this.rightDescriptor.length === 0) {
        this.panel.isUseDescriptorRight = false
      }
      if (this.panel.isUseDescriptorRight) {
        this.panel.co2 =  this.panel.right1 !== null ? (this.rightDescriptor.find(elem => { return elem.id == this.panel.right1 }).text) : ''
      } else {
        switch(lang){
          case 'en' :
            this.panel.co2 = right1_en
            break;
          case 'zh_tw' :
            this.panel.co2 = right1_tw
            break;
          case 'zh_cn' :
            this.panel.co2 = right1_cn
            break;
          default:
            this.panel.co2 = right1_en
        }
      }
      this.panel.coColor2 = coColorright1//方塊的顏色
      this.panel.lineright1 = this.hexRgbRgba(coColorright1)//hexRgbRgba
      this.panel.coLine2 = "url(#bg3)"//線的顏色
    }else if(Right.toString() == right2){ //右2
      if (this.rightDescriptor.length === 0) {
        this.panel.isUseDescriptorRight = false
      }
      if (this.panel.isUseDescriptorRight) {
        this.panel.co2 =  this.panel.right2 !== null ? (this.rightDescriptor.find(elem => { return elem.id == this.panel.right2 }).text) : ''
      } else {
        switch(lang){
          case 'en' :
            this.panel.co2 = right2_en
            break;
          case 'zh_tw' :
            this.panel.co2 = right2_tw
            break;
          case 'zh_cn' :
            this.panel.co2 = right2_cn
            break;
          default:
            this.panel.co2 = right2_en
        }
      }
      this.panel.coColor2 = coColorright2//方塊的顏色
      this.panel.lineright2 = this.hexRgbRgba(coColorright2)//hexRgbRgba
      this.panel.coLine2 = "url(#bg4)"//線的顏色
    }else{ //黑色
      this.panel.co2 = Right
      this.panel.coColor2 = "#1e1e1e"
      this.panel.coLine2 = "url(#bg5)"
    }
  }

  hexRgbRgba(hex) { //漸層色
    let hex1 = hex.match("#")
    let hex2 = hex.match("rgba")
    let hex3 = hex.match("rgb")
    if (hex1) { //hex to rgba
      // Expand shorthand form (e.g. "03F") to full form (e.g. "0033FF")
      var shorthandRegex = /^#?([a-f\d])([a-f\d])([a-f\d])$/i;
      hex = hex.replace(shorthandRegex, function(m, r, g, b) {
        return r + r + g + g + b + b ;
      });
      let result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
      result = {
        r: parseInt(result[1], 16),
        g: parseInt(result[2], 16),
        b: parseInt(result[3], 16)
      } 
      return "rgba("+ result.r + ", " + result.g + ", " + result.b + ", 0.1)";
    }else if(hex2){ //rgba to rgba
      let result1 = hex.lastIndexOf(",");
      let result2 = hex.substring(result1)
      let result3 = hex.replace(result2, ', 0.1)')
      return result3;
    }else if(hex3){ //rgb to rgba
      let result = hex.replace(')', ', 0.1)').replace('rgb', 'rgba');
      return result;
    }    
  }

  makeDescriptorList() {
    this.leftDescriptor = []
    this.rightDescriptor = []

    if (this.targetDiscreteDict[this.panel.LeftValue]) {
      this.targetDiscreteDict[this.panel.LeftValue].forEach((item) => {
        let option = {}
        option['id'] = item[0].toString()
        option['text'] = item[1].toString()
        this.leftDescriptor.push(option)
      })
    }
    if (this.targetDiscreteDict[this.panel.RightValue]) {
      this.targetDiscreteDict[this.panel.RightValue].forEach((item) => {
        let option = {}
        option['id'] = item[0].toString()
        option['text'] = item[1].toString()
        this.rightDescriptor.push(option)
      })
    }
  }
}

MachineInfo.templateUrl = 'partials/module.html';
