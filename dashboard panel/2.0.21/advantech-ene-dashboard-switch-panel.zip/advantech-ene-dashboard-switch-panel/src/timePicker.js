/*
 * @Author: NH
 * @Date: 2021-05-13 15:09:30
 * @LastEditTime: 2021-11-01 10:53:57
 * @Description: 
 */

export const defaultOptions = {
    label: {
        en: 'Time Range',
        zh_cn: '时间范围',
        zh_tw: '時間範圍',
        ja: '時間範囲'
    },
    interval: {
        label: {
            en: 'Interval',
            zh_cn: '间隔',
            zh_tw: '間隔',
            ja: '間隔'
        },
        list: [
            {
                id: 6, unit: 'y', display: { en: 'Year', zh_cn: '年', zh_tw: '年', ja: '年' }
            }, {
                id: 5, unit: 'M', display: { en: 'Month', zh_cn: '月', zh_tw: '月', ja: '月' }
            }, {
                id: 4, unit: 'w', display: { en: 'Week', zh_cn: '周', zh_tw: '周', ja: '週' }
            }, {
                id: 3, unit: 'd', display: { en: 'Day', zh_cn: '天', zh_tw: '天', ja: '日' }
            }, {
                id: 2, unit: 'h', display: { en: 'Hour', zh_cn: '小时', zh_tw: '小時', ja: '時' }
            }, {
                id: 1, unit: 'm', display: { en: 'Minute', zh_cn: '分钟', zh_tw: '分鐘', ja: '分' }
            }, {
                id: 0, unit: 's', display: { en: 'Second', zh_cn: '秒', zh_tw: '秒', ja: '秒' }
            }]
    },
    lastUpdateTime:{
        en: 'Last Updated Time',
        zh_cn: '上次更新时间',
        zh_tw: '上次更新時間',
        ja: '最終更新時刻'
    },
    groups: {
        en: 'Groups',
        zh_cn: '组织',
        zh_tw: '組織',
        ja: '組織'
    },
    objects: {
        en: 'Objects',
        zh_cn: '物件',
        zh_tw: '物體',
        ja: 'オブジェクト'
    },
    parameters: {
        en: 'Parameters',
        zh_cn: '参数',
        zh_tw: '參數',
        ja: 'パラメータ'
    },
    timeInterval: {
        en: 'Time Interval',
        zh_cn: '时间间隔',
        zh_tw: '時間間隔',
        ja: '時間間隔'
    },
    clearFilters: {
        en: 'Clear all filters',
        zh_cn: '清除所有过滤器',
        zh_tw: '清除篩檢程式',
        ja: 'クリアフィルタ'
    },
    submit: {
        en: 'Submit',
        zh_cn: '提交',
        zh_tw: '提交',
        ja: '提出する'
    },
    cancel: {
        en: 'Cancel',
        zh_cn: '取消',
        zh_tw: '取消',
        ja: '取り消し'
    },
    to: {
        en: 'To',
        zh_cn: '到',
        zh_tw: '到',
        ja: 'To'
    },
    from: {
        en: 'From',
        zh_cn: '从',
        zh_tw: '從',
        ja: 'から'
    },
    apply: {
        en: 'Apply',
        zh_cn: '应用',
        zh_tw: '應用',
        ja: '適用'
    },
    previous: {
        en: 'Previous',
        zh_cn: '上一个',
        zh_tw: '上一個',
        ja: '前の方'
    },
    next: {
        en: 'Next',
        zh_cn: '下一个',
        zh_tw: '下一個',
        ja: '次の方'
    },
}
export const defaultSelectOptions = [
    { id: 0, from: 'now', to: 'now', display: { en: 'Custom time range', zh_cn: '自定义时间范围', zh_tw: '自定義時間範圍', ja: 'カスタム時間範囲' } },
    { id: 1, from: 'now', to: 'now', display: { en: 'Custom time interval', zh_cn: '自定义时间间隔', zh_tw: '自定義時間間隔', ja: 'カスタム時間間隔' } },
    { id: 2, from: 'now-5m', to: 'now', display: { en: 'Last 5 minutes', zh_cn: '最后5分钟', zh_tw: '最後5分鐘', ja: '最後の5分' } },
    { id: 3, from: 'now-15m', to: 'now', display: { en: 'Last 15 minutes', zh_cn: '最后15分钟', zh_tw: '最後15分鐘', ja: '最後の15分' } },
    { id: 4, from: 'now-30m', to: 'now', display: { en: 'Last 30 minutes', zh_cn: '最后30分钟', zh_tw: '最後30分鐘', ja: '最後の30分' } },
    { id: 5, from: 'now-1h', to: 'now', display: { en: 'Last 1 hour', zh_cn: '最后1小时', zh_tw: '最後1小時', ja: '最後の1時間' } },
    { id: 6, from: 'now-3h', to: 'now', display: { en: 'Last 3 hours', zh_cn: '最后3小时', zh_tw: '最後3小時', ja: '最後の3時間' } },
    { id: 7, from: 'now-6h', to: 'now', display: { en: 'Last 6 hours', zh_cn: '最后6小时', zh_tw: '最後6小時', ja: '最後の6時間' } },
    { id: 8, from: 'now-12h', to: 'now', display: { en: 'Last 12 hours', zh_cn: '最后12小时', zh_tw: '最後12小時', ja: '最後の12時間' } },
    { id: 9, from: 'now-24h', to: 'now', display: { en: 'Last 24 hours', zh_cn: '最后24小时', zh_tw: '最後24小時', ja: '最後の24時間' } },
    { id: 10, from: 'now-2d', to: 'now', display: { en: 'Last 2 days', zh_cn: '最近2天', zh_tw: '最近2天', ja: '最後の2日間' } },
    { id: 11, from: 'now-7d', to: 'now', display: { en: 'Last 7 days', zh_cn: '最近7天', zh_tw: '最近7天', ja: '最後の7日間' } },
    { id: 12, from: 'now-30d', to: 'now', display: { en: 'Last 30 days', zh_cn: '最近30天', zh_tw: '最近30天', ja: '最後の30日間' } },
    { id: 13, from: 'now-90d', to: 'now', display: { en: 'Last 90 days', zh_cn: '最近90天', zh_tw: '最近90天', ja: '最後の90日間' } },
    { id: 14, from: 'now-6M', to: 'now', display: { en: 'Last 6 months', zh_cn: '过去6个月', zh_tw: '過去6個月', ja: '過去6ヶ月' } },
    { id: 15, from: 'now-1y', to: 'now', display: { en: 'Last 1 year', zh_cn: '过去1年', zh_tw: '過去1年', ja: '最後の1年' } },
    { id: 16, from: 'now-2y', to: 'now', display: { en: 'Last 2 year', zh_cn: '过去2年', zh_tw: '過去2年', ja: '最後の2年' } },
    { id: 17, from: 'now-5y', to: 'now', display: { en: 'Last 5 year', zh_cn: '过去5年', zh_tw: '過去5年', ja: '最後の5年' } },
    { id: 18, from: 'now-1d/d', to: 'now-1d/d', display: { en: 'Yesterday', zh_cn: '昨天', zh_tw: '昨天', ja: '昨日' } },
    { id: 19, from: 'now-2d/d', to: 'now-2d/d', display: { en: 'Day before yesterday', zh_cn: '前天', zh_tw: '前天', ja: '一昨日' } },
    { id: 20, from: 'now-7d/d', to: 'now-7d/d', display: { en: 'This day last week', zh_cn: '上周的今天', zh_tw: '上周的今天', ja: '先週の今日' } },
    { id: 21, from: 'now-1w/w', to: 'now-1w/w', display: { en: 'Previous week', zh_cn: '前一周', zh_tw: '前一周', ja: '前の週' } },
    { id: 22, from: 'now-1M/M', to: 'now-1M/M', display: { en: 'Previous month', zh_cn: '上个月', zh_tw: '上個月', ja: '先の月' } },
    { id: 23, from: 'now-1y/y', to: 'now-1y/y', display: { en: 'Previous year', zh_cn: '前一年', zh_tw: '前一年', ja: '前年' } },
    { id: 24, from: 'now/d', to: 'now/d', display: { en: 'Today', zh_cn: '今天', zh_tw: '今天', ja: '今日' } },
    { id: 25, from: 'now/d', to: 'now', display: { en: 'Today so far', zh_cn: '今天到现在为止', zh_tw: '今天到現在為止', ja: '今日ここまで' } },
    { id: 26, from: 'now/w', to: 'now/w', display: { en: 'This week', zh_cn: '本周', zh_tw: '本周', ja: '今週' } },
    { id: 27, from: 'now/w', to: 'now', display: { en: 'This week so far', zh_cn: '本周至今', zh_tw: '本周至今', ja: '今週今まで' } },
    { id: 28, from: 'now/M', to: 'now/M', display: { en: 'This month', zh_cn: '本月', zh_tw: '本月', ja: '今月' } },
    { id: 29, from: 'now/M', to: 'now', display: { en: 'This month so far', zh_cn: '本月至今', zh_tw: '本月至今', ja: '今までのところ' } },
    { id: 30, from: 'now/y', to: 'now/y', display: { en: 'This year', zh_cn: '今年', zh_tw: '今年', ja: '今年' } },
    { id: 31, from: 'now/y', to: 'now', display: { en: 'This year so far', zh_cn: '今年至今', zh_tw: '今年至今', ja: '今年ここまで' } },
];

export const defaultIntervalOption = {
    number: 1,
    unit: 'h',
    raw: {
        from: 'now-6h',
        to: 'now'
    }
}