## Introduction
Analog the switch for industrial control.
## Getting Started
  - set single or multiple query
  - bind the data tag in data mapping
  - set mapping value
  - click button to change current value to mapping value
### How to intsall
  - npm install
  - grunt
  - delete node_modules folder
  - compress as zip
  - upload to grafana dashboard plugin
## Query Data format:
  - timeseries

## Query time type:
  - utc

Copyright 2022 © Alisa Lin Advantech.