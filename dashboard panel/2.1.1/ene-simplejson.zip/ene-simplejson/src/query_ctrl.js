/*
 * @Author: NH
 * @Date: 2022-08-03 08:36:25
 * @LastEditTime: 2023-09-15 14:42:11
 * @Description: 2.00.001
 */

import { QueryCtrl } from 'app/plugins/sdk';
import { getMultiLang } from './multilang';
import './css/query-editor.css!'
import _ from "lodash";
import formula from './formula.js';
import coreModule from 'app/core/core_module';
import { multiDropdownDirective } from './components/multi-dropdown/multiDropdown';
import { commonDropdownDirective } from './components/common-dropdown/commonDropdown';

coreModule.directive('multiDropdown', multiDropdownDirective);
coreModule.directive('commonDropdown', commonDropdownDirective);

export class GenericDatasourceQueryCtrl extends QueryCtrl {

    constructor($scope, $injector) {
        super($scope, $injector);

        /* iswisepaas */
        // if (this.panelCtrl.$scope.$$listeners && this.panelCtrl.$scope.$$listeners.isWisePaas) {
        //   this.isWisePaas = true;
        // }
        this.isWisePaas = true;
        this.scope = $scope;

        this.langType = (this.panelCtrl.dashboard.panelLanguage || 'en').toLowerCase().replace(/\W/g, '_');
        if (this.langType.indexOf('zh') === -1) {
            this.langType = this.langType.split('_')[0] || 'en';
        }
        this.intervalTypeList = [
            { value: 'original', text: this.getMultiLang('Original') },
            { value: 'autoScale', text: this.getMultiLang('AutoScale') },
            { value: 'fixInterval', text: this.getMultiLang('FixedInterval') }];
        this.panelTypeList = [
            { value: 'table', text: this.getMultiLang('Table') },
            { value: 'timeseries', text: this.getMultiLang('Timeserie') },
        ]

        this.target.type = this.target.type || 'timeseries';
        this.target.area = this.target.area || 'select group';
        //this.target.station = this.target.station || 'select station';
        this.target.devicetype = this.target.devicetype || 'select object type';
        this.target.device = this.target.device || 'select object';
        this.target.deviceparam = this.target.deviceparam || 'select parameter';
        this.target.timeinterval = this.target.timeinterval || 'min';
        this.target.intervaltype = this.target.intervaltype || 'autoScale';
        this.target.functiontype = this.target.functiontype || 'select function type';
        this.target.dataType = this.target.dataType || 'realtime';
        this.target.statetype = this.target.statetype || 'select state';
        this.target.displayname = this.target.displayname || '@tagname';
        this.target.groupList = this.target.groupList || [];
        this.target.simulate = this.target.simulate || false;
        this.target.simulatetype = this.target.simulatetype || 'select simulate type';
        this.target.property = this.target.property || 'select property';
        this.target.paneltype = this.panel.type || 'graph';
        this.target.markException = this.target.markException === undefined ? false : this.target.markException;
        this.target.markAlarm = this.target.markAlarm === undefined ? false : this.target.markAlarm;
        this.target.markTimeRange = this.target.markTimeRange === undefined ? false : this.target.markTimeRange; // 2022/07/13 适用于查询全部alarm log，还是 timerange内alarm
        this.target.regExp = this.target.regExp || ''; // 2022/07/14 输入正则表达式，用于过滤 parameter，与$Parameter互斥
        this.target.expression = this.target.expression || ''; // 2022/07/14 用于对RT/HIS 资料进行简单的计算，包括+-*/（），仅针对当前Parameter 
        this.target.source = this.target.source || 'deviceon-bi-simplejson';
        this.target.configs = this.target.configs || []; // 用于存储KPI datasource 各项的 配置
        this.target.isKPIDatasource = this.target.isKPIDatasource || false;

        this.target.fieldId = this.target.fieldId || ''; // 2022/11/02 用于存储 inspection area id 
        this.target.stationId = this.target.stationId || ''; // 2022/11/02 用于存储 inspection station id
        this.target.markRateTimes = this.target.markRateTimes || false; // 2023/03/20 用于存储PassRate/FailRate 是否显示 times
        this.target.markSubGroup = this.target.markSubGroup === undefined ? true : this.target.markSubGroup; // 2023/04/04 默认查询 suborg, 取消时仅查询当前org alarm

        this.target.mapCardJson = this.panel.type == 'ene-worldmapcard-panel' && this.target.mapCardJson ? this.target.mapCardJson : null;
        this.target.size = this.target.size || document.getElementsByTagName('body')[0].clientWidth / 24 * this.panel.gridPos.w;
        this.target.commonLibConfig = this.target.commonLibConfig || {
            Group: {
                name: '',
                langid: '',
                id: '',
                level: 0,
            },
            Object: {
                name: '',
                langid: '',
                id: '',
                level: 0,
            },
            Parameter: {
                name: '',
                langid: '',
                id: '',
                level: 0,
            },
        }
        let varibleNum = this.panelCtrl.dashboard.templating.list.filter(x => { return /Organization\d+/.test(x.name) });
        this.groupNum = varibleNum.length > 5 ? varibleNum.length : this.target.groupList.length ? this.target.groupList.length : 5;
        this.intervalNum = '1';
        this.intervalUnit = 'm';
        this.intervaltype = 'autoScale';
        this.paramList = [];
        this.objectList = [];
        this.expressionInvalid = false;
        this.functionList = [];

        this.initTimeInterval();
        this.checkPanelName().then((result) => {
            this.target.checkPanel = result.data;
        });
        this.checkSimulateData().then(result => {
            this.target.checkSimulate = result.data;
        });
        this.onChangeInternal_datasource().then(result => {
            this.initSetGroupList();
        });
    }

    getMultiLang(key) {
        return getMultiLang(key, this.langType);
    }

    checkPanelName() {
        return this.datasource.metricFindQuery_panelname(this.panel.type);
    }

    checkSimulateData() {
        return this.datasource.metricFindQuery_simulatedata('' + this.target.area, '' + this.target.devicetype, '' + this.target.device, '' + this.target.deviceparam);
    }
    initSetGroupList() {
        let area = this.target.area.split('/');
        for (let i = 0; i < this.groupNum; i++) {
            if (this.target.groupList[i]) {
                if (area[i] && -1 !== area[i].indexOf('#')) {
                    let a = area[i].split('#').filter(x => { return !!x }) || [];
                    this.target.groupList[i] = { text: a[0] || this.getMultiLang('SelectGroup'), value: a[1] || 'select group', id: a[1] || 'select group' }
                } else if (area[i] && /^\$\S+$/.test(area[i])) {
                    this.target.groupList[i] = { text: area[i], value: area[i], id: area[i] }
                } else if (area[i]) {
                    let index = this.target.groupList.findIndex(x => { return this.target.isKPIDatasource ? x.id == area[i] : x.value == area[i] });
                    this.target.groupList[i] = index !== -1 && this.target.groupList[index].value !== 'select group' ? this.target.groupList[index] : { text: this.getMultiLang('SelectGroup'), value: 'select group', id: 'select group' };
                } else {
                    this.target.groupList[i] = { text: this.getMultiLang('SelectGroup'), value: 'select group', id: 'select group' };
                }
            } else {
                this.target.groupList.push({ text: this.getMultiLang('SelectGroup'), value: 'select group', id: 'select group' });
            }
        }
    }
    initTimeInterval() {
        if (/\d+/i.test(this.target.timeinterval)) { // custom
            this.intervaltype = 'fixInterval'
            this.intervalNum = '' + parseFloat(this.target.timeinterval);
            this.intervalUnit = this.target.timeinterval.replace(this.intervalNum, '');
        } else { // autoScale | original
            this.intervaltype = this.target.intervaltype;

        }
    }
    getOptions(query) {
        return this.datasource.metricFindQuery(query || '');
    }

    getDatasourceList(query) {
        return this.datasource.metricFindQuery_datasource(query);
    }

    getConfig(option) {
        let config = null;
        let index = this.target.configs.findIndex(x => { return x.name == option.name && x.id == option.id && x.level == option.level });
        if (index !== -1) {
            config = _.cloneDeep(this.target.configs[index]);
            config.index = index;
        }
        return config;
    }

    async getFunctionList(option) {
        console.log('get Function List')
        let config = this.getConfig(option);
        let list = [];
        if (config) {
            delete config.model;
            this.functionList = await this.datasource.metricFindQuery_functionList(this.target.source, config);
            for (let i = 0; i < this.functionList.length; i++) {
                let x = this.functionList[i];
                this.target.configs[config.index].type = x.type;
                this.target.configs[config.index].commonLibType = x.commonLibType;
                this.target.configs[config.index].displayName = x.displayName[this.langType];
                this.target.configs[config.index].isLeaf = x.isLeaf;
                this.target.configs[config.index].isQuery = x.isQuery;

                let model = x.items ? x.items.map(y => {
                    return {
                        value: y.id,
                        text: y.displayName[this.langType],
                        name: y.name
                    }
                }) : [];
                list = list.concat(model);
            }
        }
        return Promise.resolve(list);
    }

    async getNextFunctionList(options) {
        this.functionList = await this.datasource.metricFindQuery_functionList(this.target.source, options);
        let config = null;
        for (let i = 0; i < this.functionList.length; i++) {
            let x = this.functionList[i];
            if (!x) return;
            let obj = {
                type: x.type,
                name: x.name,
                displayName: x.displayName[this.langType],
                id: x.id,
                parentId: x.parentId,
                model: [],
                isLeaf: x.isLeaf,
                isQuery: x.isQuery,
                commonLibType: x.commonLibType,
                level: x.level
            };
            switch (obj.type) {
                case 'input':
                    obj.model = [{
                        value: '',
                        text: x.displayName[this.langType],
                        name: x.name
                    }];
                    break;
                case 'switch':
                    obj.model = [{
                        value: false,
                        text: x.displayName[this.langType],
                        name: x.name
                    }];
                    break;
                case 'dropdown':
                case 'multi':
                    if (x.items && x.items[0]) {
                        obj.model = [{
                            value: x.items[0].id,
                            text: x.items[0].displayName[this.langType],
                            name: x.items[0].name
                        }];
                    }
                    break;
            }
            let index = this.target.configs.findIndex(y => { return y.name == x.name && y.level == x.level && y.id == x.id });
            // 2022/11/08 如果是common library，自动把已经选中的group/object/parameter 选项带入到 组件中 -- NH
            if (obj.commonLibType != 'Null') {
                let comConfig = this.target.commonLibConfig[obj.commonLibType];
                if (comConfig) {
                    obj.model[0].value = comConfig.id;
                }
            }
            if (index == -1) {
                this.target.configs.push(obj);
            } else {
                this.target.configs[index] = obj;
            }

            if (obj.commonLibType != 'Null' && x.items) {
                let newObj = {
                    type: 'dropdown',
                    name: x.items[0].name,
                    displayName: x.items[0].displayName[this.langType],
                    id: x.items[0].id,
                    parentId: obj.id,
                    model: [],
                    isLeaf: x.isLeaf,
                    isQuery: x.isQuery,
                    commonLibType: 'Null',
                    level: obj.level * 1 + 1
                }
                this.target.configs.push(newObj);
            }
            this.setCommonConfig(obj);
            config = obj;
        }
        console.log(this.target.configs);
        return config;
    }

    setCommonConfig(config) {
        if (this.target.commonLibConfig[config.commonLibType]) {
            let comConfig = this.target.commonLibConfig[config.commonLibType];
            comConfig.name = config.name;
            // comConfig.id = config.id;
            comConfig.level = config.level;
        }
    }

    getAreaOptions(query, pindex) {
        let parent = '';
        if (pindex != -1) {
            parent = this.target.groupList[pindex][this.target.isKPIDatasource ? 'id' : 'value'];
        }
        return this.datasource.metricFindQuery_area(query, '' + parent, this.target.isKPIDatasource);
    }
    // getStationOptions (query) {   
    //   return this.datasource.metricFindQuery_station(this.target.area);
    // }
    getDeviceTypeOptions(query) {
        return this.datasource.metricFindQuery_devicetype('' + this.target.area, this.target.isKPIDatasource);
    }

    getCommonConfig(config) {
        if (config.commonLibType == 'Object') {
            return this.getDeviceOptions('');
        } else {
            return this.getDeviceParamOptions('');
        }
    }
    async getDeviceOptions(query) {
        this.objectList = await this.datasource.metricFindQuery_device('' + this.target.area, '' + this.target.devicetype, this.target.isKPIDatasource);
        return this.objectList;
    }
    async getDeviceParamOptions(query) {
        this.paramList = await this.datasource.metricFindQuery_deviceparam('' + this.target.area, '' + this.target.devicetype, '' + this.target.device, this.target.isKPIDatasource);
        return this.paramList;
    }
    async getTimeIntervalOptions(query) {
        let timeInterval = await this.datasource.metricFindQuery_timeinterval(query);
        if (this.intervaltype == 'original') {
            if (this.target.timeinterval == 'month' || this.target.timeinterval == 'year') {
                this.target.timeinterval = 'min';
            }
            timeInterval = timeInterval.filter(x => { return x.value !== 'month' && x.value !== 'year' });
        }
        return timeInterval;
    }
    getTimeIntervalNumOptions(query) {
        // let nums = [1, 2, 3, 4, 5, 6, 7, 10, 15, 20, 30, 45, 60];
        let list = null;
        switch (this.intervalUnit) {
            case 'h':
                list = [1, 2, 3, 4, 6, 8, 12];
                break;
            case 'M':
                list = [1, 2, 3, 6];
                break;
            case 'y':
                list = [1]; break;
            case 'd':
                list = [1, 2, 3, 5, 7];
                break;
            case 'm':
            default:
                list = [1, 5, 10, 15, 20, 30];//nums.filter(x => { return x !== 6 && x !== 7 });
                break;
        }
        return list.map(x => { return { text: x, value: x } });
    }
    getTimeIntervalUnitOptions(query) {
        let units = [
            { 'value': 'm', 'text': this.getMultiLang('Min') },
            { 'value': 'h', 'text': this.getMultiLang('Hour') },
            { 'value': 'd', 'text': this.getMultiLang('Day') },
            { 'value': 'M', 'text': this.getMultiLang('Month') },
            { 'value': 'y', 'text': this.getMultiLang('Year') }
        ];
        if (this.intervalNum == 7) {
            this.intervalUnit = 'd';
        } else if (this.intervalNum == 6) {
            this.intervalUnit = 'h';
        }
        return units;
    }
    getDataTypeOptions(query) {
        return this.datasource.metricFindQuery_datatype(query).then(result => {
            // if (this.intervaltype == 'autoScale' && /sec/i.test(this.target.timeinterval)) {
            //     this.target.dataType = 'history';
            //     return result.filter(x => { return x.value == 'history' });
            // } else {
            return result;
            // }
        });
    }
    getFunctionTypeOptions(query) {
        return this.datasource.metricFindQuery_functiontype(query);
    }
    getStateTypeOptions(query) {
        return this.datasource.metricFindQuery_statetype('' + this.target.area, '' + this.target.devicetype, '' + this.target.device, this.target.deviceparam);
    }

    getSimulateTypeOptions(query) {
        return this.datasource.metricFindQuery_simulatetype(query);
    }

    getParamProperty(query) {
        return this.datasource.metricFindQuery_property('' + this.target.area, '' + this.target.devicetype, '' + this.target.device, this.target.deviceparam);
    }

    getInspectionAreaOptions(query) {
        return this.datasource.metricFindQuery_inspectionarea('' + this.target.area, this.target.isKPIDatasource);
    }

    getInspectionStationOptions(query) {
        return this.datasource.metricFindQuery_inspectionstation('' + this.target.area, '' + this.target.fieldId, this.target.isKPIDatasource);
    }

    toggleEditorMode() {
        this.target.rawQuery = !this.target.rawQuery;
    }

    onChangeInternal() {
        this.panelCtrl.refresh(); // Asks the panel to refresh data.
    }

    async onChangeInternal_datasource() {
        this.target.configs.forEach(x => {
            for (let item in this.target.commonLibConfig) {
                if (x.commonLibType == item && this.target.commonLibConfig[item].id) {
                    x.model[0].value = this.target.commonLibConfig[item].id;
                }
            }
        });
        if (this.target.source.indexOf('deviceon-bi-simplejson') !== -1) {
            this.target.isKPIDatasource = false;
            this.target.area = this.target.groupList.map(x => { return x.value }).join('/') || this.target.area;
            this.target.device = this.target.commonLibConfig.Object.langid || this.target.device;
            this.target.deviceparam = this.target.commonLibConfig.Parameter.name || this.target.deviceparam;
            this.panelCtrl.refresh(); // Asks the panel to refresh data.
        } else {
            this.target.isKPIDatasource = true;
            let config = this.target.configs[this.target.configs.length - 1];
            if (config) {
                await this.onChangeInternal_KPIQuery(config);
            } else {
                await this.getNextFunctionList({
                    level: 0,
                    id: 0
                });
                this.$scope.$apply();
            }

        }
    }

    async onChangeInternal_KPIQuery(option) {
        console.log('on change: ', option);
        let config = this.getConfig(option);
        if (config && config.isQuery) {
            let child = await this.getNextFunctionList(config);
            if (!child) {
                let level = config.level;
                this.target.configs = this.target.configs.filter(x => { return x.level <= level });
            }
            this.$scope.$apply();
            await this.panelCtrl.refresh();
        } else if (config && !config.isLeaf) {
            let child = null;
            let $index = this.target.configs.findIndex(x => { return x.name == config.name });
            if ($index != -1) {
                let level = config.level;
                this.target.configs = this.target.configs.filter(x => { return x.level <= level });
                child = await this.getNextFunctionList(config);
            }
            this.$scope.$apply();
            if (!child) {
                await this.panelCtrl.refresh();
            }
        } else {
            await this.panelCtrl.refresh(); // Asks the panel to refresh data.
        }
    }

    async onChangeInternal_CommonKPIQuery(option) {
        let config = this.getConfig(option);
        if (config.commonLibType == 'Object') {
            await this.onChangeInternal_device(config);
        } else if (config.commonLibType == 'Parameter') {
            await this.onChangeInternal_deviceparam(config);
        }
    }

    async onChangeInternal_area(index, group) {
        //如果是最后一个dropdown，则search是否有子group，并追加到后面（默认5）
        if (index >= 4 && index == this.target.groupList.length - 1) {
            let result = await this.datasource.metricFindQuery_area('', this.target.groupList[index].value);
            console.log(result);
            if (result.length > 1) {
                this.target.groupList.push({ text: this.getMultiLang('SelectGroup'), value: 'select group', id: 'select group' });
            }
        }
        this.target.groupList[index] = group;
        for (let i = index + 1; i < this.target.groupList.length; i++) {
            this.target.groupList[i] = { text: this.getMultiLang('SelectGroup'), value: 'select group', id: 'select group' };
        }
        this.target.area = this.target.groupList.map(x => { return this.target.isKPIDatasource ? x.id : x.value || 'select group' }).join('/');
        this.target.devicetype = 'select object type';
        this.target.device = 'select object';
        this.target.deviceparam = 'select parameter';

        this.target.commonLibConfig.Group.id = '' + group.id;
        this.target.commonLibConfig.Group.langid = '' + group.value;
        if (!this.target.isKPIDatasource) {
            await this.panelCtrl.refresh(); // Asks the panel to refresh data.
        } else {
            let config = this.target.configs.find(x => { return x.name == this.target.commonLibConfig.Group.name && x.commonLibType == 'Group' });
            if (config) {
                config.model[config.model.length - 1].value = '' + group.id;
                await this.onChangeInternal_KPIQuery(config);
            }
        }
        this.$scope.$apply();
    }

    async onChangeInternal_devicetype() {
        this.target.device = 'select object';
        this.target.deviceparam = 'select parameter';
        await this.panelCtrl.refresh(); // Asks the panel to refresh data.
        setTimeout(()=>{
            this.$scope.$apply();
        },500);
    }

    async onChangeInternal_device(config) {
        this.target.deviceparam = 'select parameter';
        let values = config && config.model.map(x => { return x.value }) || [];
        this.target.commonLibConfig.Object.id = values.join(',');
        this.target.commonLibConfig.Object.langid = this.objectList.filter(x => { return values.indexOf(x.id) !== -1 }).map(x => { return x.value }).join(',');
        if (!this.target.isKPIDatasource) {
            await this.panelCtrl.refresh(); // Asks the panel to refresh data.
        } else {
            this.target.device = this.target.commonLibConfig.Object.langid;
            await this.onChangeInternal_KPIQuery(config);
        }
        this.$scope.$apply();
    }

    async onChangeInternal_deviceparam(config) {
        let result = await this.checkSimulateData();
        this.target.checkSimulate = result.data;
        let values = config && config.model.map(x => { return x.value }) || [];
        this.target.commonLibConfig.Parameter.id = values.join(',');
        this.target.commonLibConfig.Parameter.langid = this.paramList.filter(x => { return values.indexOf(x.id) !== -1 }).map(x => { return x.value }).join(',');
        if (!this.target.isKPIDatasource) {
            await this.panelCtrl.refresh(); // Asks the panel to refresh data.
        } else {
            this.target.deviceparam = this.target.commonLibConfig.Parameter.langid;
            await this.onChangeInternal_KPIQuery(config);
        }
        this.$scope.$apply();
    }

    onChangeInternal_timeinterval() {
        if (this.intervaltype == 'autoScale' && /\d+/i.test(this.target.timeinterval)) {
            this.target.timeinterval = 'min';
        } else if (this.intervaltype == 'autoScale' && /sec/i.test(this.target.timeinterval)) {
            this.target.dataType = 'history';
        } else if (this.intervaltype == 'fixInterval') {
            // if (!/\d+/i.test(this.target.timeinterval)){
            this.target.timeinterval = this.intervalNum + '' + this.intervalUnit;
            // }
        } else if (this.intervaltype == 'original') {
            // this.target.intervaltype = this.intervaltype;
        }
        this.target.intervaltype = this.intervaltype;
        this.panelCtrl.refresh(); // Asks the panel to refresh data.
    }

    onChangeInternal_datatype() {
        this.panelCtrl.refresh(); // Asks the panel to refresh data.
    }

    onChangeInternal_functionType() {
        this.panelCtrl.refresh(); // Asks the panel to refresh data.
    }

    onChangeInternal_simulate() {
        this.panelCtrl.refresh(); // Asks the panel to refresh data.
    }

    onChangeInternal_markException() {
        this.panelCtrl.refresh(); // Asks the panel to refresh data.
    }

    onChangeInternal_markAlarm() {
        this.panelCtrl.refresh(); // Asks the panel to refresh data.
    }

    onChangeInternal_property() {
        this.panelCtrl.refresh(); // Asks the panel to refresh data.
    }

    onChangeInternal_markTimeRange() {
        // almlog_record 是否按timerange 查询
        this.panelCtrl.refresh(); // Asks the panel to refresh data.
    }

    onChangeInternal_markSubGroup() {
        // almlog_record 是否按timerange 查询
        this.panelCtrl.refresh(); // Asks the panel to refresh data.
    }

    onChangeInternal_markRateTimes() {
        // PassRate, FailRate 是否显示 times
        this.panelCtrl.refresh(); // Asks the panel to refresh data.
    }

    onChangeInternal_paramFilterRegExp() {
        // 正则表达式 和 $Parameter 互斥
        if (!/^\$\w+$/.test(this.target.deviceparam)) {
            let newReg = createRegExp(this.target.regExp);
            if (newReg) {
                let matches = this.paramList.map(x => x.text).filter(x => { return newReg.test(x) }) || [];
                let params = this.paramList.filter(x => { return -1 !== matches.indexOf(x.text) }).map(x => x.value).join(',');
                this.target.deviceparam = params;
                this.onChangeInternal_deviceparam()
            } else {
                this.target.deviceparam = 'select parameter';
                this.onChangeInternal_deviceparam()
            }
        } else {
            this.panelCtrl.refresh(); // Asks the panel to refresh data.
        }
    }

    onChangeInternal_expression() {
        // check express
        let result = checkExpression(this.target.expression, this.target.refId);
        this.expressionInvalid = !result.valid;
        this.target.expression = result.expression;
        if (!this.expressionInvalid) {
            this.panelCtrl.refresh();
        }
    }

    onSetValueKPI() {
        return this.datasource.metricUpdate_setValueKPI(this.target.source, [this.target], [32]);
    }
}

let createRegExp = (str) => {
    str = str.trim();
    let reg = null;
    try {
        if (/^\/[^\/]+\/(i|g|m|s)*/i.test(str)) { // 标准写法 /^.sd*$/ig
            let arr = str.split(/\//g).filter(x => !!x);
            if (arr.length == 2) {
                reg = new RegExp(arr[0], arr[1]);
            } else {
                reg = new RegExp(arr[0]);
            }
        } else if (/^[^\/]+/i.test(str)) { // 非标准写法，不加 / , .*M_FAE$
            reg = new RegExp(str)
        } else if (str) {
            reg = new RegExp(str);
        }
    } catch (err) {
        console.log(err);
    }
    return reg;
}

let checkExpression = (exp, replaceStr) => {
    let bool = true;
    let newExp = null;
    let result = formula.check(exp);
    if (!result.status) {
        let reg = formula.buildRegExp(formula.changeFuncToRegStr(result.codes), 'g');
        newExp = result.formula.replace(reg, replaceStr);
    } else if (!exp) {

    } else {
        bool = false;
    }

    return {
        valid: bool,
        expression: newExp
    }
}

String.prototype.trim = function () {
    return this.replace(/^\s+/, '').replace(/\s+$/, '');
}
GenericDatasourceQueryCtrl.templateUrl = 'partials/query.editor.html';
