<!--
 * @Author: NH
 * @Date: 2022-03-22 10:05:09
 * @LastEditTime: 2022-03-22 10:10:48
 * @Description: 
-->
# Ene Event Log Panel

## 在 1.04.001 版本上重构 Ene Alarm Panel

All notable changes to this project will be documented in this file.

## [1.04.001] - Mar 22,2022

### Support query SystemLog, SystemOperationLog, DeiceLog function of datasource

