## EnE-SimpleJson Datasource - a generic backend datasource

More documentation about datasource plugins can be found in the [Docs](https://github.com/grafana/grafana/blob/master/docs/sources/plugins/developing/datasources.md).

This also serves as a living example implementation of a datasource.

Your backend needs to implement 4 urls:

- `/` should return 200 ok. Used for "Test connection" on the datasource config page.
- `/searchGroup` used by the find GroupPath metric options on the query tab in panels.
- `/searchDeviceType` used by the find ObjectType metric options on the query tab in panels.
- `/searchDevice` used by the find Object metric options on the query tab in panels.
- `/searchDeviceParam` used by the find ObjectParam metric options on the query tab in panels.
- `/searchTimeInterval` used by the find TimeInterval metric options on the query tab in panels.
- `/searchDataType` used by the find DataType metric options on the query tab in panels.
- `/searchFunctionType` used by the find FunctionType metric options on the query tab in panels.
- `/searchDiscreteState` used by the find StateType metric options on the query tab in panels.
- `/searchGroup` used by the find GroupPath metric options on the query tab in panels.
- `/query` should return metrics based on input.
- `/annotations` should return annotations.

## Installation

To install this plugin using the `grafana-cli` tool:

```
sudo grafana-cli plugins install grafana-simple-json-datasource
sudo service grafana-server restart
```

See [here](https://grafana.com/plugins/grafana-simple-json-datasource/installation) for more information.

### Example backend implementations

- https://github.com/bergquist/fake-simple-json-datasource
- https://github.com/smcquay/jsonds

### Query API

Example `timeserie` request

```
{
  "panelId": 1,
  "range": {
    "from": "2016-10-31T06:33:44.866Z",
    "to": "2016-10-31T12:33:44.866Z",
    "raw": {
      "from": "now-6h",
      "to": "now"
    }
  },
  "rangeRaw": {
    "from": "now-6h",
    "to": "now"
  },
  "interval": "30s",
  "intervalMs": 30000,
  "targets": [
     { "target": "upper_50", "refId": "A", "type": "timeserie" },
     { "target": "upper_75", "refId": "B", "type": "timeserie" }
  ],
  "format": "json",
  "maxDataPoints": 550
}
```

Example `timeserie` response

```
[
  {
    "target":"upper_75", // The field being queried for
    "datapoints":[
      [622,1450754160000],  // Metric value as a float , unixtimestamp in milliseconds
      [365,1450754220000]
    ]
  },
  {
    "target":"upper_90",
    "datapoints":[
      [861,1450754160000],
      [767,1450754220000]
    ]
  }
]
```

If the metric selected is `"type": "table"`, an example `table` response:

```
[
  {
    "columns":[
      {"text":"Time","type":"time"},
      {"text":"Country","type":"string"},
      {"text":"Number","type":"number"}
    ],
    "rows":[
      [1234567,"SE",123],
      [1234567,"DE",231],
      [1234567,"US",321]
    ],
    "type":"table"
  }
]
```

### Annotation API

The annotation request from the Simple JSON Datasource is a POST request to the /annotations endpoint in your datasource. The JSON request body looks like this:

```
{
  "range": {
    "from": "2016-04-15T13:44:39.070Z",
    "to": "2016-04-15T14:44:39.070Z"
  },
  "rangeRaw": {
    "from": "now-1h",
    "to": "now"
  },
  "annotation": {
    "name": "deploy",
    "datasource": "Simple JSON Datasource",
    "iconColor": "rgba(255, 96, 96, 1)",
    "enable": true,
    "query": "#deploy"
  }
}
```

Grafana expects a response containing an array of annotation objects in the following format:

```
[
  {
    annotation: annotation, // The original annotation sent from Grafana.
    time: time, // Time since UNIX Epoch in milliseconds. (required)
    title: title, // The title for the annotation tooltip. (required)
    tags: tags, // Tags for the annotation. (optional)
    text: text // Text for the annotation. (optional)
  }
]
```

Note: If the datasource is configured to connect directly to the backend, you also need to implement an OPTIONS endpoint at /annotations that responds with the correct CORS headers:

```
Access-Control-Allow-Headers:accept, content-type
Access-Control-Allow-Methods:POST
Access-Control-Allow-Origin:*
```

### SearchGroup API

Example request

```
{ target: '' }
```

The search api can either return an array or map.

Example array response

```
["group1#123","child_plugin#20098#"]
```

### SearchDeviceType API

Example request

```
{ area: 'group1#123' }
```

The search api can either return an array or map.

Example array response

```
["pump"]
```

### SearchDevice API

Example request

```
{"area":"plugintest#20027#","devicetype":"pump"}
```

The search api can either return an array or map.

Example array response

```
["device1#21709#","device2#21710#"]
```

### SearchDeviceParam API

Example request

```
{"area":"plugintest#20027#","devicetype":"pump","device":"test#20037#"}
```

The search api can either return an array or map.

Example array response

```
["vol","temp"]
```

### SearchTimeInterval API

Example request

```
{ timeinterval: '' }
```

The search api can either return an array or map.

Example array response

```
[{"value":"sec","text":"Second"},{"value":"min","text":"Minute"},{"value":"hour","text":"Hour"},{"value":"day","text":"Day"},{"value":"month","text":"Month"},{"value":"year","text":"Year"}]
```

### SearchDataType API

Example request

```
{ datatype: '' }
```

The search api can either return an array or map.

Example array response

```
[{"value":"realtime","text":"RT"},{"value":"history","text":"HIS"},{"value":"history_avg","text":"HIS_AVG"},{"value":"history_max","text":"HIS_MAX"},{"value":"history_min","text":"HIS_MIN"},{"value":"cumulate","text":"ACCUM"}]
```

### SearchFunctionType API

Example request

```
{ functiontype: '' }
```

The search api can either return an array or map.

Example array response

```
["select function type","YoY","YoYTrend","alarmlog_record","efficiencyRatio","groupAvail","groupStatusDuration","groupStatusOccurrence","objAvail","objStatusDuration","objStatusOccurrence","objectsMonitor","ringRatio","verticalRatio","worldmap"]
```

### SearchDiscreteState API

Example request

```
{"area":"plugintest#20027#","devicetype":"select device type","device":"test#20037#","deviceparam":"const1"}
```

The search api can either return an array or map.

Example array response

```
[{"value":"atype","text":"atype"}]
```

### SearchSetValue API

Example request

```
{ targets: [{device:'dev',deviceparam:'a'}] ,tagvalues:'123'}
```

The search api can either return an array or map.

Example array response

```
[{code:200001,message:'SetValue OK'}]
```

### Dev setup

This plugin requires node 6.10.0

```
npm install -g yarn` `yarn install` `npm run build
```

### If using Grafana 2.6

NOTE! for grafana 2.6 please use [this version](https://github.com/grafana/simple-json-datasource/commit/b78720f6e00c115203d8f4c0e81ccd3c16001f94)

Copy the data source you want to /public/app/plugins/datasource/. Then restart grafana-server. The new data source should now be available in the data source type dropdown in the Add Data Source View.