# Changelog
All notable changes to this project will be document in this file.
advantech-dash-video-panel

## [1.0.4] - Aug 11, 2020
### Bug Fix
- default image position is already center

## [1.0.3] - Jan 09, 2020
### New Feature
- Add descriptor -> id corresponds to text padding
- Add multi language title label
### Bug Fix
- tweak Display UI position
- hide descriptor when descriptor length not enough

## [1.0.2] - Oct 18, 2019
### Bug Fix
- Fix data assign error
- Remove show error when create

## [1.0.1] - Sep 6, 2019
### New Feature
- Add columns for value mapping as title
- Add columns for color mapping
- Add function for color gradient

## [1.0.0] - Aug 22, 2019
### New Feature
- Add columns for uploading pictures & adjusting the position of pictures
- Add columns for chosing datasource 
- Add columns for title setting
- Add scroll bar in display place