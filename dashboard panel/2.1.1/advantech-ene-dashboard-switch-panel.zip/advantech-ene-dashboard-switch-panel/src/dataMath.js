import _ from 'lodash';
import moment from 'moment';

var units = ['y', 'M', 'w', 'd', 'h', 'm', 's'];

const langMappingList = [
    { name: '简体中文', value: ['zh-CN', 'zh_cn'], key: 'zh_cn' },
    { name: '繁體中文', value: ['zh-TW', 'zh_tw'], key: 'zh_tw' },
    { name: 'English', value: ['en-US', 'en', ''], key: 'en' },
    { name: '日本語', value: ['ja-JP', 'ja'], key: 'ja' },
    { name: 'Español', value: ['es-ES', 'es_es'], key: 'es_es' }, //西班牙语
    { name: '한국어', value: ['ko-KR', 'ko_kr'], key: 'ko_kr' }, //韩语
    { name: 'ไทย', value: ['th-TH', 'th_th'], key: 'th_th' }, // 泰语
    { name: 'Tiếng Việt', value: ['vi-VN', 'vi_vn'], key: 'vi_vn' }, // 越南语
    { name: 'Melayu', value: ['ms-MY', 'ms_my'], key: 'ms_my' }, // 马来语
    { name: 'Indonesia.', value: ['id-ID', 'id_id'], key: 'id_id' }, // 印度尼西亚
    { name: 'Nederlands', value: ['nl-NL', 'nl_nl'], key: 'nl_nl' }, // 荷兰语
    { name: 'Português', value: ['pt-PT', 'pt_pt'], key: 'pt_pt' }, // 葡萄牙语
    { name: 'français', value: ['fr-FR', 'fr_fr'], key: 'fr_fr' }, // 法语
    { name: 'Deutsche', value: ['de-DE', 'de_de'], key: 'de_de' }, // 德语
    { name: 'Suomalainen', value: ['fi-FI', 'fi_fi'], key: 'fi_fi' }, // 芬兰语
    { name: 'dansk', value: ['da-DK', 'da_dk'], key: 'da_dk' }, // 丹麦语
    { name: 'русский', value: ['ru-RU', 'ru_ru'], key: 'ru_ru' }, // 俄语
    { name: 'italiano', value: ['it-IT', 'it_it'], key: 'it_it' }, // 意大利语
    { name: 'Ελληνικά', value: ['el-GR', 'el_gr'], key: 'el_gr' }, // 希腊语
];
export function getLangType(lang){
    let langType = 'en';
    langMappingList.forEach(x => {
        if (-1 !== x.value.indexOf(lang)) {
            langType = x.key;
            return;
        }
    });
    return langType;
}
export function isMathString(text) {
    if (!text) {
        return false;
    }

    if (typeof text === 'string' && (text.substring(0, 3) === 'now' || text.includes('||'))) {
        return true;
    } else {
        return false;
    }
}

export function parse(text, roundUp) {
    if (!text) { return undefined; }
    if (moment.isMoment(text)) { return text; }
    if (_.isDate(text)) { return moment(text); }

    var time;
    var mathString = '';
    var index;
    var parseString;

    if (text.substring(0, 3) === 'now') {
        time = moment();
        mathString = text.substring('now'.length);
    } else {
        index = text.indexOf('||');
        if (index === -1) {
            parseString = text;
            mathString = ''; // nothing else
        } else {
            parseString = text.substring(0, index);
            mathString = text.substring(index + 2);
        }
        // We're going to just require ISO8601 timestamps, k?
        time = moment(parseString, moment.ISO_8601);
    }

    if (!mathString.length) {
        return time;
    }

    return parseDateMath(mathString, time, roundUp);
}

export function isValid(text) {
    var date = parse(text);
    if (!date) {
        return false;
    }

    if (moment.isMoment(date)) {
        return date.isValid();
    }

    return false;
}

export function parseDateMath(mathString, time, roundUp) {
    var dateTime = time;
    var i = 0;
    var len = mathString.length;

    while (i < len) {
        var c = mathString.charAt(i++);
        var type;
        var num;
        var unit;

        if (c === '/') {
            type = 0;
        } else if (c === '+') {
            type = 1;
        } else if (c === '-') {
            type = 2;
        } else {
            return undefined;
        }

        if (isNaN(mathString.charAt(i))) {
            num = 1;
        } else if (mathString.length === 2) {
            num = mathString.charAt(i);
        } else {
            var numFrom = i;
            while (!isNaN(mathString.charAt(i))) {
                i++;
                if (i > 10) { return undefined; }
            }
            num = parseInt(mathString.substring(numFrom, i), 10);
        }

        if (type === 0) {
            // rounding is only allowed on whole, single, units (eg M or 1M, not 0.5M or 2M)
            if (num !== 1) {
                return undefined;
            }
        }
        unit = mathString.charAt(i++);

        if (!_.includes(units, unit)) {
            return undefined;
        } else {
            if (type === 0) {
                if (roundUp) {
                    dateTime.endOf(unit);
                } else {
                    dateTime.startOf(unit);
                }
            } else if (type === 1) {
                dateTime.add(num, unit);
            } else if (type === 2) {
                dateTime.subtract(num, unit);
            }
        }
    }
    return dateTime;
}

