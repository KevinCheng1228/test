# Changelog

All notable changes to this project will be documented in this file.

------------------ Report -----------------------

## 1.0.3 - Feb 14,2022

* support reportMerged function (currently support reportAnalogBasic and reportMerged functions)
* clear cookie duplicate ReportToken key

## [1.0.2] - Jan 01,2022

* css name fix
* all multilang add and update
* fix report input update
* subtitle hide fix
* fix image type select and page change
* label and error follow systemLang changes

------------------ Datatable -----------------------

## [1.2.6] - 2021-11-1

bug

## [1.2.5] - Oct 18,2021

bug

## [1.2.4] - Oct 14,2021

优化一天时间间隔显示

## [1.2.3] - Oct 14,2021

remove table to row;
add time to row

## [1.2.2] - Oct 11,2021

table to row

## [1.2.1] - Sep 15,2021

bug 的修改

## [1.2.0] - Sep 13,2021

bug 的修改

## [1.1.79] - Sep 12,2021

系统多语言

## [1.1.78] - August 13,2021

value mapping 和 text mapping 新增 panel 多语言

## [1.1.77] - August 10,2021

浅色主题 title 文字颜色和分割栏颜色

## [1.1.76] - July 13,2021

bug

## [1.1.75] - Jun 30,2021

固定表头

## [1.1.74] - Jun 28,2021

Add Reset Value Dialog

## [1.1.73] - Jun 25,2021

合并列标题样式

## [1.1.72] - Jun 22,2021

column style 支持按照 index 设置

## [1.1.71] - Jun 15,2021

针对 x 行列的添加 url

## [1.1.70] - Jun. 1,2021

Change Bar Style
Add Operation Setting
Reset Value

## [1.1.69] - May 19,2021

阈值可以加等号

## [1.1.68] - May 13,2021

标题加粗设置

## [1.1.67] - May 11,2021

bug

## [1.1.66] - May 8,2021

bug

## [1.1.65] - April 29,2021

row postfix prefix alarm

## [1.1.64] - April 25,2021

bug

## [1.1.63] - April 23,2021

bug

## [1.1.62] - April 23,2021

bug

## [1.1.61] - April 14,2021

calculate bug

## [1.1.60] - April 13,2021

3.0 新样式

## [1.1.59] - Mar 31,2021

分割条 bug

## [1.1.58] - Mar 30,2021

alarm bug

## [1.1.57] - Mar 19,2021

新增 status 样式,新增日期显示样式。

## [1.1.56] - Mar 17,2021

bug

## [1.1.55] - Mar 9,2021

bug

## [1.1.54] - Mar 8,2021

bug

## [1.1.53] - Mar 5,2021

datatable 优化：阈值新增 alarm，表头合并新增根据第几列合并。
Requirement #18081,Bug #17840。

## [1.1.52] - Feb 2,2021

Bug #17239

## [1.1.51] - Dec 16,2020

Bug #17832

## [1.1.50] - Dec 15,2020

bug

## [1.1.49] - Dec 4,2020

bug

## [1.1.48] - Dec 3,2020

bug #17664 多语言报错

## [1.1.47] - Dec 2,2020

Requirement #17664 行与列的阈值支持变量

## [1.1.46] - Nov 30,2020

Column Styles string 类型新增 color mappings

## [1.1.45] - Nov 27,2020

新增时间阈值

## [1.1.44] - Nov 26,2020

Bug #17490 设置合并列后，新增列，然后删除设置合并的列，新增列的标题显示跑到了上面

## [1.1.43] - Nov 23,2020

Bug #17290 隐藏 datatable 标题，然后点击 add filter 会被标题遮挡，无法点击
Bug #17289 添加多个 query，点击 add a filter，Column name 没有显示全所有的列名
Bug #15671 Table Transform 选择 Time series aggregations，在 Columns 处添加聚合列，添加一个后，再添加没有提示
Bug #17221 将列设置为居中，但是标题没有居中，不会随着列设置改变

## [1.1.42] - Nov 16,2020

### row cells bug

## [1.1.41] - Nov 13,2020

### row threshold bug

## [1.1.40] - Nov 13,2020

### more row cells

## [1.1.39] - Nov 11,2020

### row threshold

## [1.1.38] - Nov 11,2020

### 初始化多语言时字段不对

## [1.1.37] - Nov 10,2020

### 升级上来，datatable 无法显示，且控制台伴有报错

## [1.1.36] - Oct 16,2020

### 合并列 name 多语言，status name 多语言

## [1.1.35] - Sep 17,2020

### requirement panel display 和 url 等字段实现多语言

## [1.1.34] - Sep 17,2020

### requirement panel 初始化时存入当前语言的国际化字段值

## [1.1.33] - Sep 11,2020

### Bug #17221

## [1.1.32] - Sep 1,2020

### requirement panel 多语言

## [1.1.31] - Jun 31,2020

### header css

## [1.1.30] - Jun 27,2020

### table header bug

## [1.1.29] - Jun 21,2020

### 调整 table 的头部

## [1.1.28] - Jun 2,2020

### #16119

## [1.1.27] - June 30,2020

### #16818 #16801 #16668

## [1.1.26] - June 19,2020

### #16887 可以增加按钮来满足 panel 比较小的时候可以选择文字竖向排列和不排列的情况

## [1.1.25] - May 27,2020

### bug 去掉代码里的 alert，alert 改为由 dashboard 控制

## [1.1.24] - May 07,2020

### bug 16563 16588

## [1.1.23] - Apr 27,2020

### 添加 no Data to show 时显示内容从配置文件中读取

## [1.1.22] - Apr 06,2020

### 16438 当列设置为 transparent 时，列的内容显示为竖列显示

## [1.1.21] - Apr 06,2020

### Fix above bug when column styles's type use array and as bar is true

### Fix maximum text error

### Fix current text error

### Fix current value over max value lead bar overflow column

### Fix current value more than secondThreshold, bar that is second color has error length

### Tweak cell width

## [1.1.20] - Mar 30,2020

### 修复 panel title 在影藏模式下显示不正确的 bug

## [1.1.19] - Mar 27,2020

### 修复行号列会换行显示 bug

## [1.1.18] - Mar 24,2020

### 16340

## [1.1.17] - Mar 17,2020

### 16334

## [1.1.16] - Feb 26,2020

### 16286 16287

## [1.1.15] - Fub 10,2020

### 16259

## [1.1.14] - Jan 7,2020

### 15809

## [1.1.13] - Dec 26,2019

### 15809

## [1.1.12] - Dec 25,2019

### search status

## [1.1.11] - Dec 23,2019

### table math 15847，15846

## [1.1.10] - Dec 23,2019

### srp click link

## [1.1.9] - Dec 20,2019

### add status and bug

## [1.1.8] - Dec 16,2019

### float math tooltip bug

## [1.1.7] - Dec 13,2019

### add merging column bug

## [1.1.6] - Dec 10,2019

### search

### 16003

### add merging column bug

## [1.1.5] - Nov 20,2019

### 15850

## [1.1.4] - Nov 18,2019

### 15884 15652 15842 15841

## [1.1.3] - Nov 16,2019

### 15835 15832

## [1.1.2] - Nov 14,2019

### Fixed 15672 15652

## [1.1.1] - Nov 13,2019

### Fixed 15360

## [1.1.0] - Oct 9,2019

### New Feature

* Restructure
* Status Lamp
* Row Styles Thresholds Status
* Add Columns

## [1.0.55] - Sep 12,2019

### Fixed

* Modified panel id

## [1.0.54] - Sep 12,2019

### Fixed

* Fix default setting of column
* Fix the problem of array configuration and showing value

## [1.0.53] - Aug 22,2019

### New Feature

* Added two types include string with url and array with progress bar
* Fixed bug includes double trigger, color of value and weight of Status font
* Threshold color setting for Progress bar
* Add URL link and Icon option in String

### Fixed

* Fix types remain error

## [1.0.52] - Aug 21,2019

### New Feature

* Fix #14464 add status function in Column Style

## [1.0.51] - July 29,2019

### New Feature

* remove datasourceType attr for unsaved changed problem

## [1.0.50] - July 22,2019

### New Feature

* Enable datetime function to supoort null value

## [1.0.49] - July 11,2019

### Fixed

* Fix #15057
* Fix #15055

## [1.0.48] - July 10,2019

### New Feature

* Add null and zero value display for date time format

### Fixed

* Fix #15008
* Fix #15034
* Fix #15024

## [1.0.47] - June 26,2019

### New Feature

* Add Status function to Time series aggregations mode

## [1.0.46] - June 26,2019

### New Feature

* Add Threshold function to RowStyle Tab

## [1.0.45] - June 19,2019

### New Feature

* Support for variable,decimal calculate

## [1.0.44] - May 29,2019

### New Feature

* Add link support open in new tab

## [1.0.43] - April 26,2019

### Fixed

* Fix #14510

## [1.0.42] - April 23,2019

### New Feature

* Import fontsize ts

## [1.0.41] - Mar 28,2019

### Fixed

* Delete panel json datapoints

## [1.0.40] - Mar 27,2019

### Fixed

* Fix edit value to edge api route.

## [1.0.39] - Mar 20,2019

### New Feature

* support No Match ponits Metrics Calculate

## [1.0.38] - Mar 14, 2019

### New Feature

�U�� Datatable ���ܣ�����֧Ԯ�@ʾ��ͬ timestamp �Y��

## [1.0.37] - Feb 25, 2019

### Fixed

* Metrics calculate bugs fix

## [1.0.36] - Feb 22, 2019

### Fixed

* Status support column style, only for column header, column width, align

## [1.0.35] - Feb 21, 2019

### New Feature

* support Metrics Calculate

## [1.0.34] - Feb 12, 2019

### New Feature

* support alert

## [1.0.33] - Jan 18, 2019

### New Feature

* Requirement: #12046, #12075
* #12046: Column name filter
* #12075: Duplicate column name & row number warning
* Modified row number default value

## [1.0.32] - Jan 16, 2019

### Modified

* columnStyleModufy (Commit by li.na, merge by Zhou.min, changelog add by Michelle)

## [1.0.31] - Dec 6, 2018

### Fixes

* url link \__cell_

## [1.0.30] - Nov 30, 2018

### Fixes

* url link Variable

## [1.0.29] - Nov 26, 2018

### New Feature

* add Custom Colume Data

## [1.0.28] - Oct 25, 2018

### Fixes

* fixed #12676(link with thresholds)

## [1.0.27] - Oct 24, 2018

### Revert

* Revert iswisepaas sign
* fixed author

## [1.0.26] - Oct 23, 2018

### New Feature

* add Math Expression

## [1.0.25] - Oct 16, 2018

### Fixes

* fixed 12446(link color), 12449(row style color), 12646(link & status)

## [1.0.24] - Oct 16, 2018

### Fixes

* fixed 12448 (default table), 12354(stripped)

### New Feature

* Add reset color button for odd and even row

## [1.0.23] - Oct 15, 2018

### Fixes

* fixed 12424(search), 12361(order)

## [1.0.22] - Oct 03, 2018

### Fixes

* fixed 12438, 12415

## [1.0.21] - Sep 29, 2018

### New Feature

* add iswisepaas sign

## [1.0.20] - Sep 28, 2018

### Fixes

* fixed 12363, 12413, 12157

## [1.0.19] - Sep 03, 2018

### Fixes

* fixed 12207

## [1.0.18] - Aug 27, 2018

### Fixes

* fixed 12203, 12074

## [1.0.17] - Aug 24, 2018

### Fixes

* fixed 12165, 12159

## [1.0.16] - Aug 23, 2018

### Fixes

* fixed 12163, 12164, 12166

## [1.0.15] - Aug 23, 2018

### Fixes

* fixed 12161, 12160

## [1.0.14] - Aug 21, 2018

### Fixes light, and dark themes

* fix light, and dark css

## [1.0.13] - Aug 17, 2018

### Fixes

* fix 12157, 12155, 12156

## [1.0.12] - Aug 16, 2018

### New Feature

* Add column style and row style tab (12057)

## [1.0.11] - Aug 13, 2018

### New Feature

* set value from input box by scada api, only available for sso-scada-simple-json datasource.

## [1.0.10] - Aug 10, 2018

### New Feature

* code obfuscation and compress

## [1.0.9] - 2018-08-09

### Fixes

* fix 12080, 12084, 12082, search and status function refactoring, 12047, 12083

## [1.0.8] - 2018-08-07

### Fixes

* fix 12058, 12060, 12032, 12031

## [1.0.7] - 2018-08-06

### Fixes

* fix #12055, #12052

## [1.0.6] - 2018-08-06

### Fixes

* fix #12043

## [1.0.5] - 2018-07-30

### Fixes

* fix column hidden function.

## [1.0.4] - 2018-07-27

### Fixes

* fix sort column change odd/even row color which has set.

## [1.0.3] - 2018-07-24

### Fixes

* support style setting for table option in table transform.

## [1.0.2] - 2018-07-11

### Fixes

* fix sanitized HTML to add link

## [1.0.1] - 2018-07-02

### New Feature

* Change log
* font color can be defined when user change to status mode.

### Changed

* change previos and next buttom into icon

### Fixes

* data source can't be sort as query order
