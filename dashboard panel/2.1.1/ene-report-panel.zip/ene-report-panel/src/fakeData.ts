const fakeData = [
  {
    type: 'table',
    columns: [
      {sqltype: 'int', text: 'devid', type: 'number'},
      {sqltype: 'str', text: 'objectname', type: 'string'},
      {sqltype: 'str', text: 'paramname', type: 'string'},
      {sqltype: 'array', text: 'objruntime', type: 'array'},
      {sqltype: 'int', text: 'almstat', type: 'number'},
      {sqltype: 'int', text: 'status', type: 'number'},
    ],
    rows: [
      [307, 'AirBlower', 'RunTime', ['10', '100', '10', '20'], 2, 0],
      [307, 'AirBlower', 'RunTime', ['100', '100', '10', '20'], 2, 0],
      [247, 'InflowWaterPumprrr', 'RunTime', ['20', '100', '10', '20'], 2, 0],
      [247, 'InflowWaterPumprrr', 'RunTime', ['20', '100', '10', '20'], 2, 0],
      [305, 'testTagName630', 'RunTime', ['30', '100', '10', '20'], 2, 0],
      [248, 'InflowWaterPumpgggg', 'RunTime', ['50', '100', '10', null], 2, 0],
      [239, 'PP01', 'RunTime', ['70', '100', null, '50'], 2, 1],
      [
        306,
        'testTagName6302',
        'RunTime',
        ['187200', '216000.00', '144000', '187200'],
        2,
        0,
      ],
      [
        309,
        'tagNameTest6303',
        'RunTime',
        ['444311.0', '216000.00', '144000', '187200'],
        2,
        0,
      ],
      [75, 'AirBlower', 'RunTime', ['84841.0', '216000.00', '144000', '187200'], 0, 3],
      [296, 'AirBlower3', 'RunTime', ['458374.0', '216000.00', '144000', '187200'], 2, 0],
      [77, 'InflowWaterPump', 'RunTime', ['0.0', '216000.00', '144000', '187200'], 0, 1],
      [295, 'AirBlower2', 'RunTime', ['0.0', '216000.00', '144000', '187200'], 0, 0],
    ],
    time: '29ms',
  },
];

export default fakeData;
