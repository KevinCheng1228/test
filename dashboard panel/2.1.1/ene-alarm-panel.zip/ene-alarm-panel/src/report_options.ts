///<reference path="../node_modules/grafana-sdk-mocks/app/headers/common.d.ts" />

import _ from 'lodash';
import kbn from 'app/core/utils/kbn';
import { getMultiLang } from './multilang';

export class ReportOptionsCtrl {
    panel: any;
    panelCtrl: any;
    

    /** @ngInject */
    constructor($scope) {
        $scope.editor = this;

        this.panelCtrl = $scope.ctrl;
        this.panel = this.panelCtrl.panel;
    }

    resetReportButton() {
        this.panel.reportBtnText = '';
        this.panel.reportBtnTextColor = '';
        this.panel.reportBtnBgColor = '';

        this.render();
    }

    getMultiLang(key) {
        return getMultiLang(key, this.panel.langType);
    }

    render() {
        this.panelCtrl.render();
    }
}

/** @ngInject */
export function reportOptionsTab($q, uiSegmentSrv) {
    'use strict';
    return {
        restrict: 'E',
        scope: true,
        templateUrl: 'public/plugins/ene-alarm-panel/partials/report_options.html',
        controller: ReportOptionsCtrl,
    };
}
