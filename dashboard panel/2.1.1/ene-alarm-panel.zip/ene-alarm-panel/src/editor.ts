///<reference path="../node_modules/grafana-sdk-mocks/app/headers/common.d.ts" />
import _ from 'lodash';
import { transformers, transformCondition } from './transformers';
import ChangeFont from './fontsize';
import { getMultiLang } from './multilang';

export class TablePanelEditorCtrl {
    panel: any;
    panelCtrl: any;
    transformers: any;
    fontSizes: any;
    addColumnSegment: any;
    getColumnNames: any;
    canSetColumns: boolean;
    columnsHelpMessage: string;
    conditionset: any;
    filterMsg: string;
    searchName: string;

    /** @ngInject */
    constructor($scope, private $q, private uiSegmentSrv) {
        $scope.editor = this;
        this.panelCtrl = $scope.ctrl;
        this.panel = this.panelCtrl.panel;
        this.transformers = transformers;
        this.fontSizes = ChangeFont.defaultValues;
        this.searchName = '--selected--';
        this.addColumnSegment = uiSegmentSrv.newPlusButton();
        this.updateTransformHints();
        this.conditionsetRender();
    }

    getMultiLang(key) {
        return getMultiLang(key, this.panel.langType);
    }

    updateTransformHints() {
        this.canSetColumns = false;
        this.columnsHelpMessage = '';

        switch (this.panel.transform) {
            case 'timeseries_aggregations': {
                this.canSetColumns = true;
                break;
            }
            case 'json': {
                this.canSetColumns = true;
                break;
            }
            case 'table': {
                this.columnsHelpMessage =
                    this.getMultiLang('columnsHelpMessage');
            }
        }
    }

    conditionsetRender() {
        this.conditionset = [];
        if (this.panel.conditionset) {
            for (let i = 0; i < this.panel.conditionset.length; i++) {
                const condition = this.panel.conditionset[i];
                this.conditionset.push(condition);
            }
        }
    }

    searchNameChange() {
        if (this.searchName === '--selected--') {
            return;
        }
        const search: any = {};
        search.label = this.searchName;
        search.inputType = 'string';
        search.condition = 'has';
        search.title = this.searchName;
        search.text = '';
        this.conditionset.push(search);

        this.searchName = '--selected--';
    }

    removeSearch(search) {
        this.filterMsg = '';
        this.conditionset = _.without(this.conditionset, search);
        this.panel.conditionset = _.without(this.conditionset, search);
        this.render();
    }

    searchFilter() {
        this.filterMsg = '';
        if (this.conditionset.length === 0) {
            return;
        }
        for (let i = 0; i < this.panel.conditionset.length; i++) {
            const condition = this.panel.conditionset[i];
            if (!condition.label || !condition.condition || !condition.inputType) {
                this.filterMsg = this.getMultiLang('filterMsg');
            }
            break;
        }

        if (this.filterMsg) {
            return;
        }

        this.panel.conditionset = this.conditionset;
        this.render();
    }

    getColumnOptions() {
        if (!this.panelCtrl.dataRaw) {
            return this.$q.when([]);
        }
        const columns = this.transformers[this.panel.transform].getColumns(
            this.panelCtrl.dataRaw
        );
        const segments = _.map(columns, (c: any) =>
            this.uiSegmentSrv.newSegment({ value: c.text })
        );
        return this.$q.when(segments);
    }

    addColumn() {
        const columns = transformers[this.panel.transform].getColumns(this.panelCtrl.dataRaw);
        const column = _.find(columns, { text: this.addColumnSegment.value });

        if (column) {
            this.panel.columns.push(column);
            this.render();
        }

        const plusButton = this.uiSegmentSrv.newPlusButton();
        this.addColumnSegment.html = plusButton.html;
        this.addColumnSegment.value = plusButton.value;
    }

    transformChanged() {
        this.panel.columns = [];
        if (this.panel.transform === 'timeseries_aggregations') {
            this.panel.columns.push({ text: 'Avg', value: 'avg' });
        }
        this.updateTransformHints();
        this.render();
    }

    render() {
        this.panel.targets[0].mapCardJson = {
            page: this.panelCtrl.pageIndex + 1 || 1,
            pageSize: this.panel.pageSize || 10,
            conditionset: transformCondition(this.panel.conditionset)
        }
        this.panelCtrl.refresh();
    }

    removeColumn(column) {
        this.panel.columns = _.without(this.panel.columns, column);
        this.panelCtrl.render();
    }

    searchcontrol() {
        if (this.panel.searchcontrol == 'down') {
            this.panel.searchcontrol = 'up';
        } else {
            this.panel.searchcontrol = 'down';
            this.panelCtrl.clickDom = null;
        }

        this.conditionsetRender();
        this.render();
    }
    onColorChange(index) {
        return newColor => {
            let sindex = this.panel.styles.findIndex(x => { return x.colorMode == 'status' });
            if (sindex !== -1) {
                let style = this.panel.styles[sindex];
                let cindex = style.thresholds.indexOf(this.panel.statusNumList[index].value);
                cindex !== -1 && (style.colors[cindex] = newColor);
            }
            this.panel.statusNumList[index].color = newColor;
            this.render();
        };
    }
    onFontColorChange(index) {
        return newColor => {
            let sindex = this.panel.styles.findIndex(x => { return x.colorMode == 'status' });
            if (sindex !== -1) {
                let style = this.panel.styles[sindex];
                if (!style.fontColors) {
                    let dindex = this.panelCtrl.panelDefaults.styles.findIndex(x => { return x.colorMode == 'status' && x.type == 'button' });
                    dindex !== -1 && (style.fontColors = this.panelCtrl.panelDefaults.styles[dindex].fontColors);
                }
                let cindex = style.thresholds.indexOf(this.panel.statusNumList[index].value);
                cindex !== -1 && (style.fontColors[cindex] = newColor);
            }
            this.panel.statusNumList[index].fontColor = newColor;
            this.render();
        };
    }
}

/** @ngInject */
export function tablePanelEditor($q, uiSegmentSrv) {
    'use strict';
    return {
        restrict: 'E',
        scope: true,
        templateUrl: 'public/plugins/ene-alarm-panel/partials/editor.html',
        controller: TablePanelEditorCtrl,
    };
}
