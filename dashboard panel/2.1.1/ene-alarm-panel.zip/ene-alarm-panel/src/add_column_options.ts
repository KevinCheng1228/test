///<reference path="../node_modules/grafana-sdk-mocks/app/headers/common.d.ts" />
import _ from 'lodash';
import { getMultiLang } from './multilang';

export class AddColumnOptionsCtrl {
    panel: any;
    panelCtrl: any;
    addBtn: boolean;
    rowContentIdex: number;
    rowTypes: any;

    /** @ngInject */
    constructor($scope) {
        $scope.addColEditor = this;

        this.panelCtrl = $scope.ctrl;
        this.panel = this.panelCtrl.panel;
        this.addBtnStatus();

        this.rowContentIdex = 0;
        this.rowTypes = [{ text: 'Text', value: 'text' }, { text: 'Status', value: 'status' }];
    }
    getMultiLang(key) {
        return getMultiLang(key, this.panel.langType);
    }

    render() {
        this.panelCtrl.render();
    }

    addBtnStatus() {
        if (this.panel.customColumns.length > 0) {
            this.addBtn = false;
        } else {
            this.addBtn = true;
        }
    }

    addNewCol() {
        const customColumns = this.panel.customColumns;
        this.panel.activeCustomColumnIndex = customColumns.length;
        const newCol = {
            type: 'custom',
            pattern: 'New Column' + (customColumns.length + 1),
            colContentIndex: 0,
            rowContents: [
                {
                    rowType: 'text',
                    rowNumber: 1,
                    rowContent: 'Content',
                    rowStatus: null,
                },
            ],
        };

        this.panel.customColumns.push(newCol);
        this.addBtn = false;
        this.render();
    }

    removeCol(col) {
        this.panel.customColumns = _.without(this.panel.customColumns, col);
        this.panel.activeCustomColumnIndex = this.panel.customColumns.length - 1;
        this.addBtnStatus();
        this.render();
    }

    rowTypeChange(rowContent) {
        if (rowContent.rowType === 'text') {
            rowContent.rowStatus = null;
        } else if (rowContent.rowType === 'status') {
            rowContent.rowStatus = {
                columnNo: 1,
                opType: 'number',
                operator: '=',
                opValue: '',
                showCondition: false,
            };
        }

        this.render();
    }

    addNewRowContent(col) {
        const rowContent = col.rowContents;
        col.colContentIndex = rowContent.length;
        const newContent = {
            rowNumber: rowContent.length + 1,
            rowContent: 'Content',
            rowType: 'text',
            rowStatus: null,
        };
        rowContent.push(newContent);
        this.render();
    }

    removeContent(content, col) {
        col.rowContents = _.without(col.rowContents, content);
        col.colContentIndex = col.rowContents.length - 1;
        this.render();
    }
}

/** @ngInject */
export function addColumnOptionsTab($q, uiSegmentSrv) {
    'use strict';
    return {
        restrict: 'E',
        scope: true,
        templateUrl:
            'public/plugins/ene-alarm-panel/partials/add_column_options.html',
        controller: AddColumnOptionsCtrl,
    };
}
