///<reference path="../node_modules/grafana-sdk-mocks/app/headers/common.d.ts" />

import _ from 'lodash';
import moment from 'moment';
import kbn from 'app/core/utils/kbn';
import $ from 'jquery';
import {PanelCtrl} from 'app/plugins/sdk';
import appEvents from 'app/core/app_events';
import languageData from './languageData';

export class TableRenderer {
  formatters: any[];
  colorState: any;

  constructor(
    private panel,
    private table,
    private isUtc,
    private sanitize,
    private templateSrv,
    private lightTheme,
    private dataRaw
  ) {
    this.initColumns();
  }

  setTable(table) {
    this.table = table;

    this.initColumns();
    this.initMergeTitle();
  }

  getText(merge: any) {
    let displyText = this.templateSrv.replace(merge.name, this.panel.scopedVars);

    if (merge.target) {
      for (let i = 0; i < this.dataRaw.length; i++) {
        const data = this.dataRaw[i];
        if (data.target === merge.target) {
          if (merge.dataType === 'timeseries') {
            if (data.datapoints && data.datapoints[0]) {
              displyText = data.datapoints[0][0];
            }
          } else if (merge.dataType === 'table') {
            if (data.rows && data.rows[0]) {
              displyText = data.rows[0][0];
            }
          }
          break;
        }
      }
    }

    return displyText;
  }

  initMergeTitle() {
    if (this.panel.mergeColums.length === 0) {
      this.table.mergecolumns = [];
      return;
    }

    const tableColumns = [];

    for (let i = 0; i < this.table.columns.length; i++) {
      const column = this.table.columns[i];
      column.hidden = column.style.type === 'hidden' ? true : false;
      if (column.text.indexOf('.') === -1) {
        // prvent table column display async with stley
        column.title = column.style.alias !== '' ? column.style.alias : column.title
        column.type = column.style.type
      }
      if (column.hidden || (column.style && column.style.type === 'hidden')) {
        continue;
      }
      const style = {
        name: column.text,
        display: column.title,
        type: '',
        rowspan: 2,
        colspan: 1,
        merge: 'no',
      };

      if (column.style && column.style.type) {
        style.type = column.style.type;
      }

      tableColumns.push(style);
    }

    if (tableColumns.length === 0) {
      return;
    }

    const mergeNums = [];
    for (let i = 0; i < this.panel.mergeColums.length; i++) {
      const merge = this.panel.mergeColums[i];
      let startNum = null;
      let endNum = null;
      const displyText = this.getText(merge);
      if (this.panel.mergeType === 'indexNum') {
        if (merge.start && merge.end) {
          mergeNums.push({
            name: displyText,
            startNum: parseInt(merge.start) - 1,
            endNum: parseInt(merge.end) - 1,
          });
        }
      } else {
        for (let j = 0; j < tableColumns.length; j++) {
          if (
            tableColumns[j].display === merge.start ||
            tableColumns[j].name === merge.start
          ) {
            startNum = j;
          }

          if (
            tableColumns[j].display === merge.end ||
            tableColumns[j].name === merge.end
          ) {
            endNum = j;
          }
        }
      }

      if (startNum !== null && endNum !== null) {
        mergeNums.push({name: displyText, startNum: startNum, endNum: endNum});
      }
      startNum = null;
      endNum = null;
    }
    const sortMergeNums = _.sortBy(mergeNums, 'startNum');
    if (sortMergeNums.length === 0) {
      return;
    }

    let beforeHowmany = 0;

    for (let i = 0; i < sortMergeNums.length; i++) {
      const startNum = sortMergeNums[i].startNum;

      const howmany = sortMergeNums[i].endNum - startNum + 1;
      const mergeCol = {
        name: sortMergeNums[i].name,
        rowspan: 1,
        colspan: howmany,
        merge: 'yes',
      };
      tableColumns.splice(startNum - beforeHowmany, howmany, mergeCol);
      beforeHowmany = beforeHowmany + howmany - 1;
    }
    this.table.mergecolumns = _.uniqBy(tableColumns, 'name');
    if (!this.panel.mergeBottom) {
      for (let i = 0; i < this.table.columns.length; i++) {
        const col = this.table.columns[i];
        for (let j = 0; j < this.table.mergecolumns.length; j++) {
          const merge = this.table.mergecolumns[j];
          if (col.title === merge.name) {
            if (merge.merge === 'no') {
              col.isNoMergeTitle = true;
            } else {
              col.isNoMergeTitle = false;
            }
          }
        }
      }
    }
  }

  setIndexStyle(column, style, regex) {
    column.style = style;
    if (style.alias) {
      regex === 'index'
        ? (column.title = style.alias)
        : (column.title = column.text.replace(regex, style.alias));
    }
    if (style.type === 'transparent') {
      column.title = '';
    }
  }

  initColumns() {
    this.formatters = [];
    this.colorState = {};

    //status and custom
    this.removeCols();
    this.pushCustomCol();

    for (let colIndex = 0; colIndex < this.table.columns.length; colIndex++) {
      const column = this.table.columns[colIndex];
      // column.title = column.text;
      const text = column.text;
      if (this.panel.headerDateFormats && moment(parseInt(text)).isValid()) {
        moment.locale('en');
        const dateText = moment(parseInt(text));
        if (this.isUtc) {
          column.title = dateText.utc();
        }
        let date = moment(dateText);
        column.title = date.format(this.panel.headerDateFormats);
      }

      for (let i = 0; i < this.panel.styles.length; i++) {
        const style = this.panel.styles[i];
        const regex = kbn.stringToJsRegex(style.pattern);
        let patternIndex = null;

        if (style.patternIndex) {
          patternIndex = parseInt(style.patternIndex) - 1;
        }

        if (patternIndex === colIndex) {
          this.setIndexStyle(column, style, 'index');
          break;
        }

        if (column.text.match(regex)) {
          this.setIndexStyle(column, style, regex);
          break;
        }
      }
      this.formatters[colIndex] = this.createColumnFormatter(column);
    }
    this.addStatusCols();
  }

  addStatusCols() {
    if (!this.panel.statusLamp || this.panel.statusLamp.length === 0) {
      return;
    }

    const addStatusLamps = [];
    for (let i = 0; i < this.panel.statusLamp.length; i++) {
      const statusLamp = this.panel.statusLamp[i];
      if (statusLamp.display && statusLamp.conditions.length > 0) {
        const conditions = this.getConditionStyles(statusLamp.conditions);
        addStatusLamps.push({
          type: 'string',
          addStatusLampCol: true,
          text: statusLamp.name || 'status',
          title: statusLamp.name || 'status',
          relation: statusLamp.relation || '&',
          conditions: conditions,
          color: 'green',
        });
      }
    }

    if (addStatusLamps.length > 0) {
      this.table.columns.push(...addStatusLamps);
    }
  }

  getConditionStyles(conditions) {
    if (this.panel.styles.length === 0) {
      return conditions;
    }

    for (let i = 0; i < conditions.length; i++) {
      const condition = conditions[i];
      conditions[i].varValue = this.templateSrv.replace(
        condition.value,
        this.panel.scopedVars,
        encodeURIComponent
      );
      const num = this.panel.styles.length - 1;
      if (this.panel.styles[num] === '/.*/') {
        conditions[num]['unit'] = this.panel.styles[num].unit;
        conditions[num]['decimals'] = this.panel.styles[num].decimals;
      }

      for (let s = 0; s < this.panel.styles.length; s++) {
        const style = this.panel.styles[s];
        if (style.hidden || style.type !== 'number') {
          continue;
        }
        if (style.title === condition.name) {
          conditions[i]['unit'] = style.unit;
          conditions[i]['decimals'] = style.decimals;
        }
      }
    }
    return conditions;
  }

  removeCols() {
    const removeCols = [];
    for (let colIndex = 0; colIndex < this.table.columns.length; colIndex++) {
      const column = this.table.columns[colIndex];
      if (column.addStatusLampCol || column.type === 'custom') {
        removeCols.push(column);
      }
    }

    if (removeCols.length > 0) {
      _.pull(this.table.columns, ...removeCols);
    }
  }

  pushCustomCol() {
    if (this.panel.customColumns.length > 0) {
      for (let i = 0; i < this.panel.customColumns.length; i++) {
        const customColumn = this.panel.customColumns[i];
        customColumn.text = customColumn.pattern;
        customColumn.isNoMergeTitle = false;
        this.table.columns.push(customColumn);
      }
    }
  }

  getThresholds(style: any, y: any) {
    let thresholds = _.cloneDeep(style.thresholds);

    if (style.type === 'date' && style.styleDatethresholds) {
      thresholds = style.styleDatethresholds;
    }

    if (this.panel.dataType === 'table' && !!style.thresColumn && typeof y === 'number') {
      let rowIndex: any;
      this.table.columns.forEach((c, i) => {
        if (c.text === style.thresColumn) {
          rowIndex = i;
        }
      });
      if (this.table.rows[y][rowIndex] !== undefined) {
        thresholds = this.table.rows[y][rowIndex];
      }
    }

    let thresholdsString = _.cloneDeep(thresholds) || '';
    for (let i = 0; i < thresholds.length; i++) {
      thresholds[i] = this.templateSrv.replace(thresholds[i], this.panel.scopedVars);
    }

    if (_.isArray(thresholds)) {
      thresholdsString = thresholds.join(',');
    } else if (_.isString(thresholds)) {
      thresholdsString = thresholds;
    }

    thresholds = thresholdsString.split(',');
    return thresholds;
  }

  getColorForValue(value, style, y) {
    if (!style.thresholds) {
      return null;
    }

    const thresholds = this.getThresholds(style, y);
    let colors = style.colors;

    if (style.colorMode === 'alarm' && style.alarmColors) {
      colors = style.alarmColors;
    }

    for (let i = thresholds.length; i > 0; i--) {
      const v = Number(value);
      let th = thresholds[i - 1];
      let included = th.includes('=') ? true : false;

      if (included) {
        th = th.replace('=', '');
      }

      const thval = Number(th);
      if (isNaN(v) || isNaN(thval)) {
        continue;
      }

      if (included) {
        if (v > thval) {
          return colors[i];
        }
      } else {
        if (v >= thval) {
          return colors[i];
        }
      }
    }

    return _.first(colors);
  }

  // get thresholds title
  getColorForTitle(value, style, y?) {
    if (!style || !style.thresholds) {
      return null;
    }

    const thresholds = this.getThresholds(style, y);

    if (!style.thresholdsDisplay) {
      return null;
    }
    if (thresholds.length > style.thresholdsDisplay.length) {
      return null;
    }
    if (style.type === 'date') {
      return null;
    }

    for (var i = thresholds.length; i > 0; i--) {
      let thval = thresholds[i - 1];
      let included = thval.includes('=') ? true : false;
      if (included) {
        thval = thval.replace('=', '');
      }
      if (included) {
        if (parseFloat(value) > thval) {
          return style.thresholdsDisplay[i];
        }
      } else {
        if (parseFloat(value) >= thval) {
          return style.thresholdsDisplay[i];
        }
      }
    }

    return _.first(style.thresholdsDisplay);
  }

  defaultCellFormatter(v, style) {
    if (v === null || v === void 0 || v === undefined) {
      return '';
    }

    if (_.isArray(v)) {
      v = v.join(', ');
    }

    if (style && style.sanitize) {
      return this.sanitize(v);
    } else {
      return _.escape(v);
    }
  }

  colorMapSet(column, v) {
    if (column.style.colorMaps) {
      for (let i = 0; i < column.style.colorMaps.length; i++) {
        const map = column.style.colorMaps[i];

        if (!map.text) {
          break;
        }

        if (v === null) {
          if (map.value === 'null') {
            if (map.type === 'status') {
              this.colorState['status'] = map.text;
            } else {
              this.colorState['value'] = map.text;
            }
          }
          continue;
        }

        if ((!_.isString(v) && Number(map.value) === Number(v)) || map.value === v) {
          if (map.type === 'status') {
            this.colorState['status'] = map.text;
          } else {
            this.colorState['value'] = map.text;
          }
        }
      }
    }
  }

  createColumnFormatter(column) {
    if (!column.style) {
      return this.defaultCellFormatter;
    }

    if (column.style.type === 'hidden') {
      return v => {
        return undefined;
      };
    }

    if (column.style.type === 'date') {
      return v => {
        if (v === undefined || v === null || v === 0 || v === '') {
          return '-';
        }
        if (_.isArray(v)) {
          v = v[0];
        }
        column.style.styleDatethresholds = null;
        this.setDateColorState(v, column.style);
        let date = moment(v);
        if (this.isUtc) {
          date = date.utc();
        }
        return date.format(column.style.dateFormat);
      };
    }

    if (column.style.type === 'string') {
      return v => {
        if (v === '@@@@@') {
          return '';
        }
        if (_.isArray(v)) {
          v = v.join(', ');
        }
        const mappingType = column.style.mappingType || 0;
        if (mappingType === 1 && column.style.valueMaps) {
          for (let i = 0; i < column.style.valueMaps.length; i++) {
            const map = column.style.valueMaps[i];
            if (v === null) {
              if (map.value === 'null') {
                this.colorMapSet(column, v);
                return map.text;
              }
              continue;
            }

            // Allow both numeric and string values to be mapped
            if ((!_.isString(v) && Number(map.value) === Number(v)) || map.value === v) {
              this.colorMapSet(column, map.text);
              this.setColorState(v, column.style);
              return this.defaultCellFormatter(map.text, column.style);
            }
          }
        }

        if (mappingType === 2 && column.style.rangeMaps) {
          for (let i = 0; i < column.style.rangeMaps.length; i++) {
            const map = column.style.rangeMaps[i];

            if (v === null) {
              if (map.from === 'null' && map.to === 'null') {
                this.colorMapSet(column, v);
                return map.text;
              }
              continue;
            }

            if (Number(map.from) <= Number(v) && Number(map.to) >= Number(v)) {
              this.colorMapSet(column, map.text);
              this.setColorState(v, column.style);
              return this.defaultCellFormatter(map.text, column.style);
            }
          }
        }

        this.colorMapSet(column, v);

        if (v === null || v === void 0) {
          return '-';
        }

        this.setColorState(v, column.style);
        return this.defaultCellFormatter(v, column.style);
      };
    }

    if (column.style.type === 'number') {
      const valueFormatter = kbn.valueFormats[column.unit || column.style.unit || 'none'];

      return v => {
        if (v === null || v === void 0) {
          return '-';
        }

        if (_.isString(v) || _.isArray(v)) {
          return this.defaultCellFormatter(v, column.style);
        }

        this.setColorState(v, column.style);
        return valueFormatter(v, column.style.decimals, null);
      };
    }

    if (column.style.type === 'array') {
      return v => {
        if (v === null || v === void 0) {
          return '-';
        }

        let rv = [];

        if (_.isNumber(v)) {
          v = v.toString();
        }

        if (v.indexOf('{') !== -1 && v.indexOf('}') !== -1) {
          rv = v.substr(v.indexOf('{') + 1, v.lastIndexOf('}') - 1).split(',');
        } else {
          if (_.isString(v)) {
            rv[0] = v;
            rv[1] = v;
            rv[2] = 'null';
            rv[3] = 'null';
          } else {
            rv[0] = v[0];
            rv[1] = v[1] || v[0];
            rv[2] = v[2] || 'null';
            rv[3] = v[3] || 'null';
          }
        }

        if (rv.length > 0) {
          /* rv.forEach((val, k) => {
            if (val && val.toLowerCase() !== 'null') {
              const valueFormatter = kbn.valueFormats['none'];
              rv[k] = valueFormatter(val, column.style.decimals, null);
            }
          }); */
          return rv;
        }
        return v;
      };
    }

    if (column.style.type === 'transparent') {
      return v => {
        if (v === null || v === void 0) {
          return '-';
        }

        if (_.isArray(v)) {
          return this.defaultCellFormatter(v, column.style);
        }

        this.setColorState(v, column.style);
        return '';
      };
    }

    return value => {
      return this.defaultCellFormatter(value, column.style);
    };
  }

  setDateColorState(value, style) {
    if (!style.colorMode || !style.thresholds) {
      return;
    }
    const styleDatethresholds = [];
    for (let i = 0; i < style.thresholds.length; i++) {
      const threshold = style.thresholds[i];
      let time = moment.utc(threshold).valueOf();

      if (_.isNumber(time)) {
        styleDatethresholds.push(time.toString());
      }
    }
    if (styleDatethresholds.length > 0) {
      style.styleDatethresholds = styleDatethresholds;
    }
    this.setColorState(value, style);
  }

  setColorState(value, style) {
    if (!style.colorMode) {
      return;
    }

    if (value === null || value === void 0 || _.isArray(value)) {
      return;
    }

    const numericValue = Number(value);
    if (isNaN(numericValue)) {
      return;
    }

    this.colorState[style.colorMode] = this.getColorForValue(
      numericValue,
      style,
      undefined
    );
  }

  renderRowVariables(rowIndex) {
    const scopedVars = {};
    let cellVariable;
    const row = this.table.rows[rowIndex];
    for (let i = 0; i < row.length; i++) {
      cellVariable = `__cell_${i}`;
      scopedVars[cellVariable] = {value: row[i]};
    }
    return scopedVars;
  }

  formatColumnValue(colIndex, value) {
    return this.formatters[colIndex] ? this.formatters[colIndex](value) : value;
  }

  renderCellStyles(column, cellStyles, cellClasses, textStyles) {
    if (column.style) {
      //width
      if (column.style.colwidth) {
        cellStyles.width = column.style.colwidth;
      }

      if (column.style.type === 'transparent') {
        cellStyles.width = '1px';
        cellStyles['border-right'] = 'none';
      }

      if (column.style.noBorder) {
        cellStyles['border-right'] = 'none';
        cellStyles['border-bottom'] = 'none';
      }

      //align
      if (column.style.align) {
        cellStyles['text-align'] = column.style.align;
      }

      //column color
      if (column.style.colbgColor) {
        let thresholdsRow = false;
        for (let i = 0; i < this.panel.styles.length; i++) {
          const style = this.panel.styles[i];
          if (style.colorMode === 'row') {
            thresholdsRow = true;
            break;
          }
        }
        if (!thresholdsRow) {
          cellStyles['background-color'] = column.style.colbgColor;
        }
      }

      //font color
      if (column.style.colFontColorSet) {
        textStyles.color = column.style.colFontColorSet;
        cellStyles.color = column.style.colFontColorSet;
      }

      //bold
      if (column.style.bold) {
        textStyles['font-weight'] = 'bold';
        cellStyles['font-weight'] = 'bold';
      }
    }

    //column Thresholds
    if (this.colorState.cell) {
      cellStyles['background-color'] = this.colorState.cell;
      cellClasses.push('report-panel-color-cell');
    } else if (this.colorState.value) {
      cellStyles.color = this.colorState.value;
      textStyles.color = this.colorState.value;
    }
  }

  renderCellValue(column, value, indexRowStyles) {
    //postfix
    if (value !== undefined && value !== '') {
      if (indexRowStyles.rowPrefix) {
        value = indexRowStyles.rowPrefix + value;
      }
      const copyVal = value;
      if (column.style.colpostfix) {
        value = copyVal + column.style.colpostfix;
      }
      if (indexRowStyles.rowPostfix) {
        value = copyVal + indexRowStyles.rowPostfix;
      }
    }

    if (this.colorState.status || this.colorState.value) {
      let title = this.getColorForTitle(value, column.style);
      if (title) {
        if (column.style.thresholdsHasValue) {
          title = title + '(' + value + ')';
        }
        value = title;
      }
    }

    return value;
  }

  customDisplay(column, rowIndex) {
    let value = '--';
    column.rowContents.forEach((v, k) => {
      if (parseInt(v.rowNumber) - 1 === rowIndex) {
        if (v.rowType === 'text') {
          if (v.rowContent) {
            value = v.rowContent;
          }
        } else if (v.rowType === 'status') {
          if (v.rowStatus && v.rowStatus.operator && v.rowStatus.opValue) {
            value = `<span class="statusLamp ${v.statusColor}" style="background-color:${
              v.statusColor
            }"></span>`;
            if (v.rowStatus.showCondition) {
              value += `<span class="statusCondition">${v.rowStatus.operator}${
                v.rowStatus.opValue
              }</span>`;
            }
          }
        }
      }
    });
    return value;
  }

  arrayBar(column, value) {
    if (!_.isArray(value)) {
      return '--';
    }

    const currentVal = parseInt(value[0]);
    let maxVal = parseInt(value[1]);
    const valueFormatter = kbn.valueFormats[column.unit || column.style.unit || 'none'];
    const currentText = valueFormatter(value[0], column.style.decimals, null);
    const maxText = valueFormatter(value[1], column.style.decimals, null);

    if (!column.style.bar) {
      return value;
    }

    const firstThreshold = parseInt(value[2]);
    const secondThreshold = parseInt(value[3]);
    const colors = column.style.arraycolors;

    const total = 100;
    let firstBar = 0;
    let secondBar = 0;
    let thirdBar = 0;

    let nullBar = ``;
    for (let i = 0; i < 10; i++) {
      nullBar += `<span class="report-panel-bar-box" style="background-color:#1e1e1e;"></span>`;
    }
    let html =
      `<div class="bar-container">
        <span class="report-panel-current-value">${currentText}</span>
        <div class="progress-bar">` +
      nullBar +
      `</div>
        <span class="report-panel-max-value">${maxText}</span>
      </div>`;

    if (_.isNaN(currentVal)) {
      return html;
    }

    if (_.isNaN(firstThreshold) && _.isNaN(secondThreshold)) {
      return html;
    }

    if (_.isNaN(maxVal)) {
      maxVal = currentVal;
    }

    if (_.isNaN(firstThreshold) || _.isNaN(secondThreshold)) {
      const threshold = firstThreshold || secondThreshold;
      if (currentVal >= threshold) {
        firstBar = threshold / maxVal * total;
        secondBar = (currentVal - threshold) / maxVal * total;
      } else {
        firstBar = currentVal / maxVal * total;
      }
    } else {
      if (currentVal > maxVal) {
        firstBar = firstThreshold / maxVal * total;
        secondBar = (secondThreshold - firstThreshold) / maxVal * total;
        thirdBar = (maxVal - secondThreshold) / maxVal * total;
      } else if (currentVal >= firstThreshold) {
        firstBar = firstThreshold / maxVal * total;
        if (currentVal >= secondThreshold) {
          secondBar = (secondThreshold - firstThreshold) / maxVal * total;
          thirdBar = (currentVal - secondThreshold) / maxVal * total;
        } else {
          secondBar = (currentVal - firstThreshold) / maxVal * total;
          //thirdBar = 0;
        }
      } else {
        firstBar = currentVal / maxVal * total;
        secondBar = 0;
        thirdBar = 0;
      }
    }

    let bar = ``;
    let low = Math.ceil(firstBar / 10);
    let height = Math.ceil(thirdBar / 10);
    let mid = Math.ceil(secondBar / 10);
    for (let i = 0; i < 10; i++) {
      if (low > 0) {
        bar += `<span class="report-panel-bar-box" style="background-color:${colors[0]}"></span>`;
        low--;
      } else if (mid > 0) {
        bar += `<span class="report-panel-bar-box" style="background-color:${colors[1]}"></span>`;
        mid--;
      } else if (height > 0) {
        bar += `<span class="report-panel-bar-box" style="background-color:${colors[2]}"></span>`;
        height--;
      } else {
        bar += `<span class="report-panel-bar-box" style="background-color:#1e1e1e;"></span>`;
      }
    }
    html =
      `<div class="bar-container">
    <span class="report-panel-current-value">${currentText}</span>
    <div class="progress-bar">` +
      bar +
      `</div>
    <span class="report-panel-max-value">${maxText}</span>
  </div>`;

    return html;
  }

  linkOrUrl(
    columnIndex,
    column,
    value,
    rowIndex,
    cellClasses,
    indexRowStyles,
    textStyles,
    columnHtml
  ) {
    if (column.style && column.style.type === 'string' && column.style.url) {
      if (column.style.icon) {
        if (column.style.icontype) {
          value = `<a href="${value}" title="${value}" target="_blank" class="extra-icon-${
            column.style.icontype
          }" style="width:calc( ${this.panel.tableFontVal} + 0.2vw );height:calc( ${
            this.panel.tableFontVal
          } + 0.2vw );"></a>`;
        } else {
          value = `<a href="${value}" target="_blank">
            <i class="fa fa-file-text" aria-hidden="true"></i>
          </a>`;
        }
      } else {
        value = `<a href="${value}" target="_blank">${value}</a>`;
      }
    }

    let linkAClass = this.panel.compactRowsEnabled ? 'link-compact' : '';

    if (column.style && column.style.link) {
      // Render cell as link
      const scopedVars = this.renderRowVariables(rowIndex);
      scopedVars['__cell'] = {value: value};

      const cellLink = this.templateSrv.replace(
        column.style.linkUrl,
        scopedVars,
        encodeURIComponent
      );

      if (!column.style.linkTooltip) {
        column.style.linkTooltip = '';
      }

      const cellLinkTooltip = this.templateSrv.replace(
        column.style.linkTooltip,
        scopedVars
      );
      const cellTarget = column.style.linkTargetBlank ? '_blank' : '';

      if (column.style && !column.style.bar) {
        cellClasses.push('report-panel-cell-link');
      }

      const textStyle = `style="color:${textStyles.color}";font-weight:${
        textStyles['font-weight']
      };`;
      columnHtml += `
        <a class="${linkAClass}" href="${cellLink}" target="${cellTarget}" onclick="srpUrlClickEvent(this)"
        data-link-tooltip data-original-title="${cellLinkTooltip}" 
        data-placement="right"${textStyle}>${value}</a>`;
    } else {
      //row value and title
      if (column && column.thresholdColor && column.thresholdTitle) {
        if (column.rowColorMode === 'status' || column.rowColorMode === 'value') {
          if (column.thresholdsHasValue) {
            value = column.thresholdTitle + '(' + value + ')';
          } else {
            value = column.thresholdTitle;
          }
        }
      }
      let rowIndexLink = true;
      if (indexRowStyles.hasOwnProperty('wholeRow') && !indexRowStyles.wholeRow) {
        if (parseInt(indexRowStyles.colNum) - 1 !== columnIndex) {
          rowIndexLink = false;
        }
      }
      if (indexRowStyles.rowLink && rowIndexLink) {
        const scopedVars = this.renderRowVariables(rowIndex);
        scopedVars['__cell'] = {value: value};
        const rowLink = this.templateSrv.replace(
          indexRowStyles.rowLink,
          scopedVars,
          encodeURIComponent
        );
        const cellTarget = indexRowStyles.rowTarget ? '_blank' : '';

        let cellLink = true;
        if (column.style && column.style.bar) {
          cellLink = false;
        }

        if (cellLink) {
          cellClasses.push('report-panel-cell-link');
        }

        const textStyle = ` style="color:${textStyles.color}";font-weight:${
          textStyles['font-weight']
        };`;
        columnHtml += `<a class="${linkAClass}" href="${rowLink}" target="${cellTarget}" onclick="srpUrlClickEvent(this)"
        data-link-tooltip  data-placement="right" ${textStyle}>${value}</a>`;
      } else {
        columnHtml += value;
      }
    }

    return columnHtml;
  }

  convertHexToRGB(color) {
    if (color.length === 4) {
      let extendedColor = '#';
      for (let i = 1; i < color.length; i++) {
        extendedColor += color.charAt(i) + color.charAt(i);
      }
      color = extendedColor;
    }
    const values = {
      r: parseInt(color.substr(1, 2), 16),
      g: parseInt(color.substr(3, 2), 16),
      b: parseInt(color.substr(5, 2), 16),
      a: 0.2,
    };
    return `rgba(${values.r},${values.g},${values.b},${values.a})`;
  }

  setRGBA(color) {
    let values = color.match(/(\d(\.\d+)?)+/g);
    return `rgba(${values[0]},${values[1]},${values[2]},0.2)`;
  }

  setVal(columnIndex, rowIndex, value, indexRowStyles) {
    let val = value;
    const column = this.table.columns[columnIndex];
    if (column && column.style && column.style.type === 'hidden') {
      return (val = this.formatColumnValue(columnIndex, value));
    }

    if (
      columnIndex === parseInt(indexRowStyles.colNum) - 1 &&
      rowIndex === parseInt(indexRowStyles.rowNum) - 1
    ) {
      if (!_.isNumber(value)) {
        return (val = this.formatColumnValue(columnIndex, value));
      }

      if (indexRowStyles.rowDecimals || indexRowStyles.rowUnit) {
        let colUnit = 'none';
        let colDecimals = '';
        if (column && column.style) {
          colUnit = column.style.unit;
          colDecimals = column.style.decimals;
        }
        const unit = indexRowStyles.rowUnit || colUnit || 'none';
        const decimals = indexRowStyles.rowDecimals || colDecimals;
        const valueFormatter = kbn.valueFormats[unit];
        val = valueFormatter(value, decimals, null);
      } else {
        val = this.formatColumnValue(columnIndex, value);
      }
    } else {
      val = this.formatColumnValue(columnIndex, value);
    }

    return val;
  }

  renderCell(columnIndex, rowIndex, value, indexRowStyles, addWidthHack = false) {
    value = this.setVal(columnIndex, rowIndex, value, indexRowStyles);
    const column = this.table.columns[columnIndex];
    let cellStyle = '';
    const cellClasses = [];
    let cellClass = '';
    const textStyles = {color: '', 'font-size': 'normal'};
    const cellStyles = {
      width: 'unset',
      'text-align': 'unset',
      'background-color': 'unset',
      color: 'unset',
      'font-weight': 'normal',
    };

    //column styles
    if (column && column.style) {
      this.renderCellStyles(column, cellStyles, cellClasses, textStyles);
      value = this.renderCellValue(column, value, indexRowStyles);
    }

    //row Thresholds
    if (column && column.rowColorMode && column.thresholdColor) {
      if (column.rowColorMode === 'cell') {
        cellStyles['background-color'] = column.thresholdColor;
      } else if (column.rowColorMode === 'value') {
        cellStyles.color = column.thresholdColor;
        textStyles.color = column.thresholdColor;
      }
    }
    //row colorMode===row  th的backcolor should unset
    if (
      indexRowStyles &&
      indexRowStyles.thresholdConfig &&
      indexRowStyles.thresholdConfig.colorMode === 'row'
    ) {
      cellStyles['background-color'] = 'unset';
    }

    for (const key in cellStyles) {
      if (cellStyles.hasOwnProperty(key)) {
        const val = cellStyles[key];
        cellStyle += `${key}: ${val}; `;
      }
    }

    cellStyle = ' style="' + cellStyle + '"';

    // because of the fixed table headers css only solution
    // there is an issue if header cell is wider the cell
    // this hack adds header content to cell (not visible)
    let columnHtml = '';
    if (addWidthHack) {
      columnHtml =
        '<div class="table-panel-width-hack">' +
        this.table.columns[columnIndex].title +
        '</div>';
    }

    if (this.colorState.alarm || column.rowColorMode === 'alarm') {
      let color = this.colorState.alarm;
      if (column.rowColorMode === 'alarm' && column.thresholdColor) {
        color = column.thresholdColor;
      }

      if (color && color !== 'null') {
        const url = `public/plugins/ene-report-panel/img/alarm-${color}.svg`;
        columnHtml = `<span class="report-panel-alarm">${columnHtml}<img src=${url}></span>`;
      }
    }

    if (column.addStatusLampCol) {
      value = `<div class="statusLamp ${column.color}" style="background-color:${
        column.color
      }"></div>`;
    }

    if (column.type === 'custom') {
      value = this.customDisplay(column, rowIndex);
    }

    if (column.style && column.style.type === 'array') {
      value = this.arrayBar(column, value);
    } else if (
      column.style &&
      column.style.type === 'operation' &&
      column.style.operNum != undefined
    ) {
      //hao.ning add icon
      let data = [];
      this.table.columns.forEach((element, i) => {
        data.push(`data-${element.text}='${this.table.rows[rowIndex][i]}'`);
      });
      value = this.createOperation(column, cellStyle, data.join(' '));
    }

    if (value === undefined) {
      cellStyle = ' style="display:none;"';
      column.hidden = true;
    } else {
      column.hidden = false;
    }

    if (column.hidden === true) {
      return '';
    }

    if (column.style && column.style.preserveFormat) {
      cellClasses.push('report-panel-cell-pre');
    }

    columnHtml = this.linkOrUrl(
      columnIndex,
      column,
      value,
      rowIndex,
      cellClasses,
      indexRowStyles,
      textStyles,
      columnHtml
    );

    if (column.filterable) {
      cellClasses.push('report-panel-cell-filterable');
      columnHtml += `
        <a class="report-panel-filter-link" data-link-tooltip data-original-title="Filter out value" data-placement="bottom"
           data-row="${rowIndex}" data-column="${columnIndex}" data-operator="!=">
          <i class="fa fa-search-minus"></i>
        </a>
        <a class="report-panel-filter-link" data-link-tooltip data-original-title="Filter for value" data-placement="bottom"
           data-row="${rowIndex}" data-column="${columnIndex}" data-operator="=">
          <i class="fa fa-search-plus"></i>
        </a>`;
    }

    //rows Thresholds status
    if (column && column.rowColorMode === 'status' && column.thresholdColor) {
      cellClasses.push('report-panel-cell-status');
      columnHtml = `<button class="report" style="background-color:
      ${column.thresholdColor};font-size:${this.panel.tableFontVal};
      font-weight:${textStyles['font-weight']}">${columnHtml}</button>`;
    } else {
      //cloumn Thresholds status
      if (this.colorState.status) {
        cellClasses.push('report-panel-cell-status');
        const color = this.colorState.status;
        let rgbaColor = this.colorState.status;
        if (rgbaColor.indexOf('rgb') > -1) {
          rgbaColor = this.setRGBA(rgbaColor);
        } else {
          rgbaColor = this.convertHexToRGB(rgbaColor);
        }

        if (column.style.thresholdsHasBorder) {
          columnHtml = `<div style="background-color:rgba(0,0,0,0.9);display:inline-block;color:${color};
            border:2px solid ${color}">
            <div style="background-color:${rgbaColor};display:inline-block">
            <div class="report" style="border-radius:0px;">${columnHtml}</div>
            </div>
          </div>`;
        } else {
          columnHtml = `<button class="report" style="background-color:
          ${this.colorState.status};font-size:${this.panel.tableFontVal};
          font-weight:${textStyles['font-weight']}">${columnHtml}</button>`;
        }
      }
    }

    if (column && column.rowColorMode && column.thresholdColor) {
      column.rowColorMode = null;
      column.thresholdColor = null;
    }

    if (cellClasses.length) {
      cellClass = ' class="' + cellClasses.join(' ') + '"';
    }

    if (this.colorState.cell) {
      this.colorState.cell = null;
    }
    if (this.colorState.alarm) {
      this.colorState.alarm = null;
    }
    if (this.colorState.value) {
      this.colorState.value = null;
    }
    if (this.colorState.status) {
      this.colorState.status = null;
    }

    columnHtml =
      '<td' + cellClass + cellStyle + textStyles.color + '>' + columnHtml + '</td>';

    return columnHtml;
  }

  getColor(condition, relationVal) {
    let color = 'green';
    if (condition.type === 'number') {
      const valueFormatter = kbn.valueFormats[condition.unit || 'none'];
      relationVal = parseFloat(valueFormatter(relationVal, condition.decimals, null));
      let val = parseFloat(condition.varValue);
      if (condition.condition === '>') {
        if (relationVal > val) {
          color = 'red';
        }
      } else if (condition.condition === '>=') {
        if (relationVal >= val) {
          color = 'red';
        }
      } else if (condition.condition === '<') {
        if (relationVal < val) {
          color = 'red';
        }
      } else if (condition.condition === '<=') {
        if (relationVal <= val) {
          color = 'red';
        }
      } else if (condition.condition === '!=') {
        if (val !== relationVal) {
          color = 'red';
        }
      } else if (condition.condition === '=') {
        if (val === relationVal) {
          color = 'red';
        }
      }
    } else if (condition.type === 'string') {
      const rVal = relationVal.toString();
      if (condition.condition === 'has') {
        if (rVal.indexOf(condition.varValue) !== -1) {
          color = 'red';
        }
      } else if (condition.condition === 'not has') {
        if (rVal.indexOf(condition.varValue) === -1) {
          color = 'red';
        }
      } else if (condition.condition === 'equals') {
        if (rVal === condition.varValue) {
          color = 'red';
        }
      }
    }
    return color;
  }

  getStatusLampColor(statusLamCol, relationVals) {
    const conditions = statusLamCol.conditions;
    const colors = [];

    for (let i = 0; i < conditions.length; i++) {
      const condition = conditions[i];
      const columns = this.table.columns;

      for (let c = 0; c < columns.length; c++) {
        let col = columns[c];
        if (condition.selected === col.title) {
          const color = this.getColor(condition, relationVals[c]);
          colors.push(color);
        }
      }
    }

    let color = 'green';

    if (colors.length > 0) {
      if (statusLamCol.relation === '&') {
        if (_.indexOf(colors, 'green') === -1) {
          color = 'red';
        }
      } else {
        if (_.indexOf(colors, 'red') !== -1) {
          color = 'red';
        }
      }
    }
    statusLamCol.color = color;
  }

  getRowStyles(index, rowStyles) {
    // li.na add and modify
    const rowStyleArr = [];
    for (let i = 0; i < rowStyles.length; i++) {
      const indexRStyle: any = {};
      if (parseInt(rowStyles[i].rowNum) - 1 === index) {
        indexRStyle.rowBGColor = rowStyles[i].rowBGColor || null;
        indexRStyle.rowLink = rowStyles[i].rowhtml || null;
        indexRStyle.rowTarget = rowStyles[i].rowopenNewTab || null;
        indexRStyle.thresholdConfig = rowStyles[i].thresholdConfig || null;
        indexRStyle.colNum = rowStyles[i].colNum || null;
        indexRStyle.rowNum = rowStyles[i].rowNum || null;
        indexRStyle.rowPrefix = rowStyles[i].rowPrefix || null;
        indexRStyle.rowPostfix = rowStyles[i].rowPostfix || null;
        indexRStyle.wholeRow = rowStyles[i].wholeRow || null;
        indexRStyle.rowUnit = rowStyles[i].rowUnit || null;
        indexRStyle.rowDecimals = rowStyles[i].rowDecimals || null;
        rowStyleArr.push(indexRStyle);
      }
    }
    if (rowStyleArr.length === 0) {
      rowStyleArr.push({});
    }
    return rowStyleArr;
    // li.na add and modify
  }

  renderRowStyle(rowStylesColor, statusRow, bgColor, rowStyleThresholdRowColor) {
    if (!this.panel.stripedRowsEnabled) {
      bgColor = this.lightTheme ? '#fbfbfb' : '#323233';
    }

    let rowStyle = '';
    if (bgColor) {
      rowStyle = ' style="background-color:' + bgColor + '"';
    }
    if (statusRow) {
      rowStyle = ' style="background-color:' + this.colorState.row + '"';
    }

    if (rowStylesColor) {
      rowStyle = ' style="background-color:' + rowStylesColor + '"';
    }

    if (rowStyleThresholdRowColor) {
      rowStyle = ' style="background-color:' + rowStyleThresholdRowColor + '"';
    }

    return rowStyle;
  }

  getRowsStyleThresholds(row, column, indexRowStyles, y) {
    if (indexRowStyles.thresholdConfig) {
      const thresholdColor = this.getColorForValue(
        row,
        indexRowStyles.thresholdConfig,
        y
      );
      column.rowColorMode = indexRowStyles.thresholdConfig.colorMode;
      column.thresholdColor = thresholdColor;
      if (column.rowColorMode === 'status' || column.rowColorMode === 'value') {
        if (indexRowStyles.thresholdConfig.thresholdsDisplay) {
          column.thresholdTitle = this.getColorForTitle(
            row,
            indexRowStyles.thresholdConfig,
            y
          );
          column.thresholdsHasValue = indexRowStyles.thresholdConfig.thresholdsHasValue;
        }
      }
    }
  }

  rowContentStatus(value, rowContent, compareDecimals, compareUnit) {
    if (_.isNumber(value)) {
      const valueFormatter = kbn.valueFormats[compareUnit || 'none'];
      value = parseFloat(valueFormatter(value, compareDecimals, null));
    }
    const status = rowContent.rowStatus;
    let text = status.opValue;
    rowContent.statusColor = 'green';
    if (status.opType === 'number') {
      text = parseFloat(text);
      if (status.operator === '>') {
        if (value > text) {
          rowContent.statusColor = 'red';
        }
      } else if (status.operator === '>=') {
        if (value >= text) {
          rowContent.statusColor = 'red';
        }
      } else if (status.operator === '<=') {
        if (value <= text) {
          rowContent.statusColor = 'red';
        }
      } else if (status.operator === '<') {
        if (value < text) {
          rowContent.statusColor = 'red';
        }
      } else if (status.operator === '=') {
        if (value === text) {
          rowContent.statusColor = 'red';
        }
      } else if (status.operator === '!=') {
        if (value !== text) {
          rowContent.statusColor = 'red';
        }
      }
    } else if (status.opType === 'string') {
      const val = value.toString();
      if (status.operator === 'has') {
        if (val.indexOf(text) !== -1) {
          rowContent.statusColor = 'red';
        }
      } else if (status.operator === 'not has') {
        if (val.indexOf(text) === -1) {
          rowContent.statusColor = 'red';
        }
      } else if (status.operator === 'equals') {
        if (val === text) {
          rowContent.statusColor = 'red';
        }
      }
    }
  }

  appendRowsBar(startPos: number, y: number, isData = false) {
    let colsBars = {colsBar: false, colsSepStart: 0, colsSepEnd: y};

    if (!this.panel.separateRowsNum) {
      return;
    }

    const separateRowNums = this.panel.separateRowsNum.split(',');
    const separateRowOpen = this.panel.separateRowOpen;
    if (separateRowNums.length === 0) {
      return;
    }

    const num = y - startPos + 1;
    if (separateRowOpen && separateRowNums.length === 1) {
      const separate = parseInt(separateRowNums);
      if (num % separate === 0) {
        colsBars.colsBar = true;
        colsBars.colsSepStart = num - separate;
        colsBars.colsSepEnd = num;
      }
    } else {
      for (let i = 0; i < separateRowNums.length; i++) {
        const separate = parseInt(separateRowNums[i]);
        if (separate + startPos === num) {
          colsBars.colsBar = true;
          if (i - 1 >= 0) {
            colsBars.colsSepStart = startPos + parseInt(separateRowNums[i - 1]);
          } else {
            colsBars.colsSepStart = num - separate;
          }
          colsBars.colsSepEnd = separate;
        }
      }
    }
    const separateDataHidden = this.panel.separateDataHidden;
    if (colsBars.colsBar && isData && separateDataHidden) {
      if (
        this.table.columns &&
        this.table.columns[0].style &&
        this.table.columns[0].style.type === 'string'
      ) {
        const rows = this.table.rows;
        for (let i = colsBars.colsSepStart + 1; i < colsBars.colsSepEnd; i++) {
          rows[i][0] = '@@@@@';
        }
      }
    }

    return colsBars;
  }

  appendRowsBarData(startPos: number, endPos: number) {
    for (let y = startPos; y < endPos; y++) {
      this.appendRowsBar(startPos, y, true);
    }
  }

  render(page) {
    let pageSize = this.panel.pageSize || 10;

    if (this.panel.scroll) {
      pageSize = this.table.rows.length;
    }

    const pageCount = Math.ceil(this.table.rows.length / pageSize);

    if (page >= pageCount) {
      page = 0;
    }

    const startPos = page * pageSize;
    const endPos = Math.min(startPos + pageSize, this.table.rows.length);

    let html = '';
    const rowClasses = [];
    let rowClass = '';

    const rowStyles = JSON.parse(JSON.stringify(this.panel.rowStyles));
    this.appendRowsBarData(startPos, endPos);

    for (let y = startPos; y < endPos; y++) {
      const row = this.table.rows[y];
      let cellHtml = '';
      let rowStyle = '';

      const indexRowStylesArr = this.getRowStyles(y, rowStyles);

      if (this.panel.rowNumbersEnabled) {
        cellHtml += `<td class='no-break' style="width:1%">${y + 1}</td>`;
      }

      for (let i = 0; i < this.table.columns.length; i++) {
        const column = this.table.columns[i];

        if (column.addStatusLampCol) {
          this.getStatusLampColor(column, row);
        }

        // li.na modify
        for (let ri = 0; ri < indexRowStylesArr.length; ri++) {
          if (indexRowStylesArr[ri].colNum) {
            if (parseInt(indexRowStylesArr[ri].colNum) - 1 === i) {
              if (column && column.thresholdTitle) {
                column.thresholdTitle = null;
              }
              this.getRowsStyleThresholds(row[i], column, indexRowStylesArr[ri], y);
            }
          }
        }
        // li.na modify

        if (column.rowContents && column.rowContents.length > 0) {
          for (let s = 0; s < column.rowContents.length; s++) {
            const rowContent = column.rowContents[s];
            if (rowContent.rowType === 'status' && rowContent.rowStatus) {
              const conpareIndex = rowContent.rowStatus.columnNo - 1;
              let compareDecimals = null;
              let compareUnit = null;
              const styleLength = this.panel.styles.length;
              if (conpareIndex >= 0) {
                if (conpareIndex > styleLength - 1) {
                  if (this.panel.styles[styleLength - 1].pattern === '/.*/') {
                    compareDecimals = this.panel.styles[styleLength - 1].decimals;
                    compareUnit = this.panel.styles[styleLength - 1].unit;
                  }
                } else {
                  compareDecimals = this.panel.styles[conpareIndex].decimals;
                  compareUnit = this.panel.styles[conpareIndex].unit;
                }
              }
              this.rowContentStatus(
                row[conpareIndex],
                rowContent,
                compareDecimals,
                compareUnit
              );
            }
          }
        }
        let indexRowStyles: any = undefined;
        if (
          indexRowStylesArr.length === 1 &&
          indexRowStylesArr[0] &&
          !indexRowStylesArr[0].colNum
        ) {
          indexRowStyles = indexRowStylesArr[0];
        } else {
          for (let ri = 0; ri < indexRowStylesArr.length; ri++) {
            const rowStyle = indexRowStylesArr[ri];
            if (
              parseInt(rowStyle.colNum) - 1 === i &&
              parseInt(rowStyle.rowNum) - 1 === y
            ) {
              indexRowStyles = rowStyle;
            }
          }
          if (!indexRowStyles) {
            indexRowStyles = indexRowStylesArr[0];
          }
        }
        cellHtml += this.renderCell(i, y, row[i], indexRowStyles, y === startPos);
      }

      let rowStyleThresholdRowColor = null;
      // li.na modify
      for (let ri = 0; ri < indexRowStylesArr.length; ri++) {
        const indexRowStyles = indexRowStylesArr[ri];
        if (
          indexRowStyles.thresholdConfig &&
          indexRowStyles.thresholdConfig.colorMode === 'row'
        ) {
          if (indexRowStyles.colNum) {
            const num = parseInt(indexRowStyles.colNum) - 1;
            rowStyleThresholdRowColor = this.getColorForValue(
              row[num],
              indexRowStyles.thresholdConfig,
              y
            );
          }
        }
        //row background-color
        if ((y + 1) % 2 === 0) {
          rowStyle = this.renderRowStyle(
            indexRowStyles.rowBGColor,
            this.colorState.row,
            this.panel.evenRowBGColorSet,
            rowStyleThresholdRowColor
          );
        } else {
          rowStyle = this.renderRowStyle(
            indexRowStyles.rowBGColor,
            this.colorState.row,
            this.panel.oddRowBGColorSet,
            rowStyleThresholdRowColor
          );
        }

        if (this.colorState.row || indexRowStyles.rowBGColor) {
          if (rowClasses.indexOf('report-panel-color-row') !== -1) {
            rowClasses.push('report-panel-color-row');
          }
        }
      }
      // li.na modify

      if (rowClasses.length) {
        rowClass = ' class="' + rowClasses.join(' ') + '"';
      }

      if (this.colorState.row) {
        this.colorState.row = null;
      }

      html += '<tr ' + rowClass + rowStyle + '>' + cellHtml + '</tr>';
      const colsBars = this.appendRowsBar(startPos, y);

      if (colsBars && colsBars.colsBar) {
        const num = this.table.columns.length;
        html =
          html +
          `<tr class="report-panel-separate-row-bar">
          <th colspan=${num}></th>
        </tr>`;
      }
    }

    return html;
  }

  resetValue(ctrl, body) {
    $('.report-panel-extra-icon-reset')
      .unbind('click')
      .on('click', event => {
        let _this: any = event.target;
        console.log('_this', _this);
        let devid = _this.dataset['devid'];
        let param = _this.dataset['paramname'];
        console.log('resetValue', [{tagname: param, devid: parseInt(devid), value: '0'}]);
        let setArr = [{tagname: param, devid: parseInt(devid), value: '0'}];
        console.log('resetValue');
        ctrl.renderer.showDialog(ctrl, setArr);
      });
  }

  showDialog(ctrl, setArr) {
    return new Promise((resolve, reject) => {
      let modalScope = ctrl.$scope.$new(true);
      modalScope.languageData = languageData;
      modalScope.currentLanguage = ctrl.systemLang
        ? ctrl.systemLang
        : 'default';
      console.log('modalScope.currentLanguage', modalScope.currentLanguage);
      modalScope.onCancel = () => {
        console.log('onCancel');
        modalScope.dismiss();
        reject();
      };
      modalScope.onSubmit = () => {
        console.log('onSubmit');
        ctrl.datasource
          .metricUpdate_setValue(setArr)
          .then(result => {
            console.log('result', result);
            ctrl.refresh();
            modalScope.dismiss();
            resolve();
          })
          .catch(function(err) {
            console.log('catch error');
            appEvents.emit('alert-warning', [
              languageData[modalScope.currentLanguage].failed_to_send,
              '',
            ]);
          });
      };
      appEvents.emit('show-modal', {
        src: 'public/plugins/' + ctrl.pluginId + '/partials/modal-reset-value.html',
        scope: modalScope,
        modalClass: 'report-panel-center-tweak',
      });
    });
  }

  render_values() {
    const rows = [];

    for (let y = 0; y < this.table.rows.length; y++) {
      const row = this.table.rows[y];
      const newRow = [];
      for (let i = 0; i < this.table.columns.length; i++) {
        newRow.push(this.formatColumnValue(i, row[i]));
      }
      rows.push(newRow);
    }
    return {
      columns: this.table.columns,
      rows: rows,
    };
  }
  //create extra icon in table cell -- hao.ning
  createExtraIcon(column, value) {
    if (!column.style || !column.style.addUrlContent) {
      return value;
    }
    value = `${value}<a title='${column.style.addUrlContent}' href='${
      column.style.addUrlContent
    }' target='_blank' class='extra-icon-a'
          ></a>`;
    return value;
  }

  //create operation icon in table cell -- hao.ning
  createOperation(column, cellStyle, data) {
    let value = '';
    let list = column.style.operationList;
    let head = `<td ${cellStyle}>`;
    let fail = '</td>';
    let display = 'display:none;';

    for (let i = 0; i < column.style.operNum; i++) {
      value += `${i == 0 ? '' : head}
        <a title="${list[i].handler}" 
        id="operation-${list[i].handler}"
        target="_blank" class="extra-icon-${list[i].type}"
        ${data} 
        style="width:calc( ${this.panel.tableFontVal} + 0.2vw );
        height:calc( ${this.panel.tableFontVal} + 0.2vw );}">
        </a>${i == column.style.operNum - 1 ? '' : fail}`;
    }
    return value;
  }

  formatDate(time) {
    let date = new Date(time);
    let year = date.getFullYear();
    let month =
      date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1;
    let day = date.getDate() < 10 ? '0' + date.getDate() : date.getDate();
    let hour = date.getHours() < 10 ? '0' + date.getHours() : date.getHours();
    let min = date.getMinutes() < 10 ? '0' + date.getMinutes() : date.getMinutes();
    let sec = date.getSeconds() < 10 ? '0' + date.getSeconds() : date.getSeconds();
    return year + '/' + month + '/' + day + ' ' + hour + ':' + min + ':' + sec;
  }
}
