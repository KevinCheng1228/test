///<reference path="../node_modules/grafana-sdk-mocks/app/headers/common.d.ts" />
import _ from 'lodash';
import $ from 'jquery';
import kbn from 'app/core/utils/kbn';
import {MetricsPanelCtrl, loadPluginCss} from 'app/plugins/sdk';
import {transformDataToTable} from './transformers';
import {tablePanelEditor} from './editor';
import {TablePanelDisplay} from './display';
import {columnOptionsTab} from './column_options';
import {rowOptionsTab} from './row_options';
import {addColumnOptionsTab} from './add_column_options';
import {statusTab} from './status';
import {reportColumnSetting} from './report_column_setting';
import {TableRenderer} from './renderer';
import ChangeFont from './fontsize';
import appEvents from 'app/core/app_events';
import config from 'app/core/config';

System.import('plugins/ene-report-panel/css/default.css' + '!css');
loadPluginCss({
  dark: 'plugins/ene-report-panel/css/dark.css',
  light: 'plugins/ene-report-panel/css/light.css',
});

class TablePanelCtrl extends MetricsPanelCtrl {
  static templateUrl = 'partials/module.html';

  pageIndex: number;
  dataRaw: any;
  table: any;
  renderer: any;
  conditiontypes: any;
  searchConditions: any;
  lightTheme: boolean;
  tableHeader: any;
  hoverBGColorSet: any;
  dataNum: number;
  addFilter: boolean;
  filterType: string;
  filterCondition: string;
  filterValue: string;
  addFilterName: string;
  filterTip: string;
  mergeHeight: string;
  headerBoldCss: any;
  filterActionType: String;
  translate: any;
  hiddenStatus: any;

  // li.na add start at 2019.10.12
  selectMetricNames: any = [];
  computedDataList: any = [];
  selectColumnNames: any;
  selectCols: any;
  selectRows: any;
  filterCols: any = {};
  filterRows: any = {};
  thresColumnNames: any = [];
  // li.na
  //zm
  alertState: any;
  noDataContent: any;
  //zm

  $http: any; // NH at 2021/09/18

  // Alice at 2021/10/04
  pictureTypeVal: any = [
    {
      text: 'All',
      val: 'all',
    },
    {
      text: 'JPG',
      val: '.jpg',
    },
    {
      text: 'JPEG',
      val: '.jpeg',
    },
    {
      text: 'PNG',
      val: '.png',
    },
    {
      text: 'GIF',
      val: '.gif',
    },
  ];
  pictrueType: string = 'all';
  systemLang: string = document.cookie
    .split('; ')
    .find(row => row.startsWith('systemLang='))
    .split('=')[1];
  pageTotal: number;
  isUpBtn: boolean = false;
  isDownBtn: boolean = true;
  pageNum: number = 1;
  imgList: any = [];
  inputValue: any;
  host: string;
  port: string;
  protocol: string;
  $location: any;
  isReportResponse: boolean = false;
  labelTrans: any = {
    'en-US': {
      objname: 'Object Name',
      datatime: 'Data Time',
      avg: 'Avg',
      last: 'Last',
      max: 'Max',
      min: 'Min',
      merge_empty: 'merge config can not be empty',
      merge_repeat: 'merge config can not be repeat',
      search_criteria_empty: 'Search criteria cannot be empty',
      search_criteria_repeat: 'Search criteria cannot be repeat',
      condition_empty: 'condition can not empty',
      condition_repeat: 'condition can not repeat',
    },
    'zh-CN': {
      objname: '物件名称',
      datatime: '日期时间',
      avg: '平均值',
      last: '最后值',
      max: '最大值',
      min: '最小值',
      merge_empty: '合并配置不能为空',
      merge_repeat: '合并配置不能重复',
      search_criteria_empty: '搜索条件不能为空',
      search_criteria_repeat: '搜索条件不能重复',
      condition_empty: '条件不能为空',
      condition_repeat: '条件不能重复',
    },
    'zh-TW': {
      objname: '物件名稱',
      datatime: '資料時間',
      avg: '平均值',
      last: '最後值',
      max: '最大值',
      min: '最小值',
      merge_empty: '合併設定不能為空',
      merge_repeat: '合併設定不能重複',
      search_criteria_empty: '搜尋條件不能為空',
      search_criteria_repeat: '搜尋條件不能重複',
      condition_empty: '條件不能為空',
      condition_repeat: '條件不能重複',
    },
    'ja-JP': {
      objname: 'オブジェクト名',
      datatime: 'データ時間',
      avg: '平均値',
      last: '最後値',
      max: '最大値',
      min: '最小値',
      merge_empty: 'マージ構成を空にすることはできません',
      merge_repeat: 'マージ構成を繰り返すことはできません',
      search_criteria_empty: '検索条件を空にすることはできません',
      search_criteria_repeat: '検索条件を繰り返すことはできません',
      condition_empty: '条件を空にすることはできません',
      condition_repeat: '状態を繰り返すことはできません',
    },
  };
  // Alice

  panelDefaults = {
    targets: [{}],
    transform: 'timeseries_to_columns',
    showHeader: true,

    /* cloumn styles */
    styles: [
      {
        type: 'date',
        pattern: 'Time',
        alias: 'Time',
        dateFormat: 'YYYY-MM-DD HH:mm:ss',
        titleAlign: 'left',
        align: 'left',
        unit: 'none',
        colors: [
          'rgba(245, 54, 54, 0.9)',
          'rgba(237, 129, 40, 0.89)',
          'rgba(50, 172, 45, 0.97)',
          'rgba(45, 91, 172, 0.9)',
          'rgba(247, 243, 27, 0.9)',
          'rgba(184, 27, 247, 0.9)',
        ],
        alarmColors: ['green', 'yellow', 'red', 'null'],
        colorMode: null,
      },
      {
        unit: 'short',
        type: 'number',
        alias: '',
        decimals: 2,
        colors: [
          'rgba(245, 54, 54, 0.9)',
          'rgba(237, 129, 40, 0.89)',
          'rgba(50, 172, 45, 0.97)',
          'rgba(45, 91, 172, 0.9)',
          'rgba(247, 243, 27, 0.9)',
          'rgba(184, 27, 247, 0.9)',
        ],
        colorMode: null,
        pattern: '/.*/',
        thresholds: [],
        titleAlign: 'left',
        align: 'left',
        thresholdsDisplay: [],
        arraycolors: ['rgb(23, 180, 16)', 'rgb(255, 197, 0)', 'rgb(210, 30, 0)'],
        alarmColors: ['green', 'yellow', 'red', 'null'],
        bar: false,
        url: false,
        icon: false,
      },
    ],
    columns: [],

    /* option style config */
    adjFontSize: true,
    tableTitleBold: true,
    tableTitleFont: '70%',
    tableTitleFontVal: '70%',
    fontSize: '70%',
    tableFontVal: '70%',
    tableTitlebgColorSet: '',
    tableTitleFontColorSet: '',
    oddRowBGColorSet: '',
    evenRowBGColorSet: '',
    borderColor: '',
    hoverEnabled: true,
    hoverBGColorSet: '',
    headerHidden: false,
    headerBold: false,

    /* option setting config */
    rowNumbersEnabled: false,
    stripedRowsEnabled: true,
    infoEnabled: true,
    showCellBorders: false,
    showRowBorders: true,
    compactRowsEnabled: false,
    sort: {col: 0, desc: true},
    scroll: false,
    pageSize: null,
    separateColumnsNum: '',
    separateRowsNum: '',
    separateRowOpen: '',
    separateDataHidden: false,

    /* option search */
    searchEnabled: false,
    searchBtnTextColor: '',
    searchBtnBgColor: '',
    searchcontrol: 'down',
    conditionset: [],
    spreadfold: 'spread',

    /* row styles */
    rowStyles: [
      {
        rowBGColor: '',
        rowAlias: null,
        colNum: '1',
        rowNum: '1',
        rowhtml: '',
        rowopenNewTab: false,
        thresholdConfig: {
          colorMode: null,
          thresholds: [],
          thresColumn: '',
          colors: [
            'rgba(245, 54, 54, 0.9)',
            'rgba(237, 129, 40, 0.89)',
            'rgba(50, 172, 45, 0.97)',
            'rgba(45, 91, 172, 0.9)',
            'rgba(247, 243, 27, 0.9)',
            'rgba(184, 27, 247, 0.9)',
          ],
          alarmColors: ['green', 'yellow', 'red', 'null'],
        },
      },
    ],
    activeRowStyleIndex: 0,

    /* add cloumns */
    customColumns: [],
    activeCustomColumnIndex: 0,
    customColumnsNum: 1,

    /* math */
    dataType: 'timeseries',
    metricRuleObjArr: [],
    mathInputVal: '',
    isMath: false,
    isMathInputVal: false,
    isMathTip: false,
    dataTableVersion: 'new',

    /* Merging */
    mergeColums: [],
    mergeType: 'nameString',
    mergeBottom: false,

    /* status */
    statusLamp: [],
    activeStatusIndex: 0,
    breakWord: false,

    /* report */
    reportEnabled: false,
    reportBtnText: '',
    reportBtnTextColor: '',
    reportBtnBgColor: '',
    imgSelectEnabled: false,
    reportSetting: {
      title: '',
      subtitle: '',
      logo: '',
      reporter: '',
      auditor: '',
      approver: '',
      range: '',
      timeZoneOffset: 0,
      targets: [],
      maxDataPoints: 0,
      lang: 'en-US',
      sort: {},
      columnSetting: [
        // {
        //   "text": "objectname",
        //   "title": "Object Name",
        //   "hidden": false
        // },
        // {
        //   "text": "datatime",
        //   "title": "Data Time",
        //   "format": "YYYY-MM-DD",
        //   "hidden": false
        // },
        // {
        //   "text":"CalcPlus1",
        //   "title":"CalcPlus",
        //   "subTitle":[
        //     {
        //       "text":"CalcPlus1.last",
        //       "title":"Last",
        //       "hidden":true
        //     },
        //     {
        //       "text":"CalcPlus1.avg",
        //       "title":"CalcPlus1's Avg",
        //       "hidden":false
        //     },
        //     {
        //       "text":"CalcPlus1.max",
        //       "title":"CalcPlus1's Max",
        //       "hidden":false
        //     },
        //     {
        //       "text":"CalcPlus1.min",
        //       "title":"CalcPlus1's Min",
        //       "hidden":false
        //     }
        //   ]
        // },
      ],
    },
  };

  /** @ngInject */
  constructor(
    $scope,
    $injector,
    templateSrv,
    $http,
    private annotationsSrv,
    private $sanitize,
    private variableSrv,
    private contextSrv
  ) {
    super($scope, $injector);

    // Alice
    this.$location = $injector.get('$location');
    this.host = this.$location.host();
    this.port = this.$location.port();
    this.protocol = this.$location.protocol();
    // Alice

    this.pageIndex = 0;
    this.dataNum = 0;
    this.translate = $injector.get('$translate');
    this.$http = $http;
    if (contextSrv.user && contextSrv.user.lightTheme) {
      this.lightTheme = true;
    }
    this.hoverBGColorSet = this.lightTheme ? '#f1f1f1' : '#1b1b1b';

    if (this.panel.styles === void 0) {
      this.panel.styles = this.panel.columns;
      this.panel.columns = this.panel.fields;
      delete this.panel.columns;
      delete this.panel.fields;
    }

    this.conditiontypes = [
      {text: 'String', value: 'string'},
      {text: 'Number', value: 'number'},
    ];
    this.filterType = 'number';
    this.filterCondition = '>';
    this.filterValue = '';
    this.addFilterName = '';
    this.searchConditions = {
      number: [
        {text: '>', value: '>'},
        {text: '<', value: '<'},
        {text: '=', value: '='},
        {text: '!=', value: '!='},
        {text: '>=', value: '>='},
        {text: '<=', value: '<='},
      ],
      string: [
        {text: 'has', value: 'has'},
        {text: 'not has', value: 'not has'},
        {text: 'equals', value: 'equals'},
      ],
    };
    //zm
    this.alertState = null;
    if (config.configPropsValue) {
      this.noDataContent = config.configPropsValue.noDataToShow;
    }
    //zm

    //add columns compatible the previous version
    this.addColumnsCompatible();

    _.defaults(this.panel, this.panelDefaults);

    this.updateSchemaVersion();
    this.compatibleProcessing();

    if (this.scope.$$listeners.isWisePaas) {
      this.events.on('data-received', this.onDataReceived.bind(this));
      this.events.on('data-error', this.onDataError.bind(this));
      this.events.on('data-snapshot-load', this.onDataReceived.bind(this));
      this.events.on('init-edit-mode', this.onInitEditMode.bind(this));
      this.events.on('init-panel-actions', this.onInitPanelActions.bind(this));
    }

    // li.na add start at 2019.10.12
    if (this.panel.dataType === 'timeseries') {
      const usedName = this.panel.metricRuleObjArr.map(elem => {
        return elem.name;
      });
      const datasourceType = this.panel.datasource;
      let selectMetricNames = this.panel.targets.map(e => {
        const eTag =
          datasourceType === 'scada' || datasourceType === 'rmm' ? e.refId : e.alias;
        if (usedName.indexOf(eTag) === -1) {
          return eTag;
        }
      });
      selectMetricNames = selectMetricNames.filter(element => {
        if (element !== undefined) {
          return true;
        }
        return false;
      });
      this.panel.metricRuleObjArr.forEach(elem => {
        elem.selectMetricNames = [elem.name].concat(selectMetricNames);
      });
    }
    // li.na
  }

  updateSchemaVersion() {
    const oldVersion = this.panel.schemaVersion;
    this.panel.schemaVersion = 2;
    if (oldVersion === this.panel.schemaVersion) {
      return;
    }
    if (!oldVersion) {
      for (let i = 0; i < this.panel.styles.length; i++) {
        const style = this.panel.styles[i];
        style.titleAlign = style.align;
      }
      for (let j = 0; j < this.panel.rowStyles.length; j++) {
        const rowStyle = this.panel.rowStyles[j];
        if (rowStyle.thresholdConfig) {
          if (!rowStyle.thresholdConfig.alarmColors) {
            rowStyle.thresholdConfig.alarmColors = ['green', 'yellow', 'red', 'null'];
          }
        }
      }
    }

    if (oldVersion < 2) {
      for (let i = 0; i < this.panel.rowStyles.length; i++) {
        const rowStyle = this.panel.rowStyles[i];
        if (rowStyle && !rowStyle.hasOwnProperty('wholeRow')) {
          rowStyle.wholeRow = true;
        }
      }
    }
  }

  /* Processing refactoring the previous version */
  compatibleProcessing() {
    //options
    this.optionsCompatible();
    //column styles
    this.columnStylesCompatible();
    //row styles
    this.rowStylesCompatible();
  }

  onInitEditMode() {
    const translateArr = [
      'public.options',
      'public.display',
      'ene-report-panel.ColumnStyles',
      'ene-report-panel.RowStyles',
      'ene-report-panel.NewColumns',
      'ene-report-panel.Status',
      'ene-report-panel.ReportColumnSetting',
    ];
    this.translate(translateArr).then(translate => {
      this.addEditorTab(translate['public.options'], tablePanelEditor, 2);
      this.addEditorTab(translate['public.display'], TablePanelDisplay, 3);
      this.addEditorTab(translate['ene-report-panel.ColumnStyles'], columnOptionsTab, 4);
      this.addEditorTab(translate['ene-report-panel.RowStyles'], rowOptionsTab, 5);
      this.addEditorTab(translate['ene-report-panel.NewColumns'], addColumnOptionsTab, 6);
      this.addEditorTab(translate['ene-report-panel.Status'], statusTab, 7);
      this.addEditorTab(
        translate['ene-report-panel.ReportColumnSetting'],
        reportColumnSetting,
        8
      );
    });
    this.getImageList();
  }

  onInitPanelActions(actions) {
    actions.push({text: 'Export CSV', click: 'ctrl.exportCsv()'});
  }

  exportReportCsv() {
    const tableData = this.renderer.render_values();
    this.panel.exportReportCsv(tableData);
  }

  issueQueries(datasource) {
    this.pageIndex = 0;

    if (this.panel.transform === 'annotations') {
      this.setTimeQueryStart();
      return this.annotationsSrv
        .getAnnotations({
          dashboard: this.dashboard,
          panel: this.panel,
          range: this.range,
        })
        .then(annotations => {
          return {data: annotations};
        });
    }

    return super.issueQueries(datasource);
  }

  onDataError(err) {
    this.dataRaw = [];
    this.render();
  }

  onDataReceived(dataList) {
    document.cookie = 'ReportToken= ; expires = Thu, 01 Jan 1970 00:00:00 GMT';
    const isFunctionReport = target =>
      target.functiontype === 'report' ||
      target.functiontype === 'reportAnalogBasic' ||
      target.functiontype === 'reportMerged';
    if (isFunctionReport && dataList) {
      document.cookie = 'ReportToken=' + (dataList[0].token || '');
    }
    this.dataRaw = dataList;
    this.pageIndex = 0;
    // li.na add start at 2019.10.12
    if (
      this.dataRaw.length === 0 ||
      (this.panel.dataType === 'timeseries' && dataList[0].type === 'table')
    ) {
      this.panel.metricRuleObjArr = [];
      this.selectMetricNames = [];
      this.computedDataList = [];
      this.selectColumnNames = [];
      this.selectCols = [];
      this.selectRows = [];
      this.filterCols = {};
      this.filterRows = {};
      this.panel.dataType = '';
    }
    const datasourceType = this.getDatasourceType();
    if (dataList.length > 0 && dataList[0].type === 'table') {
      this.panel.dataType = 'table';
    } else if (dataList.length > 0 && dataList[0].target) {
      this.panel.dataType = 'timeseries';
      if (this.panel.isMath) {
        if (datasourceType === 'grafana') {
          this.computedDataList = this.handleGrafanaType(dataList);
          // } else if (datasourceType === 'test') {
          //   this.computedDataList = this.handleTestType(dataList);
        } else if (datasourceType === 'rmm') {
          this.computedDataList = this.handleRmmType(dataList);
        } else {
          this.computedDataList = this.handleDataSourceType(dataList);
        }
      } else {
        this.computedDataList = dataList;
        this.panel.mathInputVal = '';
      }
      this.dataRaw = this.computedDataList;
    }
    // li.na

    // automatically correct transform mode based on data
    if (this.dataRaw && this.dataRaw.length) {
      if (this.dataRaw[0].type === 'table') {
        this.panel.transform = 'table';
      } else {
        if (this.dataRaw[0].type === 'docs') {
          this.panel.transform = 'json';
        } else {
          if (this.panel.transform === 'table' || this.panel.transform === 'json') {
            this.panel.transform = 'timeseries_to_rows';
          }
        }
      }
    }

    //alert bug start
    this.annotationsSrv
      .getAnnotations({
        dashboard: this.dashboard,
        panel: this.panel,
        range: this.range,
      })
      .then(
        result => {
          this.alertState = result.alertState;
          this.render();
        },
        () => {
          this.render();
        }
      );
    //alert bug end;
  }

  // li.na add start at 2019.10.12
  handleGrafanaType(dataList) {
    const copyDataList = dataList.map(elem => {
      const copyDatapoints = elem.datapoints.map(dp => {
        return [dp[0], dp[1]];
      });
      return {
        datapoints: copyDatapoints,
        target: elem.target,
      };
    });
    this.selectMetricNames = ['A'];
    const metricRuleObjArr = this.panel.metricRuleObjArr;
    const currentDataList = copyDataList[0];
    let rule = '';
    metricRuleObjArr.every(element => {
      if (element.name === 'A' && element.isValid) {
        rule = element.rule;
        return false;
      }
      return true;
    });
    if (rule !== '') {
      const dps = currentDataList.datapoints;
      for (let i2 = 0; i2 < dps.length; i2++) {
        let ruleCopy = rule;
        ruleCopy = ruleCopy.replace(/A/g, dps[i2][0]);
        const calRes = this.$scope.$eval(ruleCopy);
        if (Number.isFinite(calRes)) {
          currentDataList.datapoints[i2] = [calRes, dps[i2][1]];
        } else {
          currentDataList.datapoints[i2] = dps[i2];
        }
      }
    }
    return copyDataList;
  }

  handleTestType(dataList) {
    const copyDataList = dataList.map(elem => {
      const copyDatapoints = elem.datapoints.map(dp => {
        return [dp[0], dp[1]];
      });
      return {
        datapoints: copyDatapoints,
        target: elem.target,
      };
    });
    this.selectMetricNames = dataList.map(elem => {
      return elem.refId;
    });
    let reg;
    const metricRuleObjArr = this.panel.metricRuleObjArr;
    for (let i0 = 0; i0 < dataList.length; i0++) {
      const currentDataList = dataList[i0];
      const currentDataListName = currentDataList.target;
      let rule = '';
      let ruleEveryFunction = function(element) {
        if (element.name === this.currentDataListName && element.isValid) {
          this.rule = element.rule;
          return false;
        }
        return true;
      };
      let ruleThis = {rule: rule, currentDataListName: currentDataListName};
      ruleEveryFunction = ruleEveryFunction.bind(ruleThis);
      metricRuleObjArr.every(ruleEveryFunction);
      rule = ruleThis.rule;
      if (rule !== '') {
        let copyElem = {datapoints: []};
        let copyEveryFunction = function(elem) {
          if (elem.target === this.currentDataListName) {
            this.copyElem = elem;
            return false;
          }
          return true;
        };
        let copyElemThis = {copyElem: copyElem, currentDataListName: currentDataListName};
        copyEveryFunction = copyEveryFunction.bind(copyElemThis);
        copyDataList.every(copyEveryFunction);
        copyElem = copyElemThis.copyElem;

        const dataListObj = {};
        for (let i1 = 0; i1 < dataList.length; i1++) {
          const dl = dataList[i1];
          const dln = dl.target;
          if (currentDataListName !== dln && rule.search(dln) !== -1) {
            dataListObj[dln] = dl;
          }
        }
        const dps = currentDataList.datapoints;
        for (let i2 = 0; i2 < dps.length; i2++) {
          let ruleCopy = rule;
          if (currentDataListName === 1) {
            reg = `${currentDataListName}(?![0-9])`;
          } else {
            reg = currentDataListName;
          }
          ruleCopy = ruleCopy.replace(new RegExp(currentDataListName, 'g'), dps[i2][0]);
          for (const dlok in dataListObj) {
            if (dataListObj.hasOwnProperty(dlok)) {
              if (currentDataListName === 1) {
                reg = `${dlok}(?![0-9])`;
              } else {
                reg = dlok;
              }
              ruleCopy = ruleCopy.replace(
                new RegExp(reg, 'g'),
                dataListObj[dlok].datapoints[i2][0]
              );
            }
          }
          const calRes = this.$scope.$eval(ruleCopy);
          if (Number.isFinite(calRes)) {
            copyElem.datapoints[i2] = [calRes, dps[i2][1]];
          } else {
            copyElem.datapoints[i2] = dps[i2];
          }
        }
      }
    }
    return copyDataList;
  }

  handleRmmType(dataList) {
    const refIdRMMMap = {};
    this.selectMetricNames = this.panel.targets.map(elem => {
      const key = elem.alias
        ? elem.alias
        : `${elem.device}|${elem.plugin}|${elem.sensor}`;
      const v = `${elem.refId}`;
      if (!refIdRMMMap[key]) {
        refIdRMMMap[key] = [];
      }
      refIdRMMMap[key].push(v);
      return elem.refId;
    });

    const metricRuleObjArr = this.panel.metricRuleObjArr;
    dataList.forEach(elem => {
      const currentDataListName = elem.target;
      const refIds = refIdRMMMap[currentDataListName];
      if (refIds) {
        elem.refId = refIds.shift();
        metricRuleObjArr.every(element => {
          if (element.name === elem.refId && element.isValid) {
            elem.rule = element.rule;
            return false;
          }
          return true;
        });
      }
    });

    const copyDataList = dataList.map(elem => {
      const copyDatapoints = elem.datapoints.map(dp => {
        return [dp[0], dp[1]];
      });
      return {
        refId: elem.refId,
        datapoints: copyDatapoints,
        target: elem.target,
      };
    });

    metricRuleObjArr.forEach(metricRuleObj => {
      let dataLine = {
        rule: '',
        refId: '',
        datapoints: [],
      };
      dataList.every(dle => {
        if (dle.refId === metricRuleObj.name) {
          dataLine = dle;
          return false;
        }
        return true;
      });
      let copyElem = {
        datapoints: [],
      };
      copyDataList.every(elem => {
        if (elem.refId === dataLine.refId) {
          copyElem = elem;
          return false;
        }
        return true;
      });
      if (dataLine.rule) {
        const dataListObj = {
          arr: [],
        };
        for (let i1 = 0; i1 < dataList.length; i1++) {
          const dl = dataList[i1];
          if (dl.refId !== dataLine.refId) {
            if (dataLine.rule.search(dl.refId) !== -1) {
              dataListObj[dl.refId] = {
                dataList: dl,
              };
              dataListObj.arr.push(dl.refId);
            }
          }
        }
        //isInclude select metricData
        let dps = [];
        const isInclude = metricRuleObj.rule.indexOf(`${metricRuleObj.name}`);
        if (isInclude !== -1) {
          dps = dataLine.datapoints;
        } else {
          let minIndex = Infinity;
          let minIndexDataline = {
            datapoints: [],
          };
          dataListObj.arr.forEach(k => {
            const kIndex = metricRuleObj.rule.indexOf(k);
            if (kIndex < minIndex) {
              minIndex = kIndex;
              minIndexDataline = dataListObj[k].dataList;
            }
          });
          dps = minIndexDataline.datapoints;
          copyElem.datapoints = [];
        }
        dps.forEach((ele, i2, dps) => {
          let ruleCopy = dataLine.rule;
          let reg;
          if (dataLine.refId.length === 1) {
            reg = `${dataLine.refId}(?![0-9])`;
          } else {
            reg = dataLine.refId;
          }
          ruleCopy = ruleCopy.replace(new RegExp(reg, 'g'), dps[i2][0]);
          const ts = dps[i2][1];
          dataListObj.arr.forEach(dlok => {
            const otherComputeDataList = dataListObj[dlok].dataList.datapoints;
            const matchArr = otherComputeDataList.filter(e => {
              if (e[1] === ts) {
                return true;
              }
              return false;
            });
            let v = 0;
            if (matchArr.length === 0) {
              //searh left datapoint
              let leftDataPoint = [0, -Infinity];
              otherComputeDataList.forEach(element => {
                const otherComputeDatapointTs = element[1];
                if (
                  otherComputeDatapointTs < ts &&
                  otherComputeDatapointTs > leftDataPoint[1]
                ) {
                  leftDataPoint = element;
                }
              });
              //search right datapoint
              let rightDataPoint = [0, Infinity];
              otherComputeDataList.forEach(element => {
                const otherComputeDatapointTs = element[1];
                if (
                  otherComputeDatapointTs > ts &&
                  otherComputeDatapointTs < rightDataPoint[1]
                ) {
                  rightDataPoint = element;
                }
              });
              //fill new value
              if (leftDataPoint[1] !== -Infinity && rightDataPoint[1] !== Infinity) {
                const timeOffset = rightDataPoint[1] - leftDataPoint[1];
                const valueOffset = rightDataPoint[0] - leftDataPoint[0];
                const ratio = valueOffset / timeOffset;
                const basicToLeftTimeOffset = ts - leftDataPoint[1];
                v = leftDataPoint[0] + ratio * basicToLeftTimeOffset;
              } else if (leftDataPoint[1] !== -Infinity) {
                v = leftDataPoint[0];
              } else if (rightDataPoint[1] !== Infinity) {
                v = rightDataPoint[0];
              }
            } else {
              v = matchArr[0][0];
            }
            if (dlok.length === 1) {
              reg = `${dlok}(?![0-9])`;
            } else {
              reg = dlok;
            }
            ruleCopy = ruleCopy.replace(new RegExp(reg, 'g'), '' + v);
          });
          const calRes = this.$scope.$eval(ruleCopy);
          if (Number.isFinite(calRes)) {
            copyElem.datapoints[i2] = [calRes, dps[i2][1]];
          } else {
            copyElem.datapoints[i2] = dps[i2];
          }
        });
      }
    });
    return copyDataList;
  }

  handleDataSourceType(dataList) {
    const RefIdDataSourceMap = {};
    let key = 0;
    this.selectMetricNames = this.panel.targets.map(elem => {
      const v = `${elem.refId}`;
      if (!RefIdDataSourceMap[key]) {
        RefIdDataSourceMap[key] = [];
      }
      RefIdDataSourceMap[key].push(v);
      key++;
      return elem.refId;
    });
    const metricRuleObjArr = this.panel.metricRuleObjArr;
    dataList.forEach((elem, i) => {
      const refIds = RefIdDataSourceMap[i];
      if (refIds) {
        elem.refId = refIds.shift();
        metricRuleObjArr.every(element => {
          if (element.name === elem.refId && element.isValid) {
            elem.rule = element.rule;
            return false;
          }
          return true;
        });
      }
    });
    const copyDataList = dataList.map(elem => {
      const copyDatapoints = elem.datapoints.map(dp => {
        return [dp[0], dp[1]];
      });
      return {
        refId: elem.refId,
        datapoints: copyDatapoints,
        target: elem.target,
      };
    });

    metricRuleObjArr.forEach(metricRuleObj => {
      let dataLine = {rule: '', refId: '', datapoints: []};
      dataList.every(dle => {
        if (dle.refId === metricRuleObj.name) {
          dataLine = dle;
          return false;
        }
        return true;
      });

      let copyElem = {datapoints: []};
      copyDataList.every(elem => {
        if (elem.refId === dataLine.refId) {
          copyElem = elem;
          return false;
        }
        return true;
      });

      let reg;
      if (dataLine.rule) {
        const dataListObj = {};
        for (let i1 = 0; i1 < dataList.length; i1++) {
          const dl = dataList[i1];
          if (dl.refId !== dataLine.refId) {
            if (dl.refId.length === 1) {
              reg = `${dl.refId}(?![0-9])`;
            } else {
              reg = `${dl.refId}`;
            }
            if (dataLine.rule.search(reg) !== -1) {
              dataListObj[dl.refId] = {
                dataList: dl,
              };
            }
          }
        }
        //isInclude select metricData
        let dps = [];
        let isInclude;
        if (metricRuleObj.name.length === 1) {
          reg = new RegExp(`${metricRuleObj.name}(?![0-9])`);
        } else {
          reg = new RegExp(`${metricRuleObj.name}`);
        }
        isInclude = metricRuleObj.rule.indexOf(`${metricRuleObj.name}`);
        if (isInclude !== -1) {
          //include
          dps = dataLine.datapoints;
        } else {
          //not include
          let minIndex = Infinity;
          let minIndexDataline = {datapoints: []};
          for (const k in dataListObj) {
            if (dataListObj.hasOwnProperty(k)) {
              const kIndex = metricRuleObj.rule.indexOf(k);
              if (kIndex < minIndex) {
                minIndex = kIndex;
                minIndexDataline = dataListObj[k].dataList;
              }
            }
          }
          dps = minIndexDataline.datapoints;
          copyElem.datapoints = [];
        }
        for (let i2 = 0; i2 < dps.length; i2++) {
          let ruleCopy = dataLine.rule;
          if (dataLine.refId.length === 1) {
            reg = `${dataLine.refId}(?![0-9])`;
          } else {
            reg = dataLine.refId;
          }
          ruleCopy = ruleCopy.replace(new RegExp(reg, 'g'), dps[i2][0]);
          const ts = dps[i2][1];
          for (const dlok in dataListObj) {
            if (dataListObj.hasOwnProperty(dlok)) {
              const otherComputeDataList = dataListObj[dlok].dataList.datapoints;
              let filterFunction = function(e) {
                if (e[1] === this.ts) {
                  return true;
                }
                return false;
              };
              filterFunction = filterFunction.bind({ts: ts});
              const matchArr = otherComputeDataList.filter(filterFunction);
              let v = 0;
              if (matchArr.length === 0) {
                //searh left datapoint
                let leftDataPoint = [0, -Infinity];
                let leftForEachFunction = function(element) {
                  const otherComputeDatapointTs = element[1];
                  if (
                    otherComputeDatapointTs < this.ts &&
                    otherComputeDatapointTs > this.leftDataPoint[1]
                  ) {
                    this.leftDataPoint = element;
                  }
                };
                let leftThis = {ts: ts, leftDataPoint: leftDataPoint};
                leftForEachFunction = leftForEachFunction.bind(leftThis);
                otherComputeDataList.forEach(leftForEachFunction);
                leftDataPoint = leftThis.leftDataPoint;
                //search right datapoint
                let rightDataPoint = [0, Infinity];
                let rightForEachFunction = function(element) {
                  const otherComputeDatapointTs = element[1];
                  if (
                    otherComputeDatapointTs > this.ts &&
                    otherComputeDatapointTs < this.rightDataPoint[1]
                  ) {
                    this.rightDataPoint = element;
                  }
                };
                let rightThis = {ts: ts, rightDataPoint: rightDataPoint};
                rightForEachFunction = rightForEachFunction.bind(rightThis);
                otherComputeDataList.forEach(rightForEachFunction);
                rightDataPoint = rightThis.rightDataPoint;
                //fill new value
                if (leftDataPoint[1] !== -Infinity && rightDataPoint[1] !== Infinity) {
                  const timeOffset = rightDataPoint[1] - leftDataPoint[1];
                  const valueOffset = rightDataPoint[0] - leftDataPoint[0];
                  const ratio = valueOffset / timeOffset;
                  const basicToLeftTimeOffset = ts - leftDataPoint[1];
                  v = leftDataPoint[0] + ratio * basicToLeftTimeOffset;
                } else if (leftDataPoint[1] !== -Infinity) {
                  v = leftDataPoint[0];
                } else if (rightDataPoint[1] !== Infinity) {
                  v = rightDataPoint[0];
                }
              } else {
                v = matchArr[0][0];
              }
              if (dlok.length === 1) {
                reg = `${dlok}(?![0-9])`;
              } else {
                reg = dlok;
              }
              ruleCopy = ruleCopy.replace(new RegExp(reg, 'g'), '' + v);
            }
          }
          const calRes = this.$scope.$eval(ruleCopy);
          if (Number.isFinite(calRes)) {
            copyElem.datapoints[i2] = [calRes, dps[i2][1]];
          } else {
            copyElem.datapoints[i2] = dps[i2];
          }
        }
      }
    });
    return copyDataList;
  }

  checkInputIfValid(metricRuleObj) {
    let rule = metricRuleObj.rule;
    let isValid = this.inputIfValid(rule);
    let selectMetricNames;
    if (this.panel.dataType === 'timeseries') {
      selectMetricNames = this.selectMetricNames;
    } else if (this.panel.dataType === 'table') {
      selectMetricNames = this.selectColumnNames;
      selectMetricNames = selectMetricNames.map(s => {
        return s.slice(-2, -1);
      });
    }
    let reg;
    selectMetricNames.forEach(element => {
      if (element.length === 1) {
        reg = `${element}(?![0-9])`;
      } else {
        reg = element;
      }
      rule = rule.replace(new RegExp(reg, 'g'), 1);
    });
    if (/[A-Za-z]/.test(rule)) {
      isValid = false;
    }
    if (rule !== '' && isValid === true) {
      try {
        const res = this.$scope.$eval(rule);
        if (!Number.isFinite(res)) {
          isValid = false;
        }
      } catch (error) {
        isValid = false;
      }
    }
    if (isValid) {
      metricRuleObj.isValid = true;
      metricRuleObj.inputTip = false;
    } else {
      metricRuleObj.isValid = false;
      metricRuleObj.inputTip = true;
    }
    this.refresh();
  }

  inputIfValid(rule) {
    if (rule === '') {
      return true;
    }
    const mathInputValTest = kbn.strMathFn(rule);
    if (mathInputValTest) {
      return true;
    }
    return false;
  }

  changeDatasource() {
    this.refresh();
  }
  // li.na

  searchSpreadClick(pageType) {
    if (this.panel.spreadfold === 'spread') {
      this.panel.spreadfold = 'fold';
    } else {
      this.panel.spreadfold = 'spread';
    }

    if (pageType === 'module') {
      this.render();
    }
  }

  getColumnNameOptions() {
    if (!this.table) {
      return [];
    }

    const names = [];
    if (this.table.columns) {
      _.forEach(this.table.columns, (column, key) => {
        if (!column.addStatusLampCol && column.type !== 'custom') {
          if (column.title) {
            names.push({text: column.title, value: column.title});
          }
        }
      });
    }
    return names;
  }

  getDateFormatOptions() {
    const format = [
      {text: 'YYYY-MM-DD HH:mm:ss', value: 'YYYY-MM-DD HH:mm:ss'},
      {text: 'YYYY-MM-DD', value: 'YYYY-MM-DD'},
      {text: 'YYYY-MM', value: 'YYYY-MM'},
    ];
    return format;
  }

  addSearchFilter() {
    this.addFilter = !this.addFilter;
    this.filterTip = '';
  }

  addFilterFn() {
    this.filterTip = '';
    const search: any = {};
    search.label = this.addFilterName;
    search.condition = this.filterCondition;
    search.inputType = this.filterType;
    search.text = this.filterValue;

    if (this.addFilterName === '' || !this.filterCondition || !this.filterType) {
      this.filterTip = this.labelTrans[this.systemLang].search_criteria_empty;
      return;
    }

    for (let i = 0; i < this.panel.conditionset.length; i++) {
      const condition = this.panel.conditionset[i];
      if (_.isEqual(search, condition)) {
        this.filterTip = this.labelTrans[this.systemLang].search_criteria_repeat;
        break;
      }
    }

    if (this.filterTip) {
      return;
    }

    this.panel.conditionset.push(search);
    this.addFilter = false;
    this.addFilterName = '';
    this.filterCondition = '>';
    this.filterType = 'number';
    this.filterValue = '';
    this.pageIndex = 0;
    this.render();
  }

  removeSearch(search) {
    this.panel.conditionset = _.without(this.panel.conditionset, search);
    this.render();
  }

  fontSizeChange() {
    let mobileApp = '';
    if (this.dashboard && this.dashboard.meta) {
      if (this.dashboard.meta.isPc === false) {
        mobileApp = 'mobile';
      }
    }
    const isVw = this.panel.adjFontSize;
    this.panel.tableTitleFontVal = ChangeFont.fontSizeChange(
      isVw,
      this.panel.tableTitleFont,
      mobileApp
    );
    this.panel.tableFontVal = ChangeFont.fontSizeChange(
      isVw,
      this.panel.fontSize,
      mobileApp
    );

    if (mobileApp === 'mobile') {
      this.panel.tableTitleFontVal = this.panel.tableFontVal = '14px';
    }
  }

  handleTableMath() {
    if (this.table.columns && this.table.columns.length > 0) {
      this.selectMathData();
      this.selectColumnNames = this.selectCols.map((c, i) => {
        var indexChar = String.fromCharCode(Number(i + 65));
        return c.text + '(' + indexChar + ')';
      });
      if (this.panel.isMath) {
        this.computedDataList = this.TableMath();
        if (Object.keys(this.filterCols).length > 0) {
          this.resetMathData();
        }
      } else {
        this.computedDataList = this.table.rows;
        this.panel.mathInputVal = '';
      }
      this.table.rows = this.computedDataList;
    }
  }

  selectMathData() {
    const saveRow = [];
    this.selectRows = JSON.parse(JSON.stringify(this.table.rows));
    this.selectCols = JSON.parse(JSON.stringify(this.table.columns));
    this.filterCols = {};
    this.filterRows = {};
    var hasColType = this.table.columns[0].type;
    if (hasColType) {
      this.selectCols = this.table.columns.filter((col, i) => {
        if (col.type === 'number') {
          saveRow.push(i);
          return true;
        } else {
          let filterValueArr = [];
          this.filterCols[i] = col;
          this.table.rows.forEach(row => {
            const filterValue = String(row.splice(i, 1 + 1));
            filterValueArr.push(filterValue);
          });
          this.filterRows[i] = filterValueArr;
          return false;
        }
      });
    } else {
      this.selectCols = this.table.columns.filter((col, i) => {
        var count = 0;
        this.table.rows.forEach(row => {
          if (isFinite(row[i])) {
            count++;
          }
        });
        if (count !== this.table.rows.length) {
          let filterValueArr = [];
          this.filterCols[i] = col;
          this.table.rows.forEach(row => {
            const filterValue = String(row.slice(i, i + 1));
            filterValueArr.push(filterValue);
          });
          this.filterRows[i] = filterValueArr;
          return false;
        } else {
          saveRow.push(i);
          return true;
        }
      });
    }
    this.selectRows.forEach(srow => {
      srow.splice(0, srow.length);
    });
    this.table.rows.forEach((row, k) => {
      if (saveRow.length > 0) {
        saveRow.forEach((s, t) => {
          this.selectRows[k].push(row[s]);
        });
      }
    });
    if (saveRow.length === 0) {
      this.selectRows = JSON.parse(JSON.stringify(this.table.rows));
    }
  }

  TableMath() {
    const metricRuleObjArr = this.panel.metricRuleObjArr;
    let copyDataRows = this.selectRows.map(row => {
      const rowCopy = row.map(col => {
        return col;
      });
      return rowCopy;
    });
    metricRuleObjArr.forEach(metricRuleObj => {
      if (metricRuleObj.isValid && metricRuleObj.rule !== '') {
        let ruleCopy;
        let calRes;
        let colResArr = [];
        this.selectRows.forEach(row => {
          ruleCopy = metricRuleObj.rule;
          this.selectColumnNames.forEach((name, i) => {
            let item = name.slice(-2, -1);
            ruleCopy = ruleCopy.replace(new RegExp(item, 'g'), row[i]);
          });
          calRes = this.$scope.$eval(ruleCopy);
          colResArr.push(calRes);
        });
        this.selectColumnNames.forEach((col, j) => {
          if (metricRuleObj.name === col) {
            copyDataRows.forEach((row, k) => {
              row[j] = colResArr[k];
            });
          }
        });
      }
    });
    return copyDataRows;
  }

  resetMathData() {
    if (Object.keys(this.filterCols).length > 0) {
      this.computedDataList.forEach((row, i) => {
        for (var k in this.filterRows) {
          if (this.filterRows[k][i] !== '') {
            row.splice(k, 0, this.filterRows[k][i]);
          }
        }
      });
    }
  }

  render() {
    this.fontSizeChange();
    this.table = transformDataToTable(this.dataRaw, this.panel);
    this.table.sort(this.panel.sort);
    if (this.panel.dataType === 'table' && this.panel.isMath) {
      this.handleTableMath();
    }

    this.renderer = new TableRenderer(
      this.panel,
      this.table,
      this.dashboard.isTimezoneUtc(),
      this.$sanitize,
      this.templateSrv,
      this.lightTheme,
      this.dataRaw
    );

    // li.na add
    this.thresColumnNames = _.map(this.table.columns, (col: any) => {
      if (col.addStatusLampCol) {
        return '';
      }
      return col.text;
    });
    this.thresColumnNames.unshift('');
    const isFunctionReport = target =>
      target.functiontype === 'report' || target.functiontype === 'reportAnalogBasic';
    if (this.panel.targets.every(isFunctionReport)) {
      if (this.panel.reportSetting.columnSetting.length <= 0) {
        this.panel.reportSetting.columnSetting = _.cloneDeep(
          this.columnSettingMaker(this.table)
        );
      } else {
        this.panel.reportSetting.columnSetting = _.cloneDeep(
          this.columnSettingCompare(
            this.panel.reportSetting.columnSetting,
            this.columnSettingMaker(this.table)
          )
        );
      }
      this.columnStyleMatch();
    }
    // Handle subtitle hiding
    this.hiddenStatus = {};
    this.panel.styles.forEach(style => {
      if (style.pattern.indexOf('.') > -1) {
        if (!this.hiddenStatus[style.pattern.substring(0, style.pattern.indexOf('.'))]) {
          this.hiddenStatus[style.pattern.substring(0, style.pattern.indexOf('.'))] = [];
        }
        if (style.type !== 'hidden') {
          this.hiddenStatus[style.pattern.substring(0, style.pattern.indexOf('.'))].push(
            style.type
          );
        }
      }
    });
    this.mergeCheckAfterHide();

    return super.render(this.table);
  }

  getImageList() {
    let pictrueType = this.pictrueType;
    var self_t = this;
    let pageNum = this.pageNum;

    if (pageNum === 1) {
      this.isUpBtn = false;
      this.isDownBtn = true;
    } else if (pageNum === this.pageTotal) {
      this.isDownBtn = false;
      this.isUpBtn = true;
    } else {
      this.isUpBtn = true;
      this.isDownBtn = true;
    }

    this.$http({
      method: 'GET',
      url:
        '/api/images/getImageListDetail?type=' +
        pictrueType +
        '&pageSize=10&pageNum=' +
        pageNum,
    })
      .then(function(response) {
        if (response.data && response.data.imageInfo) {
          self_t.imgList = [];
          let accepctFormat = ['gif', 'jpeg', 'jpg', 'png'];
          response.data.imageInfo.forEach(e => {
            if (
              accepctFormat.findIndex(
                x => e.name.substring(e.name.lastIndexOf('.') + 1) === x
              ) > -1
            ) {
              self_t.imgList.push(e);
            }
          });
          for (let i = 0; i < self_t.imgList.length; i++) {
            self_t.imgList[i].url =
              '/api/images/getImage?imageId=' + self_t.imgList[i].id;
          }

          self_t.pageTotal = Math.ceil(response.data.pageTotal / 10);
          if (self_t.pageTotal <= 1) {
            self_t.pageNum = 1;
          }
        }
      })
      .catch(function(error) {
        console.log(error);
      });
  }

  checkFn(index) {
    var checkBox = document.getElementsByClassName('check');
    if (checkBox.length > 0) {
      for (var i = 0; i < checkBox.length; i++) {
        let id = checkBox[i].id;
        let idNum = Number(id.slice(5, id.length));
        let selectItem = document.getElementById(checkBox[i].id) as HTMLInputElement;
        if (idNum != index) {
          selectItem.checked = false;
        } else {
          selectItem.checked = true;
        }
      }
    }
    this.panel.reportSetting.logo =
      this.protocol +
      '://' +
      this.host +
      ':' +
      this.port +
      '/api/images/getImage?imageId=' +
      index;
    this.render();
  }

  pageChange(index) {
    switch (index) {
      case 'down':
        if (this.pageNum < this.pageTotal) {
          this.pageNum++;
        }
        break;
      case 'up':
        if (this.pageNum > 1) {
          this.pageNum--;
        }
        break;
      default:
        this.inputValue = document.getElementById('pageNumVal');
        let pageNum = Number(this.inputValue.value);
        if (1 <= pageNum && pageNum <= this.pageTotal) {
          this.pageNum = pageNum;
          document.getElementById('pageNumVal').style.border = '1px solid #ddd';
        } else {
          document.getElementById('pageNumVal').style.border = '1px solid red';
        }
        break;
    }
    this.getImageList();
  }

  resetReportButton() {
    this.panel.reportBtnText = '';
    this.panel.reportBtnTextColor = '';
    this.panel.reportBtnBgColor = '';
  }

  resetSearchButton() {
    this.panel.searchBtnTextColor = '';
    this.panel.searchBtnBgColor = '';
  }

  columnSettingMaker(tableData) {
    let columnStruct = [];
    let targetArry = [];
    let dotIndex = -1;
    let target = '';
    let targetIndex = null;
    tableData.columns.forEach(element => {
      dotIndex = element.text.indexOf('.');
      target = element.text.substring(0, dotIndex);
      if (dotIndex > -1 && !targetArry.find(e => e === target)) {
        targetArry.push(target);
        columnStruct.push({
          text: target,
          title: target,
          subTitle: [],
        });
      }
      if (dotIndex > -1 && targetArry.find(e => e === target)) {
        targetIndex = columnStruct
          .map(function(e) {
            return e.text;
          })
          .indexOf(target);
        columnStruct[targetIndex].subTitle.push({
          text: element.text,
          title: element.title,
          hidden: false,
        });
      } else {
        let column = {
          text: element.text,
          title: element.title,
          hidden: false,
        };
        if (column.text === 'datatime') {
          let style = this.panel.styles.find(x => {
            return x.pattern === 'datatime';
          });
          column['format'] = style ? style.dateFormat : 'YYYY-MM-DD HH:mm:ss';
        }
        columnStruct.push(column);
      }
    });
    return columnStruct;
  }

  columnSettingCompare(orginalData, newData) {
    let result = _.cloneDeep(orginalData);
    if (_.isEqual(orginalData, newData)) {
      return result;
    } else {
      newData.forEach((item, index) => {
        if (
          result.find(x => {
            return x.text === item.text;
          })
        ) {
          const data = result.find(x => {
            return x.text === item.text;
          });
          if (data.text === 'datatime' && data.hasOwnProperty('format')) {
            newData[index].format = data.format;
            newData[index].title = data.title;
          } else {
            newData[index] = data;
          }
        }
      });
      result = _.cloneDeep(newData);
      return result;
    }
  }

  columnStyleMatch() {
    let newStyleRule = {
      unit: 'none',
      type: 'number',
      alias: '',
      decimals: 2,
      colors: [
        'rgba(245, 54, 54, 0.9)',
        'rgba(237, 129, 40, 0.89)',
        'rgba(50, 172, 45, 0.97)',
        'rgba(45, 91, 172, 0.9)',
        'rgba(247, 243, 27, 0.9)',
        'rgba(184, 27, 247, 0.9)',
      ],
      colorMode: null,
      pattern: '',
      dateFormat: 'YYYY-MM-DD HH:mm:ss',
      thresholds: [],
      mappingType: 1,
      titleAlign: 'left',
      align: 'left',
      thresholdsDisplay: [],
      arraycolors: ['rgb(23, 180, 16)', 'rgb(255, 197, 0)', 'rgb(210, 30, 0)'],
      alarmColors: ['green', 'yellow', 'red', 'null'],
      bar: false,
      url: false,
      icon: false,
      handler: 'ResetValue',
      icontype: 'reset',
      operNum: 1,
      operationList: [
        {
          type: 'reset',
          handler: 'ResetValue',
        },
      ],
    };

    let currentTarget = this.table.columns.map(x => x.text);
    // remove pattern no match style
    this.panel.styles.forEach((style, index) => {
      if (
        currentTarget.indexOf(style.pattern) === -1 ||
        style.pattern.indexOf('/') > -1
      ) {
        this.panel.styles.splice(index, 1);
      }
    });

    this.panel.mergeColums = [];

    // add style for no style's pattern
    this.panel.reportSetting.columnSetting.forEach(element => {
      if (element.subTitle) {
        this.panel.mergeColums.push({
          end: element.subTitle[element.subTitle.length - 1].text,
          name: element.title + (element.unit ? ' (' + element.unit + ')' : ''),
          start: element.subTitle[0].text,
        });
        element.subTitle.forEach(subElement => {
          if (
            !this.panel.styles.find(style => {
              return style.pattern === subElement.text;
            })
          ) {
            newStyleRule.pattern = subElement.text;
            this.panel.styles.push(_.cloneDeep(newStyleRule));
          }
        });
      } else {
        if (
          !this.panel.styles.find(style => {
            return style.pattern === element.text;
          })
        ) {
          newStyleRule.pattern = element.text;
          if (element.text !== 'datatime') {
            this.panel.styles.push(_.cloneDeep(newStyleRule));
          } else {
            let datatimeStyle = {
              type: 'date',
              pattern: element.text,
              alias: element.title,
              dateFormat: 'YYYY-MM-DD HH:mm:ss',
              titleAlign: 'left',
              align: 'left',
              unit: 'none',
              colors: [
                'rgba(245, 54, 54, 0.9)',
                'rgba(237, 129, 40, 0.89)',
                'rgba(50, 172, 45, 0.97)',
                'rgba(45, 91, 172, 0.9)',
                'rgba(247, 243, 27, 0.9)',
                'rgba(184, 27, 247, 0.9)',
              ],
              alarmColors: ['green', 'yellow', 'red', 'null'],
              colorMode: null,
            };
            this.panel.styles.push(_.cloneDeep(datatimeStyle));
          }
        }
      }
    });
  }

  columnTableChange(item, pos) {
    // change
    if (pos === 'columnStyles') {
      this.panel.reportSetting.columnSetting.find(element => {
        if (element.subTitle) {
          element.subTitle.find(subElement => {
            if (item.pattern === subElement.text) {
              subElement.title = item.alias;
              subElement.hidden = item.type === 'hidden' ? true : false;
            }
          });
        } else {
          if (item.pattern === element.text) {
            element.title = item.alias;
            element.hidden = item.type === 'hidden' ? true : false;
          }
        }
      });
    } else if (pos === 'item' || pos === 'subitem') {
      this.panel.styles.find(element => {
        if (element.pattern === item.text) {
          element.alias = item.title;
          element.type = item.hidden
            ? 'hidden'
            : item.text === 'datatime' ? 'date' : 'objectname' ? 'string' : 'number';
        }
      });
    }
    this.render();
  }

  datatimeFormatChange(item) {
    this.panel.styles.find(x => {
      if (x.pattern === 'datatime') {
        x.type = 'date';
        x.dateFormat = item.format;
      }
    });
    this.render();
  }

  mergeCheckAfterHide() {
    let result = _.cloneDeep(this.panel.mergeColums);
    let dotIndex = -1;
    let target = '';
    if (this.panel.mergeColums.length > 0) {
      result.forEach(element => {
        dotIndex = element.start.indexOf('.');
        target = element.start.substring(0, dotIndex);
        let subTitleObj = _.cloneDeep(
          this.panel.reportSetting.columnSetting.find(element => {
            return element.text === target && element.subTitle;
          })
        );
        if (subTitleObj) {
          let newStartText = subTitleObj.subTitle.find(x => {
            return !x.hidden;
          });
          let newEndText = subTitleObj.subTitle.reverse().find(y => {
            return !y.hidden;
          });
          element.start = newStartText.text;
          element.end = newEndText.text;
        }
      });
    }
    this.panel.mergeColums = _.cloneDeep(result);
  }

  mergeColumsTitleChage(item) {
    let dotIndex = -1;
    let target = '';
    if (this.panel.mergeColums.length > 0) {
      this.panel.mergeColums.forEach(element => {
        dotIndex = element.start.indexOf('.');
        target = element.start.substring(0, dotIndex);
        if (target === item.text) {
          element.title = item.title + (item.unit ? ' (' + item.unit + ')' : '');
        }
      });
    }
    this.render();
  }

  toggleColumnSort(col, colIndex) {
    // remove sort flag from current column
    if (this.table.columns[this.panel.sort.col]) {
      this.table.columns[this.panel.sort.col].sort = false;
    }

    if (this.panel.sort.col === colIndex) {
      if (this.panel.sort.desc) {
        this.panel.sort.desc = false;
      } else {
        this.panel.sort.col = null;
      }
    } else {
      this.panel.sort.col = colIndex;
      this.panel.sort.desc = true;
    }
    this.render();
  }

  moveQuery(target, direction) {
    super.moveQuery(target, direction);
    super.refresh();
  }

  exportCsv() {
    const scope = this.$scope.$new(true);
    scope.tableData = this.renderer.render_values();
    scope.panel = 'table';
    this.publishAppEvent('show-modal', {
      templateHtml:
        '<export-data-modal panel="panel" data="tableData"></export-data-modal>',
      scope,
      modalClass: 'modal--narrow',
    });
  }

  searchResult(value, search) {
    let isResult = false;
    if (search.inputType === 'number') {
      const text = parseFloat(search.text);
      value = parseFloat(value);
      if (search.condition === '>') {
        if (value > text) {
          isResult = true;
        }
      } else if (search.condition === '>=') {
        if (value >= text) {
          isResult = true;
        }
      } else if (search.condition === '<=') {
        if (value <= text) {
          isResult = true;
        }
      } else if (search.condition === '<') {
        if (value < text) {
          isResult = true;
        }
      } else if (search.condition === '=') {
        if (value === text) {
          isResult = true;
        }
      } else if (search.condition === '!=') {
        if (value !== text) {
          isResult = true;
        }
      }
    } else if (search.inputType === 'string') {
      const val = value.toString();
      const text = search.text;
      if (search.condition === 'has') {
        if (val.indexOf(text) !== -1) {
          isResult = true;
        }
      } else if (search.condition === 'not has') {
        if (val.indexOf(text) === -1) {
          isResult = true;
        }
      } else if (search.condition === 'equals') {
        if (val === text) {
          isResult = true;
        }
      }
    }

    return isResult;
  }

  searchData(data) {
    const searchs = this.panel.conditionset;
    const searchConditions = [];
    for (let i = 0; i < searchs.length; i++) {
      const search = searchs[i];
      let canSearch = false;
      if (search.inputType && search.condition && search.text) {
        canSearch = true;
      }

      if (data.columns && canSearch) {
        let colIndex = 0;
        let unit = null;
        let decimals = '';
        for (let c = 0; c < data.columns.length; c++) {
          const col = data.columns[c];
          if (col.title === search.label) {
            colIndex = c;
            if (col.type === 'number') {
              unit = col.unit || (col.style && col.style.unit);
              decimals = col.decimals || (col.style && col.style.decimals);
            }
          } else {
            if (this.panel.styles[this.panel.styles.length - 1].pattern === '/.*/') {
              const num = this.panel.styles.length - 1;
              const style = this.panel.styles[num];
              if (style.type === 'number') {
                unit = style.unit;
                decimals = style.decimals;
              }
            }
          }
        }
        searchConditions.push({
          colIndex: colIndex,
          unit: unit,
          decimals: decimals,
          inputType: search.inputType,
          condition: search.condition,
          text: search.text,
        });
      }
    }

    const removeRows = [];
    if (searchConditions.length > 0) {
      this.dataNum = data.rows.length;
      for (let r = 0; r < data.rows.length; r++) {
        const row = data.rows[r];
        let isResult = true;

        for (let s = 0; s < searchConditions.length; s++) {
          const index = searchConditions[s].colIndex;
          let rowData = row[index];
          if (_.isNumber(rowData)) {
            if (searchConditions[s].decimals !== '') {
              const valueFormatter = kbn.valueFormats[searchConditions[s].unit || 'none'];
              rowData = valueFormatter(row[index], searchConditions[s].decimals, null);
            }
          }
          isResult = this.searchResult(rowData, searchConditions[s]);
          if (!isResult) {
            break;
          }
        }

        if (!isResult) {
          removeRows.push(row);
        }
      }
    } else {
      this.dataNum = 0;
    }
    _.pull(data.rows, ...removeRows);
  }

  scrollEvent(elem, ctrl) {
    const scrollElem = elem.find('.report-panel-scroll');
    let left = 0;

    scrollElem[0].addEventListener('scroll', () => {
      const scrollLeft = scrollElem.scrollLeft();
      const scrollTop = scrollElem.scrollTop();

      const elemThead = elem.find('thead');
      if (elemThead.length > 0) {
        elemThead[0].style.transform = 'translateY(' + scrollTop + 'px)';
      }

      if (scrollLeft !== left) {
        const scrollDvalue = scrollLeft - left;
        const tableTitleElem = elem.find('.report-panel-table-title');
        if (tableTitleElem.length > 0) {
          for (let t = 0; t < tableTitleElem.length; t++) {
            const left = parseInt(tableTitleElem[t].style.left);
            tableTitleElem[t].style.left = left - scrollDvalue + 'px';
          }
        }

        const mergeTitleElem = elem.find('.report-panel-merge-title');
        if (mergeTitleElem.length > 0) {
          for (let i = 0; i < mergeTitleElem.length; i++) {
            const left = parseInt(mergeTitleElem[i].style.left);
            mergeTitleElem[i].style.left = left - scrollDvalue + 'px';
          }
        }
      }
      left = scrollLeft;
    });
  }

  // li.na add start at 2019.10.12
  addMetricRuleEntry() {
    if (this.panel.dataType === 'table') {
      const usedName = this.panel.metricRuleObjArr.map(elem => {
        return elem.name;
      });
      //this.panel.selectColumnNames = [];
      var selectColumnNames;
      selectColumnNames = this.selectColumnNames.map(e => {
        if (usedName.indexOf(e) === -1) {
          return e;
        }
      });
      selectColumnNames = selectColumnNames.filter(element => {
        if (element !== undefined) {
          return true;
        }
        return false;
      });
      this.panel.metricRuleObjArr.push({
        name: '',
        rule: '',
        isValid: false,
        inputTip: false,
        selectMetricNames: selectColumnNames,
      });
    } else {
      const usedName = this.panel.metricRuleObjArr.map(elem => {
        return elem.name;
      });
      let selectMetricNames = [];
      const datasourceType = this.getDatasourceType();
      if (datasourceType === 'grafana' && this.panel.metricRuleObjArr.length === 0) {
        selectMetricNames.push('A');
      } else if (datasourceType === 'scada' || datasourceType === 'rmm') {
        selectMetricNames = this.panel.targets.map(e => {
          const eTag =
            datasourceType === 'scada' || datasourceType === 'rmm' ? e.refId : e.alias;
          if (usedName.indexOf(eTag) === -1) {
            return eTag;
          }
        });
      } else {
        selectMetricNames = this.panel.targets.map(e => {
          const eTag = e.refId;
          if (usedName.indexOf(eTag) === -1) {
            return eTag;
          }
        });
      }
      selectMetricNames = selectMetricNames.filter(element => {
        if (element !== undefined) {
          return true;
        }
        return false;
      });
      this.panel.metricRuleObjArr.push({
        name: '',
        rule: '',
        isValid: false,
        inputTip: false,
        selectMetricNames: selectMetricNames,
      });
    }
  }

  getDatasourceType() {
    if (/scada/i.test(this.datasource.meta.name)) {
      return 'scada';
    }
    if (/rmm/i.test(this.datasource.meta.name)) {
      return 'rmm';
    }
    if (/grafana/i.test(this.datasource.meta.name)) {
      return 'grafana';
    }
    if (/test/i.test(this.datasource.meta.name)) {
      return 'test';
    }
    return null;
  }

  deleteMetricRuleEntry(metricRuleObj) {
    if (this.panel.dataType === 'table') {
      this.panel.metricRuleObjArr.splice(
        this.panel.metricRuleObjArr.indexOf(metricRuleObj),
        1
      );
      const usedName = this.panel.metricRuleObjArr.map(elem => {
        return elem.name;
      });
      let selectColumnNames = [];
      selectColumnNames = this.selectColumnNames.map(e => {
        if (usedName.indexOf(e) === -1) {
          return e;
        }
      });
      selectColumnNames = selectColumnNames.filter(element => {
        if (element !== undefined) {
          return true;
        }
        return false;
      });
      this.panel.metricRuleObjArr.forEach(ele => {
        ele.selectMetricNames = [ele.name].concat(selectColumnNames);
      });
    } else {
      this.panel.metricRuleObjArr.splice(
        this.panel.metricRuleObjArr.indexOf(metricRuleObj),
        1
      );
      const usedName = this.panel.metricRuleObjArr.map(elem => {
        return elem.name;
      });

      let selectMetricNames = [];
      const datasourceType = this.getDatasourceType();
      if (datasourceType === 'grafana') {
        selectMetricNames.push('A');
      } else if (datasourceType === 'scada' || datasourceType === 'rmm') {
        selectMetricNames = this.panel.targets.map(e => {
          const eTag =
            datasourceType === 'scada' || datasourceType === 'rmm' ? e.refId : e.alias;
          if (usedName.indexOf(eTag) === -1) {
            return eTag;
          }
        });
      } else {
        selectMetricNames = this.panel.targets.map(e => {
          const eTag = e.refId;
          if (usedName.indexOf(eTag) === -1) {
            return eTag;
          }
        });
      }

      selectMetricNames = selectMetricNames.filter(element => {
        if (element !== undefined) {
          return true;
        }
        return false;
      });

      if (datasourceType === 'grafana') {
        if (this.panel.metricRuleObjArr.length >= 1) {
          if (usedName.indexOf('A') === -1) {
            this.panel.metricRuleObjArr[0].selectMetricNames = selectMetricNames;
          }
        }
      } else {
        this.panel.metricRuleObjArr.forEach(ele => {
          ele.selectMetricNames = [ele.name].concat(selectMetricNames);
        });
      }
    }
    this.refresh();
  }
  // li.na
  //report
  columnSettingMakerForOtherFunction() {
    let structOne = []; // level one
    let structTwo = []; // level two
    let struct = [];
    let startPos = null;
    let endPos = null;

    this.table.columns.forEach(element => {
      let levelOneStruct = {};
      if (element.type === 'date') {
        levelOneStruct = {
          text: element.text,
          title: element.title,
          format: element.style.dateFormat,
          hidden: false,
        };
      } else {
        levelOneStruct = {
          text: element.text,
          title: element.title,
          hidden: element.type === 'hidden' ? true : false,
        };
      }
      structOne.push(levelOneStruct);
    });

    this.panel.mergeColums.forEach(element => {
      let mainStruct = {
        text: element.name,
        title: element.name,
        subTitle: [],
      };
      if (this.panel.mergeType === 'indexNum') {
        // index mode
        startPos = element.start - 1;
        endPos = element.end - 1;
      }
      if (this.panel.mergeType === 'nameString') {
        // name mode
        startPos = this.table.columns.findIndex(column => column.text === element.start);
        endPos = this.table.columns.findIndex(column => column.text === element.end);
      }
      // make the subtitle struct
      for (var i = startPos; i < endPos + 1; i++) {
        let subStruct;
        if (this.table.columns[i].type === 'date') {
          subStruct = {
            text: this.table.columns[i].text,
            title: this.table.columns[i].title,
            format: this.table.columns[i].style.dateFormat,
            hidden: false,
          };
        } else {
          subStruct = {
            text: this.table.columns[i].text,
            title: this.table.columns[i].title,
            hidden: this.table.columns[i].type === 'hidden' ? true : false,
          };
        }
        mainStruct.subTitle.push(subStruct);
      }
      structTwo.push(mainStruct);
    });
    // merge single layer and double-layer structure
    structOne.forEach((element, index) => {
      structTwo.forEach(x => {
        for (var i = 0; i < x.subTitle.length; i++) {
          if (i === 0 && element.text === x.subTitle[i].text) {
            structOne[index] = x;
          } else if (i !== 0 && element.text === x.subTitle[i].text) {
            structOne.splice(index, x.subTitle.length - 1);
          }
        }
      });
    });
    struct = _.cloneDeep(structOne);
    return struct;
  }

  reportHandle() {
    if (this.panel.targets.find(target => target.functiontype === 'reportMerged')) {
      this.panel.reportSetting.columnSetting = this.columnSettingMakerForOtherFunction();
    }
    this.refresh();
    this.isReportResponse = true;
    let range = this.timeSrv.timeRange();
    this.panel.reportSetting.range = {
      from: new Date(range.from._d).toISOString(),
      to: new Date(range.to._d).toISOString(),
      raw: range.raw,
    };
    this.panel.reportSetting.timeZoneOffset = new Date().getTimezoneOffset();
    this.panel.reportSetting.lang = this.dashboard.meta.language;
    this.panel.reportSetting.maxDataPoints = this.resolution;
    let varList = this.dashboard.templating.list || [];
    let targets = _.cloneDeep(this.panel.targets);
    if (varList.length > 0) {
      try {
        for (let i = 0; i < targets.length; i++) {
          let target = targets[i];
          var str = JSON.stringify(target);
          // let matches = [... new Set(str.match(/\$[^'"/]+/g) || [])];
          let matches = (str.match(/\$[^'"/]+/g) || []).filter((x, i, arr) => {
            return arr.indexOf(x, i + 1) == -1;
          });
          matches.length &&
            matches.forEach(x => {
              let index = varList.findIndex(y => {
                return x == '$' + y.name;
              });
              if (index !== -1) {
                let current = varList[index].current;
                let reg = new RegExp(`\\${x}`, 'g');
                let value = _.isArray(current.value)
                  ? `{${current.value.join(',')}}`
                  : current.value;
                str = str.replace(reg, value);
              }
            });
          targets[i] = JSON.parse(str);
        }
      } catch (error) {
        console.log(error);
      }
    }
    this.panel.reportSetting.sort = _.cloneDeep(this.panel.sort);
    this.panel.reportSetting.targets = targets;
    let domain = window.location.hostname.replace('dashboard', '');
    let url = `https://api-report-deviceon-bi${domain}/excelreport`;
    let cookies = window.document.cookie.split(';').map(x => {
      let arr = x.split('=');
      return {key: arr[0].trim(), value: arr[1].trim()};
    });
    let index = cookies.findIndex(x => {
      return /ReportToken/i.test(x.key);
    });
    let token = index !== -1 ? cookies[index].value : '';
    this.$http({
      url,
      method: 'POST',
      data: this.panel.reportSetting,
      responseType: 'blob',
      headers: {
        authorization: `Bearer ${token}`,
      },
    })
      .then(res => {
        this.isReportResponse = false;
        if (res && res.data && !res.data.err) {
          let fileName =
            (res.headers('Content-Disposition').match(/filename=([^;]+)/i) || [])[1] ||
            '';
          this.downloadFile(res.data, fileName);
        } else {
          console.log(res && res.data);
        }
      })
      .catch(err => {
        this.isReportResponse = false;
        console.log(err);
      });
  }
  /**
   * @name: downloadFile
   * @description: 下载文件 at 2021/09/17 NH
   * @param {*} content
   * @param {*} fileName
   * @return {*}
   */

  downloadFile(content, fileName) {
    let element = document.createElement('a');
    let blob = new Blob([content], {
      type: 'application/vnd.ms-excel,charset=UTF-8',
    });
    element.setAttribute('download', fileName || 'DataReport.xlsx');
    element.setAttribute('href', window.URL.createObjectURL(blob));
    element.click();
    window.URL.revokeObjectURL(element.href);
    element.remove();
  }

  // link start
  link(scope, elem, attrs, ctrl: TablePanelCtrl) {
    let data;
    const panel = ctrl.panel;
    let pageCount = 0;
    ctrl.scrollEvent(elem, ctrl);

    function getTableHeight() {
      let height = ctrl.height;
      const searchHeight = ctrl.panel.searchcontrol === 'up' ? 38 : 0;
      height -= searchHeight;

      if (pageCount > 1) {
        height -= 20;
      } else {
        height -= 5;
      }

      return height + 'px';
    }

    function appendSeparateBar() {
      const elemColBar = elem.find('.report-panel-table-col-bar-container');
      elemColBar.empty();

      if (!ctrl.panel.separateColumnsNum) {
        return;
      }

      const separateColumnsNums = ctrl.panel.separateColumnsNum.split(',');
      if (separateColumnsNums.length === 0) {
        return;
      }

      let elements = elem.find('.table-panel-width-hack');

      const widths = [];
      for (let i = 0; i < elements.length; i++) {
        const element = elements[i];

        const parentElementWidth = $(element)
          .parents('td')
          .outerWidth();

        widths.push(parentElementWidth);
      }
      if (widths.length === 0) {
        return;
      }

      const separates = [];
      for (let sep = 0; sep < separateColumnsNums.length; sep++) {
        const separate = parseInt(separateColumnsNums[sep]);
        let leftWidth = 0;
        for (let i = 0; i < separate; i++) {
          leftWidth += widths[i];
        }
        if (leftWidth) {
          separates.push(leftWidth);
        }
      }

      if (separates.length === 0) {
        return;
      }

      const height = elem.find('.report-panel-table').height();
      for (let s = 0; s < separates.length; s++) {
        const left = separates[s] - 2;
        elemColBar.append(`
        <div class="report-panel-table-cell-bar" style="left:${left}px;height:${height}px"></div>`);
      }
    }

    function appendTableRows(tbodyElem) {
      //zy add
      if (ctrl.renderer) {
        ctrl.renderer.setTable(data);
        tbodyElem.empty();
        tbodyElem.html(ctrl.renderer.render(ctrl.pageIndex));
        setTimeout(() => {
          appendSeparateBar();
        }, 200);
      }
    }

    function switchPage(e) {
      const el = $(e.currentTarget);
      ctrl.pageIndex = parseInt(el.text(), 10) - 1;
      renderPanel();
    }

    function appendPaginationControls(footerElem) {
      let lang = ctrl.systemLang || 'en-US';
      const translate = {
        'en-US': {
          FooterCounting: 'Showing {start} to {end} of {total}  entries',
          DataNumInfo: '(filtered from {dataNum} total entries)',
        },
        'zh-CN': {
          FooterCounting: '显示条目 {start} 到 {end} 于 {total} 条目',
          DataNumInfo: '(从总共 {dataNum} 个条目中过滤)',
        },
        'zh-TW': {
          FooterCounting: '顯示項目 {start} 到 {end} 於 {total} 項目',
          DataNumInfo: '從總共 {dataNum} 個項目中過濾',
        },
        'ja-JP': {
          FooterCounting: '{total} エントリの {start} から {end} までを表示',
          DataNumInfo: '({dataNum} 合計エントリからフィルタリング)',
        },
      };
      footerElem.empty();

      let pageSize = panel.pageSize || 10;

      if (panel.scroll) {
        pageSize = data.rows.length;
      }

      pageCount = Math.ceil(data.rows.length / pageSize);

      if (pageCount === 1) {
        return;
      }

      const startPage = Math.max(ctrl.pageIndex - 3, 0);
      const endPage = Math.min(pageCount, startPage + 9);

      const paginationList = $('<ul class="paginationList"></ul>');

      for (let i = startPage; i < endPage; i++) {
        const activeClass = i === ctrl.pageIndex ? 'active' : '';

        const pageLinkElem = $(
          '<li><a class="report-panel-page-link pointer ' +
            activeClass +
            '">' +
            (i + 1) +
            '</a></li>'
        );
        paginationList.append(pageLinkElem);
      }

      const startNum = ctrl.pageIndex * pageSize + 1;
      let endNum = startNum + pageSize - 1;

      if (endNum > data.rows.length) {
        endNum = data.rows.length;
      }

      if (data.rows.length > 0 && panel.infoEnabled && elem.width() >= 520) {
        let dataNumInfo = '';
        if (ctrl.dataNum > 0) {
          dataNumInfo = translate[lang].DataNumInfo.replace('{dataNum}', ctrl.dataNum);
        }
        const pageInfo = $(
          `<div class="pageInfo">${translate[lang].FooterCounting.replace(
            '{start}',
            startNum
          )
            .replace('{end}', endNum)
            .replace('{total}', data.rows.length)} ${dataNumInfo}</div>`
        );
        footerElem.append(pageInfo);
      }
      footerElem.append(paginationList);
    }

    function renderPanel() {
      const panelElem = elem.find('.report-panel');
      const scrollElem = elem.find('.report-panel-scroll');
      const tbodyElem = elem.find('tbody');
      const footerElem = elem.find('.report-panel-footer');
      const body = elem.closest('body');
      appendTableRows(tbodyElem);
      appendPaginationControls(footerElem);
      /* option style setting*/
      optionsStyleChange();
      panelElem.css({height: ctrl.height + 'px'});
      setTimeout(() => {
        scrollElem.css({'max-height': getTableHeight()});
      });

      resetValue(body);
    }

    function resetValue(body) {
      if (ctrl.renderer) {
        ctrl.renderer.resetValue(ctrl, body);
      }
    }

    function optionsStyleChange() {
      /* hover color */
      let beforeColor = 'unset';
      let hoverBGColorSet = ctrl.hoverBGColorSet;
      if (panel.hoverBGColorSet) {
        hoverBGColorSet = panel.hoverBGColorSet;
      }
      if (panel.hoverEnabled) {
        elem.find('tbody tr').hover(
          events => {
            const target = events.currentTarget;
            beforeColor = $(target).css('background-color');
            $(target).css({'background-color': hoverBGColorSet});
          },
          events => {
            const target = events.currentTarget;
            $(target).css({'background-color': beforeColor});
          }
        );
      }

      /* row cell border */

      if (panel.showRowBorders) {
        if (!panel.showCellBorders) {
          elem.find('tbody td').css({'border-right': 'none'});
        }
        if (panel.borderColor) {
          elem.find('tbody td').css({'border-bottom': '1px solid ' + panel.borderColor});
        }
      } else {
        if (!panel.showCellBorders) {
          elem.find('tbody td').css({'border-right': 'none'});
          elem.find('tbody td').css({'border-bottom': 'none'});
        } else {
          if (panel.borderColor) {
            elem.find('tbody td').css({'border-right': '1px solid ' + panel.borderColor});
            elem
              .find('tbody td')
              .css({'border-bottom': '1px solid ' + panel.borderColor});
            elem.find('td:last-child').css({'border-right': 'none'});
          }
        }
      }

      if (panel.compactRowsEnabled) {
        elem.find('tbody td').css({padding: '0.25em 0 0.25em 1.1em'});
      }

      if (ctrl.table.mergecolumns.length > 0 && panel.borderColor) {
        elem
          .find('.mergeThead th')
          .css({'border-right': '1px solid ' + panel.borderColor});
        elem.find('.mergeTh th:last-child').css({'border-right': 'none'});
        elem.find('thead').css({'border-bottom': '1px solid ' + panel.borderColor});
        elem.find('th:last-child').css({'border-right': 'none'});
      } else {
        elem.find('.mergeThead th').css('border-right', '');
        elem.find('thead').css('border-bottom', '');
      }

      if (panel.headerBold) {
        setTimeout(() => {
          elem.find('.mergeThead th').css({'font-weight': 'bold'});
        });
      } else {
        elem.find('.mergeThead th').css({'font-weight': 'normal'});
      }
    }

    // hook up link tooltips
    elem.tooltip({
      selector: '[data-link-tooltip]',
    });

    function addFilterClicked(e) {
      const filterData = $(e.currentTarget).data();
      const options = {
        datasource: panel.datasource,
        key: data.columns[filterData.column].text,
        value: data.rows[filterData.row][filterData.column],
        operator: filterData.operator,
      };

      ctrl.variableSrv.setAdhocFilter(options);
    }

    elem.on('click', '.report-panel-page-link', switchPage);
    elem.on('click', '.report-panel-filter-link', addFilterClicked);
    elem.on('click', 'a[id*="operation-"]', ctrl, ctrl.operationItemChange);

    const unbindDestroy = scope.$on('$destroy', () => {
      elem.off('click', '.report-panel-page-link');
      elem.off('click', '.report-panel-filter-link');
      elem.off('click', 'a[id*="operation-"]');
      unbindDestroy();
    });
    ctrl.events.on('render', renderData => {
      data = renderData || data;
      if (data) {
        if (data.rows.length > 0) {
          ctrl.searchData(data);
        }
        renderPanel();
      }
      ctrl.renderingCompleted();
    });
  }
  // link end

  optionsCompatible() {
    //paging
    if (this.panel.transform === 'timeseries_to_columns_duplicate') {
      this.panel.transform = 'timeseries_to_columns';
    }

    if (this.panel.rowsPerPage) {
      this.panel.pageSize = this.panel.rowsPerPage;
      delete this.panel.rowsPerPage;
    }

    if (this.panel.oddRowBGColor) {
      if (
        this.panel.oddRowBGColor === '#e6e6ea' ||
        this.panel.oddRowBGColor === '#323233'
      ) {
        this.panel.oddRowBGColor = '';
      }
      this.panel.oddRowBGColorSet = this.panel.oddRowBGColor;
      delete this.panel.oddRowBGColor;
    }

    if (this.panel.evenRowBGColor) {
      if (
        this.panel.evenRowBGColor === '#fafafc' ||
        this.panel.evenRowBGColor === '#464646'
      ) {
        this.panel.evenRowBGColor = '';
      }
      this.panel.evenRowBGColorSet = this.panel.evenRowBGColor;
      delete this.panel.evenRowBGColor;
    }

    if (this.panel.hoverBGColor) {
      if (
        this.panel.hoverBGColor === '#f1f1f1' ||
        this.panel.hoverBGColor === '#1b1b1b'
      ) {
        this.panel.hoverBGColor = '';
      }
      this.panel.hoverBGColorSet = this.panel.hoverBGColor;
      delete this.panel.hoverBGColor;
    }

    if (this.panel.tableTitlebgColor) {
      if (
        this.panel.tableTitlebgColor === '#1e1e1e' ||
        this.panel.tableTitlebgColor === '#d2d6df'
      ) {
        this.panel.tableTitlebgColor = '';
      }
      this.panel.tableTitlebgColorSet = this.panel.tableTitlebgColor;
      delete this.panel.tableTitlebgColor;
    }

    if (this.panel.tableTitleFontColor) {
      if (
        this.panel.tableTitleFontColor === '#008cd6' ||
        this.panel.tableTitleFontColor === '#00ffff'
      ) {
        this.panel.tableTitleFontColor = '';
      }
      this.panel.tableTitleFontColorSet = this.panel.tableTitleFontColor;
      delete this.panel.tableTitleFontColor;
    }
  }

  columnStylesCompatible() {
    //col status lamp
    let hasStatus = false;
    let statusHasStylePattern = 'no';
    if (this.panel.statusname && this.panel.statusType && this.panel.statuscondition) {
      hasStatus = true;
    }

    if (this.panel.styles) {
      for (let i = 0; i < this.panel.styles.length; i++) {
        //link url
        if (this.panel.styles[i].colhtml) {
          this.panel.styles[i].link = true;
          this.panel.styles[i].linkUrl = this.panel.styles[i].colhtml;
          delete this.panel.styles[i].colhtml;
        }

        //link target
        if (this.panel.styles[i].colopenNewTab) {
          this.panel.styles[i].linkTargetBlank = this.panel.styles[i].colopenNewTab;
          delete this.panel.styles[i].colopenNewTab;
        }

        //col style font color
        if (this.panel.styles[i].colFontColor) {
          if (
            this.panel.styles[i].colFontColor === 'rgb(50,50,51)' ||
            this.panel.styles[i].colFontColor === 'rgb(255,255,255)'
          ) {
            this.panel.styles[i].colFontColor = '';
          }
          this.panel.styles[i].colFontColorSet = this.panel.styles[i].colFontColor;
          delete this.panel.styles[i].colFontColor;
        }

        //col status lamp
        if (hasStatus) {
          if (this.panel.styles[i].pattern === this.panel.statusname) {
            this.panel.styles[i].statusLamp = this.colStatusLamp();
            statusHasStylePattern = 'has';
          }
        }
      }
      this.statusCompatible(hasStatus, statusHasStylePattern);
    }
  }

  statusCompatible(hasStatus, statusHasStylePattern) {
    if (hasStatus && statusHasStylePattern === 'no') {
      const style = {
        unit: 'short',
        type: 'string',
        alias: '',
        decimals: 2,
        colors: [
          'rgba(245, 54, 54, 0.9)',
          'rgba(237, 129, 40, 0.89)',
          'rgba(50, 172, 45, 0.97)',
          'rgba(45, 91, 172, 0.9)',
          'rgba(247, 243, 27, 0.9)',
          'rgba(184, 27, 247, 0.9)',
        ],
        colorMode: null,
        pattern: this.panel.statusname || '/.*/',
        thresholds: [],
        align: 'left',
        thresholdsDisplay: [],
        statusLamp: {},
        arraycolors: ['rgb(23, 180, 16)', 'rgb(255, 197, 0)', 'rgb(210, 30, 0)'],
        alarmColors: ['green', 'yellow', 'red', 'null'],
        bar: false,
        url: false,
        icon: false,
      };
      style.statusLamp = this.colStatusLamp();
      this.panel.styles.push(style);
    }

    if (this.panel.statusname) {
      delete this.panel.statusEnabled;
      delete this.panel.statusname;
      delete this.panel.statusType;
      delete this.panel.statuscondition;
      delete this.panel.statustext;
    }

    //兼容1.1.0版本
    for (let i = 0; i < this.panel.styles.length; i++) {
      const style = this.panel.styles[i];
      if (style.pattern === '/.*/') {
        continue;
      }
      if (style.statusLamp && style.statusLamp.value && style.statusLamp.condition) {
        this.panel.statusLamp.push({
          name: style.statusLamp.name || style.pattern + '-s',
          display: style.statusLamp.display,
          relation: '&',
          conditions: [
            {
              selected: style.alias || style.pattern,
              type: style.statusLamp.type,
              condition: style.statusLamp.condition,
              value: style.statusLamp.value,
              varValue: this.templateSrv.replace(
                style.statusLamp.value,
                this.panel.scopedVars,
                encodeURIComponent
              ),
            },
          ],
        });
        delete style.statusLamp;
      }
    }
  }

  colStatusLamp() {
    const statusLamp = {
      display: true,
      type: 'number',
      name: 'status',
      condition: this.panel.statuscondition,
      value: this.panel.statustext,
    };
    if (this.panel.statusEnabled === false) {
      statusLamp.display = false;
    }
    if (this.panel.statusType === 'string') {
      statusLamp.type = 'string';
    }

    return statusLamp;
  }

  rowStylesCompatible() {
    if (this.panel.rowStyles) {
      for (let i = 0; i < this.panel.rowStyles.length; i++) {
        //rowbgColor
        if (
          this.panel.rowStyles[i].rowbgColor === '#e6e6ea' ||
          this.panel.rowStyles[i].rowbgColor === '#323233'
        ) {
          this.panel.rowStyles[i].rowbgColor = '';
        }
        this.panel.rowStyles[i].rowBGColor = this.panel.rowStyles[i].rowbgColor;
        delete this.panel.rowStyles[i].rowbgColor;
      }
    }
  }

  addColumnsCompatible() {
    if (this.panel.dataTableVersion === 'new') {
      return;
    }

    if (this.panel.sort) {
      this.panel.sort.col = null;
    }

    if (this.panel.transform !== 'timeseries_aggregations') {
      this.panel.customColumns = [];
      this.panel.activeCustomColumnIndex = 0;
      this.panel.customColumnsNum = 1;
    }

    if (this.panel.customColumns) {
      for (let i = 0; i < this.panel.customColumns.length; i++) {
        const custom = this.panel.customColumns[i];
        this.panel.customColumns[i].colContentIndex = 0;
        this.panel.customColumns[i].type = 'custom';
        for (let c = 0; c < custom.rowContents.length; c++) {
          if (custom.rowContents[c].rowType === 'status') {
            if (custom.rowContents[c].rowStatus) {
              const num = parseInt(custom.rowContents[c].rowStatus.columnNo);
              custom.rowContents[c].rowStatus.columnNo = num + 1 + '';
            }
          }
        }
      }
    }

    if (this.panel.rowStyles) {
      for (let i = 0; i < this.panel.rowStyles.length; i++) {
        const colNum = parseInt(this.panel.rowStyles[i].colNum);
        this.panel.rowStyles[i].colNum = colNum + 1 + '';
      }
    }
  }
  operationItemChange(event) {
    let id = event.target.id;
    let ctrl = event.data;
    let data = event.target.dataset;
    ctrl.panel.showDialog = true;
    ctrl.panel.dialogData = {};
    ctrl.panel.dialogData.data = Object.assign({}, data);
    ctrl.panel.dialogData.type = id.split('-')[1];

    let setArray = {devid: data.devid, tagname: data.paramname, value: 0};
    ctrl.datasource
      .metricUpdate_setValue(setArray)
      .then(result => {
        ctrl.render();
      })
      .catch(e => {
        console.log(e);
        ctrl.appEventHandle('alert-warning', ['Error', e.message]);
      });
  }

  appEventHandle(title, msg) {
    appEvents.emit(title, msg);
  }
}

export {TablePanelCtrl, TablePanelCtrl as PanelCtrl};
