///<reference path="../node_modules/grafana-sdk-mocks/app/headers/common.d.ts" />
import _ from 'lodash';
import i18n from 'app/features/i18n';

export class statusCtrl {
  panel: any;
  dashboard: any;
  panelCtrl: any;
  addStatusLamp: any;

  statusLampType: any;
  statusLampOption: any;
  statusRelation: any;
  addBtn: boolean;
  errMsg: string;

  /** @ngInject */
  constructor($scope) {
    $scope.editor = this;
    this.panelCtrl = $scope.ctrl;
    this.panel = this.panelCtrl.panel;
    this.dashboard = this.panelCtrl.dashboard;

    this.addStatusLamp = {
      selected: '',
      type: 'string',
      condition: 'has',
      value: '',
    };

    this.statusLampType = [
      {text: 'Number', value: 'number'},
      {text: 'String', value: 'string'},
    ];
    this.statusRelation = [{text: '&', value: '&'}, {text: '||', value: '||'}];
    this.statusLampOption = {
      number: [
        {text: '>', value: '>'},
        {text: '<', value: '<'},
        {text: '=', value: '='},
        {text: '!=', value: '!='},
        {text: '>=', value: '>='},
        {text: '<=', value: '<='},
      ],
      string: [
        {text: 'has', value: 'has'},
        {text: 'not has', value: 'not has'},
        {text: 'equals', value: 'equals'},
      ],
    };

    this.addBtnStatus();
  }

  addBtnStatus() {
    if (this.panel.statusLamp.length > 0) {
      this.addBtn = false;
    } else {
      this.addBtn = true;
    }
  }

  render() {
    this.panelCtrl.render();
  }

  addNewStatus(type) {
    let num = 0;
    if (this.panel.statusLamp) {
      num = this.panel.statusLamp.length;
      if (!type) {
        this.panel.activeStatusIndex++;
      }
    }

    const status = {
      name: 'New Status' + num,
      display: true,
      relation: '&',
      conditions: [],
    };
    this.panel.statusLamp.push(status);
    this.addBtn = false;
  }

  statusLampTypeChange() {
    if (this.addStatusLamp.type === 'number') {
      this.addStatusLamp.condition = '>';
    } else {
      this.addStatusLamp.condition = 'has';
    }
  }

  addOneStatus() {
    if (this.addStatusLamp.selected === '' || !this.addStatusLamp.value) {
      this.errMsg = this.panelCtrl.labelTrans[this.panelCtrl.systemLang].condition_empty;
      return;
    }
    for (let i = 0; i < this.panel.statusLamp.length; i++) {
      const status = this.panel.statusLamp[i];
      if (this.panel.activeStatusIndex === i) {
        let repeat = false;
        for (let j = 0; j < status.conditions.length; j++) {
          const con = status.conditions[j];
          const addS = this.addStatusLamp;

          if (
            addS.selected === con.selected &&
            addS.condition == con.condition &&
            addS.value === con.value
          ) {
            repeat = true;
            break;
          }
        }
        if (repeat) {
          this.errMsg = this.panelCtrl.labelTrans[this.panelCtrl.systemLang].condition_repeat;
        } else {
          this.errMsg = '';
          status.conditions.push(_.cloneDeep(this.addStatusLamp));
        }
      }
    }

    if (!this.errMsg) {
      this.addStatusLamp = {
        selected: '',
        type: 'string',
        condition: 'has',
        value: '',
      };
      this.render();
    }
  }

  removeOnestatus(condition) {
    for (let i = 0; i < this.panel.statusLamp.length; i++) {
      const status = this.panel.statusLamp[i];
      if (this.panel.activeStatusIndex === i) {
        status.conditions = _.without(status.conditions, condition);
      }
    }
    this.render();
  }

  removeStatus() {
    const avtive = this.panel.activeStatusIndex;
    this.panel.statusLamp.splice(avtive, 1);
    i18n.deletePanelI18n(this.panel, 'customColumns', avtive);

    if (this.panel.activeStatusIndex > 0) {
      this.panel.activeStatusIndex--;
    }

    if (this.panel.statusLamp.length === 0) {
      this.addBtn = true;
    }
    this.render();
  }

  handleStatusNameChange() {
    i18n.setPanelI18n(this.panel, 'statusLamp', 'name');
  }
}

/** @ngInject */
export function statusTab($q, uiSegmentSrv) {
  'use strict';
  return {
    restrict: 'E',
    scope: true,
    templateUrl: 'public/plugins/ene-report-panel/partials/status.html',
    controller: statusCtrl,
  };
}
