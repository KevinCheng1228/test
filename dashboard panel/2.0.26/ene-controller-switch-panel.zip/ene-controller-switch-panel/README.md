# Controller Switch Panel v1.0.5

## Introduction
This panel is a simple application for showing four buttons with its information.
Two queries are for two switches, and there are two buttons in each switch.

User can select data and color of buttons for  both switches , and input value.
 
## Data Source of Machine Temperature Panel:
  - Simple SQL data source

## Query Data format:
  - table

## Query time type:
  - utc

## Query example:
Query example:

Queries  for the Controller Switch:
```
select the datasource from two of queries
input the value and title of buttons and click the button to send value 
```

### Authors
1. Advantech
2. Tsung-Yu, Chen
3. Chih-Chun, Yeh

Copyright 2019 ©  ITsung, Tom, Linda, Alisa, TingWei / Advantech.
