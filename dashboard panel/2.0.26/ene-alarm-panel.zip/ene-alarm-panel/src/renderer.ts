///<reference path="../node_modules/grafana-sdk-mocks/app/headers/common.d.ts" />

import _ from 'lodash';
import moment from 'moment';
import kbn from 'app/core/utils/kbn';
import $ from 'jquery';
import { getMultiLang } from './multilang';

export class TableRenderer {
    formatters: any[];
    colorState: any;
    SOEHisData: any = {};
    SOESortRule: any[] = [];

    constructor(
        private panel,
        private table,
        private isUtc,
        private sanitize,
        private templateSrv,
        private lightTheme,
        private dataRaw
    ) {
        this.initColumns();
    }

    setTable(table) {
        this.table = table;

        this.initMergeTitle();
        this.initColumns();
    }

    initMergeTitle() {
        if (this.panel.mergeColums.length === 0) {
            this.table.mergecolumns = [];
            this.table.mergeHeight = '';
            return;
        }

        const tableColumns = [];

        for (let i = 0; i < this.table.columns.length; i++) {
            const column = this.table.columns[i];
            if (column.hidden || (column.style && column.style.type === 'hidden')) {
                continue;
            }
            const style = {
                name: column.text,
                display: column.title,
                rowspan: 2,
                colspan: 1,
                merge: 'no',
            };
            tableColumns.push(style);
        }

        if (tableColumns.length === 0) {
            return;
        }

        const mergeNums = [];
        for (let i = 0; i < this.panel.mergeColums.length; i++) {
            const merge = this.panel.mergeColums[i];
            let startNum = null;
            let endNum = null;
            for (let j = 0; j < tableColumns.length; j++) {
                if (tableColumns[j].display === merge.start ||
                    tableColumns[j].name === merge.start) {
                    startNum = j;
                }

                if (tableColumns[j].display === merge.end || tableColumns[j].name === merge.end) {
                    endNum = j;
                }
            }

            if (startNum !== null && endNum !== null) {
                mergeNums.push({ name: merge.name, startNum: startNum, endNum: endNum });
            }
            startNum = null;
            endNum = null;
        }
        const sortMergeNums = _.sortBy(mergeNums, 'startNum');

        if (sortMergeNums.length === 0) {
            return;
        }

        let beforeHowmany = 0;
        for (let i = 0; i < sortMergeNums.length; i++) {
            const startNum = sortMergeNums[i].startNum;
            const howmany = sortMergeNums[i].endNum - startNum + 1;
            const mergeCol = {
                name: sortMergeNums[i].name,
                rowspan: 1,
                colspan: howmany,
                merge: 'yes',
            };
            tableColumns.splice(startNum - beforeHowmany, howmany, mergeCol);
            beforeHowmany = beforeHowmany + howmany - 1;
        }

        this.table.mergeHeight = '5.8em';
        this.table.mergecolumns = _.uniqBy(tableColumns, 'name');
    }

    initColumns() {
        this.formatters = [];
        this.colorState = {};

        //status and custom
        this.removeCols();
        this.pushCustomCol();

        for (let colIndex = 0; colIndex < this.table.columns.length; colIndex++) {
            const column = this.table.columns[colIndex];
            column.title = column.title || column.text;

            for (let i = 0; i < this.panel.styles.length; i++) {
                const style = this.panel.styles[i];
                const regex = kbn.stringToJsRegex(style.pattern);
                if (column.text.match(regex)) {
                    column.style = style;
                    if (style.alias) {
                        column.title = column.text.replace(regex, style.alias);
                    }
                    break;
                }
            }
            this.formatters[colIndex] = this.createColumnFormatter(column);
        }
        this.addStatusCols();
    }

    addStatusCols() {
        if (!this.panel.statusLamp || this.panel.statusLamp.length === 0) {
            return;
        }

        const addStatusLamps = [];
        for (let i = 0; i < this.panel.statusLamp.length; i++) {
            const statusLamp = this.panel.statusLamp[i];
            if (statusLamp.display && statusLamp.conditions.length > 0) {
                const conditions = this.getConditionStyles(statusLamp.conditions);
                addStatusLamps.push({
                    type: 'string',
                    addStatusLampCol: true,
                    text: statusLamp.name || 'status',
                    title: statusLamp.name || 'status',
                    relation: statusLamp.relation || '&',
                    conditions: conditions,
                    color: 'green',
                });
            }
        }

        if (addStatusLamps.length > 0) {
            this.table.columns.push(...addStatusLamps);
        }
    }

    getConditionStyles(conditions) {
        if (this.panel.styles.length === 0) {
            return conditions;
        }

        for (let i = 0; i < conditions.length; i++) {
            const condition = conditions[i];
            conditions[i].varValue = this.templateSrv.replace(
                condition.value,
                this.panel.scopedVars,
                encodeURIComponent
            );
            const num = this.panel.styles.length - 1;
            if (this.panel.styles[num] === '/.*/') {
                conditions[num]['unit'] = this.panel.styles[num].unit;
                conditions[num]['decimals'] = this.panel.styles[num].decimals;
            }

            for (let s = 0; s < this.panel.styles.length; s++) {
                const style = this.panel.styles[s];
                if (style.hidden || style.type !== 'number') {
                    continue;
                }
                if (style.title === condition.name) {
                    conditions[i]['unit'] = style.unit;
                    conditions[i]['decimals'] = style.decimals;
                }
            }
        }
        return conditions;
    }

    removeCols() {
        const removeCols = [];
        for (let colIndex = 0; colIndex < this.table.columns.length; colIndex++) {
            const column = this.table.columns[colIndex];
            if (column.addStatusLampCol || column.type === 'custom') {
                removeCols.push(column);
            }
        }

        if (removeCols.length > 0) {
            _.pull(this.table.columns, ...removeCols);
        }
    }

    pushCustomCol() {
        if (this.panel.customColumns.length > 0) {
            for (let i = 0; i < this.panel.customColumns.length; i++) {
                const customColumn = this.panel.customColumns[i];
                customColumn.text = customColumn.pattern;
                this.table.columns.push(customColumn);
            }
        }
    }

    getColorForValue(value, style, y) {
        if (!style.thresholds) {
            return null;
        }

        const thresholds = this.getThresholds(style, y);
        let colors = style.colors;

        if (style.colorMode === 'alarm' && style.alarmColors) {
            colors = style.alarmColors;
        }

        for (let i = thresholds.length; i > 0; i--) {
            const v = Number(value);
            let th = thresholds[i - 1];
            let included = th.includes('=') ? true : false;

            if (included) {
                th = th.replace('=', '');
            }

            const thval = Number(th);
            if (isNaN(v) || isNaN(thval)) {
                continue;
            }

            if (included) {
                if (v > thval) {
                    return colors[i];
                }
            } else {
                if (v >= thval) {
                    return colors[i];
                }
            }
        }

        return _.first(colors);
    }

    getThresholds(style, y) {
        let thresholds = _.cloneDeep(style.thresholds);

        if (style.type === 'date' && style.styleDatethresholds) {
            thresholds = style.styleDatethresholds;
        }

        if (this.panel.dataType === 'table' && !!style.thresColumn && typeof y === 'number') {
            let rowIndex;
            this.table.columns.forEach((c, i) => {
                if (c.text === style.thresColumn) {
                    rowIndex = i;
                }
            });
            if (this.table.rows[y][rowIndex] !== undefined) {
                thresholds = this.table.rows[y][rowIndex];
            }
        }

        let thresholdsString = _.cloneDeep(thresholds) || '';
        for (let i = 0; i < thresholds.length; i++) {
            thresholds[i] = this.templateSrv.replace(thresholds[i], this.panel.scopedVars);
        }

        if (_.isArray(thresholds)) {
            thresholdsString = thresholds.join(',');
        } else if (_.isString(thresholds)) {
            thresholdsString = thresholds;
        }

        thresholds = thresholdsString.split(',');
        return thresholds;
    }

    // get thresholds title
    getColorForTitle(value, style, y?) {
        if (!style || !style.thresholds) {
            return null;
        }

        const thresholds = this.getThresholds(style, y);

        if (!style.thresholdsDisplay) {
            return null;
        }
        if (thresholds.length > style.thresholdsDisplay.length) {
            return null;
        }
        if (style.type === 'date') {
            return null;
        }

        for (var i = 0; i < thresholds.length; i++) {
            let thval = thresholds[i];
            let included = thval.includes('=') ? true : false;
            if (included) {
                thval = thval.replace('=', '');
            }
            if (parseFloat(value) <= thval) {
                return style.thresholdsDisplay[i];
            }
        }
        // for (var i = thresholds.length; i > 0; i--) {
        //     let thval = thresholds[i - 1];
        //     let included = thval.includes('=') ? true : false;
        //     if (included) {
        //         thval = thval.replace('=', '');
        //     }
        //     if (included) {
        //         if (parseFloat(value) > thval) {
        //             return style.thresholdsDisplay[i];
        //         }
        //     } else {
        //         if (parseFloat(value) >= thval) {
        //             return style.thresholdsDisplay[i];
        //         }
        //     }
        // }

        return _.first(style.thresholdsDisplay);
    }

    defaultCellFormatter(v, style) {
        if (v === null || v === void 0 || v === undefined) {
            return '';
        }

        if (_.isArray(v)) {
            v = v.join(', ');
        }

        if (style && style.sanitize) {
            return this.sanitize(v);
        } else {
            return _.escape(v);
        }
    }

    createColumnFormatter(column) {
        if (!column.style) {
            return this.defaultCellFormatter;
        }

        if (column.style.type === 'hidden') {
            return v => {
                return undefined;
            };
        }

        if (column.style.type === 'date') {
            return v => {
                if (v === undefined || v === null) {
                    return '-';
                }

                if (_.isArray(v)) {
                    v = v[0];
                }
                let date = moment(v);
                if (this.isUtc) {
                    date = date.utc();
                }
                return date.format(column.style.dateFormat);
            };
        }

        if (column.style.type === 'string') {
            return v => {
                if (_.isArray(v)) {
                    v = v.join(', ');
                }

                const mappingType = column.style.mappingType || 0;

                if (mappingType === 1 && column.style.valueMaps) {
                    for (let i = 0; i < column.style.valueMaps.length; i++) {
                        const map = column.style.valueMaps[i];

                        if (v === null) {
                            if (map.value === 'null') {
                                return map.text;
                            }
                            continue;
                        }

                        // Allow both numeric and string values to be mapped
                        if ((!_.isString(v) && Number(map.value) === Number(v)) || map.value === v) {
                            this.setColorState(v, column.style);
                            return this.defaultCellFormatter(map.text, column.style);
                        }
                    }
                }

                if (mappingType === 2 && column.style.rangeMaps) {
                    for (let i = 0; i < column.style.rangeMaps.length; i++) {
                        const map = column.style.rangeMaps[i];

                        if (v === null) {
                            if (map.from === 'null' && map.to === 'null') {
                                return map.text;
                            }
                            continue;
                        }

                        if (Number(map.from) <= Number(v) && Number(map.to) >= Number(v)) {
                            this.setColorState(v, column.style);
                            return this.defaultCellFormatter(map.text, column.style);
                        }
                    }
                }

                if (v === null || v === void 0) {
                    return '-';
                }

                this.setColorState(v, column.style);
                return this.defaultCellFormatter(v, column.style);
            };
        }

        if (column.style.type === 'number') {
            const valueFormatter = kbn.valueFormats[column.unit || column.style.unit || 'none'];

            return v => {
                if (v === null || v === void 0) {
                    return '-';
                }

                if (_.isString(v) || _.isArray(v)) {
                    return this.defaultCellFormatter(v, column.style);
                }

                this.setColorState(v, column.style);
                return valueFormatter(v, column.style.decimals, null);
            };
        }

        if (column.style.type === 'array') {
            return v => {
                if (v === null || v === void 0) {
                    return '-';
                }

                let rv = [];

                if (_.isNumber(v)) {
                    v = v.toString();
                }

                if (v.indexOf('{') !== -1 && v.indexOf('}') !== -1) {
                    rv = v.substr(v.indexOf('{') + 1, v.lastIndexOf('}') - 1).split(',');
                } else {
                    if (_.isString(v)) {
                        rv[0] = v;
                        rv[1] = v;
                        rv[2] = 'null';
                        rv[3] = 'null';
                    } else {
                        rv[0] = v[0];
                        rv[1] = v[1] || v[0];
                        rv[2] = v[2] || 'null';
                        rv[3] = v[3] || 'null';
                    }
                }

                if (rv.length > 0) {
                    rv.forEach((val, k) => {
                        if (val && val.toLowerCase() !== 'null') {
                            const valueFormatter =
                                kbn.valueFormats[column.unit || column.style.unit || 'none'];
                            rv[k] = valueFormatter(val, column.style.decimals, null);
                        }
                    });
                    return rv;
                }
                return v;
            };
        }

        return value => {
            return this.defaultCellFormatter(value, column.style);
        };
    }

    setColorState(value, style) {
        if (!style.colorMode) {
            return;
        }

        if (value === null || value === void 0 || _.isArray(value)) {
            return;
        }

        const numericValue = Number(value);
        if (isNaN(numericValue)) {
            return;
        }

        this.colorState[style.colorMode] = this.getColorForValue(numericValue, style, undefined);
    }

    renderRowVariables(rowIndex) {
        const scopedVars = {};
        let cellVariable;
        const row = this.table.rows[rowIndex];
        for (let i = 0; i < row.length; i++) {
            cellVariable = `__cell_${i}`;
            scopedVars[cellVariable] = { value: row[i] };
        }
        return scopedVars;
    }

    formatColumnValue(colIndex, value) {
        return this.formatters[colIndex] ? this.formatters[colIndex](value) : value;
    }

    renderCellStyles(column, cellStyles, cellClasses, textStyles) {
        if (column.style) {
            //width
            if (column.style.colwidth) {
                cellStyles.width = column.style.colwidth;
            }

            //align
            if (column.style.align) {
                cellStyles['text-align'] = column.style.align;
            }

            //column color
            if (column.style.colbgColor && !this.colorState.row) {
                cellStyles['background-color'] = column.style.colbgColor;
            }

            //font color
            if (column.style.colFontColorSet) {
                textStyles.color = column.style.colFontColorSet;
                cellStyles.color = column.style.colFontColorSet;
            }

            //bold
            if (column.style.bold) {
                textStyles['font-weight'] = 'bold';
                cellStyles['font-weight'] = 'bold';
            }
        }

        //column Thresholds
        if (this.colorState.cell) {
            cellStyles['background-color'] = this.colorState.cell;
            cellClasses.push('table-panel-color-cell');
        } else if (this.colorState.value) {
            cellStyles.color = this.colorState.value;
            textStyles.color = this.colorState.value;
        }
    }

    renderCellValue(column, value) {
        //postfix
        if (column.style.colpostfix) {
            value = value + column.style.colpostfix;
        }

        if (this.colorState.status || this.colorState.value) {
            let title = this.getColorForTitle(value, column.style);
            if (title) {
                if (column.style.thresholdsHasValue) {
                    title = title + '(' + value + ')';
                }
                value = title;
            }
        }

        return value;
    }

    customDisplay(column, rowIndex) {
        let value = '--';
        column.rowContents.forEach((v, k) => {
            if (parseInt(v.rowNumber) - 1 === rowIndex) {
                if (v.rowType === 'text') {
                    if (v.rowContent) {
                        value = v.rowContent;
                    }
                } else if (v.rowType === 'status') {
                    if (v.rowStatus && v.rowStatus.operator && v.rowStatus.opValue) {
                        value = `<span class="statusLamp ${v.statusColor}" style="background-color:${v.statusColor
                            }"></span>`;
                        if (v.rowStatus.showCondition) {
                            value += `<span class="statusCondition">${v.rowStatus.operator}${v.rowStatus.opValue
                                }</span>`;
                        }
                    }
                }
            }
        });
        return value;
    }

    arrayBar(column, value) {
        if (!_.isArray(value)) {
            return '--';
        }

        const currentVal = parseInt(value[0]);
        let maxVal = parseInt(value[1]);
        const valueFormatter = kbn.valueFormats[column.unit || column.style.unit || 'none'];
        const currentText = valueFormatter(currentVal, column.style.decimals, null);
        const maxText = valueFormatter(maxVal, column.style.decimals, null);

        if (!column.style.bar) {
            return value;
        }

        const firstThreshold = parseInt(value[2]);
        const secondThreshold = parseInt(value[3]);
        const colors = column.style.arraycolors;

        const total = 100;
        let firstBar = 0;
        let secondBar = 0;
        let thirdBar = 0;

        let html = `<div class="barContainer">
      <span class="currentVal">${currentText}</span>
      <div class="progressBar"></div>
      <span class="maxVal">${maxText}</span>
  </div>`;

        if (_.isNaN(currentVal)) {
            return html;
        }

        if (_.isNaN(firstThreshold) && _.isNaN(secondThreshold)) {
            return html;
        }

        if (_.isNaN(maxVal)) {
            maxVal = currentVal;
        }

        if (_.isNaN(firstThreshold) || _.isNaN(secondThreshold)) {
            const threshold = firstThreshold || secondThreshold;
            if (currentVal >= threshold) {
                firstBar = threshold / maxVal * total;
                secondBar = (currentVal - threshold) / maxVal * total;
            } else {
                firstBar = currentVal / maxVal * total;
            }
        } else {
            if (currentVal >= firstThreshold) {
                firstBar = firstThreshold / maxVal * total;
                if (currentVal >= secondThreshold) {
                    secondBar = (secondThreshold - firstBar) / maxVal * total;
                    thirdBar = (currentVal - secondThreshold) / maxVal * total;
                } else {
                    secondBar = (currentVal - firstThreshold) / maxVal * total;
                    //thirdBar = 0;
                }
            } else {
                firstBar = currentVal / maxVal * total;
                secondBar = 0;
                thirdBar = 0;
            }
        }

        html = `<div class="barContainer">
    <span class="currentVal">${currentText}</span>
    <div class="progressBar">
      <span class="firstBar" style="width:${firstBar}%;background-color:${colors[0]
            }"></span>
      <span class="secondBar" style="width:${secondBar}%;left:${firstBar}%;background-color:${colors[1]
            }"></span>
      <span class="thirdBar" style="width:${thirdBar}%;left:${firstBar +
            secondBar}%;background-color:${colors[2]}"></span>
    </div>
    <span class="maxVal">${maxText}</span>
  </div>`;

        return html;
    }

    linkOrUrl(
        column,
        value,
        rowIndex,
        cellClasses,
        indexRowStyles,
        textStyles,
        columnHtml
    ) {
        if (column.style && column.style.type === 'string' && column.style.url) {
            if (column.style.icon) {
                if (column.style.icontype) {
                    value = `<a href="${value}" title="${value}" target="${column.style.hrefTarget || '_blank'}" class="extra-icon-${column.style.icontype}" style="width:calc( ${this.panel.tableFontVal} + 0.2vw );height:calc( ${this.panel.tableFontVal} + 0.2vw );"></a>`
                } else {
                    value = `<a href="${value}" title="${value}" target="${column.style.hrefTarget || '_blank'}">
            <i class="fa fa-file-text" aria-hidden="true"></i>
          </a>`;
                }
            } else {
                value = `<a href="${value}" target="${column.style.hrefTarget || '_blank'}">${value}</a>`;
            }
        }

        if (column.style && column.style.link) {
            // Render cell as link
            const scopedVars = this.renderRowVariables(rowIndex);
            scopedVars['__cell'] = { value: value };

            const cellLink = this.templateSrv.replace(
                column.style.linkUrl,
                scopedVars,
                encodeURIComponent
            );

            if (!column.style.linkTooltip) {
                column.style.linkTooltip = '';
            }

            const cellLinkTooltip = this.templateSrv.replace(
                column.style.linkTooltip,
                scopedVars
            );
            const cellTarget = column.style.linkTargetBlank ? '_blank' : '';

            if (column.style && !column.style.bar) {
                cellClasses.push('table-panel-cell-link');
            }

            const textStyle = `style="color:${textStyles.color}";font-weight:${textStyles['font-weight']
                };`;

            columnHtml += `
        <a href="${cellLink}" target="${cellTarget}" onclick="srpUrlClickEvent(this)"
        data-link-tooltip data-original-title="${cellLinkTooltip}" 
        data-placement="right"${textStyle}>${value}</a>`;
        } else {
            //row value and title
            if (column && column.thresholdColor && column.thresholdTitle) {
                if (column.rowColorMode === 'status' || column.rowColorMode === 'value') {
                    if (column.thresholdsHasValue) {
                        value = column.thresholdTitle + '(' + value + ')';
                    } else {
                        value = column.thresholdTitle;
                    }
                }
            }

            if (indexRowStyles.rowLink) {
                const scopedVars = this.renderRowVariables(rowIndex);
                scopedVars['__cell'] = { value: value };

                const rowLink = this.templateSrv.replace(
                    indexRowStyles.rowLink,
                    scopedVars,
                    encodeURIComponent
                );
                const cellTarget = indexRowStyles.rowTarget ? '_blank' : '';

                let cellLink = true;
                if (column.style && column.style.bar) {
                    cellLink = false;
                }

                if (cellLink) {
                    cellClasses.push('table-panel-cell-link');
                }

                const textStyle = ` style="color:${textStyles.color}";font-weight:${textStyles['font-weight']
                    };`;

                columnHtml += `<a href="${rowLink}" target="${cellTarget}" onclick="srpUrlClickEvent(this)"
        data-link-tooltip  data-placement="right" ${textStyle}>${value}</a>`;
            } else {
                columnHtml += value;
            }
        }

        return columnHtml;
    }

    renderCell(columnIndex, rowIndex, value, indexRowStyles, addWidthHack = false) {
        let defaultValue = value;
        value = this.formatColumnValue(columnIndex, value);

        const column = this.table.columns[columnIndex];
        if (column.text == 'commenter' || column.text == 'operator') {
            if (column.style && column.style.type == 'hidden') {
                value = undefined;
            } else {
                value = value ? decodeURIComponent(value).split('@')[0] : '';
            }
        }
        let cellStyle = '';
        const cellClasses = [];
        let cellClass = '';
        const textStyles = {
            color: '',
            'font-size': 'normal',
        };
        const cellStyles = {
            width: 'unset',
            'text-align': 'unset',
            'background-color': 'unset',
            color: 'unset',
            'font-weight': 'normal',
        };

        //column styles
        if (column && column.style) {
            this.renderCellStyles(column, cellStyles, cellClasses, textStyles);
            value = this.renderCellValue(column, value);
        }

        //row Thresholds
        if (column && column.rowColorMode && column.thresholdColor) {
            if (column.rowColorMode === 'cell') {
                cellStyles['background-color'] = column.thresholdColor;
            } else if (column.rowColorMode === 'value') {
                cellStyles.color = column.thresholdColor;
                textStyles.color = column.thresholdColor;
            }
        }
        //row colorMode===row  th的backcolor should unset
        if (
            indexRowStyles &&
            indexRowStyles.thresholdConfig &&
            indexRowStyles.thresholdConfig.colorMode === 'row'
        ) {
            cellStyles['background-color'] = 'unset';
        }
        if (column.text == 'level') {
            let lv = this.dataRaw.levelInfo.find(x => {
                return x.level == value;
            });
            if (lv) {
                cellStyles.color = lv.color;
                textStyles.color = `title='${lv.desc}'`
            }
        }
        for (const key in cellStyles) {
            if (cellStyles.hasOwnProperty(key)) {
                const val = cellStyles[key];
                cellStyle += `${key}:${val};`;
            }
        }

        cellStyle = ' style="' + cellStyle + '"';

        // because of the fixed table headers css only solution
        // there is an issue if header cell is wider the cell
        // this hack adds header content to cell (not visible)
        let columnHtml = '';
        if (addWidthHack) {
            columnHtml =
                '<div class="table-panel-width-hack">' +
                this.table.columns[columnIndex].title +
                '</div>';
        }

        if (column.addStatusLampCol) {
            value = `<div class="statusLamp ${column.color}" style="background-color:${column.color
                }"></div>`;
        }

        if (column.type === 'custom') {
            value = this.customDisplay(column, rowIndex);
        }

        if (column.style && column.style.type === 'array') {
            value = this.arrayBar(column, value);
        } else if (column.style && column.style.type === 'button') {//hao.ning add button 
            value = this.createButton(column, value, this.table.rows[rowIndex]);
        } else if (column.style && column.style.type === 'operation' && column.style.operNum != undefined) {//hao.ning add icon 
            let data = [];
            this.table.columns.forEach((element, i) => {
                data.push(`data-${element.text}='${this.table.rows[rowIndex][i]}'`);
            });
            value = this.createOperation(column, cellStyle, data.join(' '));
        } else if (column.style && column.style.type === 'number' && column.style.colorMode === 'status') {
            value = this.createBorderButton(column, defaultValue, value, this.table.rows[rowIndex]);
        }

        if (value === undefined) {
            cellStyle = ' style="display:none;"';
            column.hidden = true;
        } else {
            column.hidden = false;
        }

        if (column.hidden === true) {
            return '';
        }

        if (column.style && column.style.preserveFormat) {
            cellClasses.push('table-panel-cell-pre');
        }

        columnHtml = this.linkOrUrl(
            column,
            value,
            rowIndex,
            cellClasses,
            indexRowStyles,
            textStyles,
            columnHtml
        );

        if (column.filterable) {
            cellClasses.push('table-panel-cell-filterable');
            columnHtml += `
        <a class="table-panel-filter-link" data-link-tooltip data-original-title="Filter out value" data-placement="bottom"
           data-row="${rowIndex}" data-column="${columnIndex}" data-operator="!=">
          <i class="fa fa-search-minus"></i>
        </a>
        <a class="table-panel-filter-link" data-link-tooltip data-original-title="Filter for value" data-placement="bottom"
           data-row="${rowIndex}" data-column="${columnIndex}" data-operator="=">
          <i class="fa fa-search-plus"></i>
        </a>`;
        }

        //rows Thresholds status
        if (column && column.rowColorMode === 'status' && column.thresholdColor) {
            cellClasses.push('table-panel-cell-status');
            columnHtml = `<button class="datatable" style="background-color:
      ${column.thresholdColor};font-size:${this.panel.tableFontVal};
      font-weight:${textStyles['font-weight']}">${columnHtml}</button>`;
        } else {
            //cloumn Thresholds status
            //     if (this.colorState.status) {
            //         cellClasses.push('table-panel-cell-status');
            //         columnHtml = `<button class="datatable" style="background-color:
            // ${this.colorState.status};font-size:${this.panel.tableFontVal};
            // font-weight:${textStyles['font-weight']}">${columnHtml}</button>`;
            //     }
        }

        if (column && column.rowColorMode && column.thresholdColor) {
            column.rowColorMode = null;
            column.thresholdColor = null;
        }

        if (cellClasses.length) {
            cellClass = ' class="' + cellClasses.join(' ') + '"';
        }

        if (this.colorState.cell) {
            this.colorState.cell = null;
        } else if (this.colorState.value) {
            this.colorState.value = null;
        } else if (this.colorState.status) {
            this.colorState.status = null;
        }

        columnHtml =
            '<td' + cellClass + cellStyle + textStyles.color + '>' + columnHtml + '</td>';

        return columnHtml;
    }

    getColor(condition, relationVal) {
        let color = 'green';
        if (condition.type === 'number') {
            const valueFormatter = kbn.valueFormats[condition.unit || 'none'];
            relationVal = parseFloat(valueFormatter(relationVal, condition.decimals, null));
            let val = parseFloat(condition.varValue);
            if (condition.condition === '>') {
                if (relationVal > val) {
                    color = 'red';
                }
            } else if (condition.condition === '>=') {
                if (relationVal >= val) {
                    color = 'red';
                }
            } else if (condition.condition === '<') {
                if (relationVal < val) {
                    color = 'red';
                }
            } else if (condition.condition === '<=') {
                if (relationVal <= val) {
                    color = 'red';
                }
            } else if (condition.condition === '!=') {
                if (val !== relationVal) {
                    color = 'red';
                }
            } else if (condition.condition === '=') {
                if (val === relationVal) {
                    color = 'red';
                }
            }
        } else if (condition.type === 'string') {
            const rVal = relationVal.toString();
            if (condition.condition === 'has') {
                if (rVal.indexOf(condition.varValue) !== -1) {
                    color = 'red';
                }
            } else if (condition.condition === 'not has') {
                if (rVal.indexOf(condition.varValue) === -1) {
                    color = 'red';
                }
            } else if (condition.condition === 'equals' || condition.condition === 'selected') {
                if (rVal === condition.varValue) {
                    color = 'red';
                }
            }
        }
        return color;
    }

    getStatusLampColor(statusLamCol, relationVals) {
        const conditions = statusLamCol.conditions;
        const colors = [];

        for (let i = 0; i < conditions.length; i++) {
            const condition = conditions[i];
            const columns = this.table.columns;

            for (let c = 0; c < columns.length; c++) {
                let col = columns[c];
                if (condition.selected === col.title) {
                    const color = this.getColor(condition, relationVals[c]);
                    colors.push(color);
                }
            }
        }

        let color = 'green';

        if (colors.length > 0) {
            if (statusLamCol.relation === '&') {
                if (_.indexOf(colors, 'green') === -1) {
                    color = 'red';
                }
            } else {
                if (_.indexOf(colors, 'red') !== -1) {
                    color = 'red';
                }
            }
        }
        statusLamCol.color = color;
    }

    getRowStyles(index, rowStyles) {
        let indexRowStyles = {
            rowBGColor: null,
            rowLink: null,
            rowTarget: null,
            colNum: null,
            thresholdConfig: null,
        };
        for (let i = 0; i < rowStyles.length; i++) {
            if (parseInt(rowStyles[i].rowNum) - 1 === index) {
                indexRowStyles.rowBGColor = rowStyles[i].rowBGColor;
                indexRowStyles.rowLink = rowStyles[i].rowhtml;
                indexRowStyles.rowTarget = rowStyles[i].rowopenNewTab;
                indexRowStyles.thresholdConfig = rowStyles[i].thresholdConfig;
                indexRowStyles.colNum = rowStyles[i].colNum;
            }
        }
        return indexRowStyles;
    }

    renderRowStyle(rowStylesColor, statusRow, bgColor, rowStyleThresholdRowColor) {
        if (!this.panel.stripedRowsEnabled) {
            bgColor = this.lightTheme ? '#fbfbfb' : '#323233';
        }

        let rowStyle = '';
        if (bgColor) {
            rowStyle = ' style="background-color:' + bgColor + '"';
        }
        if (statusRow) {
            rowStyle = ' style="background-color:' + this.colorState.row + '"';
        }

        if (rowStylesColor) {
            rowStyle = ' style="background-color:' + rowStylesColor + '"';
        }

        if (rowStyleThresholdRowColor) {
            rowStyle = ' style="background-color:' + rowStyleThresholdRowColor + '"';
        }

        return rowStyle;
    }

    getRowsStyleThresholds(row, column, indexRowStyles, y) {
        if (indexRowStyles.thresholdConfig) {
            const thresholdColor = this.getColorForValue(row, indexRowStyles.thresholdConfig, y);
            column.rowColorMode = indexRowStyles.thresholdConfig.colorMode;
            column.thresholdColor = thresholdColor;

            if (column.rowColorMode === 'status' || column.rowColorMode === 'value') {
                if (indexRowStyles.thresholdConfig.thresholdsDisplay) {
                    column.thresholdTitle = this.getColorForTitle(
                        row,
                        indexRowStyles.thresholdConfig,
                        y
                    );
                    column.thresholdsHasValue = indexRowStyles.thresholdConfig.thresholdsHasValue;
                }
            }
        }
    }

    rowContentStatus(value, rowContent, compareDecimals, compareUnit) {
        if (_.isNumber(value)) {
            const valueFormatter = kbn.valueFormats[compareUnit || 'none'];
            value = parseFloat(valueFormatter(value, compareDecimals, null));
        }
        const status = rowContent.rowStatus;
        let text = status.opValue;
        rowContent.statusColor = 'green';
        if (status.opType === 'number') {
            text = parseFloat(text);
            if (status.operator === '>') {
                if (value > text) {
                    rowContent.statusColor = 'red';
                }
            } else if (status.operator === '>=') {
                if (value >= text) {
                    rowContent.statusColor = 'red';
                }
            } else if (status.operator === '<=') {
                if (value <= text) {
                    rowContent.statusColor = 'red';
                }
            } else if (status.operator === '<') {
                if (value < text) {
                    rowContent.statusColor = 'red';
                }
            } else if (status.operator === '=') {
                if (value === text) {
                    rowContent.statusColor = 'red';
                }
            } else if (status.operator === '!=') {
                if (value !== text) {
                    rowContent.statusColor = 'red';
                }
            }
        } else if (status.opType === 'string') {
            const val = value.toString();
            if (status.operator === 'has') {
                if (val.indexOf(text) !== -1) {
                    rowContent.statusColor = 'red';
                }
            } else if (status.operator === 'not has') {
                if (val.indexOf(text) === -1) {
                    rowContent.statusColor = 'red';
                }
            } else if (status.operator === 'equals' || status.operator === 'selected') {
                if (val === text) {
                    rowContent.statusColor = 'red';
                }
            }
        }
    }

    render(page) {
        let pageSize = this.panel.pageSize || 10;

        if (this.panel.scroll) {
            pageSize = this.table.rows.length;
        }

        const pageCount = Math.ceil(this.table.rows.length / pageSize);

        if (page >= pageCount) {
            page = 0;
        }

        const startPos = page * pageSize;
        const endPos = Math.min(startPos + pageSize, this.table.rows.length);
        let html = '';

        const rowStyles = _.uniqBy(this.panel.rowStyles, 'rowNum');

        for (let y = startPos; y < endPos; y++) {
            const row = this.table.rows[y];
            let cellHtml = '';
            let rowStyle = '';
            let rowClasses = [];
            let rowClass = '';
            const indexRowStyles = this.getRowStyles(y, rowStyles);

            //hao.ning add checkbox at 2019.12.04
            if (this.panel.checkboxEnable) {
                var r = this.table.rows[y];
                //如果status为22，为Open的需要Ack,且level设置ack为true
                let stat = this.table.columns.findIndex(x => { return x.text == 'almstat' });
                if (stat != -1) {
                    stat = row[stat];
                }
                var lv = this.table.columns.findIndex(x => { return x.text == 'level' });
                if (lv != -1) {
                    lv = this.dataRaw.levelInfo.find(x => { return x.level == r[lv] }) || {};
                    lv = lv.requires && lv.requires[0];
                }
                let disabled = stat == 5 && lv == 1 ? '' : 'disabled';
                var id = this.table.columns.findIndex(x => { return x.text == 'almid' });
                if (id != -1) {
                    id = row[id]
                } else {
                    id = page + ':' + y;
                }
                cellHtml += `<td style="width:1%"><input style="display:none" type="checkbox"" ${disabled} id="checkbox-item-${id}" data-id="${id}"/><label for="checkbox-item-${id}"></label></td>`;
            }

            if (this.panel.rowNumbersEnabled) {
                cellHtml += `<td style="width:1%">${y + 1}</td>`;
            }

            for (let i = 0; i < this.table.columns.length; i++) {
                const column = this.table.columns[i];

                if (column.addStatusLampCol) {
                    this.getStatusLampColor(column, row);
                }

                if (indexRowStyles.colNum) {
                    if (parseInt(indexRowStyles.colNum) - 1 === i) {
                        this.getRowsStyleThresholds(row[i], column, indexRowStyles, y);
                    }
                }

                if (column.rowContents && column.rowContents.length > 0) {
                    for (let s = 0; s < column.rowContents.length; s++) {
                        const rowContent = column.rowContents[s];
                        if (rowContent.rowType === 'status' && rowContent.rowStatus) {
                            const conpareIndex = rowContent.rowStatus.columnNo - 1;
                            let compareDecimals = null;
                            let compareUnit = null;
                            const styleLength = this.panel.styles.length;
                            if (conpareIndex >= 0) {
                                if (conpareIndex > styleLength - 1) {
                                    if (this.panel.styles[styleLength - 1].pattern === '/.*/') {
                                        compareDecimals = this.panel.styles[styleLength - 1].decimals;
                                        compareUnit = this.panel.styles[styleLength - 1].unit;
                                    }
                                } else {
                                    compareDecimals = this.panel.styles[conpareIndex].decimals;
                                    compareUnit = this.panel.styles[conpareIndex].unit;
                                }
                            }
                            this.rowContentStatus(
                                row[conpareIndex],
                                rowContent,
                                compareDecimals,
                                compareUnit
                            );
                        }
                    }
                }

                cellHtml += this.renderCell(i, y, row[i], indexRowStyles, y === startPos);
            }

            let rowStyleThresholdRowColor = null;
            if (
                indexRowStyles.thresholdConfig &&
                indexRowStyles.thresholdConfig.colorMode === 'row'
            ) {
                if (indexRowStyles.colNum) {
                    const num = parseInt(indexRowStyles.colNum) - 1;
                    rowStyleThresholdRowColor = this.getColorForValue(
                        row[num],
                        indexRowStyles.thresholdConfig,
                        y
                    );
                }
            }
            //row background-color
            var r = this.table.rows[y];
            var lvIndex = this.table.columns.findIndex(e => { return e.text == 'level' });
            let level = lvIndex != -1 ? this.dataRaw.levelInfo.find(x => { return x.level == r[lvIndex] }) : null;
            var statIndex = this.table.columns.findIndex(e => { return e.text == 'almstat' });
            let almstat = statIndex != -1 ? r[statIndex] : 0;
            if ((y + 1) % 2 === 0) {
                rowStyle = this.renderRowStyle(
                    indexRowStyles.rowBGColor,
                    this.colorState.row,
                    this.panel.evenRowBGColorSet,
                    rowStyleThresholdRowColor
                );
                if (level && level.requires[1] && almstat == 5 && this.panel.alarmBlinking) rowClasses.push('row-animate0');//添加行闪烁 --hao.ning
            } else {
                rowStyle = this.renderRowStyle(
                    indexRowStyles.rowBGColor,
                    this.colorState.row,
                    this.panel.oddRowBGColorSet,
                    rowStyleThresholdRowColor
                );
                if (level && level.requires[1] && almstat == 5 && this.panel.alarmBlinking) rowClasses.push('row-animate1');//添加行闪烁 --hao.ning
            }
            //change row background-color with category -- hao.ning
            var cateIndex = this.table.columns.findIndex(e => { return e.text == 'category' });
            let categoryColor = '';
            if (cateIndex != -1) {
                let cate = this.dataRaw.categoryInfo.find(e => {
                    return e.desc == r[cateIndex];
                });
                categoryColor = cate != undefined ? cate.color : '';
            }
            if (categoryColor && this.panel.targets[0].dataType == 'realtime' && this.panel.alarmBgCategoryColor) rowStyle = ` style="background-color:${categoryColor}" data-bgcolor="${categoryColor}"`;

            if (this.colorState.row || indexRowStyles.rowBGColor) {
                rowClasses.push('table-panel-color-row');
            }

            if (rowClasses.length) {
                rowClass = ' class="' + rowClasses.join(' ') + '"';
            }

            if (this.colorState.row) {
                this.colorState.row = null;
            }

            html += '<tr ' + rowClass + rowStyle + '>' + cellHtml + '</tr>';
        }

        return html;
    }

    render_values() {
        const rows = [];

        for (let y = 0; y < this.table.rows.length; y++) {
            const row = this.table.rows[y];
            const newRow = [];
            for (let i = 0; i < this.table.columns.length; i++) {
                newRow.push(this.formatColumnValue(i, row[i]));
            }
            rows.push(newRow);
        }
        return {
            columns: this.table.columns,
            rows: rows,
        };
    }
    //create button in table cell -- hao.ning 
    createButton(column, value, row) {
        if (!column.style) {
            return value;
        }
        let thresholds = column.style.thresholds;
        let thresholdsDisplay = column.style.thresholdsDisplay;
        let colors = column.style.colors;
        let fontColor = '';
        let colorMode = column.style.colorMode;

        if (colorMode != 'status' || _.isEmpty(thresholds)) {
            return value;
        }
        // thresholds.sort();
        let index = thresholds.findIndex(x => {
            return ('' + value).length && value == x;
        });
        if (index == -1) index = thresholds.length;
        (value === '' || value === undefined || value === null) && (value = '-');
        let text = this.panel.statusNumList.find(x => { return x.value == value });
        fontColor = text && text.fontColor || '#fff';
        text = text && text.text[this.panel.langType] || '';

        let almid = this.table.columns.findIndex(x => { return x.text == 'almid' });
        if (almid != -1) {
            almid = row[almid];
        }
        let lv = this.table.columns.findIndex(x => { return x.text == 'level' });
        if (lv != -1) {
            lv = this.dataRaw.levelInfo.find(x => { return x.level == row[lv] });
            lv = lv && lv.requires ? lv.requires[0] : 0;
        }
        let disabled = value == 5 && lv == 1 ? '' : 'disabled';
        value = `<button class="datatable table-cell-button" style="font-size:${this.panel.tableFontVal};background-color:${colors[index] || 'transparent'};width:100%;font-weight:${column.style.bold ? 700 : 400};font-family:${this.panel.fontFamily};color:${fontColor};" data-almid="${almid}"
     data-almstat="${value}" data-ack="${lv}" ${disabled}>
            ${text}
            </button>`
        return value;
    }

    // create border status button in table cell -- hao.ning at 2021/12/17
    createBorderButton(column, defaultValue, value, row) {
        if (!column.style) {
            return value;
        }
        let thresholds = column.style.thresholds;
        let thresholdsDisplay = column.style.thresholdsDisplay;
        let colors = column.style.colors;
        let fontColor = '';
        let colorMode = column.style.colorMode;

        if (colorMode != 'status' || _.isEmpty(thresholds)) {
            return value;
        }
        // thresholds.sort();
        let index = thresholds.findIndex(x => {
            return defaultValue <= x;
        });
        if (index == -1) index = thresholds.length - 1;

        fontColor = colors[index] || colors[colors.length - 1];
        let almid = this.table.columns.findIndex(x => { return x.text == 'almid' });
        if (almid != -1) {
            almid = row[almid];
        }
        value = `<div ${column.style.asButton ? 'class="number-button"' : ''} style="padding:0px;border-radius:0px;border:2px solid ${fontColor};font-size:${this.panel.tableFontVal};background-color:rgba(0,0,0,0.9);font-weight:${column.style.bold ? 700 : 400};font-family:${this.panel.fontFamily.replace(/"/g, "'")};cursor:${column.style.asButton ? 'pointer' : 'default'};color:${fontColor};"
     data-${column.text}="${defaultValue}" data-almid="${almid}" data-handler="${column.style.handler}">
        <div style="background-color:${this.colorToRGBA(fontColor, 0.2)};">
            <div class="datatable" style="">${value}</div></div>
            </div>`;
        return value;
    }

    //create extra icon in table cell -- hao.ning
    createExtraIcon(column, value) {
        if (!column.style || !column.style.addUrlContent) {
            return value;
        }
        value = `${value}<a title='${column.style.addUrlContent}' href='${column.style.addUrlContent}' target='_blank' class='extra-icon-a'
          ></a>`;
        return value;
    }

    //create operation icon in table cell -- hao.ning
    createOperation(column, cellStyle, data) {
        let value = '';
        let list = column.style.operationList;
        let head = `<td ${cellStyle}>`;
        let fail = '</td>';
        let almid = data.match(/-almid=['"]?([^'"]+)/);
        let level = data.match(/-level=['"]?([^'"]+)/);
        let status = data.match(/-almstat=['"]?([^'"]+)/);
        let action = data.match(/-action=['"]?([^'"]+)/);
        let soe = data.match(/-soe=['"]?([^'"]+)/);
        let display = '';
        if (level && status) {
            almid = almid[1];
            level = level[1];
            status = status[1];
            action = action[1];
            let lv = this.dataRaw.levelInfo.find(x => { return x.level == level });
            if (status >= 5 && lv && !lv.requires[2] && !lv.requires[0]) { // [Ack'ed, Blinking, Proccess, LogOnly]
                display = 'display:none;'
            }
        }
        soe = soe && soe.length >= 2 && parseInt(soe[1]) || 0;

        // if(action){
        //   action = action[1];
        //   if(column.style.operNum > action){
        //     column.style.operNum = action;
        //     column.style.operationList.splice(0,column.style.operNum - action);
        //   }
        // }
        for (let i = 0; i < column.style.operNum; i++) {
            let disabled = list[i].handler == 'SOE' && !soe ? 'disabled' : '';
            value +=
                `${i == 0 ? '' : head}<a title="${list[i].handler}" ${disabled} id="operation-${list[i].handler}-${almid}" target="_blank" class="extra-icon-${list[i].type}${disabled ? '-' + disabled : ''}"
                ${data} style="width:calc( ${this.panel.tableFontVal} + 0.2vw );height:calc( ${this.panel.tableFontVal} + 0.2vw );${list[i].handler == 'Ack' ? display : ''}">
                </a>${i == column.style.operNum - 1 ? '' : fail}`;
        }
        return value;
    }

    appendDialog(data, record = [], ctrl, body) {
        if (body.find('.data-table-panel-dialog').length) {
            body.find('.data-table-panel-dialog').empty().remove();
        }
        let dialog = '';
        let title = data.type == 'Ack' ? getMultiLang('update_report', this.panel.langType) : getMultiLang('alarm_progress', this.panel.langType);
        let btnTxt = data.type == 'Ack' ? 'save' : 'close';
        let filler = ctrl.filler;
        let operator = ctrl.operator.split(/@/)[0];
        let level = this.dataRaw.levelInfo.find(x => { return x.level == data.data.level });
        let lv = level;
        level = level ? ':' + level.desc : '';

        let time = '00:00:00';
        if (record.length) {
            record.sort(function (a, b) {
                return new Date(b.Time).getTime() - new Date(a.Time).getTime();
            });
            if (ctrl.panel.targets.length && ctrl.panel.targets[0].datatType == 'realtime') { // 实时报警删除closed的记录
                let closeIndex = record.findIndex(x => { return x.Status == 1 });
                if (closeIndex != -1) {
                    record.splice(closeIndex, 1);
                }
            }
            let timestamp = Math.abs(new Date(record[0].Time).getTime() - new Date(record[record.length - 1].Time).getTime());
            let hour = Math.floor(timestamp / 1000 / 60 / 60 % 24);
            let min = Math.floor(timestamp / 1000 / 60 % 60);
            let sec = Math.floor(timestamp / 1000 % 60);
            time = (hour < 10 ? '0' + hour : hour) + ':' + (min < 10 ? '0' + min : min) + ':' + (sec < 10 ? '0' + sec : sec);
        }

        let header = '';
        let almstat = data.data.almstat = record[0].Status;
        let style = ctrl.panel.statusNumList.find(x => { return almstat == x.value }) || {};
        if (data.type == 'Ack') {
            let statCon = '';
            if (!style.nextProccess.length) {
                statCon = `<span style='text-indent:7px;display:inline-block' id="dialog-status" data-value="${style.value || ''}">${style.text || ''}</span>`;
            } else {
                let temp = style.nextProccess.map(x => {
                    if (lv) {
                        if (lv.requires[0] && lv.requires[2]) {
                            let index = ctrl.panel.statusNumList.findIndex(y => { return y.value == x });
                            return index != -1 ? `<option value="${x}">${ctrl.panel.statusNumList[index].text[ctrl.panel.langType]}</option>` : '';
                        } else if (lv.requires[0]) {
                            if (x == 10) {
                                let index = ctrl.panel.statusNumList.findIndex(y => { return y.value == x });
                                return index != -1 ? `<option value="${x}">${ctrl.panel.statusNumList[index].text[ctrl.panel.langType]}</option>` : '';
                            } else {
                                return '';
                            }
                        } else if (lv.requires[2]) {
                            if ([15, 20, 25].indexOf(x) != -1) {
                                let index = ctrl.panel.statusNumList.findIndex(y => { return y.value == x });
                                return index != -1 ? `<option value="${x}">${ctrl.panel.statusNumList[index].text[ctrl.panel.langType]}</option>` : '';
                            } else {
                                return '';
                            }
                        } else {
                            return '';
                        }
                    }
                }).join(' ');
                statCon = `<select class="dialog-input" id="dialog-status" style="width:auto;height:auto;color:#5ac8fa;">${temp}</select>`
            }
            header = `
                <div class="margin-bottom dialog-acknowledgement" style="background-color:#323233;padding:12px;">
                <h3 style="font-size:1rem;font-weight:bold;line-height:1.2;text-align:center;color:#fff">${getMultiLang('acknowledgement', ctrl.panel.langType)}</h3>
                <div class="margin-bottom">
                    <span class="dialog-label">${getMultiLang('alarm_state', ctrl.panel.langType)}</span>
                    <span class="dialog-value">${statCon}</span>
                </div>
                <div class="margin-bottom">
                    <span class="dialog-label">${getMultiLang('commenter', ctrl.panel.langType)}</span>
                    <span class="dialog-value"><span style='text-indent:7px;display:inline-block'>${filler}</span></span>
                </div>
                <div class="margin-bottom">
                    <span class="dialog-label">${getMultiLang('operator', ctrl.panel.langType)}</span>
                    <span class="dialog-value"><input type='text' id='dialog-user' style='width:50%' class='dialog-input' placeholder='Enter username' value="${operator || filler}"></span>
                </div>
                <div>
                    <span class="dialog-label">${getMultiLang('comment', ctrl.panel.langType)}</span>
                    <span class="dialog-value"><textarea class='dialog-input' id='dialog-comment' placeholder='Enter your comments' style='resize:none;vertical-align:top;' rows='4' cols='20'></textarea></span>
                </div>
                </div>
            `;
        } else {
            header = `
                <div class="margin-bottom dialog-detail-container">
                <div class="dialog-detail">
                    <h3 style="font-size:1rem;font-weight:bold;line-height:1.2;text-align:center;color:#fff">${getMultiLang('alarm_detail', ctrl.panel.langType)}</h3>
                    <div class="margin-bottom dialog-item">
                    <span class="dialog-label">${getMultiLang('level', ctrl.panel.langType)}</span>
                    <span class="dialog-value"><span class="dialog-value-item" >${data.data.level == 'null' ? '' : data.data.level + level}</span></span>
                    </div>
                    <div class="margin-bottom dialog-item">
                    <span class="dialog-label">${getMultiLang('category', ctrl.panel.langType)}</span>
                    <span class="dialog-value"><span class="dialog-value-item" title="${data.data.category == 'null' ? '' : data.data.category}">${data.data.category == 'null' ? '' : data.data.category}</span></span>
                    </div>
                    <div class="margin-bottom dialog-item">
                    <span class="dialog-label">${getMultiLang('source', ctrl.panel.langType)}</span>
                    <span class="dialog-value"><span class="dialog-value-item" title="${data.data.source == 'null' ? '' : data.data.source}">${data.data.source == 'null' ? '' : data.data.source}</span></span>
                    </div>
                    <div class="margin-bottom dialog-item">
                    <span class="dialog-label">${getMultiLang('param_name', ctrl.panel.langType)}</span>
                    <span class="dialog-value"><span class="dialog-value-item" title="${data.data.equipparam == 'null' ? '' : data.data.equipparam}">${data.data.equipparam == 'null' ? '' : data.data.equipparam}</span></span>
                    </div>
                    <div class="margin-bottom dialog-item">
                    <span class="dialog-label">${getMultiLang('message', ctrl.panel.langType)}</span>
                    <span class="dialog-value"><span class="dialog-value-item" title="${record.length ? record[0].Record : ''}">${record.length ? record[0].Record : ''}</span></span>
                    </div>
                    <div class=" dialog-item">
                    <span class="dialog-label">${getMultiLang('reason', ctrl.panel.langType)}</span>
                    <span class="dialog-value"><span class="dialog-value-item" title="${data.data.almdesc == 'null' ? '' : data.data.almdesc}">${data.data.almdesc == 'null' ? '' : data.data.almdesc}</span></span>
                    </div>
                </div>
                <div class="dialog-state margin-bottom" style="background-color:${style.color};">
                    <h3 style="font-size:1rem;font-weight:bold;line-height:1.2;text-align:center;color:${style.fontColor}">${getMultiLang('alarm_state', ctrl.panel.langType)}</h3>
                    <div style="color:${style.fontColor};white-space:nowrap;">${style.text[ctrl.panel.langType]}</div>
                </div>
                <div class="dialog-time">
                    <h3 style="font-size:1rem;font-weight:bold;line-height:1.2;text-align:center;color:#fff">${getMultiLang('spend_time', ctrl.panel.langType)}</h3>
                    <div style="color:#fff;white-space:nowrap;">${time}</div>
                </div>
                </div>
            `;
        }

        let tableContent = ``;

        for (let i = 0; i < record.length; i++) {
            var s = record[i].Status;
            let rc = ctrl.panel.statusNumList.find(x => { return x.value == s }) || {};

            tableContent += `
                <tr>
                <td style="width: 25%;" title="${this.formatDate(record[i].Time)}">${this.formatDate(record[i].Time)}</td>
                <td style="width: 15%;padding:.4em;"><div style="background-color:${rc.color};width:100%;text-align:center;font-weight:bold;color:${style.fontColor};height:2em;line-height:2em;">${rc.text[ctrl.panel.langType]}</div></td>
                <td style="width: 20%;" title="${record[i].Filler}">${record[i].Filler.split(/@/)[0]}</td>
                <td style="width: 20%;" title="${record[i].Handler}">${record[i].Handler.split(/@/)[0]}</td>
                <td style="width: 40%;" title="${record[i].Record}">${record[i].Record}</td>
                </tr>
            `
        }
        let disabled = 'disabled';
        if (almstat >= 5 && lv && lv.requires[2]) {
            disabled = '';
        }
        dialog = `
            <div class="data-table-panel-dialog">
                <div class="dialog-container">
                <div class="dialog-content">
                    <h3 class="margin-bottom dialog-title" style="height:2.75rem;font-size:1.5em;padding-left:12px;line-height:2.75rem;color:#fff;font-weight:bold;background-color:#323233;">${title}</h3>
                    ${header}
                    <div class="dialog-progress" style="background-color:#323233;padding:12px 0;">
                    <h3 class="dialog-progress-caption" style="font-size:1rem;font-weight:bold;line-height:1.2;text-align:center;color:#fff">${getMultiLang('progress_his', ctrl.panel.langType)}</h3>
                    <table style="width:100%;border-collapse:collapse;table-layout:fixed;">
                        <thead>
                        <tr>
                        <th style="width: 25%;">${getMultiLang('time', ctrl.panel.langType)}</th>
                        <th style="width: 15%;">${getMultiLang('state', ctrl.panel.langType)}</th>
                        <th style="width: 20%;">${getMultiLang('commenter', ctrl.panel.langType)}</th>
                        <th style="width: 20%;">${getMultiLang('operator', ctrl.panel.langType)}</th>
                        <th style="width: 40%;">${getMultiLang('comment', ctrl.panel.langType)}</th>
                        </tr>
                        </thead><tbody>
                        ${tableContent}</tbody>
                    </table>
                    </div>
                </div>
                <div class="dialog-confirm" style="display:none;">
                    <h3 class="margin-bottom" style="height:2.75rem;font-size:1.5em;padding-left:12px;line-height:2.75rem;color:#fff;font-weight:bold;">${getMultiLang('confirm_discard_change', ctrl.panel.langType)}</h3>
                    <p style="font-size:20px;line-height:1.2;color:#fff;padding-left:12px;">${getMultiLang('confirm_discard_change_msg', ctrl.panel.langType)}</p>
                </div>
                <div class="dialog-button margin-top">
                    <button id="dialog-save-btn" class="dialog-btn" ${data.data.almstat == 1 && btnTxt == 'save' ? 'disabled' : ''}>${getMultiLang(btnTxt, ctrl.panel.langType)}</button>
                    <div class="dialog-btn-list" style="display:none;">
                    <button id="dialog-updata-btn" ${disabled} class="dialog-btn">${getMultiLang('update', ctrl.panel.langType)}</button>
                    <button id="dialog-refresh-btn" class="dialog-btn">${getMultiLang('refresh', ctrl.panel.langType)}</button>
                    </div>
                    <button id="dialog-cancel-btn" class="dialog-btn">${getMultiLang('cancel', ctrl.panel.langType)}</button>
                </div>
                </div>  
            </div>
            `
        let $dialog = $(dialog);
        body.append($dialog);

        if (data.type != 'Ack') {
            $dialog.find('#dialog-cancel-btn').hide();
            $dialog.find('#dialog-save-btn').text(`${getMultiLang('close', ctrl.panel.langType)}`);
            if (ctrl.panel.targets[0].dataType == 'realtime') {
                $dialog.find('.dialog-btn-list').show();
            }
        }
        $dialog.on('click', '#dialog-save-btn', function () {
            if ($dialog.find('#dialog-save-btn').text() == getMultiLang('ok', ctrl.panel.langType) || $dialog.find('#dialog-save-btn').text() == getMultiLang('close', ctrl.panel.langType)) {
                $dialog.remove();
            } else {
                ctrl.operator = $dialog.find('#dialog-user').val().trim().split(/@/)[0];
                ctrl.datasource.metricUpdate_almrecord({
                    almid: data.data.almid * 1, //想要改變的alm id
                    status: $dialog.find('#dialog-status').is('select') ? $dialog.find('#dialog-status').val() * 1 : $dialog.find('#dialog-status').data('value') * 1,  //想改變的狀態
                    filler: filler, //填寫人
                    handler: $dialog.find('#dialog-user').val().trim() || filler, //處理人
                    record: $dialog.find('#dialog-comment').val().trim() // 處理內容
                }).then(result => {
                    $dialog.remove();
                    let msg = '';
                    if (result.data && !_.isArray(result.data) && result.data.statusCode != 200) {
                        msg = result.data.error.message;
                    }
                    if (!msg) {
                        ctrl.appEventHandle("alert-success", [getMultiLang('success', ctrl.panel.langType), getMultiLang('success_update', ctrl.panel.langType)]);
                        ctrl.refresh();
                    } else {
                        ctrl.appEventHandle("alert-warning", [getMultiLang('error', ctrl.panel.langType), msg]);
                    }
                }).catch(e => {
                    console.log(e.message);
                    ctrl.appEventHandle("alert-warning", [getMultiLang('error', ctrl.panel.langType), e.message]);
                });
            }
        });
        $dialog.on('click', '#dialog-cancel-btn', function () {
            if ($dialog.find('#dialog-save-btn').is(':disabled')) $dialog.find('#dialog-save-btn').removeAttr('disabled');
            if ($dialog.find('#dialog-save-btn').text() == getMultiLang('ok', ctrl.panel.langType)) {
                $dialog.find('.dialog-content').show();
                $dialog.find('.dialog-confirm').hide();
                $dialog.find('#dialog-save-btn').text(getMultiLang('save', ctrl.panel.langType));
            } else {
                $dialog.find('.dialog-content').hide();
                $dialog.find('.dialog-confirm').show();
                $dialog.find('#dialog-save-btn').text(getMultiLang('ok', ctrl.panel.langType));
            }
        });
        $dialog.on('click', '#dialog-refresh-btn', function () {
            ctrl.datasource.metricFindQuery_almrecord(data.data.almid || 0).then(result => {
                let record = result.data[0] || [];
                ctrl.appEventHandle("alert-success", [getMultiLang('success', ctrl.panel.langType), getMultiLang('success_refresh', ctrl.panel.langType)]);
                ctrl.renderer.appendDialog(data, record, ctrl, body);
            }).catch(e => {
                console.log(e);
                ctrl.appEventHandle("alert-warning", [getMultiLang('error', ctrl.panel.langType), e.message]);
            });
        });
        $dialog.on('click', '#dialog-updata-btn', function () {
            ctrl.datasource.metricFindQuery_almrecord(data.data.almid || 0).then(result => {
                let record = result.data[0] || [];
                data.type = 'Ack';
                ctrl.renderer.appendDialog(data, record, ctrl, body);
            }).catch(e => {
                console.log(e);
                ctrl.appEventHandle("alert-warning", [getMultiLang('error', ctrl.panel.langType), e.message]);
            });
        })
        $dialog.css({
            width: '100%',
            height: '100%',
            'font-family': ctrl.panel.fontFamily
        });
        $dialog.find('h3,button,input,select,textarea').css({
            'font-family': ctrl.panel.fontFamily
        });
        $dialog.find('.dialog-state,.dialog-time').css({
            height: ($dialog.find('.dialog-detail').height() + 8) / 2 + 'px'
        });

        let containerH = $dialog.find('.dialog-container').height() || 0;
        let titleH = $dialog.find('.dialog-title').outerHeight(true) || 0;
        let buttonH = $dialog.find('.dialog-button').outerHeight(true) || 0;
        let akwH = $dialog.find('.dialog-acknowledgement').outerHeight(true) || 0;
        let detailH = $dialog.find('.dialog-detail-container').outerHeight(true) || 0;
        let captionH = $dialog.find('.dialog-progress-caption').outerHeight(true) || 0;
        $dialog.find('.dialog-progress tbody').css({
            height: (containerH - titleH - buttonH - detailH - akwH - 24 - captionH - 41) + 'px'
        })
    }

    appendSOEDialog(data, ruleList = [], ctrl, body) {
        if (body.find('.data-table-panel-dialog').length) {
            body.find('.data-table-panel-dialog').empty().remove();
        }
        let dialog = '';
        let pageIndex = 0;
        let title = getMultiLang('SOERule', this.panel.langType);
        let cate = this.dataRaw.categoryInfo.find(e => {
            return data.category && e.desc == data.category;
        });
        let eventRowStyle = cate ? `style="background-color:${cate.color};"` : ''
        let ruleHtml = ``;
        for (let i = 0; i < ruleList.length; i++) {
            let data = [];
            let obj = ruleList[i];
            for (let item in obj) {
                data.push(`data-${item}='${obj[item]}'`);
            }
            ruleHtml += `
                <li class='dialog-soe-li' ${data.join(' ')}><span class="dialog-value-item" style="line-height:2.5;vertical-align:middle;">${ruleList[i]['ruleName']}</span></li>
            `;
        }

        dialog = `
            <div class="data-table-panel-dialog">
                <div class="dialog-container">
                <div class="dialog-content">
                    <h3 class="margin-bottom dialog-title dialog-soe-title" style="height:2.75rem;font-size:1.5em;padding:0 12px;line-height:2.75rem;color:#fff;font-weight:normal;background-color:#323233;">
                        <div style="width:30%;">${title}</div>
                        <div class="dialog-soe-title">
                            <i class="img-title-bar-div"></i>
                            <div class="dialog-soe-select-container dialog-soe-title">
                                <div class="dialog-soe-select-icon"></div>
                                <div class="dialog-soe-select-input"></div>
                                <div class="dialog-soe-select-btn"></div>
                                <div class="dialog-soe-rule-list">
                                    <ul class="dialog-soe-rule-ul" style="list-style: none;">
                                        ${ruleHtml}
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </h3>
                    <div class="margin-bottom dialog-detail-container dialog-soe-datalist" >
                        <h3 class="dialog-title" style="height:2.75rem;font-size:1.5em;margin:0;padding:0 12px;line-height:2.75rem;text-align:center;color:#fff;font-weight:normal;background-color:#323233;">${getMultiLang('ReferParamList', this.panel.langType)}</h3>
                        <div class="dialog-detail" style="overflow:hidden;overflow-x:auto;height:100%;width:100%;padding:0;">
                            <div class="dialog-soe-nodata">${getMultiLang('nodata', ctrl.panel.langType)}</div>
                            <table class="dialog-soe-datatable">
                            </table>
                        </div>
                    </div>
                    <div class="dialog-button margin-top">
                        <button id="dialog-cancel-soe-btn" class="dialog-btn">${getMultiLang('close', ctrl.panel.langType)}</button>
                        <div class="data-table-panel-footer" style="float:left;display:none"></div>
                    </div>
                </div>
            </div>
            `
        let $dialog = $(dialog);
        let loading = this.loadingDialog();
        let $loading = $(loading.html);
        body.append($dialog);
        body.append($loading);
        let render = this;
        $dialog.on('click', function (event) {
            if (!$(event.target).closest('.dialog-soe-select-container').length) {
                $dialog.find('.dialog-soe-rule-list').hide();
                $dialog.find('.dialog-soe-select-btn').removeClass('active');
            }
        });
        $dialog.on('click', '.dialog-soe-select-container', function () {
            $dialog.find('.dialog-soe-rule-list').toggle();
            $dialog.find('.dialog-soe-select-btn').toggleClass('active');
            let dataset = $dialog.find('.dialog-soe-select-input').data();
            let node = $dialog.find('.dialog-soe-li')
            for (let i = 0; i < node.length; i++) {
                if ($(node[i]).data('id') == dataset.id) {
                    $(node[i]).addClass('active')
                } else {
                    $(node[i]).removeClass('active')
                }
            }
        });
        $dialog.on('click', '.dialog-soe-li', function () {
            let dataset = $(this).data();
            $dialog.find('.dialog-soe-rule-list').hide();
            $dialog.find('.dialog-soe-select-btn').removeClass('active');
            $dialog.find('.dialog-soe-select-input').text(dataset.rulename).data(dataset);
            $loading.show();
            ctrl.datasource.metricFindQuery_soehisdata({
                soeid: dataset.id,
                lang: ctrl.panel.langType
            }).then(result => {
                $loading.hide();
                if (result.data && result.data.rows && result.data.rows.length) {
                    render.SOEHisData = result.data;
                    (result.data.columns || []).forEach((x, i) => {
                        if (/date|time/i.test(x.type)) {
                            let index = result.data.rows.findIndex(y => { return y[i] == result.data.eventTime });
                            pageIndex = Math.floor(index / (ctrl.panel.pageSOESize || 10));
                        }
                    });
                    render.showSOEPageing('.data-table-panel-footer', $dialog, result.data, pageIndex, ctrl.panel.pageSOESize || 10);
                    $dialog.find('.dialog-soe-nodata').hide();
                    render.showSOETable('.dialog-soe-datatable', $dialog, result.data, pageIndex, ctrl.panel.pageSOESize || 10, eventRowStyle);
                    $dialog.find('.dialog-soe-datalist').show();
                } else {
                    pageIndex = 0;
                    render.SOEHisData.columns = [];
                    render.SOEHisData.rows = [];
                    render.SOEHisData.eventTime = null;
                    $dialog.find('.dialog-soe-datatable').hide();
                    $dialog.find('.dialog-soe-nodata').show();
                }
            }).catch(e => {
                console.log(e.message);
                $loading.hide();
                pageIndex = 0;
                render.SOEHisData.columns = [];
                render.SOEHisData.rows = [];
                render.SOEHisData.eventTime = null;
                $dialog.find('.dialog-soe-datatable').hide();
                $dialog.find('.dialog-soe-nodata').show();
                ctrl.appEventHandle("alert-warning", [getMultiLang('error', ctrl.panel.langType), e.message]);
            });
            return false;
        });
        $dialog.on('click', '#dialog-cancel-soe-btn', function () {
            $dialog.remove();
        });
        $dialog.on('click', '.paginationList > li', function () {
            let index = $(this).data('index');
            let oldIndex = parseInt($(this).parent().find('li:has(a.active)').data('index') || 0);
            $(this).parent().find('li > a').removeClass('active');
            // let pageIndex = null;
            let total = render.SOEHisData && render.SOEHisData.rows && render.SOEHisData.rows.length || 0;
            switch (index) {
                case 's':
                    pageIndex = 0;
                    break;
                case 'e':
                    pageIndex = Math.ceil(total / ctrl.panel.pageSOESize) - 1;
                    break;
                case 'p':
                    pageIndex = oldIndex - 1 >= 0 ? oldIndex - 1 : 0;
                    break;
                case 'n':
                    pageIndex = oldIndex + 1 <= Math.ceil(total / ctrl.panel.pageSOESize) - 1 ? oldIndex + 1 : Math.ceil(total / ctrl.panel.pageSOESize) - 1;
                    break;
                default:
                    pageIndex = parseInt(index);
                    break;
            }
            // $(this).parent().find(`li[data-index='${pageIndex}'] a`).addClass('active');
            render.showSOEPageing('.data-table-panel-footer', $dialog, render.SOEHisData, pageIndex, ctrl.panel.pageSOESize || 10);
            render.showSOETable('.dialog-soe-datatable', $dialog, render.SOEHisData, pageIndex, ctrl.panel.pageSOESize || 10, eventRowStyle);
        });
        $dialog.on('click', '.dialog-soe-datatable-th', function () {
            let index = $(this).index();
            let sortFlag = parseInt($(this).data('sort') || '-1');
            $(this).data('sort', sortFlag * -1 + '');
            render.SOESortRule[index].sort = sortFlag * -1;
            render.SOEHisData.rows.sort((a, b) => {
                let c = a[index] == '-' ? -9999999999 : _.isArray(a[index]) ? a[index][0] : a[index];
                let d = b[index] == '-' ? -9999999999 : _.isArray(b[index]) ? b[index][0] : b[index];
                if (sortFlag == 1) {
                    return d > c ? 1 : d < c ? -1 : 0;
                } else {
                    return c > d ? 1 : c < d ? -1 : 0;
                }
            })
            render.showSOETable('.dialog-soe-datatable', $dialog, render.SOEHisData, pageIndex, ctrl.panel.pageSOESize || 10, eventRowStyle);
        });
        $dialog.css({
            width: '100%',
            height: '100%',
            'font-family': ctrl.panel.fontFamily
        });
        $dialog.find('h3,button,input,select,textarea').css({
            'font-family': ctrl.panel.fontFamily
        });
        $dialog.find('.dialog-state,.dialog-time').css({
            height: ($dialog.find('.dialog-detail').height() + 8) / 2 + 'px'
        });

        let containerH = $dialog.find('.dialog-container').height() || 0;
        let titleH = $dialog.find('.dialog-title').outerHeight(true) || 0;
        let buttonH = $dialog.find('.dialog-button').outerHeight(true) || 0;
        let akwH = $dialog.find('.dialog-acknowledgement').outerHeight(true) || 0;
        let detailH = $dialog.find('.dialog-detail-container').outerHeight(true) || 0;
        let captionH = $dialog.find('.dialog-progress-caption').outerHeight(true) || 0;
        $dialog.find('.dialog-progress tbody').css({
            height: (containerH - titleH - buttonH - detailH - akwH - 24 - captionH - 41) + 'px'
        });

        // trigger
        $dialog.find('.dialog-soe-li').eq(0).click();

    }
    showSOETable(node, dom, data, pageIndex, pageSize, rowStyle) {
        let tabelNode = dom.find(node);
        tabelNode.empty().hide();
        let headContent = ``;
        let bodyContent = ``;
        for (let i = 0; i < data.columns.length; i++) {
            let col = data.columns[i];
            let sortRule = this.SOESortRule[i] || (this.SOESortRule[i] = { idnex: i, sort: -1 }) && { idnex: i, sort: -1 };
            headContent += `<th data-sort='${sortRule.sort}' class='dialog-soe-datatable-th' title='${col.title || col.text}' style='width:${i == 0 ? '20%' : 'auto'};min-width:20%;'>${col.title || col.text}</th>`;

        }
        headContent = `<thead><tr>${headContent}</tr></thead>`;
        let startNum = (pageIndex >= 0 ? pageIndex : 0) * pageSize;
        let endNum = Math.min(pageSize + startNum, data.rows.length);
        for (let i = startNum; i < endNum; i++) {
            let isAlarm = false;
            let row = data.rows[i];
            let bodyTd = ``;
            for (let j = 0; j < row.length; j++) {
                let value = null;
                let quality = 0;
                switch (data.columns[j].type) {
                    case 'date':
                    case 'time':
                        if (data.eventTime && row[j] == data.eventTime) {
                            isAlarm = true;
                        }
                        value = this.formatDate(row[j]);
                        break;
                    default:
                        if (row[j] == '-') {
                            value = '-';
                        } else if (_.isArray(row[j])) {
                            value = row[j][0];
                            quality = row[j][1] || 0;
                        } else {
                            value = row[j];
                        }
                        break;
                }
                bodyTd += `<td style='width:${j == 0 ? '20%' : 'auto'};min-width:20%;background:${quality > 0 ? 'red' : 'transparent'};' title='${value}'>${value}</td>`;
            }
            bodyContent += `<tr ${isAlarm ? rowStyle : ''}>${bodyTd}</tr>`;
        }
        bodyContent = `<tbody style="height:auto;max-height:420px;">${bodyContent}</tbody>`;
        tabelNode.html(headContent + bodyContent).show();
        tabelNode.css({
            width: (data.columns.length > 5 ? 20 * data.columns.length : 100) + '%'
        });
        tabelNode.find('td:first-child').css({ width: 'auto' });
        tabelNode.find('th:first-child').css({ width: 'auto' });
    }
    showSOEPageing(node, dom, data, pageIndex, pageSize) {
        let pageContainer = dom.find(node);
        pageContainer.empty().hide();
        let pageCount = Math.ceil(data.rows.length / pageSize);
        let startPage = Math.max(pageIndex - 3, 0);
        let endPage = Math.min(pageCount, startPage + 9);
        let pageLiList = ``;
        for (let i = startPage; i < endPage; i++) {
            pageLiList += `<li data-index='${i}'><a class='table-panel-page-link pointer dialog-soe-page-link ${pageIndex == i ? 'active' : ''}'>${i + 1}</a></li>`
        }
        let pageHTML = `<ul class="paginationList" style="margin-top:0px">
            <li data-index='s'><a class='table-panel-page-link pointer dialog-soe-page-link'>|◀</a></li>
            <li data-index='p'><a class='table-panel-page-link pointer dialog-soe-page-link'>◀</a></li>
            ${pageLiList}
            <li data-index='n'><a class='table-panel-page-link pointer dialog-soe-page-link'>▶</a></li>
            <li data-index='e'><a class='table-panel-page-link pointer dialog-soe-page-link'>▶|</a></li>
            `;
        pageContainer.html(pageHTML).show();
    }
    loadingDialog() {
        return {
            html: `
                <div class="dialog-soe-loading">
                    <div class="dialog-soe-loading-spinner">
                        <i class="dialog-soe-loading-icon"></i>
                        <p>${getMultiLang('loading', this.panel.langType)}</p>
                    </div>
                </div>
            `,
            class: '.dialog-soe-loading',
            name: 'dialog-soe-loading'
        }
    }
    formatDate(time) {
        let date = new Date(time);
        let year = date.getFullYear();
        let month =
            (date.getMonth() + 1) < 10
                ? '0' + (date.getMonth() + 1)
                : date.getMonth() + 1
        let day = date.getDate() < 10 ? '0' + date.getDate() : date.getDate()
        let hour = date.getHours() < 10 ? '0' + date.getHours() : date.getHours()
        let min =
            date.getMinutes() < 10 ? '0' + date.getMinutes() : date.getMinutes()
        let sec =
            date.getSeconds() < 10 ? '0' + date.getSeconds() : date.getSeconds()
        return (
            year + '-' + month + '-' + day + ' ' + hour + ':' + min + ':' + sec
        );
    }
    colorToRGBA(color, alpha = 1) {
        let newColor = color.toLowerCase().replace(/\s/g, '');
        let reg1 = /^#([0-9|a-f]{3}|[0-9|a-f]{6})$/;
        let reg2 = /^rgba?\((\d+,?){3}([01](\.\d+)?)?\)$/;
        if (newColor) {
            if (reg1.test(newColor)) {
                let list = [];
                if (newColor.length == 4) {
                    newColor = '#' + newColor[1] + newColor[2] + newColor[2] + newColor[3] + newColor[3];
                }
                for (let i = 1; i < 7; i += 2) {
                    list.push(parseInt('0x' + newColor.slice(i, i + 2)));
                }
                newColor = `rgba(${list.join(',')},${alpha})`;
            } else if (reg2.test(newColor)) {
                let matches = newColor.match(/\([^\)]+\)/);
                let match = matches && matches.length ? matches[0] : null;
                if (match) {
                    let list = match.replace(/\(|\)/g, '').split(',');
                    newColor = `rgba(${list.slice(0, 3).join(',')},${alpha})`;
                }
            }

        }
        return newColor;
    }
}
