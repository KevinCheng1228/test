
import classLevelOptions from './class-level-options'
import dateOptions from './date-options.js'
export default {
  logBase: {
    'mm/s': 5,
    'in/s': 10
  },
  defaultSetting: {
    name: null,
    symbol: 'circle',
    color: '#81DBC1',
    fontSize: 12,
    fontWeight: 'normal',
    fontColor: '#ffffff',
    type: 'log'
  },
  classLevelOptions,
  dateOptions
}
