export default [
    {
      label: "Y/M/D hh:mm:ss",
      formatText: "y/M/d HH:mm:ss"
    },
    {
      label: "Y/M/D hh:mm",
      formatText: "y/M/d HH:mm"
    },
    {
      label: "Y/M/D",
      formatText: "y/M/d"
    },
    {
      label: "M/D/Y hh:mm:ss",
      formatText: "M/d/y HH:mm:ss"
    },
    {
      label: "M/D/Y hh:mm",
      formatText: "M/d/y HH:mm"
    },
    {
      label: "M/D/Y",
      formatText: "M/d/y"
    },
    {
      label: "Mth D, Y hh:mm:ss",
      formatText: "MMM d, y HH:mm:ss"
    },
    {
      label: "Mth D, Y",
      formatText: "MMM d, y"
    },
    {
      label: "hh:mm:ss",
      formatText: "HH:mm:ss"
    },
    {
      label: "hh:mm",
      formatText: "HH:mm"
    }
  ]
