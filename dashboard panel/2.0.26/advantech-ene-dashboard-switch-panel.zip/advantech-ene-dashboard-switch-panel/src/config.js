const levelConfig = {
    firstModel: '',
    // {
    //     "name": {
    //         "en": "研华总部",
    //         "zh_cn": "研华总部",
    //         "zh_tw": "研华总部"
    //     },
    //     "value": "#121122#"
    // }, 
    datasources: ['wise.mplus-org-simplejson', 'deviceon-bi-simplejson'],
    dropdowns: {// dropdowns list
        levels: [{//company level
            itemList: [{
                name: "select group",
                value: "select group",
                dependentList: ""
            }],
            model: [],
            display: '', // input 初始化显示内容，默认等于model[0].name
            filter: '', // 输入事件时赋值，输入过滤使用，需要支持特殊字符*
            isMulti: true,
            includeAll: true,
            blocked: true,
            label: {
                'en': 'Organization',
                'zh_cn': '组织',
                'zh_tw': '組織'
            },
            query: '"func":"searchGroup"',
            title: "Organization0",
            type: "query"
        }, {
            itemList: [{
                name: "select group",
                value: "select group",
                dependentList: ""
            }],
            model: [],
            display: '', // input 初始化显示内容，默认等于model[0].name
            filter: '', // 输入事件时赋值，输入过滤使用，需要支持特殊字符*
            includeAll: true,
            isMulti: true,
            blocked: true,
            query: '"func":"searchGroup","parentGroup":"$Organization0"',
            title: "Organization1",
            label: {
                'en': 'Group1',
                'zh_cn': '组1',
                'zh_tw': '組1'
            },
            type: "query"
        }, {
            itemList: [{
                name: "select group",
                value: "select group",
                dependentList: ""
            }],
            model: [],
            display: '', // input 初始化显示内容，默认等于model[0].name
            filter: '', // 输入事件时赋值，输入过滤使用，需要支持特殊字符*
            includeAll: true,
            isMulti: true,
            blocked: true,
            query: '"func":"searchGroup","parentGroup":"$Organization1"',
            title: "Organization2",
            label: {
                'en': 'Group2',
                'zh_cn': '组2',
                'zh_tw': '組2'
            },
            type: "query"
        }, {
            itemList: [{
                name: "select group",
                value: "select group",
                dependentList: ""
            }],
            model: [],
            display: '', // input 初始化显示内容，默认等于model[0].name
            filter: '', // 输入事件时赋值，输入过滤使用，需要支持特殊字符*
            includeAll: true,
            isMulti: true,
            blocked: true,
            query: '"func":"searchGroup","parentGroup":"$Organization2"',
            title: "Organization3",
            label: {
                'en': 'Group3',
                'zh_cn': '组3',
                'zh_tw': '組3'
            },
            type: "query"
        }, {
            itemList: [{
                name: "select group",
                value: "select group",
                dependentList: ""
            }],
            model: [],
            display: '', // input 初始化显示内容，默认等于model[0].name
            filter: '', // 输入事件时赋值，输入过滤使用，需要支持特殊字符*
            includeAll: true,
            isMulti: true,
            blocked: true,
            query: '"func":"searchGroup","parentGroup":"$Organization3"',
            title: "Organization4",
            label: {
                'en': 'Group4',
                'zh_cn': '组4',
                'zh_tw': '組4'
            },
            type: "query"
        }],
        params: [
            {
                itemList: [{
                    name: "select object",
                    value: "select object",
                    dependentList: ""
                }],
                label: {
                    'en': 'Object',
                    'zh_cn': '物件',
                    'zh_tw': '物件'
                },
                model: [],
                display: '', // input 初始化显示内容，默认等于model[0].name
                filter: '', // 输入事件时赋值，输入过滤使用，需要支持特殊字符*
                includeAll: true,
                isMulti: true,
                query: '"func":"searchDevice","area":"$Organization0/$Organization1/$Organization2/$Organization3/$Organization4"',
                title: "Object",
                type: "query"
            }, {
                itemList: [{
                    name: "select parameter",
                    value: "select parameter",
                    dependentList: ""
                }],
                label: {
                    'en': 'Parameter',
                    'zh_cn': '参数',
                    'zh_tw': '參數'
                },
                model: [],
                display: '', // input 初始化显示内容，默认等于model[0].name
                filter: '', // 输入事件时赋值，输入过滤使用，需要支持特殊字符*
                includeAll: true,
                isMulti: true,
                query: '"func":"searchDeviceParam","area":"$Organization0/$Organization1/$Organization2/$Organization3/$Organization4","device":"$Object"',
                title: "Parameter",
                type: "query"
            }, {
                itemList: [
                    { dependentList: "", name: "Minute", value: "Minute" }
                ],
                model: [],
                display: '', // input 初始化显示内容，默认等于model[0].name
                filter: '', // 输入事件时赋值，输入过滤使用，需要支持特殊字符*
                includeAll: false,
                isMulti: false,
                query: '"func":"searchTimeInterval","timeinterval":""',
                label: {
                    'en': 'TimeInterval',
                    'zh_cn': '时间间隔',
                    'zh_tw': '時間間隔'
                },
                title: "TimeInterval",
                type: "query"
            }
        ]
    },
    checkboxs: []
}
export { levelConfig }