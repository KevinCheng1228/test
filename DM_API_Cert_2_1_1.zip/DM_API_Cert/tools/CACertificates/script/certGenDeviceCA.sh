#!/bin/bash
home_dir="${1}"
cd "${home_dir}"

# create device ca
# $2: common name (not use)
# $3: organization name
# $4: root password
# $5: expire days
# $6: intermediate password
# $7: common name (for device serialno)
# $8: intermediate_ca number
# $9: device password
# $10: rabbitmq ip
# $11: rabbitmq dns
# $12: extension name (for device)
./certGen.sh create_device_certificate_from_intermediate "${2}" "${3}" "${4}" "${5}" "${6}" "${7}" "${8}" "${9}" "${10}" "${11}" "${12}"

# gen keyvault file
cat ./device_ca/device-${7}.cert.pem ./device_ca/device-${7}.pkcs8.pem > ./keyvault/outbound/device-${7}.keyvault.pem
