#!/bin/bash
home_dir="${1}"
cd "${home_dir}"

# create root ca
# $2: common name
# $3: organization name
# $4: root password
# $5: expire days
./certGen.sh create_root_and_intermediate "${2}" "${3}" "${4}" "${5}"

# gen keyvault file
cat ./certs/root.ca.cert.pem ./private/root.ca.pkcs8.pem > ./keyvault/outbound/root.ca.keyvault.pem
