#!/bin/bash
home_dir="$1"
echo "${home_dir}"
cd "${home_dir}"

# prepare x.509 folder and file
# iothub path
iothub_ca_csr_folder="CACertificates/csr"
iothub_ca_private_folder="CACertificates/private"
iothub_ca_certs_folder="CACertificates/certs"
iothub_ca_intermediate_ca_folder="CACertificates/intermediate_ca"
iothub_ca_server_ca_folder="CACertificates/server_ca"
iothub_ca_device_ca_folder="CACertificates/device_ca"
iothub_ca_newcerts_folder="CACertificates/newcerts"
iothub_ca_keyvault_folder="CACertificates/keyvault"
iothub_ca_outbound_folder="CACertificates/keyvault/outbound"
iothub_ca_inbound_folder="CACertificates/keyvault/inbound"
iothub_ca_index_file="CACertificates/index.txt"
iothub_ca_serial_file="CACertificates/serial"

# rabbitmq path
rabbitmq_ca_csr_folder="CACertificatesForRabbitMQ/csr"
rabbitmq_ca_private_folder="CACertificatesForRabbitMQ/private"
rabbitmq_ca_certs_folder="CACertificatesForRabbitMQ/certs"
rabbitmq_ca_intermediate_ca_folder="CACertificatesForRabbitMQ/intermediate_ca"
rabbitmq_ca_server_ca_folder="CACertificatesForRabbitMQ/server_ca"
rabbitmq_ca_device_ca_folder="CACertificatesForRabbitMQ/device_ca"
rabbitmq_ca_newcerts_folder="CACertificatesForRabbitMQ/newcerts"
rabbitmq_ca_keyvault_folder="CACertificatesForRabbitMQ/keyvault"
rabbitmq_ca_outbound_folder="CACertificatesForRabbitMQ/keyvault/outbound"
rabbitmq_ca_inbound_folder="CACertificatesForRabbitMQ/keyvault/inbound"
rabbitmq_ca_index_file="CACertificatesForRabbitMQ/index.txt"
rabbitmq_ca_serial_file="CACertificatesForRabbitMQ/serial"

# log
log_folder="log"
# add permission to the log_folder
sudo chmod -Rf 2774 ${log_folder}

# tools
tools_folder="tools"
# add permission to the tools_folder
sudo chmod -Rf 2774 ${tools_folder}

tools_dir="$2"
echo "${tools_dir}"
cd "${tools_dir}"

# file list (index.txt)
indexFiles="${iothub_ca_index_file} ${rabbitmq_ca_index_file}"

for file in ${indexFiles}; do
    if [ -f "$file" ]; then
        echo "File exists: '$file'"
    else
        echo "Create file: ${file}"
        touch ${file}
        sudo chmod -f 2774 ${file}
    fi
done

# file list (serial file)
serialFiles="${iothub_ca_serial_file} ${rabbitmq_ca_serial_file}"

for file in $serialFiles; do
    if [ -f "$file" ]; then
        echo "File exists: '$file'"
    else
        echo "Create file: ${file}"
        echo 01 > ${file}
        sudo chmod -f 2774 ${file}
    fi
done

# folders
folders="${iothub_ca_csr_folder} 
    ${iothub_ca_private_folder} 
    ${iothub_ca_certs_folder} 
    ${iothub_ca_intermediate_ca_folder} 
    ${iothub_ca_server_ca_folder} 
    ${iothub_ca_device_ca_folder} 
    ${iothub_ca_newcerts_folder} 
    ${iothub_ca_keyvault_folder} 
    ${iothub_ca_outbound_folder} 
    ${iothub_ca_inbound_folder} 
    ${rabbitmq_ca_csr_folder} 
    ${rabbitmq_ca_private_folder} 
    ${rabbitmq_ca_certs_folder} 
    ${rabbitmq_ca_intermediate_ca_folder} 
    ${rabbitmq_ca_server_ca_folder} 
    ${rabbitmq_ca_device_ca_folder} 
    ${rabbitmq_ca_newcerts_folder} 
    ${rabbitmq_ca_keyvault_folder} 
    ${rabbitmq_ca_outbound_folder} 
    ${rabbitmq_ca_inbound_folder} "

for folder in $folders; do
    if [ -d "$folder" ]; then
        echo "Folder exists: '$folder'"
    else
        echo "Create folder: ${folder}"
        mkdir -p ${folder}
        sudo chmod -Rf 2774 ${folder}
    fi
done
