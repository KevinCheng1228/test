# docker image build -t harbor.arfa.wise-paas.com/isensing/api-cert:test .
podman image build --format docker -t harbor.arfa.wise-paas.com/isensing/api-cert:test .
