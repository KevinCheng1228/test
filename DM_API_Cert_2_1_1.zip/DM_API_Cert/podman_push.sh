# docker push harbor.arfa.wise-paas.com/isensing/api-cert:test
podman push harbor.arfa.wise-paas.com/isensing/api-cert:test
