module.exports = {
    env: {
        browser: false,
        commonjs: true,
        es2021: true,
        node: true
    },
    extends: [
        'standard'
    ],
    parserOptions: {
        ecmaVersion: 'latest'
    },
    rules: {
        indent: ['error', 4],
        'spaced-comment': 0,
        semi: 0,
        'space-before-blocks': 0,
        'comma-spacing': 0,
        'keyword-spacing': 0,
        'space-before-function-paren': 0,
        'new-cap': 0,
        'prefer-const': 0,
        'quote-props': 0,
        'camelcase': 0,
        'no-throw-literal': 0,
        'dot-notation': 0
    }
}
