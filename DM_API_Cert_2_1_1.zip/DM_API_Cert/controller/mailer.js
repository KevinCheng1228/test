const mailer = require('../lib/mailer');
const pg = require('../lib/db');
const crypt = require('../lib/crypt');
const common = require('../lib/common');
const setting = require('../conf/setting');
const logger = require('../lib/logger').getLogger('mailerCtrl');

async function getMailConfig() {
    try {
        let name = 'manage_portal'
        // get mail config by app name
        let queryResult = await pg.getMailConfig(name);
        if (!queryResult.status) throw new Error(queryResult.message);

        // decode password
        let passwordResult = crypt.decryptAes256Cbc(queryResult.result.rows[0].password, queryResult.result.rows[0].account);
        if (!passwordResult.status) throw new Error(passwordResult.message);

        let result = {
            host: queryResult.result.rows[0].host,
            port: queryResult.result.rows[0].port,
            secure: queryResult.result.rows[0].secure,
            email: queryResult.result.rows[0].sender_email,
            password: passwordResult.result,
            from: `"${queryResult.result.rows[0].sender_name}" <${queryResult.result.rows[0].sender_email}>`
        };

        return { status: true, result: result }
    } catch (error) {
        logger.error('getMailConfig error: ', error);
        return { status: false, message: error.message };
    }
}

/**
 * send a mail
 * @param {string} mailType mail type (error notify: -1, cert creation notify: 0, cert rotate nodify: 1)
 * @param {string} type cert type (root, intermediate, device, server)
 * @param {string} serialNo only for device serialNo
 * @param {string} message error message
 * @returns status is true / false
 */
async function sendCertMail(mailType, type, serialNo, message) {
    try {
        let content;
        let config = await getMailConfig();
        if (!config.result) throw new Error(config.message);
        let { from, ...mailConfig } = config.result;

        content = await getMailRecipientContent(mailType, from, type, serialNo, message);
        if (!content.result) throw new Error(content.message);

        let arr = [];
        content.result.forEach(mail => {
            arr.push(mailer.wrapedSendMail(mailConfig, mail))
        })
        // start to send mail
        let mailResults = await Promise.all(arr);
        mailResults.forEach(result => {
            if (!result.status) throw new Error(result.message);
        })

        return { status: true };
    } catch (error) {
        logger.error('sendCertMail error: ', error);
        return { status: false, message: error.message };
    }
}

async function getMailRecipientContent(mailType, from, type, serialNo, message) {
    try {
        let html;
        let subject;
        let mailOptions = [];

        // Get mail recipient
        let queryResult = await pg.getMailRecipientByUserRoleId([common.MAIL_ERROR_GROUP.ADMIN, common.MAIL_ERROR_GROUP.EdgeLink_Device_Platform_AE]);
        if (!queryResult.status) throw new Error(queryResult.message);

        // Get html format
        queryResult.result.rows.forEach(mail => {
            let mailContent = {
                recipient: mail.recipient.substring(0, mail.recipient.indexOf('@')),
                certHostName: `api-cert-${setting.NAMESPACE}-${setting.CLUSTER}.${setting.EXTERNAL_URL}`
            }

            switch(mailType) {
            case common.MAIL_TYPE.ERROR:
                subject = 'System Error Notification'
                mailContent.title = 'Certification API has encountered an error'
                mailContent.descriptionTitle = 'Error Details:'
                mailContent.description = `- Error Description: "${type} ${[common.CERT_NAME.DEVICE].includes(type) ? `serialno: ${serialNo}` : ''}, ${message}"`
                break;
            case common.MAIL_TYPE.CERT_CREATION:
                subject = 'System Notification'
                mailContent.title = 'Certification Creation has successfully'
                mailContent.descriptionTitle = 'Creation Details:'
                mailContent.description = `- Creation Description: "The ${type} cert ${message}"`
                break;
            case common.MAIL_TYPE.CERT_ROTATION:
                subject = 'System Notification'
                mailContent.title = 'Certification rotation has successfully'
                mailContent.descriptionTitle = 'Rotation Details:'
                mailContent.description = `- Rotation Description: "The ${type} cert ${message}"`
                break;
            default:
                throw new Error('The mail type is not defined');
            }

            html = getTemplateHtml(mailContent);

            mailOptions.push({
                from: from,
                to: mail.recipient,
                subject: subject,
                html: html
            });
        })

        return { status: true, result: mailOptions }
    } catch (error) {
        logger.error('getMailRecipientContent error: ', error);
        return { status: false, message: error.message };
    }
}

function getTemplateHtml(content) {
    let html;

    html = '<p>Dear ' + content.recipient + ',</p>' +
            '<p>' + content.title + '</p>' +
            '<p>Host Name: "' + content.certHostName + '" </p>' +
            '<p>' + content.descriptionTitle + '</p>' +
            '<p>' + content.description + '</p>' +
            '<p>- Date and Time of Occurrence: "' + new Date() + '"</p>' +
            '<p>Thank you.</p>' +
            '<p>Best regards</p>';

    return html;
}

module.exports = {
    sendCertMail
}
