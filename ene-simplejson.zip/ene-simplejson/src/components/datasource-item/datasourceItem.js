/*
 * @Author: NH
 * @Date: 2022-08-08 11:44:43
 * @LastEditTime: 2022-08-12 09:46:45
 * @Description: 
 */
import _ from 'lodash';
import './datasourceItem.css!';
import coreModule from 'app/core/core_module';
import { multiDropdownDirective } from '../multi-dropdown/multiDropdown';
coreModule.directive('multiDropdown', multiDropdownDirective);

class DatasourceItem {
    constructor($scope, $element) {
        this.list = [];
        console.log($element);
        this.elem = $element;
        $scope.$watch('ctrl.model', this.modelChanged.bind(this));
        // this.init();

    }

    async init() {
        this.list = await this.getOptions('');
        this.modelChanged();
    }

    modelChanged() {
        console.log('datasource item: ', this.model);
        // this.onChange();
    }
}

export function datasourceItemDirective() {
    return {
        restrict: 'E',
        templateUrl: 'public/plugins/ene-simple-json-datasource/components/datasource-item/datasourceItem.html',
        controller: DatasourceItem,
        controllerAs: 'ctrl',
        bindToController: true,
        scope: {
            model: '=',
            rawQuery: '=',
            datasource: '=',
            getOptions: '&',
            onChange: '&',
            type: '@',
            name: '@',
            displayName: '@',
        }
    }
}