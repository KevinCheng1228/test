///<reference path="../node_modules/grafana-sdk-mocks/app/headers/common.d.ts" />
import _ from 'lodash';
import { transformers } from './transformers';
import ChangeFont from './fontsize';
import FontFamily from './fontfamily';
import { getMultiLang } from './multilang';

export class TablePanelDisplayCtrl {
    panel: any;
    panelCtrl: any;
    transformers: any;
    fontSizes: any;
    getColumnNames: any;
    canSetColumns: boolean;
    columnsHelpMessage: string;
    mergeError: string;
    mergeColums: any;
    fontFamilys: any;
    langType: string;

    /** @ngInject */
    constructor($scope, private $q, private uiSegmentSrv) {
        $scope.editor = this;
        this.panelCtrl = $scope.ctrl;
        this.panel = this.panelCtrl.panel;
        this.fontSizes = ChangeFont.defaultValues;
        this.fontFamilys = FontFamily.getFontFamily();
        this.mergeError = '';
        this.langType = this.panel.langType;
        this.getMergeColumns();
    }
    getMultiLang(key) {
        this.langType = this.panelCtrl.getLangType(this.panelCtrl.dashboard.panelLanguage);
        return getMultiLang(key, this.langType);
    }

    getMergeColumns() {
        this.mergeColums = [];
        _.forEach(this.panel.mergeColums, merge => {
            this.mergeColums.push(merge);
        });
    }

    render() {
        this.panelCtrl.render();
    }

    resetColor() {
        this.panel.tableTitlebgColorSet = null;
        this.panel.tableTitleFontColorSet = null;
        this.panel.evenRowBGColorSet = null;
        this.panel.oddRowBGColorSet = null;

        this.panel.hoverBGColorSet = null;
        this.panelCtrl.render();
    }

    showRowBordersChanged() {
        if (this.panel.showRowBorders) {
            this.panel.showCellBorders = false;
        }
        this.panelCtrl.render();
    }

    showCellBordersChanged() {
        if (this.panel.showCellBorders) {
            this.panel.showRowBorders = false;
        }
        this.panelCtrl.render();
    }

    addMergeColumns() {
        const merges = this.mergeColums;

        if (merges.length > 0) {
            let noMerge = false;
            for (let i = 0; i < merges.length; i++) {
                if (!merges[i].start || !merges[i].end || !merges[i].name) {
                    noMerge = true;
                }
            }
            if (noMerge) {
                return;
            }
        }
        const merge = { start: '', end: '', name: '' };
        this.mergeColums.push(merge);
    }

    getColumnStrat() {
        if (!this.panelCtrl.table) {
            return [];
        }

        const names = [];
        if (this.panelCtrl.table.columns) {
            for (let i = 0; i < this.panelCtrl.table.columns.length; i++) {
                const column = this.panelCtrl.table.columns[i];
                if (column.hidden || (column.style && column.style.type === 'hidden')) {
                    continue;
                }
                names.push({ text: column.title, value: column.title });
            }
        }
        return names;
    }

    getColumnEnd(merge) {
        if (!this.panelCtrl.table) {
            return [];
        }

        if (!merge.start) {
            return [];
        }

        const tableCols = [];

        for (let i = 0; i < this.panelCtrl.table.columns.length; i++) {
            const column = this.panelCtrl.table.columns[i];
            if (column.hidden || (column.style && column.style.type === 'hidden')) {
                continue;
            }
            tableCols.push(column);
        }

        if (tableCols.length === 0) {
            return [];
        }

        let start = 0;
        for (let t = 0; t < tableCols.length; t++) {
            if (merge.start === tableCols[t].text) {
                start = t + 1;
            }
        }

        const names = [];
        for (let i = start; i < tableCols.length; i++) {
            names.push({ text: tableCols[i].title, value: tableCols[i].title });
        }

        return names;
    }

    startChange(merge) {
        for (let i = 0; i < this.panelCtrl.table.columns.length; i++) {
            const column = this.panelCtrl.table.columns[i];
            if (column.title === merge.displayS) {
                merge.start = column.text || column.title;
            }
        }

        merge.end = '';
    }

    endChange(merge) {
        for (let i = 0; i < this.panelCtrl.table.columns.length; i++) {
            const column = this.panelCtrl.table.columns[i];
            if (column.title === merge.displayE) {
                merge.end = column.text;
            }
        }
    }

    mergingColumn() {
        this.checkError();
        if (this.mergeError) {
            return;
        }

        this.panel.mergeColums = [];
        _.forEach(this.mergeColums, merge => {
            this.panel.mergeColums.push(merge);
        });
        this.render();
    }

    nameChange() {
        //this.checkError();
    }

    removeMerge(merge) {
        this.mergeColums = _.without(this.mergeColums, merge);
        this.mergingColumn();
    }

    checkError() {
        let mergeError = '';
        let startToEnd = '';

        for (let i = 0; i < this.mergeColums.length; i++) {
            const mergeCol = this.mergeColums[i];
            if (!mergeCol.start || !mergeCol.end || !mergeCol.name) {
                mergeError = 'merge config can not be empty';
            }

            if (mergeError) {
                break;
            }

            let startNum = 0;
            let endNum = 0;
            for (let t = 0; t < this.panelCtrl.table.columns.length; t++) {
                const column = this.panelCtrl.table.columns[t];
                if (mergeCol.start === column.text) {
                    startNum = t;
                }

                if (mergeCol.end === column.text) {
                    endNum = t;
                }
            }
            for (let j = startNum; j <= endNum; j++) {
                startToEnd = startToEnd + j;
            }
        }

        let repeat = '';
        for (let r = 0; r < startToEnd.length; r++) {
            if (startToEnd[r] === repeat) {
                mergeError = 'merge config can not be repeat';
                break;
            }
            repeat = startToEnd[r];
        }

        this.mergeError = mergeError;
    }

    setFontFamily(cloumn, subItem) {
        this.panel.fontFamily = subItem.value;
        // column.unit = subItem.value;
        this.panelCtrl.render();
    }
}

/** @ngInject */
export function TablePanelDisplay($q, uiSegmentSrv) {
    'use strict';
    return {
        restrict: 'E',
        scope: true,
        templateUrl: 'public/plugins/ene-alarm-panel/partials/display.html',
        controller: TablePanelDisplayCtrl,
    };
}
