<!--
 * @Author: NH
 * @Date: 2019-11-07 10:51:03
 * @LastEditTime: 2023-04-04 09:15:02
 * @Description: 
-->
# Changelog

All notable changes to this project will be documented in this file.

## [2.00.013] - Apr 04,2023

### Add: Almlog_record function supports querying whether the scope includes sub organizations

## [2.00.001] - Mar 20,2023

### Update: PassRate and FailRate function supports displaying times

### Update: Fixed Interval supports '12h' and '8h'

### Update: Exchange Datatype and TimeInterval positions

### Update: TimeInterval 'Original' cancel 'month' and 'year' options

### Update: When switching the first group, the previously selected second group does not reset the default item

### Update: When switching source, the selected items in common library will be filled automatically

### Add 'inspection area' and 'inspection station' setting for inspection function

### Add common library component: Group, Object, Parameter

### Update default value of 'mark exception' and 'mark alarm' are false

### Support KPI Datasource query

### Support KPI Datasource setValue

## [1.05.001] - Aug 25,2022

### Timeinterval adds 'Original ' to query raw data

### Filter parameter by regular expression

### Transformation function supports simple mathematical operation of rt/his data

### [bug fixed] the dropdown does not display when editing the panel

## [1.04.001] - Mar 23,2022

### The plugin configuration page supports multiple languages

### Support SOE API, query soe rules and soe log

### Support Event API, query  event detail
