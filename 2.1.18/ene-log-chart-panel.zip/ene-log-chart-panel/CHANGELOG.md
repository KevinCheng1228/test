## [1.0.1] - Jan 14, 2020
### New Feature
- upper edge and lower edge will dynamic add level now when level > mm/s's or in/s's min or mm/s's or in/s's max > level 
### Bug Fix
- it support 0, last y axis will show 0
## [1.0.0] - Nov 18, 2019
### New Feature
- Complete log chart
