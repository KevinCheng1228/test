export default {
  "Class I": {
    "mm/s": {
      "good": {
        "min": 0.01,
        "max": 0.71
      },
      "satisfactory": {
        "min": 0.71,
        "max": 1.80
      },
      "unsatisfactory": {
        "min": 1.80,
        "max": 4.50
      },
      "unacceptable": {
        "min": 4.50,
        "max": 50
      }
    },
    "in/s": {
      "good": {
        "min": 0.001,
        "max": 0.03
      },
      "satisfactory": {
        "min": 0.03,
        "max": 0.07
      },
      "unsatisfactory": {
        "min": 0.07,
        "max": 0.18
      },
      "unacceptable": {
        "min": 0.18,
        "max": 1.10
      }
    }
  },
  "Class II": {
    "mm/s": {
      "good": {
        "min": 0.01,
        "max": 1.12
      },
      "satisfactory": {
        "min": 1.12,
        "max": 2.80
      },
      "unsatisfactory": {
        "min": 2.80,
        "max": 7.10
      },
      "unacceptable": {
        "min": 7.10,
        "max": 50
      }
    },
    "in/s": {
      "good": {
        "min": 0.001,
        "max": 0.04
      },
      "satisfactory": {
        "min": 0.04,
        "max": 0.11
      },
      "unsatisfactory": {
        "min": 0.11,
        "max": 0.28
      },
      "unacceptable": {
        "min": 0.28,
        "max": 1.10
      }
    }
  },
  "Class III": {
    "mm/s": {
      "good": {
        "min": 0.01,
        "max": 1.80
      },
      "satisfactory": {
        "min": 1.80,
        "max": 4.50
      },
      "unsatisfactory": {
        "min": 4.50,
        "max": 11.20
      },
      "unacceptable": {
        "min": 11.20,
        "max": 50
      }
    },
    "in/s": {
      "good": {
        "min": 0.001,
        "max": 0.07
      },
      "satisfactory": {
        "min": 0.07,
        "max": 0.18
      },
      "unsatisfactory": {
        "min": 0.18,
        "max": 0.44
      },
      "unacceptable": {
        "min": 0.44,
        "max": 1.10
      }
    }
  },
  "Class IV": {
    "mm/s": {
      "good": {
        "min": 0.01,
        "max": 2.80
      },
      "satisfactory": {
        "min": 2.80,
        "max": 7.10
      },
      "unsatisfactory": {
        "min": 7.10,
        "max": 18
      },
      "unacceptable": {
        "min": 18,
        "max": 50
      }
    },
    "in/s": {
      "good": {
        "min": 0.001,
        "max": 0.11
      },
      "satisfactory": {
        "min": 0.11,
        "max": 0.28
      },
      "unsatisfactory": {
        "min": 0.28,
        "max": 0.70
      },
      "unacceptable": {
        "min": 0.70,
        "max": 1.10
      }
    }
  }
};
