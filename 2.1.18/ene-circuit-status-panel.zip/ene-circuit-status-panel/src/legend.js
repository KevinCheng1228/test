import angular from "angular";
import kbn from "app/core/utils/kbn";
import $ from "jquery";
import "jquery.flot";
import "jquery.flot.time";
import PerfectScrollbar from "./lib/perfect-scrollbar.min";

angular
  .module("grafana.directives")
  .directive("piechartLegend", function (popoverSrv, $timeout) {
    return {
      link: function (scope, elem) {

      }
    };
  });
