import { MachineInfo } from './machine_ctrl';
import { loadPluginCss } from 'app/plugins/sdk';

loadPluginCss({
  light: 'plugins/ene-circuit-status-panel/css/light.css',
  dark: 'plugins/ene-circuit-status-panel/css/dark.css'
});

export { MachineInfo as PanelCtrl };
