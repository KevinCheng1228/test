///<reference path="../node_modules/grafana-sdk-mocks/app/headers/common.d.ts" />

import _ from 'lodash';
import kbn from 'app/core/utils/kbn';
import { getMultiLang } from './multilang';

export class ColumnOptionsCtrl {
    panel: any;
    panelCtrl: any;
    colorModes: any;
    columnStyles: any;
    columnTypes: any;
    dateFormats: any;
    addColumnSegment: any;
    unitFormats: any;
    getColumnNames: any;
    activeStyleIndex: number;
    mappingTypes: any;
    columnAligns: any;
    buttonHandlers: any;
    iconlist: any;
    hrefTargetList: any;
    statusList: any;
    colors: any[];

    /** @ngInject */
    constructor($scope) {
        $scope.editor = this;

        this.activeStyleIndex = 0;
        this.panelCtrl = $scope.ctrl;
        this.panel = this.panelCtrl.panel;
        this.unitFormats = kbn.getUnitFormats();
        this.colorModes = [
            { text: 'Disabled', value: null },
            { text: 'Cell', value: 'cell' },
            { text: 'Value', value: 'value' },
            { text: 'Row', value: 'row' },
            { text: 'Status', value: 'status' },
        ];
        this.columnTypes = [
            { text: 'Number', value: 'number' },
            { text: 'String', value: 'string' },
            { text: 'Date', value: 'date' },
            { text: 'Array', value: 'array' },
            { text: 'Button', value: 'button' },
            { text: 'Operation', value: 'operation' },
            { text: 'Status', value: 'status' },
            { text: 'Hidden', value: 'hidden' },
        ];
        this.dateFormats = [
            { text: 'YYYY-MM-DD HH:mm:ss', value: 'YYYY-MM-DD HH:mm:ss' },
            { text: 'YYYY-MM-DD HH:mm:ss.SSS', value: 'YYYY-MM-DD HH:mm:ss.SSS' },
            { text: 'MM/DD/YY h:mm:ss a', value: 'MM/DD/YY h:mm:ss a' },
            { text: 'MMMM D, YYYY LT', value: 'MMMM D, YYYY LT' },
            { text: 'YYYY-MM-DD', value: 'YYYY-MM-DD' },
        ];
        this.mappingTypes = [
            { text: 'Value to text', value: 1 },
            { text: 'Range to text', value: 2 },
        ];
        this.columnAligns = [
            { text: 'Left', value: 'left' },
            { text: 'Center', value: 'center' },
            { text: 'Right', value: 'right' },
        ];

        this.buttonHandlers = [].concat(this.panel.checkboxHandlers);
        this.iconlist = [
            { text: 'Edit', value: 'edit' },
            { text: 'Tracking', value: 'tracking' },
            { text: 'Suggestion', value: 'suggestion' },
            { text: 'SOE', value: 'soe' }
        ];

        this.hrefTargetList = [
            { text: 'Blank', value: '_blank' },
            { text: 'Self', value: '_self' }
        ]

        this.statusList = [].concat(this.panelCtrl.statusList);
        this.getColumnNames = () => {
            if (!this.panelCtrl.table) {
                return [];
            }
            return _.map(this.panelCtrl.table.columns, (col: any) => {
                if (col.addStatusLampCol) {
                    return '';
                }
                return col.text;
            });
        };

        this.onColorChange = this.onColorChange.bind(this);

    }
    getMultiLang(key) {
        return getMultiLang(key, this.panel.langType);
    }
    changeType(style) {
        if (['number', 'string', 'button'].indexOf(style.type) != -1) {
            style.colors = [].concat(this.statusList);
        }

        this.render();
    }

    render() {
        this.panelCtrl.render();
    }

    setUnitFormat(column, subItem) {
        column.unit = subItem.value;
        this.panelCtrl.render();
    }

    addColumnStyle() {
        const newStyleRule = {
            unit: 'short',
            type: 'number',
            alias: '',
            decimals: 2,
            colors: [].concat(this.statusList),
            colorMode: null,
            pattern: '',
            dateFormat: 'YYYY-MM-DD HH:mm:ss',
            thresholds: [],
            mappingType: 1,
            align: 'left',
            thresholdsDisplay: [],
            arraycolors: [].concat(this.statusList),
            bar: false,
            url: false,
            icon: false,
            handler: 'Detail',
            icontype: 'tracking',
            hrefTarget: '_self',
            statusStyle: [],
            operNum: 1,
            operationList: [
                {
                    type: 'tracking',
                    handler: 'Detail'
                }
            ]
        };

        const styles = this.panel.styles;
        const stylesCount = styles.length;
        let indexToInsert = stylesCount;

        // check if last is a catch all rule, then add it before that one
        if (stylesCount > 0) {
            const last = styles[stylesCount - 1];
            if (last.pattern === '/.*/') {
                indexToInsert = stylesCount - 1;
            }
        }

        styles.splice(indexToInsert, 0, newStyleRule);
        this.activeStyleIndex = indexToInsert;
    }

    removeColumnStyle(style) {
        this.panel.styles = _.without(this.panel.styles, style);
        this.activeStyleIndex = this.panel.styles.length - 1;
        this.panelCtrl.render();
    }

    getLogType(style) {
        let arr = [];
        if (this.panelCtrl.dataRaw.length && this.panelCtrl.dataRaw[0].logType && this.panelCtrl.dataRaw[0].logType.length) {
            arr = this.panelCtrl.dataRaw[0].logType.filter(x => { 
                return -1 == style.statusStyle.findIndex(y => { return y.name == x }) 
            }).map(x => {
                return {
                    text: x,
                    value: x
                }
            });
        }
        return arr;
    }

    addStatusStyle(style) {
        let newStatusStyle = {
            name: '',
            bgColor: '#FF231E',
            color: '#000',
            bold: 'bold'
        }
        style.statusStyle.unshift(newStatusStyle);
        this.panelCtrl.render();
    }
    removeStatusStyle(index, status, style) {
        style.statusStyle.splice(index, 1);
        this.panelCtrl.render();
    }
    invertColorOrder(index) {
        const ref = this.panel.styles[index].colors;
        ref.reverse();
        this.panel.styles[index].colors = ref;
        this.panelCtrl.render();
    }
    open(statusStyle){
        statusStyle.show = !statusStyle.show;
        this.panelCtrl.render();
    }
    onStatusColorChange(color, statusStyle) {
        statusStyle.bgColor = color;
        statusStyle.show = false;
        this.panelCtrl.render();
    }
    onColorChange(styleIndex, colorIndex) {
        return newColor => {
            this.panel.styles[styleIndex].colors[colorIndex] = newColor;
            this.render();
        };
    }

    addValueMap(style) {
        if (!style.valueMaps) {
            style.valueMaps = [];
        }
        style.valueMaps.push({ value: '', text: '' });
        this.panelCtrl.render();
    }

    removeValueMap(style, index) {
        style.valueMaps.splice(index, 1);
        this.panelCtrl.render();
    }

    addRangeMap(style) {
        if (!style.rangeMaps) {
            style.rangeMaps = [];
        }
        style.rangeMaps.push({ from: '', to: '', text: '' });
        this.panelCtrl.render();
    }

    removeRangeMap(style, index) {
        style.rangeMaps.splice(index, 1);
        this.panelCtrl.render();
    }

    resetColumnColor(style) {
        delete style.colbgColor;
        delete style.colFontColorSet;
        this.panelCtrl.render();
    }

    linkChecked(style) {
        if (style.link) {
            style.url = false;
        }
        this.render();
    }

    asUrlChecked(style) {
        if (style.url) {
            style.link = false;
        }
        this.render();
    }

    operationChangeNum(style) {
        if (style.operNum == undefined) {
            style.operNum = 1;
            style.operationList = [{
                type: 'tracking',
                handler: 'Detail'
            }];
        }
        let temp = {
            type: 'tracking',
            handler: 'Detail'
        }

        if (style.operNum < 0) style.operNum = 0;
        if (style.operNum > 3) style.operNum = 3;
        if (style.operNum > style.operationList.length) {
            let len = style.operationList.length;
            for (let i = len; i < style.operNum; i++) {
                style.operationList.push(Object.assign({}, temp));
            }
        } else if (style.operNum < style.operationList.length) {
            let len = style.operationList.length - style.operNum;
            style.operationList.splice(style.operNum, len);
        }

        this.render();
    }
}

/** @ngInject */
export function columnOptionsTab($q, uiSegmentSrv) {
    'use strict';
    return {
        restrict: 'E',
        scope: true,
        templateUrl: 'public/plugins/ene-event-log-panel/partials/column_options.html',
        controller: ColumnOptionsCtrl,
    };
}
