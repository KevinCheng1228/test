<!--
 * @Author: NH
 * @Date: 2021-05-13 17:28:05
 * @LastEditTime: 2022-07-27 12:46:37
 * @Description: 
-->
# Changelog

All notable changes to this project will be documented in this file.

## [1.04.002] - July 27,2022

### New Feature

- The level of panel default configuration is set to 5 levels

## [1.04.001] - Mar 17,2022

### New Feature

- The panel configuration page supports multiple languages
- Support export report function
- Cancel the length limit of the title

## [1.0.0] - 2019-04-23

### New Feature

- first version
