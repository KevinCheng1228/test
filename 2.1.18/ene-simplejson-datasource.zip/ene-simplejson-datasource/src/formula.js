/*
 * @Author: NH
 * @Date: 2022-07-14 16:35:10
 * @LastEditTime: 2022-07-14 16:48:02
 * @Description: 
 */
class Formula {
    constructor() {
        this.stringModifier = `'`;
        this.index = -1;
        this.formula = '';
        this.formula0 = '';
        this.symbols = null;
        this.funcs = null;
        this.diyFuncs = null;
        this.symbol = '';
        this.var = '';
        this.param = '';
        this.func = '';
        this.symbolNoBrackets = null;
        this.plugins = null;
        this.plu = null;
        this.result = {
            codes: null,
            message: '',
            status: 0,
            nums: null,
            strs: null,
            formula: null,
            functions: null,
            outputs: null
        }
    }

    //0.验证成功 ok
    //1.验证formula为空 ok
    //2.验证空括号()，空括号必须是function调用 ok
    //3.验证括号匹配 ok 
    //4.验证符号是否为待选符号 ok
    //5.验证连续非()运算符，运算符前后必须是数字或字母 ok
    //6.验证（括号后面不可为运算符，除了（ ok
    //7.验证（括号前面必是运算符或字母，并且字母必为待选函数名，不可为数字 ok
    //8.验证）括号前面不可为运算符，除了）
    //9.验证）括号后面必是运算符，除了（
    //10.验证函数是否为待选函数 ok
    //11.逗号，必在函数参数中 ok
    //12.句号，必在数字中，或在plugin()后面，且其后紧跟有效字符串 ok
    //13.验证变量不可以以数字或符号开头，变量名不能存在特殊符号，只能是字母或数字 ok
    //14.校验首尾输入只能是数字，字母或（） ok
    //15.验证引号字符串是否合法，并提取
    //16.验证自定义函数传入参数格式
    //17.验证是否含有Plugin，plugin传入参数格式，验证output链接格式
    check(formula = '', funcs = [], symbols = ['+','-','*','/','(',')'], diyFuncs = [], plugins = []) {
        this.formula0 = formula.replace(/\s+/g, '');
        this.formula = formula.replace(/\s+/g, '');
        if (-1 == symbols.indexOf(',')) symbols.push(',');
        if (-1 == symbols.indexOf('.')) symbols.push('.');
        if (-1 == symbols.indexOf(this.stringModifier)) symbols.push(this.stringModifier);
        this.symbols = symbols;
        this.symbolNoBrackets = this.symbols.filter(x => { return x != '(' && x != ')' && x != ',' && x != this.stringModifier });
        this.funcs = [].concat(funcs, diyFuncs, plugins);
        this.diyFuncs = diyFuncs;
        this.plugins = plugins;

        if (this.isNull()) {
            this.resultEngine(1, 'Formula is null');//为空
            return this.result;
        } else if (this.isInValidString()) {
            this.resultEngine(2, `InvalidString Error:Unexpected "${this.symbol}" symbol in "${this.formula0}" at index ${this.index}`);//字符串输入校验
            return this.result;
        } else if (this.isInValidHeadOrTail()) {
            this.resultEngine(3, `InvalidHeadOrTail Error:Unexpected "${this.symbol}" symbol in "${this.formula0}" at index ${this.index}`);//首尾输入校验
            return this.result;
        } else if (this.isMatchBracket()) {
            this.resultEngine(4, `MatchBracket Error:Unexpected "${this.symbol}" symbol in "${this.formula0}" at index ${this.index}`);//括号匹配
            return this.result;
        } else if (this.isEmptyBracket()) {
            this.resultEngine(5, `EmptyBracket Error:Unexpected "${this.symbol}" in "${this.formula0}" at index ${this.index}`);//空括号
            return this.result;
        } else if (this.isInValidSymbol()) {
            this.resultEngine(6, `InvalidSymbol Error:Unexpected "${this.symbol}" symbol in "${this.formula0}" at index ${this.index}`);//待选运算符
            return this.result;
        } else if (this.isConsecutiveSymbol()) {
            this.resultEngine(7, `ConsecutiveSymbol Error:Unexpected "${this.symbol}" symbol in "${this.formula0}" at index ${this.index}`);//连续运算符
            return this.result;
        } else if (this.isInValidBracket()) {
            this.resultEngine(8, `InvalidBracket Error:Unexpected "${this.symbol}" symbol in "${this.formula0}" at index ${this.index}`);//括号校验
            return this.result;
        } else if (this.isInValidFunction()) {
            this.resultEngine(9, `InvalidFunction Error:Unexpected "${this.func}" function in "${this.formula0}" at index ${this.index}`);//待选函数
            return this.result;
        } else if (this.isInValidComma()) {
            this.resultEngine(10, `InvalidComma Error:Unexpected "," comma in "${this.formula0}" at index ${this.index}`);//验证逗号位置
            return this.result;
        } else if (this.isInValidDIYFuncVariable()) {
            this.resultEngine(11, `InvalidParameter Error:"${this.param}" function cannot have an expression as an argument in "${this.formula0}"`);//验证自定义函数参数
            this.param = null;
            return this.result;
        } else if (this.isInValidPluginVariable()) {
            this.resultEngine(12, `InvalidPlugin Error:"${this.plu}" plugin format is error in "${this.formula0}"`);//验证plugin参数
            this.param = null;
            return this.result;
        } else if (this.isInValidVariable()) {
            this.resultEngine(13, `InvalidVariable Error:Unexpected "${this.var}" variable in "${this.formula0}" at index ${this.index}`);//验证变量合法性
            return this.result;
        } else {
            this.resultEngine(0, `success`, this.result.codes, this.result.nums, this.result.functions, this.result.strs, this.result.outputs);
            return this.result;
        }
    }
    //1.是否为空
    isNull() {
        if (!this.formula) {
            return true
        }
        return false;
    }
    //2.是否是有效字符串
    isInValidString() {
        let num = this.formula.match(/'/g) || [];
        if (num.length % 2 != 0) {
            this.index = this.formula.lastIndexOf("'");
            this.symbol = "'";
            return true;
        }
        //提取引号
        let strs = this.formula.match(/'[^']*'/g) || [];
        this.formula = this.changeStrToChar(this.formula, /'[^']*'/g, this.stringModifier);
        this.result.strs = strs.map(x => { return x.replace(/'/g, '') });
        return false;
    }
    //3.首尾验证
    isInValidHeadOrTail() {
        let index = this.formula.search(/^[^0-9A-z(-]|[^0-9A-z)]$/);
        if (-1 != index) {
            this.index = index;
            this.symbol = this.formula.match(/^[^0-9A-z(-]|[^0-9A-z)]$/)[0];
            return true;
        }
        return false;
    }
    //4.括号匹配
    isMatchBracket() {
        let left = this.formula.match(/\(/g) ? this.formula.match(/\(/g).length : 0;
        let right = this.formula.match(/\)/g) ? this.formula.match(/\)/g).length : 0;
        if (left > right) {
            this.index = this.formula.lastIndexOf('(');
            this.symbol = '(';
            return true;
        } else if (left < right) {
            this.index = this.formula.indexOf(')') + 1;
            this.symbol = ')';
            return true;
        }
        let flag = true;
        let formula = this.formula;
        while (flag) {
            formula = this.changeStrToChar(formula, /\([^()]*\)/g, ' ');
            let matches = formula.match(/\([^()]*\)/g);
            if (!matches) {
                flag = false;
            }
        }
        let index = formula.search(/\(|\)/g);
        if (-1 != index) {
            this.index = index;
            this.symbol = formula.match(/\(|\)/g)[0];
            return true;
        }
        return false;
    }
    //5.是否为空括号，为空则判断是否为合法函数引用
    isEmptyBracket() {
        let index = 0, flag = false;
        do {
            index = this.formula.indexOf('()', index);
            if (-1 != index) {
                let prefix = this.formula.substring(0, index).match(/\w+$/) || [];
                if (-1 != this.funcs.indexOf(prefix[0])) {
                    index++;
                    flag = true;
                } else {
                    this.index = index;
                    flag = false
                    index = -2;
                }

            } else {
                flag = false
            }
        } while (flag)
        if (-2 == index) {
            this.symbol = '()'
            return true
        }
        return false
    }
    //6.无效符号
    isInValidSymbol() {
        let formula = this.formula;
        formula = this.changeStrToChar(formula, /\w+/g, ',');
        this.symbols.forEach(x => {
            if (-1 != formula.indexOf(x)) {
                let reg = this.buildRegExp(this.changeSymbolToRegStr([x]), 'g');
                formula = this.changeStrToChar(formula, reg, ' ');
            }
        });

        if (-1 != formula.search(/\S+/)) {
            this.index = formula.search(/\S+/);
            this.symbol = formula.match(/\S+/)[0];
            return true;
        }
        let match = this.formula.match(/\D\.\D/g);
        if (match && match.length) {
            for (let i = 0; i < match.length; i++) {
                if (!/\)\.[A-z]/g.test(match[i])) {
                    this.index = this.formula.indexOf(match[i]) + 1;
                    this.symbol = '.';
                    return true;
                }
            }
        }

        return false
    }
    //7.除了（）括号外，其他符号是否连续，运算符前后必须是数字或字母
    isConsecutiveSymbol() {
        let reg = this.buildRegExp(`(${this.changeSymbolToRegStr(this.symbolNoBrackets)}){2,}`, 'g');
        let index = this.formula.search(reg);
        if (-1 != index) {
            let doubleSymbol = this.symbolNoBrackets.filter(x => { return x.length > 1 });
            let s = this.formula.match(reg) || [];
            for (let i = 0; i < s.length; i++) {
                let e = s[i];
                i = doubleSymbol.findIndex(x => { return x == e });
                if (-1 == i) {
                    this.index = this.formula.indexOf(e);
                    this.symbol = e;
                    return true;
                }
            }
        }
        return false;
    }
    //8.校验括号
    isInValidBracket() {
        let index = -1;

        index = this.formula.search(/\([^0-9A-z()-\\']+/g);
        if (-1 != index) {
            this.index = index + 1;
            this.symbol = this.formula.match(/\([^0-9A-z()-\\']+/g)[0].substring(1);
            return true;
        }
        index = this.formula.search(/^\)/);
        if (-1 != index) {
            this.index = index;
            this.symbol = ')';
            return true;
        }
        index = this.formula.search(/[^0-9A-z()\\']+\)/g);
        if (-1 != index) {
            this.index = index;
            this.symbol = this.formula.match(/[^0-9A-z()\\']+\)/g)[0].replace(')', '');
            return true;
        }
        index = this.formula.search(/\)[0-9A-z(]+/g);
        if (-1 != index) {
            this.index = index + 1;
            this.symbol = this.formula.match(/\)[0-9A-z(]+/g)[0].replace(')', '');
            return true;
        }
        return false;
    }
    //9.验证函数合法性
    isInValidFunction() {
        let matches = this.formula.match(/\w+\(/g) || [];
        let funcs = [];
        for (let i = 0; i < matches.length; i++) {
            let index = this.funcs.findIndex(x => {
                return x == matches[i].replace('(', '');
            });
            if (-1 == index) {
                this.index = this.formula.indexOf(matches[i]);
                this.func = matches[i].replace('(', '');
                return true;
            }
            funcs.push(matches[i].replace('(', ''));
        }
        this.result.functions = funcs;
        return false;
    }
    //10.验证逗号
    isInValidComma() {
        let index = 0;
        index = this.formula.search(/\(,/);
        if (index != -1) {
            this.index = index + 1;
            this.symbol = ',';
            return true;
        }

        index = this.formula.search(/,\)/);
        if (index != -1) {
            this.index = index;
            this.symbol = ',';
            return true;
        }

        if (this.formula.indexOf(',') == -1) {
            return false;
        } else {
            let commaIndexs = [];
            this.formula.split('').forEach((e, i) => { if (e == ',') commaIndexs.push(i) });

            let indexes = [];
            for (let j = 0; j < commaIndexs.length; j++) {
                let e = commaIndexs[j];
                let preIndex = -1;//前左括号数
                let pre = 0;
                let nextIndex = -1;//后右括号数
                let next = 0;
                for (let i = e - 1; i >= 0; i--) {
                    if (this.formula[i] == ')') pre--;
                    if (this.formula[i] == '(') pre++;
                    if (pre == 1) {
                        preIndex = i;
                        break;
                    }
                }
                for (let i = e + 1; i < this.formula.length; i++) {
                    if (this.formula[i] == '(') next--;
                    if (this.formula[i] == ')') next++;
                    if (next == 1) {
                        nextIndex = i;
                        break;
                    }
                }
                if (preIndex == -1 || nextIndex == -1) {
                    index = e;
                    break;
                } else {
                    indexes.push(preIndex + '#' + nextIndex + '#' + e);
                }
            }
            for (let i = 0; i < indexes.length; i++) {
                let pre = indexes[i].split('#')[0];
                let cindex = indexes[i].split('#')[2];
                //以括号开头，包含逗号
                if (pre == 0) {
                    index = cindex;
                    break;
                }
                //左括号前面不是字母
                if (!/[A-z0-9_]/.test(this.formula.charAt(pre - 1))) {
                    index = cindex;
                    break;
                }
                //左括号前面是字母，判断是否是合法func
                let str = this.formula.substring(0, pre).split('').reverse().join('');
                let len = str.search(/[^A-z0-9_]/) == -1 ? str.length : str.search(/[^A-z0-9_]/);
                str = str.substring(0, len).split('').reverse().join('');
                if (this.funcs.indexOf(str) == -1) {
                    index = pre;
                    break;
                }
            }
        }


        // let reg = this.buildRegExp(`(${this.changeFuncToRegStr(this.funcs)})\\([^,]+,[^,]+\\)`,'g');// /\([^\(\)]+,[^\(\)]+\)/g;
        // let flag = false,formula = this.changeStrToChar(this.formula, reg, ' ');
        // do{
        //     formula = this.changeStrToChar(formula, reg, ' ');
        //     if(formula.search(reg) != -1){
        //         flag = true;
        //     }else{
        //         flag = false;
        //     }
        // }while(flag);
        // index = formula.search(',');
        if (-1 != index) {
            this.index = index;
            this.symbol = ',';
            return true;
        }
        return false;
    }
    //11.验证自定义函数参数合法性
    isInValidDIYFuncVariable() {
        let reg = this.buildRegExp(`(${this.changeFuncToRegStr(this.diyFuncs)})\\(`, 'g');
        let matches = this.formula.match(reg);
        if (!matches) return false;
        for (let i = 0; i < matches.length; i++) {
            let index = this.formula.indexOf(matches[i]);
            let next = 0;
            let str = '';
            for (let j = index + matches[i].length - 1; j < this.formula.length; j++) {
                if (this.formula[j] == '(') next++;
                if (this.formula[j] == ')') next--;
                if (next == 0 && j != index) {
                    str = this.formula.substring(index, j).replace(matches[i], '');
                    break;
                }
            }
            let arr = str.split(',');
            for (let j = 0; j < arr.length; j++) {
                if (!isNaN(arr[j]) || arr[j].indexOf(this.stringModifier) != -1) {

                } else if (!/^[A-z]\w*$/.test(arr[j])) {
                    // this.param = matches[i].replace('(','');
                    // break;
                }
            }
            if (this.param) break;
        }
        if (this.param) {
            this.index = this.formula.indexOf(this.param);
            return true;
        } else {
            return false;
        }
    }
    //12.验证Plugin合法性
    isInValidPluginVariable() {
        if (!this.plugins.length) return false;
        let reg = this.buildRegExp(`(${this.changeFuncToRegStr(this.plugins)})\\(`, 'g');
        let matches = this.formula.match(reg);
        if (!matches) return false;
        let outputs = [];
        let len = 0;
        for (let i = 0; i < matches.length; i++) {
            let index = this.formula.indexOf(matches[i], len);
            let next = 0;
            let str = '';
            let outputIndex = -1;
            for (let j = index + matches[i].length - 1; j < this.formula.length; j++) {
                if (this.formula[j] == '(') next++;
                if (this.formula[j] == ')') next--;
                if (next == 0 && j != index) {
                    str = this.formula.substring(index, j).replace(matches[i], '');
                    len = outputIndex = j;
                    break;
                }
            }
            if (outputIndex !== -1) {
                let match = this.formula.substring(outputIndex).match(/^\)\.[A-z0-9]+/);
                if (match && match.length) {
                    let output = this.formula.substr(outputIndex + 1, match[0].length - 1);
                    outputs.push(output.replace('.', ''));
                    this.formula = this.changeStrToChar(this.formula, output, ' ');
                } else {
                    this.index = index;
                    this.plu = matches[0].replace('(', '');
                    return true;
                }
            }
            let arr = str.split(',');
            for (let j = 0; j < arr.length; j++) {
                if (!isNaN(arr[j]) || arr[j].indexOf(this.stringModifier) != -1) {

                } else if (!/^[A-z]\w*$/.test(arr[j])) {
                    // this.param = matches[i].replace('(','');
                    // break;
                }
            }
            if (this.param) break;
        }
        if (outputs.length) {
            this.result.outputs = outputs;
        }
        if (this.param) {
            this.index = this.formula.indexOf(this.param);
            return true;
        } else {
            return false;
        }
    }
    //13.验证变量合法性
    isInValidVariable() {
        let syregstr = this.changeSymbolToRegStr(this.symbols.filter(x => { return x != '.' }));
        let funregstr = this.changeFuncToRegStr(this.funcs);

        let formula = this.changeStrToChar(this.formula, this.buildRegExp(`(${funregstr})\\(`, 'g'), ' ');
        let nums = formula.match(/^(-?\d+(\.\d+)?)|((\(|,)\s*-?\d+(\.\d+)?)|(\d+(\.\d+)?)/g) || [];
        nums = nums.map(x => { return x.replace(/^\s+|\s+$/g, '').replace(/\(|,/g, '') });
        formula = this.changeStrToChar(formula, this.buildRegExp(`${syregstr}`, 'g'), ' ');

        let variables = formula.split(/\s+/g).filter(x => { return !!x });
        let vars = variables.filter(x => { return isNaN(x) });
        for (let i = 0; i < vars.length; i++) {
            let index = this.funcs.findIndex(x => { return x == vars[i] });
            if (index != -1 || !/^[A-z]\w*$/.test(vars[i])) {
                this.var = vars[i];
                this.index = this.formula.indexOf(vars[i]);
                return true;
            }
        }
        // this.result.strs = strs.map(x=>{return x.replace(/'/g,'')});
        this.result.nums = nums.filter(x => { return !isNaN(x) }).map(x => { return 1 * x });
        this.result.codes = vars;
        return false;
    }
    //设置结果
    resultEngine(status = 0, msg = '', codes = [], nums = [], funcs = [], strs = [], outputs = []) {
        this.result.codes = [... new Set(codes)].sort();
        this.result.message = msg;
        this.result.status = status;
        this.result.nums = [... new Set(nums)].sort();
        this.result.strs = [... new Set(strs)].sort();
        this.result.functions = [... new Set(funcs)].sort();
        this.result.formula = this.formula0;
        this.result.outputs = [... new Set(outputs)].sort();
        console.log(this.result);
    }
    //日志
    log(msg) {
        console.log(msg);
    }
    //构建在正则表达式
    buildRegExp(str, meta) {
        return new RegExp(str, meta);
    }
    //符号变为reg string
    changeSymbolToRegStr(arr) {
        return arr.map(x => {
            let t = x.split('');
            return t.map(y => {
                return `\\${y}`
            }).join('')
        }).join('|');
    }
    //函数变为reg string
    changeFuncToRegStr(arr) {
        return arr.map(x => {
            return x;
        }).join('|');
    }
    //把字符串转换为对应长度的符号串
    changeStrToChar(str, reg, char) {
        return str.replace(reg, x => {
            return x.split('').map(x => {
                return char
            }).join('')
        })
    }
}


let formula = new Formula();
export default formula;