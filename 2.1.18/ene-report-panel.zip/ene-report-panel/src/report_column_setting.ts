import i18n from 'app/features/i18n';

export class ReportColumnSettingCtrl {
  panel: any;
  dashboard: any;
  panelCtrl: any;
  dateFormats: any;
  columnTypes: any;

  /** @ngInject */
  constructor($scope) {
    $scope.editor = this;
    this.panelCtrl = $scope.ctrl;
    this.panel = this.panelCtrl.panel;
    this.dashboard = this.panelCtrl.dashboard;

    this.dateFormats = [
      {text: 'YYYY-MM-DD HH:mm:ss', value: 'YYYY-MM-DD HH:mm:ss'},
      {text: 'YYYY-MM-DD', value: 'YYYY-MM-DD'},
      {text: 'YYYY-MM', value: 'YYYY-MM'},
    ];
    this.columnTypes = [
      {text: 'Number', value: 'number'},
      {text: 'String', value: 'string'},
      {text: 'Date', value: 'date'},
      {text: 'Array', value: 'array'},
      {text: 'Operation', value: 'operation'},
      {text: 'Hidden', value: 'hidden'},
      {text: 'Transparent', value: 'transparent'},
    ];
  }
}
/** @ngInject */
export function reportColumnSetting($q, uiSegmentSrv) {
  'use strict';
  return {
    restrict: 'E',
    scope: true,
    templateUrl: 'public/plugins/ene-report-panel/partials/report_column_setting.html',
    controller: ReportColumnSettingCtrl,
  };
}
