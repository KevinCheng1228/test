# Changelog
All notable changes to this project will be document in this file.
advantech-dash-video-panel

## [1.0.5] - Jul 19, 2021
### Fix
- fix the problem that the language has not changed
## [1.0.4] - Aug 12, 2020
### Fix
- Defect #21172: When switch changed, login Successfully and the role is Admin but the user got Permission Denied message.

## [1.0.3] - Jan 02, 2020
### New Feature
- add descriptor list
### Fix
- code refactoring

## [1.0.2] - Dec 25, 2019
### New Feature
- add frame blinking and use state color as frame color
- improve editor layout
- validate user when click button for change state
### Fix
- pop save change that cause of panel Default data change

## [1.0.1] - Oct 17, 2019
### Fix
- show N/A when no query data or no select switch data
- fix multiple panels will affect each other
- remove extra throw error

## [1.0.0] - Sep 4, 2019
### New Feature
- Add columns for inputing value and color & title of each button 
- Add columns for chosing datasource for both switches
- Add columns for outer frame setting
- Add columns for general setting