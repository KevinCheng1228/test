import { ControllerSwitch } from './switch_ctrl';
import { loadPluginCss } from 'app/plugins/sdk';

loadPluginCss({
  light: 'plugins/ene-controller-switch-panel/css/light.css',
  dark: 'plugins/ene-controller-switch-panel/css/dark.css'
});

export { ControllerSwitch as PanelCtrl };
