import { MetricsPanelCtrl } from 'app/plugins/sdk';
import _ from 'lodash';
import kbn from 'app/core/utils/kbn';
import rendering from './rendering';
// import ChangeFont from './fontsize' // for test and debug
import ChangeFont from 'app/core/utils/fontsize'; // for demo
import appEvents from 'app/core/app_events'; // for demo
import * as commonFunction from './commonFunction';

export class ControllerSwitch extends MetricsPanelCtrl {
  constructor($scope, $injector, $rootScope) {
    super($scope, $injector);
    this.$timeout = this.$injector.get('$timeout');
    this.$rootScope = $rootScope;
    this.dictFontCalc = {};
    this.resultData = [];
    this.ctrlId = Date.now();
    this.ifDataEmpty = true;
    this.leftFrameColor = ''
    this.rightFrameColor = ''
    this.leftFrameBlinking = false
    this.rightFrameBlinking = false
    this.leftSwitchData = 0
    this.rightSwitchData = 0
    this.btnTitleLL = ''
    this.btnTitleLR = ''
    this.btnTitleRL = ''
    this.btnTitleRR = ''
    this.leftDescriptor = []
    this.rightDescriptor = []
    this.targetDiscreteDict = {}
    this.LLText = ''
    this.LRText = ''
    this.RLText = ''
    this.RRText = ''
    this.lang = commonFunction.getLangType(this.dashboard.meta.language) || 'en' //Default  

    try {
      this.ifLocal = widnow.location.hostname === 'localhost';
    } catch (e) {
      console.error(e)
    }

    if (!$rootScope.MplusSwitchPanelIdArray) {
      $rootScope.MplusSwitchPanelIdArray = [];
    }
    while ($rootScope.MplusSwitchPanelIdArray.indexOf(this.ctrlId) !== -1) {
      this.ctrlId = Date.now();
    }
    $rootScope.MplusSwitchPanelIdArray.push(this.ctrlId);
    $rootScope.$on('$routeChangeSuccess', function () {
      $rootScope.MplusSwitchPanelIdArray = [];
    });

    var panelDefaults = {
      fontSizeout: '80%',
      fontSizeBtn: '80%',
      cssFontSizeBtn: {
        text: '80%',
        value: '80%',
        vw: '1vw',
        px: '19px',
      },
      cssFontSizeout: {
        text: '80%',
        value: '80%',
        vw: '1vw',
        px: '19px',
      },
      isBtnTextBold: false,
      isTextBoldout: false,
      leftSwitch: {
        target: null,
        data: "0",
        isUseSourceDescriptor: false,
        leftState: {
          turnOn: false,
          value: null,
          enTitle: "AUTO",
          zh_twTitle: "自動",
          zh_cnTitle: "自动",
          color: "#f5a623",
          isUseStateColor: false,
          isFrameBlinking: false,
          descriptor: null
        },
        rightState: {
          turnOn: false,
          value: null,
          enTitle: "MANUAL",
          zh_twTitle: "手動",
          zh_cnTitle: "手动",
          color: "#008cd6",
          isUseStateColor: false,
          isFrameBlinking: false,
          descriptor: null
        }
      },
      rightSwitch: {
        target: null,
        data: "0",
        isUseSourceDescriptor: false,
        leftState: {
          turnOn: false,
          value: null,
          enTitle: "STOP",
          zh_twTitle: "停機",
          zh_cnTitle: "停机",
          color: "#ff1330",
          isUseStateColor: false,
          isFrameBlinking: false,
          descriptor: null
        },
        rightState: {
          turnOn: false,
          value: null,
          enTitle: "START",
          zh_twTitle: "啟動",
          zh_cnTitle: "启动",
          color: "#64bb01",
          isUseStateColor: false,
          isFrameBlinking: false,
          descriptor: null
        }
      },
      coboldout: '',
      btnFontColor: '#ffffff',
      outColor: 'rgb(46, 204, 230)',
      outleftTitle: 'MODE',
      outrightTitle: 'STATUS'
    };

    // init font size setting
    this.fontCalc = ChangeFont.defaultValues;
    this.fontCalc.forEach((item, index) => {
      this.dictFontCalc[this.fontCalc[index].text] = this.fontCalc[index];
    })

    if (this.scope.$$listeners.isWisePaas || this.ifLocal) {
      _.defaults(this.panel, panelDefaults);
      this.events.on('data-received', this.onDataReceived.bind(this));
      this.events.on('init-edit-mode', this.onInitEditMode.bind(this));
    }

  }
  validateUser() {
    /* validate user */
    return new Promise((resolve, reject) => {
      let modalScope = this.$scope.$new(true);
      modalScope.onCancel = () => {
        console.log('onCancel');
        modalScope.dismiss();
        reject();
      };
      modalScope.onSubmit = () => {
        console.log(modalScope)
        modalScope.form.$setDirty();
        modalScope.form.$touched = false;
        let orgId = +new URLSearchParams(window.location.search).get('orgId')
        for (let formKey in modalScope.form) {
          if (formKey.indexOf('$') == -1) {
            modalScope.form[formKey].$setDirty();
            modalScope.form[formKey].$touched = false;
          }
        }
        if (modalScope.form.$valid) {
          // /* local dev use */
          // if (this.ifLocal) {
          //   const res ={"Cookie":[],"token":{"tokenType":"Bearer","accessToken":"eyJhbGciOiJIUzUxMiJ9.eyJpc3MiOiJ3aXNlcGFhc2NuIiwiaWF0IjoxNTc3MTc2MDIwLCJleHAiOjE1NzcxNzk2MjAsInVzZXJJZCI6ImVmZmZhOWM3LTMzNWUtNDQ1MS1iOTkyLWJkODZkNDUwMjBlYiIsInVhYUlkIjoiZGFiMTQyYzgtYWFjNS00ZTYwLWExODQtNzIxMDg1MDQ1OTdiIiwiY3JlYXRpb25UaW1lIjoxNTU1NDkyNTgyMDAwLCJsYXN0TW9kaWZpZWRUaW1lIjoxNTc1OTQxOTQ4MDAwLCJ1c2VybmFtZSI6InRpbmd3ZWkubGluQGFkdmFudGVjaC5jb20udHciLCJmaXJzdE5hbWUiOiJUaW5nV2VpIiwibGFzdE5hbWUiOiJMaW4iLCJjb3VudHJ5IjoiVFciLCJyb2xlIjoidGVuYW50IiwiZ3JvdXBzIjpbIjQyYzBhMDU5LWU5ZmItNDViOC05NTkyLTA2Y2E4OWVjMDg4YSIsInRpbmd3ZWkubGluQGFkdmFudGVjaC5jb20udHciXSwiY2ZTY29wZXMiOlt7Imd1aWQiOiI0MmMwYTA1OS1lOWZiLTQ1YjgtOTU5Mi0wNmNhODllYzA4OGEiLCJzc29fcm9sZSI6InRlbmFudCIsInNwYWNlcyI6WyIqIl19XSwic2NvcGVzIjpbImRhc2hib2FyZC0xNTU5MDQyMTU0MDgzLkFkbWluIl0sInN0YXR1cyI6ImFjdGl2ZSIsIm9yaWdpbiI6IlNTTyIsIm92ZXJQYWRkaW5nIjpmYWxzZSwic3lzdGVtIjpmYWxzZSwicmVmcmVzaFRva2VuIjoiN2MwN2VkMzAtZmE4YS00MTJlLTk1OGMtMGJhZjJjNWQ2YTMwIn0.Lmuq5ykw8KfaJIjbPyDzxR0RP4IGlCQrDAh_I3B5LQ8thHt301itJTPjOqKvUFhCAx3bOlb_S-nkZjzp_Rx4BA","expiresIn":1577179620,"refreshToken":"7c07ed30-fa8a-412e-958c-0baf2c5d6a30","error":"","message":""},"userRole":[{"orgId":5,"name":"A-Good-Company1","role":"Admin"},{"orgId":97,"name":"Has Space7","role":"Admin"},{"orgId":94,"name":" J J\\","role":"Admin"},{"orgId":1,"name":"Main Org.","role":"Viewer"},{"orgId":223,"name":"newOrg_for_Alisa1","role":"Viewer"},{"orgId":33,"name":"Secret-Agency1","role":"Admin"},{"orgId":193,"name":"SummerIntern4","role":"Admin"},{"orgId":73,"name":"Test7","role":"Admin"},{"orgId":214,"name":"TestNotificationGroupError7","role":"Admin"},{"orgId":78,"name":"tingwei27","role":"Admin"},{"orgId":371,"name":"Water Treatment System1","role":"Admin"}]};
          //   console.log(res.userRole.some(v=>v.orgId === orgId && v.role === 'Admin'))
          //   const ifValid = Array.isArray(res.userRole) && res.userRole.some(v=>v.orgId === orgId && v.role === 'Admin')
          //   console.log(ifValid)

          //   if(ifValid){
          //     modalScope.onCancel();
          //     resolve(ifValid)
          //   }else{
          //     const e={}
          //     appEvents.emit("alert-warning", ["Permission Denied"])
          //     reject()
          //   }
          //   return 
          // }
          let url = '/userLogin'
          let data = angular.copy(modalScope.formData);

          data.password = window.btoa(modalScope.formData.password)
          console.log(data)
          $.post(url, data, res => {
            console.log(res)
            try {
              const ifValid = Array.isArray(res.userRole) && res.userRole.some(v => v.orgId === orgId && v.role === 'Admin')
              if (ifValid) {
                modalScope.dismiss()
                resolve()
              } else {
                appEvents.emit("alert-warning", ["Permission Denied"])
              }
            } catch (e) {
              console.error(e)
              appEvents.emit("alert-warning", ["Permission Denied"])
            }
          }).fail(err => {
            console.error(err)
            try {
              appEvents.emit("alert-warning", [err.responseJSON.message])
            } catch (e) {
              appEvents.emit("alert-warning", ["User Invalid"])
            }
          })
        }
      }
      modalScope.formData = {
        user: '',
        password: '',
        type: "standard"
      }
      appEvents.emit('show-modal', {
        src: 'public/plugins/' + this.pluginId + '/partials/modal-validate-user.html',
        modalClass: 'modal-validate',
        scope: modalScope,
      });
    })
  }
  onInitEditMode() {
    this.addEditorTab('Display', 'public/plugins/' + this.pluginId + '/partials/editor.html', 2);
    this.unitFormats = kbn.getUnitFormats();
  }
  onDataReceived(dataList) {
    if (!_.isEmpty(dataList) && dataList.length) {
      this.lang = commonFunction.getLangType(this.dashboard.meta.language || dataList[0].langType) || 'en';
    }

    this.leftDescriptor = []
    this.rightDescriptor = []
    // dataList = [{ "target": "DO2", "unit": "", "spanhi": "10.00000000", "spanlo": "0.00000000", "desc": "Analog Output", "devid": 443, "tagname": "DO2", "datapoints": [[Math.floor(Math.random() * 2), 1577090231233]], "discrete": [[0, "Manual"], [1, "Auto"]], "time": "23ms" }, { "target": "DO3", "unit": "", "spanhi": "10.00000000", "spanlo": "0.00000000", "desc": "Analog Output", "devid": 443, "tagname": "DO3", "datapoints": [[Math.floor(Math.random() * 2), 1577090231233]], "discrete": [[0, "OFF"], [1, "ON"]] }]
    if (_.isEmpty(dataList) || (_.isNil(this.panel.leftSwitch.target) && _.isNil(this.panel.rightSwitch.target))) {
      this.ifDataEmpty = true;
    } else {
      this.ifDataEmpty = false;
    }
    this.resultData = dataList;
    // 找尋選取綁定的 data
    this.resultData.forEach(element => {
      if (element.target == this.panel.leftSwitch.target) { this.leftSwitchData = element.datapoints[0][0] }
      if (element.target == this.panel.rightSwitch.target) { this.rightSwitchData = element.datapoints[0][0] }
      if (element.discrete && element.discrete.length > 0) { this.targetDiscreteDict[element.target] = element.discrete }
    })
    this.makeDescriptorList()
    this.draw();
    this.fontsizeChange();
  }
  //fontsize
  fontsizeChange() {
    this.panel.cssFontSizeBtn = _.find(this.fontCalc, (o) => { return o.text == this.panel.fontSizeBtn });
    this.panel.cssFontSizeout = _.find(this.fontCalc, (o) => { return o.text == this.panel.fontSizeout });
  }

  link(scope, elem, attrs, ctrl) {
    rendering(scope, elem, attrs, ctrl);
  }

  makeDescriptorList() {
    if (this.targetDiscreteDict[this.panel.leftSwitch.target]) {
      this.targetDiscreteDict[this.panel.leftSwitch.target].forEach((item) => {
        let option = {}
        option['id'] = item[0].toString()
        option['text'] = item[1].toString()
        this.leftDescriptor.push(option)
      })
    }
    if (this.targetDiscreteDict[this.panel.rightSwitch.target]) {
      this.targetDiscreteDict[this.panel.rightSwitch.target].forEach((item) => {
        let option = {}
        option['id'] = item[0].toString()
        option['text'] = item[1].toString()
        this.rightDescriptor.push(option)
      })
    }
    this.draw()
  }

  draw() {
    // 左邊或右邊已有一個選 Data
    if (!_.isNil(this.panel.leftSwitch.target) || !_.isNil(this.panel.rightSwitch.target)) {
      this.ifDataEmpty = false;
    }

    // switch button container
    let elem1 = null;
    let elem2 = null;
    let elem3 = null;
    let elem4 = null;

    // switch button element binding
    // angular.element(document).ready(() => {
    elem1 = $(document).find('.leftBtn1_' + this.ctrlId);
    elem2 = $(document).find('.leftBtn2_' + this.ctrlId);
    elem3 = $(document).find('.rightBtn1_' + this.ctrlId);
    elem4 = $(document).find('.rightBtn2_' + this.ctrlId);
    // });

    // init color, blinking state
    this.leftFrameColor = ''
    this.rightFrameColor = ''
    this.leftFrameBlinking = false
    this.rightFrameBlinking = false

    //font bold
    let isBtnTextBold = this.panel.isBtnTextBold;
    let isTextBoldout = this.panel.isTextBoldout;
    this.panel.cobold = isBtnTextBold ? 'bold' : 'normal';
    this.panel.coboldout = isTextBoldout ? 'bold' : 'normal';

    let leftIndex;
    let rightIndex;
    for (let i = 0; i < this.resultData.length; i++) {
      if (this.resultData[i].target == this.panel.leftSwitch.target) { leftIndex = i; }
      if (this.resultData[i].target == this.panel.rightSwitch.target) { rightIndex = i; }
    }

    this.LLText = this.panel.leftSwitch.leftState.descriptor !== null ? (this.leftDescriptor.find(elem => { return elem.id == this.panel.leftSwitch.leftState.descriptor }).text) : ''
    this.LRText = this.panel.leftSwitch.rightState.descriptor !== null ? (this.leftDescriptor.find(elem => { return elem.id == this.panel.leftSwitch.rightState.descriptor }).text) : ''
    this.RLText = this.panel.rightSwitch.leftState.descriptor !== null ? (this.rightDescriptor.find(elem => { return elem.id == this.panel.rightSwitch.leftState.descriptor }).text) : ''
    this.RRText = this.panel.rightSwitch.rightState.descriptor !== null ? (this.rightDescriptor.find(elem => { return elem.id == this.panel.rightSwitch.rightState.descriptor }).text) : ''

    // left isUseSourceDescriptor
    this.determineDescriptor(
      this.panel.leftSwitch.isUseSourceDescriptor,
      this.panel.leftSwitch.leftState,
      'btnTitleLL',
      elem1[0],
      'leftSwitchData',
      'LLText'
    )

    this.determineDescriptor(
      this.panel.leftSwitch.isUseSourceDescriptor,
      this.panel.leftSwitch.rightState,
      'btnTitleLR',
      elem2[0],
      'leftSwitchData',
      'LRText'
    )

    // right isUseSourceDescriptor
    this.determineDescriptor(
      this.panel.rightSwitch.isUseSourceDescriptor,
      this.panel.rightSwitch.leftState,
      'btnTitleRL',
      elem3[0],
      'rightSwitchData',
      'RLText'
    )

    this.determineDescriptor(
      this.panel.rightSwitch.isUseSourceDescriptor,
      this.panel.rightSwitch.rightState,
      'btnTitleRR',
      elem4[0],
      'rightSwitchData',
      'RRText'
    )

    // draw color
    this.determineStateColor(this.panel.leftSwitch.leftState, 'leftSwitchData', 'leftFrameColor', elem1[0])
    this.determineStateColor(this.panel.leftSwitch.rightState, 'leftSwitchData', 'leftFrameColor', elem2[0])
    this.determineStateColor(this.panel.rightSwitch.leftState, 'rightSwitchData', 'rightFrameColor', elem3[0])
    this.determineStateColor(this.panel.rightSwitch.rightState, 'rightSwitchData', 'rightFrameColor', elem4[0])

    // rewatch
    this.$timeout(() => {

      let rightSwitch = this.panel.rightSwitch
      let leftSwitch = this.panel.leftSwitch

      // rightSwitch Frame Blinking
      if (rightSwitch.leftState.value !== null && rightSwitch.leftState.isFrameBlinking && this.rightSwitchData.toString() === rightSwitch.leftState.value.toString()) {
        this.rightFrameBlinking = true
      } else if (rightSwitch.rightState.value !== null && rightSwitch.rightState.isFrameBlinking && this.rightSwitchData.toString() === rightSwitch.rightState.value.toString()) {
        this.rightFrameBlinking = true
      } else {
        this.rightFrameBlinking = false
      }

      // leftSwitch Frame Blinking
      if (leftSwitch.leftState.value !== null && leftSwitch.leftState.isFrameBlinking && this.leftSwitchData.toString() === leftSwitch.leftState.value.toString()) {
        this.leftFrameBlinking = true
      } else if (leftSwitch.rightState.value !== null && leftSwitch.rightState.isFrameBlinking && this.leftSwitchData.toString() === leftSwitch.rightState.value.toString()) {
        this.leftFrameBlinking = true
      } else {
        this.leftFrameBlinking = false
      }
    }, 0)

    // click event
    elem1.unbind('click').bind('click', () => {
      this.validateUser().then(res => {
        if (this.panel.leftSwitch.leftState.value && this.panel.leftSwitch.rightState.value) {
          this.datasource.metricFindQuery_setvalue(this.panel.targets[leftIndex], Number(this.panel.leftSwitch.leftState.value))
            .then(response => {
              console.log('response1:', response.data[0]);
              if (response.data[0].code === 200001) {
                elem1[0].attributes.fill.nodeValue = this.panel.leftSwitch.leftState.color;
                elem2[0].attributes.fill.nodeValue = '#000000';
                if (this.panel.targets[leftIndex] === this.panel.targets[rightIndex]) {
                  elem3[0].attributes.fill.nodeValue = '#000000';
                  elem4[0].attributes.fill.nodeValue = '#000000';
                }
                this.leftSwitchData = this.panel.leftSwitch.leftState.value
                this.draw()
              } else {
                try{
                  appEvents.emit("alert-warning", [response.data[0].message]);
                }catch(e){
                  appEvents.emit("alert-warning", ["Updating Failed"]);
                }
                console.log("error");
              }
            })
            .catch(error => {
              console.log(error);
              appEvents.emit("alert-warning", ["Updating Failed"]);
            })
          console.log('targets', this.panel.targets);
        }
      }, err => { })
    });
    elem2.unbind('click').bind('click', () => {
      this.validateUser().then(res => {
        if (this.panel.leftSwitch.leftState.value && this.panel.leftSwitch.rightState.value) {
          this.datasource.metricFindQuery_setvalue(this.panel.targets[leftIndex], Number(this.panel.leftSwitch.rightState.value))
            .then(response => {
              console.log('response2:', response);
              if (response.data[0].code === 200001) {
                elem1[0].attributes.fill.nodeValue = '#000000';
                elem2[0].attributes.fill.nodeValue = this.panel.leftSwitch.rightState.color;
                if (this.panel.targets[leftIndex] === this.panel.targets[rightIndex]) {
                  elem3[0].attributes.fill.nodeValue = '#000000';
                  elem4[0].attributes.fill.nodeValue = '#000000';
                }
                this.leftSwitchData = this.panel.leftSwitch.rightState.value
                this.draw()
              } else {
                try{
                  appEvents.emit("alert-warning", [response.data[0].message]);
                }catch(e){
                  appEvents.emit("alert-warning", ["Updating Failed"]);
                }
                console.log("error");
              }
            })
            .catch(error => {
              console.log(error);
              appEvents.emit("alert-warning", ["Updating Failed"]);
            })
        }
      }, err => { })
    });
    elem3.unbind('click').bind('click', () => {
      this.validateUser().then(res => {
        if (this.panel.rightSwitch.leftState.value && this.panel.rightSwitch.rightState.value) {
          this.datasource.metricFindQuery_setvalue(this.panel.targets[rightIndex], Number(this.panel.rightSwitch.leftState.value))
            .then(response => {
              console.log('response3:', response);
              if (response.data[0].code === 200001) {
                elem3[0].attributes.fill.nodeValue = this.panel.rightSwitch.leftState.color;
                elem4[0].attributes.fill.nodeValue = '#000000';
                if (this.panel.targets[leftIndex] === this.panel.targets[rightIndex]) {
                  elem1[0].attributes.fill.nodeValue = '#000000';
                  elem2[0].attributes.fill.nodeValue = '#000000';
                }
                this.rightSwitchData = this.panel.rightSwitch.leftState.value
                this.draw()
              } else {
                try{
                  appEvents.emit("alert-warning", [response.data[0].message]);
                }catch(e){
                  appEvents.emit("alert-warning", ["Updating Failed"]);
                }
                console.log("error");
              }
            })
            .catch(error => {
              console.log(error);
              appEvents.emit("alert-warning", ["Updating Failed"]);
            })
        }
      }, err => { })
    });
    elem4.unbind('click').bind('click', () => {
      this.validateUser().then(res => {
        if (this.panel.rightSwitch.leftState.value && this.panel.rightSwitch.rightState.value) {
          this.datasource.metricFindQuery_setvalue(this.panel.targets[rightIndex], Number(this.panel.rightSwitch.rightState.value))
            .then(response => {
              console.log('response4:', response);
              if (response.data[0].code === 200001) {
                elem3[0].attributes.fill.nodeValue = '#000000';
                elem4[0].attributes.fill.nodeValue = this.panel.rightSwitch.rightState.color;
                if (this.panel.targets[leftIndex] === this.panel.targets[rightIndex]) {
                  elem1[0].attributes.fill.nodeValue = '#000000';
                  elem2[0].attributes.fill.nodeValue = '#000000';
                }
                this.rightSwitchData = this.panel.rightSwitch.rightState.value
                this.draw()
              } else {
                try{
                  appEvents.emit("alert-warning", [response.data[0].message]);
                }catch(e){
                  appEvents.emit("alert-warning", ["Updating Failed"]);
                }
                console.log("error");
              }
            })
            .catch(error => {
              console.log(error);
              appEvents.emit("alert-warning", ["Updating Failed"]);
            })
        }
      }, err => { })
    });
  }

  determineDescriptor(isUseDescriptor, switchState, btnTitle, btnElem, DataKey, text) {
    if (isUseDescriptor) {
      if (switchState.descriptor !== null) {
        switchState.value = switchState.descriptor
        this[btnTitle] = this[text]
        console.log('switchState', switchState)
        console.log('this[DataKey]', this[DataKey])
        console.log('this[text]', this[text])
        if (switchState.value !== this[DataKey]) {
          btnElem.attributes.fill.nodeValue = '#000000'
        }
      } else {
        this[btnTitle] = null
        btnElem.attributes.fill.nodeValue = '#000000'
      }
    } else {
      if (switchState.value !== null) {
        switch (this.lang) {
          case 'en':
            this[btnTitle] = switchState.enTitle
            break;
          case 'zh_tw':
            this[btnTitle] = switchState.zh_twTitle
            break;
          case 'zh_cn':
            this[btnTitle] = switchState.zh_cnTitle
            break;
          case 'ja':
            this[btnTitle] = switchState.enTitle
            break;
          case 'default':
            this[btnTitle] = switchState.enTitle
        }
      }
    }
  }

  determineStateColor(state, dataKey, frameColorKey, element) {
    if (state.value !== null && this[dataKey].toString() === state.value.toString()) {
      if (state.isUseStateColor) {
        this[frameColorKey] = state.color
      } else {
        this[frameColorKey] = this.panel.outColor
      }
      element.attributes.fill.nodeValue = this[frameColorKey]
    } else {
      element.attributes.fill.nodeValue = '#000000'
    }
  }
}

ControllerSwitch.templateUrl = 'partials/module.html';
