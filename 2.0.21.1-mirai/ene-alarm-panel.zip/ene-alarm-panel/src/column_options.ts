///<reference path="../node_modules/grafana-sdk-mocks/app/headers/common.d.ts" />

import _ from 'lodash';
import kbn from 'app/core/utils/kbn';
import { getMultiLang } from './multilang';

export class ColumnOptionsCtrl {
    panel: any;
    panelCtrl: any;
    colorModes: any;
    columnStyles: any;
    columnTypes: any;
    dateFormats: any;
    addColumnSegment: any;
    unitFormats: any;
    getColumnNames: any;
    activeStyleIndex: number;
    mappingTypes: any;
    columnAligns: any;
    buttonHandlers: any;
    iconlist: any;
    hrefTargetList: any;
    statusList: any;

    /** @ngInject */
    constructor($scope) {
        $scope.editor = this;

        this.activeStyleIndex = 0;
        this.panelCtrl = $scope.ctrl;
        this.panel = this.panelCtrl.panel;
        this.unitFormats = kbn.getUnitFormats();
        this.colorModes = [
            { text: 'Disabled', value: null },
            { text: 'Cell', value: 'cell' },
            { text: 'Value', value: 'value' },
            { text: 'Row', value: 'row' },
            { text: 'Status', value: 'status' },
        ];
        this.columnTypes = [
            { text: 'Number', value: 'number' },
            { text: 'String', value: 'string' },
            { text: 'Date', value: 'date' },
            { text: 'Array', value: 'array' },
            { text: 'Button', value: 'button' },
            { text: 'Operation', value: 'operation' },
            { text: 'Hidden', value: 'hidden' },
        ];
        this.dateFormats = [
            { text: 'YYYY-MM-DD HH:mm:ss', value: 'YYYY-MM-DD HH:mm:ss' },
            { text: 'YYYY-MM-DD HH:mm:ss.SSS', value: 'YYYY-MM-DD HH:mm:ss.SSS' },
            { text: 'MM/DD/YY h:mm:ss a', value: 'MM/DD/YY h:mm:ss a' },
            { text: 'MMMM D, YYYY LT', value: 'MMMM D, YYYY LT' },
            { text: 'YYYY-MM-DD', value: 'YYYY-MM-DD' },
        ];
        this.mappingTypes = [
            { text: 'Value to text', value: 1 },
            { text: 'Range to text', value: 2 },
        ];
        this.columnAligns = [
            { text: 'Left', value: 'left' },
            { text: 'Center', value: 'center' },
            { text: 'Right', value: 'right' },
        ];

        this.buttonHandlers = [].concat(this.panel.checkboxHandlers);
        this.iconlist = [
            { text: 'Edit', value: 'edit' },
            { text: 'Tracking', value: 'tracking' },
            { text: 'Suggestion', value: 'suggestion' },
            { text: 'SOE', value: 'soe' }
        ];

        this.hrefTargetList = [
            { text: 'Blank', value: '_blank' },
            { text: 'Self', value: '_self' }
        ]

        this.statusList = this.panel.statusNumList.filter(x => { return x.value > -1 });

        this.getColumnNames = () => {
            if (!this.panelCtrl.table) {
                return [];
            }
            return _.map(this.panelCtrl.table.columns, (col: any) => {
                if (col.addStatusLampCol) {
                    return '';
                }
                return col.text;
            });
        };

        this.onColorChange = this.onColorChange.bind(this);

        if (this.panel.targets[0].dataType != 'realtime') {
            let index = this.buttonHandlers.findIndex(x => { return x.value == 'Ack' });
            this.buttonHandlers.splice(index, 1);
            this.panel.styles.forEach(x => {
                x.operationList && x.operationList.forEach(y => {
                    y.handler = 'Detail';
                    y.type = 'tracking';
                });
            })
        }
    }
    getMultiLang(key) {
        return getMultiLang(key, this.panel.langType);
    }
    changeType(style) {
        if (['number', 'string', 'button'].indexOf(style.type) != -1 && !style.thresholds.length && !style.thresholdsDisplay.length) {
            style.thresholds = this.statusList.map(x => { return x.value });
            style.thresholdsDisplay = this.statusList.map(x => { return x.text[this.panel.langType || 'en'] });
            style.colors = this.statusList.map(x => { return x.color });
            style.next = [].concat(this.statusList);
        }

        this.render();
    }

    render() {
        this.panelCtrl.render();
    }

    setUnitFormat(column, subItem) {
        column.unit = subItem.value;
        this.panelCtrl.render();
    }

    addColumnStyle() {
        const newStyleRule = {
            unit: 'short',
            type: 'number',
            alias: '',
            decimals: 2,
            colors: [
                'rgba(245, 54, 54, 0.9)',
                'rgba(237, 129, 40, 0.89)',
                'rgba(50, 172, 45, 0.97)',
                'rgba(45, 91, 172, 0.9)',
                'rgba(247, 243, 27, 0.9)',
                'rgba(184, 27, 247, 0.9)',
            ],
            colorMode: null,
            pattern: '',
            dateFormat: 'YYYY-MM-DD HH:mm:ss',
            thresholds: [],
            mappingType: 1,
            align: 'left',
            thresholdsDisplay: [],
            arraycolors: ['rgb(23, 180, 16)', 'rgb(255, 197, 0)', 'rgb(210, 30, 0)'],
            bar: false,
            url: false,
            icon: false,
            handler: 'Ack',
            icontype: 'tracking',
            hrefTarget: '_self',
            operNum: 1,
            operationList: [
                {
                    type: 'edit',
                    handler: 'Ack'
                }
            ]
        };

        const styles = this.panel.styles;
        const stylesCount = styles.length;
        let indexToInsert = stylesCount;

        // check if last is a catch all rule, then add it before that one
        if (stylesCount > 0) {
            const last = styles[stylesCount - 1];
            if (last.pattern === '/.*/') {
                indexToInsert = stylesCount - 1;
            }
        }

        styles.splice(indexToInsert, 0, newStyleRule);
        this.activeStyleIndex = indexToInsert;
    }

    removeColumnStyle(style) {
        this.panel.styles = _.without(this.panel.styles, style);
        this.activeStyleIndex = this.panel.styles.length - 1;
        this.panelCtrl.render();
    }

    invertColorOrder(index) {
        const ref = this.panel.styles[index].colors;
        const copy1 = ref[0];
        const copy2 = ref[1];
        const copy3 = ref[2];
        ref[0] = ref[5];
        ref[1] = ref[4];
        ref[2] = ref[3];
        ref[3] = copy3;
        ref[4] = copy2;
        ref[5] = copy1;
        this.panelCtrl.render();
    }

    onColorChange(styleIndex, colorIndex) {
        return newColor => {
            this.panel.styles[styleIndex].colors[colorIndex] = newColor;
            this.panelCtrl.statusList[colorIndex].color = newColor;
            let index = this.panel.statusNumList.findIndex(x => { return x.value == this.panelCtrl.statusList[colorIndex].value });
            index !== -1 && (this.panel.statusNumList[index].color = newColor);
            this.render();
        };
    }

    addValueMap(style) {
        if (!style.valueMaps) {
            style.valueMaps = [];
        }
        style.valueMaps.push({ value: '', text: '' });
        this.panelCtrl.render();
    }

    removeValueMap(style, index) {
        style.valueMaps.splice(index, 1);
        this.panelCtrl.render();
    }

    addRangeMap(style) {
        if (!style.rangeMaps) {
            style.rangeMaps = [];
        }
        style.rangeMaps.push({ from: '', to: '', text: '' });
        this.panelCtrl.render();
    }

    removeRangeMap(style, index) {
        style.rangeMaps.splice(index, 1);
        this.panelCtrl.render();
    }

    resetColumnColor(style) {
        delete style.colbgColor;
        delete style.colFontColorSet;
        this.panelCtrl.render();
    }

    linkChecked(style) {
        if (style.link) {
            style.url = false;
        }
        this.render();
    }

    asUrlChecked(style) {
        if (style.url) {
            style.link = false;
        }
        this.render();
    }

    operationChangeNum(style) {
        if (style.operNum == undefined) {
            style.operNum = 1;
            style.operationList = [{
                type: 'tracking',
                handler: 'Detail'
            }];
        }
        let temp = {
            type: 'tracking',
            handler: 'Detail'
        }

        if (style.operNum < 0) style.operNum = 0;
        if (style.operNum > 3) style.operNum = 3;
        if (style.operNum > style.operationList.length) {
            let len = style.operationList.length;
            for (let i = len; i < style.operNum; i++) {
                style.operationList.push(Object.assign({}, temp));
            }
        } else if (style.operNum < style.operationList.length) {
            let len = style.operationList.length - style.operNum;
            style.operationList.splice(style.operNum, len);
        }

        this.render();
    }
}

/** @ngInject */
export function columnOptionsTab($q, uiSegmentSrv) {
    'use strict';
    return {
        restrict: 'E',
        scope: true,
        templateUrl: 'public/plugins/ene-alarm-panel/partials/column_options.html',
        controller: ColumnOptionsCtrl,
    };
}
