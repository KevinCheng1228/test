/*
 * @Author: NH
 * @Date: 2021-05-31 09:23:40
 * @LastEditTime: 2021-05-31 13:32:49
 * @Description: global font family list
 */

const FontFamilyList: {} = {
    default: {
        name: '默认',
        list: [
            {
                zh_cn: '默认',
                en: 'default',
                ja: 'default',
                zh_tw: 'default'
            }
        ]
    },
    windows: {
        name: 'Windows', list: [
            {
                'zh_cn': '宋体',
                'en': 'SimSun',
                'ja': '宋体',
                'zh_tw': '宋体'
            },
            {
                'zh_cn': '黑体',
                'en': 'SimHei',
                'ja': '黑体',
                'zh_tw': '黑体'
            },
            {
                'zh_cn': '微软雅黑',
                'en': 'Microsoft Yahei',
                'ja': '微软雅黑',
                'zh_tw': '微软雅黑'
            },
            {
                'zh_cn': '微软正黑体',
                'en': 'Microsoft JhengHei',
                'ja': '微软正黑体',
                'zh_tw': '微软正黑体'
            },
            {
                'zh_cn': '楷体',
                'en': 'KaiTi',
                'ja': '楷体',
                'zh_tw': '楷体'
            },
            {
                'zh_cn': '新宋体',
                'en': 'NSimSun',
                'ja': '新宋体',
                'zh_tw': '新宋体'
            },
            {
                'zh_cn': '仿宋',
                'en': 'FangSong',
                'ja': '仿宋',
                'zh_tw': '仿宋'
            }]
    },
    IOS: {
        name: 'Mac OS', list: [
            {
                'zh_cn': '苹方',
                'en': 'PingFang SC',
                'ja': '苹方',
                'zh_tw': '苹方'
            },
            {
                'zh_cn': '华文黑体',
                'en': 'STHeiti',
                'ja': '华文黑体',
                'zh_tw': '华文黑体'
            },
            {
                'zh_cn': '华文楷体',
                'en': 'STKaiti',
                'ja': '华文楷体',
                'zh_tw': '华文楷体'
            },
            {
                'zh_cn': '华文宋体',
                'en': 'STSong',
                'ja': '华文宋体',
                'zh_tw': '华文宋体'
            },
            {
                'zh_cn': '华文仿宋',
                'en': 'STFangsong',
                'ja': '华文仿宋',
                'zh_tw': '华文仿宋'
            },
            {
                'zh_cn': '华文中宋',
                'en': 'STZhongsong',
                'ja': '华文中宋',
                'zh_tw': '华文中宋'
            },
            {
                'zh_cn': '华文琥珀',
                'en': 'STHupo',
                'ja': '华文琥珀',
                'zh_tw': '华文琥珀'
            },
            {
                'zh_cn': '华文新魏',
                'en': 'STXinwei',
                'ja': '华文新魏',
                'zh_tw': '华文新魏'
            },
            {
                'zh_cn': '华文隶书',
                'en': 'STLiti',
                'ja': '华文隶书',
                'zh_tw': '华文隶书'
            },
            {
                'zh_cn': '华文行楷',
                'en': 'STXingkai',
                'ja': '华文行楷',
                'zh_tw': '华文行楷'
            },
            {
                'zh_cn': '冬青黑体简',
                'en': 'Hiragino Sans GB',
                'ja': '冬青黑体简',
                'zh_tw': '冬青黑体简'
            },
            {
                'zh_cn': '兰亭黑-简',
                'en': 'Lantinghei SC',
                'ja': '兰亭黑-简',
                'zh_tw': '兰亭黑-简'
            },
            {
                'zh_cn': '翩翩体-简',
                'en': 'Hanzipen SC',
                'ja': '翩翩体-简',
                'zh_tw': '翩翩体-简'
            },
            {
                'zh_cn': '手札体-简',
                'en': 'Hannotate SC',
                'ja': '手札体-简',
                'zh_tw': '手札体-简'
            },
            {
                'zh_cn': '宋体-简',
                'en': 'Songti SC',
                'ja': '宋体-简',
                'zh_tw': '宋体-简'
            },
            {
                'zh_cn': '娃娃体-简',
                'en': 'Wawati SC',
                'ja': '娃娃体-简',
                'zh_tw': '娃娃体-简'
            },
            {
                'zh_cn': '魏碑-简',
                'en': 'Weibei SC',
                'ja': '魏碑-简',
                'zh_tw': '魏碑-简'
            },
            {
                'zh_cn': '行楷-简',
                'en': 'Xingkai SC',
                'ja': '行楷-简',
                'zh_tw': '行楷-简'
            },
            {
                'zh_cn': '雅痞-简',
                'en': 'Yapi SC',
                'ja': '雅痞-简',
                'zh_tw': '雅痞-简'
            },
            {
                'zh_cn': '圆体-简',
                'en': 'Yuanti SC',
                'ja': '圆体-简',
                'zh_tw': '圆体-简'
            }]
    },
    office: {
        name: 'Office', list: [
            {
                'zh_cn': '幼圆',
                'en': 'YouYuan',
                'ja': '幼圆',
                'zh_tw': '幼圆'
            },
            {
                'zh_cn': '隶书',
                'en': 'LiSu',
                'ja': '隶书',
                'zh_tw': '隶书'
            },
            {
                'zh_cn': '华文细黑',
                'en': 'STXihei',
                'ja': '华文细黑',
                'zh_tw': '华文细黑'
            },
            {
                'zh_cn': '华文楷体',
                'en': 'STKaiti',
                'ja': '华文楷体',
                'zh_tw': '华文楷体'
            },
            {
                'zh_cn': '华文宋体',
                'en': 'STSong',
                'ja': '华文宋体',
                'zh_tw': '华文宋体'
            },
            {
                'zh_cn': '华文仿宋',
                'en': 'STFangsong',
                'ja': '华文仿宋',
                'zh_tw': '华文仿宋'
            },
            {
                'zh_cn': '华文中宋',
                'en': 'STZhongsong',
                'ja': '华文中宋',
                'zh_tw': '华文中宋'
            },
            {
                'zh_cn': '华文彩云',
                'en': 'STCaiyun',
                'ja': '华文彩云',
                'zh_tw': '华文彩云'
            },
            {
                'zh_cn': '华文琥珀',
                'en': 'STHupo',
                'ja': '华文琥珀',
                'zh_tw': '华文琥珀'
            },
            {
                'zh_cn': '华文新魏',
                'en': 'STXinwei',
                'ja': '华文新魏',
                'zh_tw': '华文新魏'
            },
            {
                'zh_cn': '华文隶书',
                'en': 'STLiti',
                'ja': '华文隶书',
                'zh_tw': '华文隶书'
            },
            {
                'zh_cn': '华文行楷',
                'en': 'STXingkai',
                'ja': '华文行楷',
                'zh_tw': '华文行楷'
            },
            {
                'zh_cn': '方正舒体',
                'en': 'FZShuTi',
                'ja': '方正舒体',
                'zh_tw': '方正舒体'
            },
            {
                'zh_cn': '方正姚体',
                'en': 'FZYaoti',
                'ja': '方正姚体',
                'zh_tw': '方正姚体'
            }]
    },
    open: {
        name: '开源', list: [
            {
                'zh_cn': '思源黑体',
                'en': 'Source Han Sans CN',
                'ja': '思源黑体',
                'zh_tw': '思源黑体'
            },
            {
                'zh_cn': '思源宋体',
                'en': 'Source Han Serif SC',
                'ja': '思源宋体',
                'zh_tw': '思源宋体'
            },
            {
                'zh_cn': '文泉驿微米黑',
                'en': 'WenQuanYi Micro Hei',
                'ja': '文泉驿微米黑',
                'zh_tw': '文泉驿微米黑'
            }]
    },
    hanyi: {
        name: '版权字体（汉仪）', list: [
            {
                'zh_cn': '汉仪旗黑',
                'en': 'HYQihei 40S',
                'ja': '汉仪旗黑',
                'zh_tw': '汉仪旗黑'
            },
            {
                'zh_cn': '汉仪旗黑',
                'en': 'HYQihei 50S',
                'ja': '汉仪旗黑',
                'zh_tw': '汉仪旗黑'
            },
            {
                'zh_cn': '汉仪旗黑',
                'en': 'HYQihei 60S',
                'ja': '汉仪旗黑',
                'zh_tw': '汉仪旗黑'
            },
            {
                'zh_cn': '汉仪大宋简',
                'en': 'HYDaSongJ',
                'ja': '汉仪大宋简',
                'zh_tw': '汉仪大宋简'
            },
            {
                'zh_cn': '汉仪楷体',
                'en': 'HYKaiti',
                'ja': '汉仪楷体',
                'zh_tw': '汉仪楷体'
            },
            {
                'zh_cn': '汉仪家书简',
                'en': 'HYJiaShuJ',
                'ja': '汉仪家书简',
                'zh_tw': '汉仪家书简'
            },
            {
                'zh_cn': '汉仪PP体简',
                'en': 'HYPPTiJ',
                'ja': '汉仪PP体简',
                'zh_tw': '汉仪PP体简'
            },
            {
                'zh_cn': '汉仪乐喵体简',
                'en': 'HYLeMiaoTi',
                'ja': '汉仪乐喵体简',
                'zh_tw': '汉仪乐喵体简'
            },
            {
                'zh_cn': '汉仪小麦体',
                'en': 'HYXiaoMaiTiJ',
                'ja': '汉仪小麦体',
                'zh_tw': '汉仪小麦体'
            },
            {
                'zh_cn': '汉仪程行体',
                'en': 'HYChengXingJ',
                'ja': '汉仪程行体',
                'zh_tw': '汉仪程行体'
            },
            {
                'zh_cn': '汉仪黑荔枝',
                'en': 'HYHeiLiZhiTiJ',
                'ja': '汉仪黑荔枝',
                'zh_tw': '汉仪黑荔枝'
            },
            {
                'zh_cn': '汉仪雅酷黑W',
                'en': 'HYYaKuHeiW',
                'ja': '汉仪雅酷黑W',
                'zh_tw': '汉仪雅酷黑W'
            },
            {
                'zh_cn': '汉仪大黑简',
                'en': 'HYDaHeiJ',
                'ja': '汉仪大黑简',
                'zh_tw': '汉仪大黑简'
            },
            {
                'zh_cn': '汉仪尚魏手书W',
                'en': 'HYShangWeiShouShuW',
                'ja': '汉仪尚魏手书W',
                'zh_tw': '汉仪尚魏手书W'
            }]
    },
    fangzheng: {
        name: '版权字体（方正）', list: [
            {
                'zh_cn': '方正粗雅宋简体',
                'en': 'FZYaSongS-B-GB',
                'ja': '方正粗雅宋简体',
                'zh_tw': '方正粗雅宋简体'
            },
            {
                'zh_cn': '方正报宋简体',
                'en': 'FZBaoSong-Z04S',
                'ja': '方正报宋简体',
                'zh_tw': '方正报宋简体'
            },
            {
                'zh_cn': '方正粗圆简体',
                'en': 'FZCuYuan-M03S',
                'ja': '方正粗圆简体',
                'zh_tw': '方正粗圆简体'
            },
            {
                'zh_cn': '方正大标宋简体',
                'en': 'FZDaBiaoSong-B06S',
                'ja': '方正大标宋简体',
                'zh_tw': '方正大标宋简体'
            },
            {
                'zh_cn': '方正大黑简体',
                'en': 'FZDaHei-B02S',
                'ja': '方正大黑简体',
                'zh_tw': '方正大黑简体'
            },
            {
                'zh_cn': '方正仿宋简体',
                'en': 'FZFangSong-Z02S',
                'ja': '方正仿宋简体',
                'zh_tw': '方正仿宋简体'
            },
            {
                'zh_cn': '方正黑体简体',
                'en': 'FZHei-B01S',
                'ja': '方正黑体简体',
                'zh_tw': '方正黑体简体'
            },
            {
                'zh_cn': '方正琥珀简体',
                'en': 'FZHuPo-M04S',
                'ja': '方正琥珀简体',
                'zh_tw': '方正琥珀简体'
            },
            {
                'zh_cn': '方正楷体简体',
                'en': 'FZKai-Z03S',
                'ja': '方正楷体简体',
                'zh_tw': '方正楷体简体'
            },
            {
                'zh_cn': '方正隶变简体',
                'en': 'FZLiBian-S02S',
                'ja': '方正隶变简体',
                'zh_tw': '方正隶变简体'
            },
            {
                'zh_cn': '方正隶书简体',
                'en': 'FZLiShu-S01S',
                'ja': '方正隶书简体',
                'zh_tw': '方正隶书简体'
            },
            {
                'zh_cn': '方正美黑简体',
                'en': 'FZMeiHei-M07S',
                'ja': '方正美黑简体',
                'zh_tw': '方正美黑简体'
            },
            {
                'zh_cn': '方正书宋简体',
                'en': 'FZShuSong-Z01S',
                'ja': '方正书宋简体',
                'zh_tw': '方正书宋简体'
            },
            {
                'zh_cn': '方正舒体简体',
                'en': 'FZShuTi-S05S',
                'ja': '方正舒体简体',
                'zh_tw': '方正舒体简体'
            },
            {
                'zh_cn': '方正水柱简体',
                'en': 'FZShuiZhu-M08S',
                'ja': '方正水柱简体',
                'zh_tw': '方正水柱简体'
            },
            {
                'zh_cn': '方正宋黑简体',
                'en': 'FZSongHei-B07S',
                'ja': '方正宋黑简体',
                'zh_tw': '方正宋黑简体'
            },
            {
                'zh_cn': '方正宋三简体',
                'en': 'FZSong',
                'ja': '方正宋三简体',
                'zh_tw': '方正宋三简体'
            },
            {
                'zh_cn': '方正魏碑简体',
                'en': 'FZWeiBei-S03S',
                'ja': '方正魏碑简体',
                'zh_tw': '方正魏碑简体'
            },
            {
                'zh_cn': '方正细等线简体',
                'en': 'FZXiDengXian-Z06S',
                'ja': '方正细等线简体',
                'zh_tw': '方正细等线简体'
            },
            {
                'zh_cn': '方正细黑一简体',
                'en': 'FZXiHei I-Z08S',
                'ja': '方正细黑一简体',
                'zh_tw': '方正细黑一简体'
            },
            {
                'zh_cn': '方正细圆简体',
                'en': 'FZXiYuan-M01S',
                'ja': '方正细圆简体',
                'zh_tw': '方正细圆简体'
            },
            {
                'zh_cn': '方正小标宋简体',
                'en': 'FZXiaoBiaoSong-B05S',
                'ja': '方正小标宋简体',
                'zh_tw': '方正小标宋简体'
            },
            {
                'zh_cn': '方正行楷简体',
                'en': 'FZXingKai-S04S',
                'ja': '方正行楷简体',
                'zh_tw': '方正行楷简体'
            },
            {
                'zh_cn': '方正姚体简体',
                'en': 'FZYaoTi-M06S',
                'ja': '方正姚体简体',
                'zh_tw': '方正姚体简体'
            },
            {
                'zh_cn': '方正中等线简体',
                'en': 'FZZhongDengXian-Z07S',
                'ja': '方正中等线简体',
                'zh_tw': '方正中等线简体'
            },
            {
                'zh_cn': '方正准圆简体',
                'en': 'FZZhunYuan-M02S',
                'ja': '方正准圆简体',
                'zh_tw': '方正准圆简体'
            },
            {
                'zh_cn': '方正综艺简体',
                'en': 'FZZongYi-M05S',
                'ja': '方正综艺简体',
                'zh_tw': '方正综艺简体'
            },
            {
                'zh_cn': '方正彩云简体',
                'en': 'FZCaiYun-M09S',
                'ja': '方正彩云简体',
                'zh_tw': '方正彩云简体'
            },
            {
                'zh_cn': '方正隶二简体',
                'en': 'FZLiShu II-S06S',
                'ja': '方正隶二简体',
                'zh_tw': '方正隶二简体'
            },
            {
                'zh_cn': '方正康体简体',
                'en': 'FZKangTi-S07S',
                'ja': '方正康体简体',
                'zh_tw': '方正康体简体'
            },
            {
                'zh_cn': '方正超粗黑简体',
                'en': 'FZChaoCuHei-M10S',
                'ja': '方正超粗黑简体',
                'zh_tw': '方正超粗黑简体'
            },
            {
                'zh_cn': '方正新报宋简体',
                'en': 'FZNew BaoSong-Z12S',
                'ja': '方正新报宋简体',
                'zh_tw': '方正新报宋简体'
            },
            {
                'zh_cn': '方正新舒体简体',
                'en': 'FZNew ShuTi-S08S',
                'ja': '方正新舒体简体',
                'zh_tw': '方正新舒体简体'
            },
            {
                'zh_cn': '方正黄草简体',
                'en': 'FZHuangCao-S09S',
                'ja': '方正黄草简体',
                'zh_tw': '方正黄草简体'
            },
            {
                'zh_cn': '方正少儿简体',
                'en': 'FZShaoEr-M11S',
                'ja': '方正少儿简体',
                'zh_tw': '方正少儿简体'
            },
            {
                'zh_cn': '方正稚艺简体',
                'en': 'FZZhiYi-M12S',
                'ja': '方正稚艺简体',
                'zh_tw': '方正稚艺简体'
            },
            {
                'zh_cn': '方正细珊瑚简体',
                'en': 'FZXiShanHu-M13S',
                'ja': '方正细珊瑚简体',
                'zh_tw': '方正细珊瑚简体'
            },
            {
                'zh_cn': '方正粗宋简体',
                'en': 'FZCuSong-B09S',
                'ja': '方正粗宋简体',
                'zh_tw': '方正粗宋简体'
            },
            {
                'zh_cn': '方正平和简体',
                'en': 'FZPingHe-S11S',
                'ja': '方正平和简体',
                'zh_tw': '方正平和简体'
            },
            {
                'zh_cn': '方正华隶简体',
                'en': 'FZHuaLi-M14S',
                'ja': '方正华隶简体',
                'zh_tw': '方正华隶简体'
            },
            {
                'zh_cn': '方正瘦金书简体',
                'en': 'FZShouJinShu-S10S',
                'ja': '方正瘦金书简体',
                'zh_tw': '方正瘦金书简体'
            },
            {
                'zh_cn': '方正细倩简体',
                'en': 'FZXiQian-M15S',
                'ja': '方正细倩简体',
                'zh_tw': '方正细倩简体'
            },
            {
                'zh_cn': '方正中倩简体',
                'en': 'FZZhongQian-M16S',
                'ja': '方正中倩简体',
                'zh_tw': '方正中倩简体'
            },
            {
                'zh_cn': '方正粗倩简体',
                'en': 'FZCuQian-M17S',
                'ja': '方正粗倩简体',
                'zh_tw': '方正粗倩简体'
            },
            {
                'zh_cn': '方正胖娃简体',
                'en': 'FZPangWa-M18S',
                'ja': '方正胖娃简体',
                'zh_tw': '方正胖娃简体'
            },
            {
                'zh_cn': '方正宋一简体',
                'en': 'FZSongYi-Z13S',
                'ja': '方正宋一简体',
                'zh_tw': '方正宋一简体'
            },
            {
                'zh_cn': '方正剪纸简体',
                'en': 'FZJianZhi-M23S',
                'ja': '方正剪纸简体',
                'zh_tw': '方正剪纸简体'
            },
            {
                'zh_cn': '方正流行体简体',
                'en': 'FZLiuXingTi-M26S',
                'ja': '方正流行体简体',
                'zh_tw': '方正流行体简体'
            },
            {
                'zh_cn': '方正祥隶简体',
                'en': 'FZXiangLi-S17S',
                'ja': '方正祥隶简体',
                'zh_tw': '方正祥隶简体'
            },
            {
                'zh_cn': '方正粗活意简体',
                'en': 'FZCuHuoYi-M25S',
                'ja': '方正粗活意简体',
                'zh_tw': '方正粗活意简体'
            },
            {
                'zh_cn': '方正胖头鱼简体',
                'en': 'FZPangTouYu-M24S',
                'ja': '方正胖头鱼简体',
                'zh_tw': '方正胖头鱼简体'
            },
            {
                'zh_cn': '方正卡通简体',
                'en': 'FZKaTong-M19S',
                'ja': '方正卡通简体',
                'zh_tw': '方正卡通简体'
            },
            {
                'zh_cn': '方正艺黑简体',
                'en': 'FZYiHei-M20S',
                'ja': '方正艺黑简体',
                'zh_tw': '方正艺黑简体'
            },
            {
                'zh_cn': '方正水黑简体',
                'en': 'FZShuiHei-M21S',
                'ja': '方正水黑简体',
                'zh_tw': '方正水黑简体'
            },
            {
                'zh_cn': '方正古隶简体',
                'en': 'FZGuLi-S12S',
                'ja': '方正古隶简体',
                'zh_tw': '方正古隶简体'
            },
            {
                'zh_cn': '方正幼线简体',
                'en': 'FZYouXian-Z09S',
                'ja': '方正幼线简体',
                'zh_tw': '方正幼线简体'
            },
            {
                'zh_cn': '方正启体简体',
                'en': 'FZQiTi-S14S',
                'ja': '方正启体简体',
                'zh_tw': '方正启体简体'
            },
            {
                'zh_cn': '方正小篆体',
                'en': 'FZXiaoZhuanTi-S13T',
                'ja': '方正小篆体',
                'zh_tw': '方正小篆体'
            },
            {
                'zh_cn': '方正硬笔楷书简体',
                'en': 'FZYingBiKaiShu-S15S',
                'ja': '方正硬笔楷书简体',
                'zh_tw': '方正硬笔楷书简体'
            },
            {
                'zh_cn': '方正毡笔黑简体',
                'en': 'FZZhanBiHei-M22S',
                'ja': '方正毡笔黑简体',
                'zh_tw': '方正毡笔黑简体'
            },
            {
                'zh_cn': '方正硬笔行书简体',
                'en': 'FZYingBiXingShu-S16S',
                'ja': '方正硬笔行书简体',
                'zh_tw': '方正硬笔行书简体'
            }]
    }
};
let getFontFamily = () => {
    let res = [];
    for (let item in FontFamilyList) {
        let obj = {
            text: FontFamilyList[item].name,
            submenu: FontFamilyList[item].list.map(x=>{return {text:x.zh_cn,value:x.en}})
        }
        res.push(obj);
    }
    return res;
}
let setFontFamily = (name = 'default', value) => {
    FontFamilyList[name || 'default'].list.forEach(x => {
        x.en = value;
    });
}
export default { getFontFamily, setFontFamily };