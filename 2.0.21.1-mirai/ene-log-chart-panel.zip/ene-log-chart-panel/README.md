# Log Chart Panel v1.0.1

## Introduction
- The log chart panel is a log based panel, this panel only supports the timesires format.
- This panel's y axis is based on the unit that selected by the user and the class level (follow the ISO 10816 rules).
- This panel's x axis is show time range and format that the customer chooses to display.
- Line color, symbol and legend font can use custom setting to assign.
- This panel is follow by ISO 10816 Mechanical vibration to formulate in/s and mm/s interval.
- Query data must be all positive integers.

## Data Source of This Panel:
  - simple-json

## Query Data format:
  - timeseries

## Query time type:
  - localtime

## Query example: 

Use simple json data source and select tag, wait the data return.

![log-chart-query-teach_001.png](public/plugins/ene-log-chart-panel/img/log-chart-query-teach_001.png)

Check the response data format like below picture.

![log-chart-query-teach_002.png](public/plugins/ene-log-chart-panel/img/log-chart-query-teach_002.png)

Copyright 2020 © Alisa.Lin, TingWei.Lin, ITsung.Shen / Advantech.
