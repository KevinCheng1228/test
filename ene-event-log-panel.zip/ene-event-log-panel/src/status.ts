///<reference path="../node_modules/grafana-sdk-mocks/app/headers/common.d.ts" />

import _ from 'lodash';
import { getMultiLang } from './multilang';
//import kbn from 'app/core/utils/kbn';

export class statusCtrl {
    panel: any;
    panelCtrl: any;
    addStatusLamp: any;

    statusLampType: any;
    statusLampOption: any;
    statusRelation: any;
    addBtn: boolean;
    errMsg: string;

    /** @ngInject */
    constructor($scope) {
        $scope.editor = this;
        this.panelCtrl = $scope.ctrl;
        this.panel = this.panelCtrl.panel;

        this.addStatusLamp = {
            selected: '--selected--',
            type: 'string',
            condition: 'has',
            value: '',
        };

        this.statusLampType = [
            { text: 'Number', value: 'number' },
            { text: 'String', value: 'string' },
        ];
        this.statusRelation = [{ text: '&', value: '&' }, { text: '||', value: '||' }];
        this.statusLampOption = {
            number: [
                { text: '>', value: '>' },
                { text: '<', value: '<' },
                { text: '=', value: '=' },
                { text: '!=', value: '!=' },
                { text: '>=', value: '>=' },
                { text: '<=', value: '<=' },
            ],
            string: [
                { text: 'has', value: 'has' },
                { text: 'not has', value: 'not has' },
                { text: 'equals', value: 'equals' },
                { text: 'selected', value: 'selected' },
            ],
        };

        this.addBtnStatus();
    }

    getMultiLang(key) {
        return getMultiLang(key, this.panel.langType);
    }

    addBtnStatus() {
        if (this.panel.statusLamp.length > 0) {
            this.addBtn = false;
        } else {
            this.addBtn = true;
        }
    }

    render() {
        this.panelCtrl.render();
    }

    addNewStatus() {
        let num = 0;
        if (this.panel.statusLamp) {
            num = this.panel.statusLamp.length;
        }
        const status = {
            name: 'New Status' + num,
            display: true,
            relation: '&',
            conditions: [],
        };
        this.panel.statusLamp.push(status);
        this.addBtn = false;
    }

    statusLampTypeChange() {
        if (this.addStatusLamp.type === 'number') {
            this.addStatusLamp.condition = '>';
        } else {
            this.addStatusLamp.condition = 'has';
        }
    }

    addOneStatus() {
        if (this.addStatusLamp.selected === '--selected--' || !this.addStatusLamp.value) {
            this.errMsg = 'condition can not empty';
            return;
        }
        for (let i = 0; i < this.panel.statusLamp.length; i++) {
            const status = this.panel.statusLamp[i];
            if (this.panel.activeStatusIndex === i) {
                let repeat = false;
                for (let j = 0; j < status.conditions.length; j++) {
                    const con = status.conditions[j];
                    const addS = this.addStatusLamp;

                    if (
                        addS.selected === con.selected &&
                        addS.condition == con.condition &&
                        addS.value === con.value
                    ) {
                        repeat = true;
                        break;
                    }
                }
                if (repeat) {
                    this.errMsg = 'condition can not repeat';
                } else {
                    this.errMsg = '';
                    status.conditions.push(_.cloneDeep(this.addStatusLamp));
                }
            }
        }

        if (!this.errMsg) {
            this.addStatusLamp = {
                selected: '--selected--',
                type: 'string',
                condition: 'has',
                value: '',
            };
            this.render();
        }
    }

    removeOnestatus(condition) {
        for (let i = 0; i < this.panel.statusLamp.length; i++) {
            const status = this.panel.statusLamp[i];
            if (this.panel.activeStatusIndex === i) {
                status.conditions = _.without(status.conditions, condition);
            }
        }
        this.render();
    }

    removeStatus() {
        const avtive = this.panel.activeStatusIndex;
        this.panel.statusLamp.splice(avtive, 1);

        if (this.panel.activeStatusIndex > 0) {
            this.panel.activeStatusIndex--;
        }

        this.render();
    }
}

/** @ngInject */
export function statusTab($q, uiSegmentSrv) {
    'use strict';
    return {
        restrict: 'E',
        scope: true,
        templateUrl: 'public/plugins/ene-event-log-panel/partials/status.html',
        controller: statusCtrl,
    };
}
