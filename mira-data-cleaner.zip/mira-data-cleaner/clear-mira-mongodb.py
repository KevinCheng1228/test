import json
import re
import math
from datetime import datetime
import paho.mqtt.client as mqtt

# === Set MQTT info ===
BROKER = "rabbitmq-dev.edge365.wise-paas.io"   # MQTT broker IP/hostname
PORT = 1883
TOPIC = "testtest"
FILE_PATH = "sembcorp_mongo_collection_list.txt"
CHUNK_SIZE = 100
CUTOFF_DATE = datetime(2025, 8, 8).date()  # Delete collection before this date 
USERNAME = "3Ke5G572xnyY:BbylDjMVGMyM"         # MQTT username
PASSWORD = "4SPF6F6sv04w2NY4DxBN"     # MQTT password

# === Connect MQTT broker ===
client = mqtt.Client()
client.username_pw_set(USERNAME, PASSWORD)   # Set MQTT username and password
client.connect(BROKER, PORT, 60)

# === Read collection ===
with open(FILE_PATH, "r") as f:
    lines = f.read().splitlines()

# === Get collections to drop ===
pattern = re.compile(r'^(dc_data_discreterecording|dc_data_a_).*?(\d{8})$')
older = []

for line in lines:
    match = pattern.match(line)
    if match:
        date_str = match.group(2)
        try:
            date_val = datetime.strptime(date_str, "%Y%m%d").date()
            if date_val < CUTOFF_DATE:
                older.append(line)
        except ValueError:
            continue

print(f"Total collections matching regex and before {CUTOFF_DATE}: {len(older)}")

# === Publish MQTT message every 100 collection ===
num_chunks = math.ceil(len(older) / CHUNK_SIZE)  # <- 改成 older

client.loop_start()  # Start MQTT loop service

for i in range(num_chunks):
    chunk = older[i*CHUNK_SIZE:(i+1)*CHUNK_SIZE]  # <- 改成 older
    message = {
        "d": {"notifyType": "dropCollection", "collections": chunk},
        "ts": datetime.utcnow().isoformat() + "Z"
    }
    payload = json.dumps(message, ensure_ascii=False)
    
    client.publish(TOPIC, payload)
    print(f"Sent chunk {i+1}/{num_chunks}, contains {len(chunk)} collections")

client.loop_stop()  # Stop MQTT loop service
client.disconnect()
print("All messages sent.")