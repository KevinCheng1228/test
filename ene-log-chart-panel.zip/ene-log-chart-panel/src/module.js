import { LogChartPanel } from './log-chart_ctrl';
import { loadPluginCss } from 'app/plugins/sdk';

loadPluginCss({
    dark: 'plugins/ene-log-chart-panel/css/dark.css',
    light: 'plugins/ene-log-chart-panel/css/light.css',
})

export { LogChartPanel as PanelCtrl };
