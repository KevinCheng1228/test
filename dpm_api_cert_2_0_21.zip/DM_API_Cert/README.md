API server for Device Management Certification Files
