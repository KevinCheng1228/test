const express = require('express');
const { v4: uuidv4 } = require('uuid');
const pg = require('../../lib/db');
const common = require('../../lib/common');
const setting = require('../../conf/setting');
const certCtrl = require('../../controller/cert');
const logger = require('../../lib/logger').getLogger('apiCert');

const router = express.Router();

function responseError(res, msg) {
    res.status(400).json({ 'code': 4000, 'result': msg });
}

// API: /cert/root
/**
    @api {post} /cert/root Create root cert
    @apiVersion 0.1.0
    @apiDescription Create root cert
    @apiGroup Cert
    @apiHeaderExample {json} Header-Example:
        {
            "X-Cert-Token": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhY2NvdW50TmFtZSI6InRvbS5jaG91QGFkdmFudGVjaC5jb20udHciLCJpYXQiOjE2ODY2MTk2MjgsImV4cCI6MTY4NjYxOTgwOH0.2lAyJ84lDZznnmWcU0lXaL_WSIwT1DMSCBcQjYygjbc"
        }

    @apiBody {Number} expireDay the expireDay of the root cert
    @apiParamExample Request-Example:
        http://4.193.252.254:3000/v1.0/cert/root
    @apiParamExample {json} Request-Example:
        {
            "expireDay": 365
        }

    @apiSuccess {Number} id the id of the root

    @apiSuccessExample {json} Success-Response:
        HTTP/1.1 200 OK
        {
            "id": 3
        }

*/
router.post('/root', (req, res) => {
    let accountId;
    let fileName = 'root';
    let today = new Date();
    let passphrase = uuidv4();
    let accountName = common.getUserNameFromJwtToken(req);
    let expireDayNumber = setting.ROOT_EXPIRY_DAY_NUMBER;
    let certCommonName = `"${setting.CERT_COMMON_NAME} Root Cert for ${setting.NAMESPACE}"`;
    let certOrganizationName = setting.CERT_ORANIZATION_NAME;

    pg.getAccountIdByAccountName(accountName)
        .then(queryResult => {
            if (!queryResult.status) throw new Error(queryResult.message);
            accountId = queryResult.result.rows[0].accountid;
            return certCtrl.generateRootCert(accountId, accountName, fileName, today, passphrase, expireDayNumber, certCommonName, certOrganizationName)
        })
        .then(genRootCertResult => {
            if (!genRootCertResult.status) throw new Error(genRootCertResult.message)
            return res.send({ id: genRootCertResult.id })
        })
        .catch(error => {
            logger.error('api post root cert: ', error.message);
            responseError(res, error.message);
        })
})

// API: /cert/intermediate
/**
    @api {post} /cert/intermediate Create intermediate cert
    @apiVersion 0.1.0
    @apiDescription Create intermediate cert
    @apiGroup Cert
    @apiHeaderExample {json} Header-Example:
        {
            "X-Cert-Token": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhY2NvdW50TmFtZSI6InRvbS5jaG91QGFkdmFudGVjaC5jb20udHciLCJpYXQiOjE2ODY2MTk2MjgsImV4cCI6MTY4NjYxOTgwOH0.2lAyJ84lDZznnmWcU0lXaL_WSIwT1DMSCBcQjYygjbc"
        }

    @apiBody {Number} rootId the rootId of the root cert id
    @apiParamExample Request-Example:
        http://4.193.252.254:3000/v1.0/cert/intermediate
    @apiParamExample {json} Request-Example:
        {
            "rootId": 3,
        }

    @apiSuccess {Number} id the id of the root

    @apiSuccessExample {json} Success-Response:
        HTTP/1.1 200 OK
        {
            "id": 3
        }

*/
router.post('/intermediate', (req, res) => {
    let accountId;
    let today = new Date();
    let passphrase = uuidv4();
    let rooCaId = req.body.rootId;
    let status = common.CERT_STATUS.NEW;
    let fileName = 'intermediate';
    let accountName = common.getUserNameFromJwtToken(req);
    let certOrganizationName = setting.CERT_ORANIZATION_NAME;
    let certCommonName = `"${setting.CERT_COMMON_NAME} Intermediate Cert for ${setting.NAMESPACE}"`;

    pg.getAccountIdByAccountName(accountName)
        .then(queryResult => {
            if (!queryResult.status) throw new Error(queryResult.message);
            accountId = queryResult.result.rows[0].accountid;
            return certCtrl.generateIntermediateCert(accountId, accountName, fileName, rooCaId, status, passphrase, today, certCommonName, certOrganizationName)
        })
        .then(result => {
            if (!result.status) throw new Error(result.message);
            return res.send({ id: result.id });
        })
        .catch(error => {
            logger.error('api post intermediate cert: ', error.message);
            responseError(res, error.message);
        })
});

// API: /cert/device
/**
    @api {post} /cert/device Create device cert
    @apiVersion 0.1.0
    @apiDescription Create device cert
    @apiGroup Cert
    @apiHeaderExample {json} Header-Example:
        {
            "X-Cert-Token": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhY2NvdW50TmFtZSI6InRvbS5jaG91QGFkdmFudGVjaC5jb20udHciLCJpYXQiOjE2ODY2MTk2MjgsImV4cCI6MTY4NjYxOTgwOH0.2lAyJ84lDZznnmWcU0lXaL_WSIwT1DMSCBcQjYygjbc"
        }

    @apiBody {String} serialNo the serialNo of the device
    @apiBody {Number} expireDay the expireDay of the device
    @apiBody {Number} orgId the orgId of the device
    @apiBody {String} vhost the vhost of the rabbitMQ
    @apiParamExample Request-Example:
        http://4.193.252.254:3000/v1.0/cert/device
    @apiParamExample {json} Request-Example:
        {
            "serialNo": "00D0CD000062",
            "expireDay": 365,
            "orgId": 11,
            "vhost": "3Ke5G572xnyY"
        }

    @apiSuccess {String} serialNo the serialNo of the device

    @apiSuccessExample {json} Success-Response:
        HTTP/1.1 200 OK
        {
            "serialNo": "00D0CD000062"
        }

*/
router.post('/device', (req, res) => {
    let accountId;
    let accountName = common.getUserNameFromJwtToken(req);
    let serialNo = req.body.serialNo;
    let fileName = common.CERT_NAME.DEVICE;
    let status = common.CERT_STATUS.ACTIVE;
    let orgId = parseInt(req.body.orgId);
    let caIdx = common.getIntermediateCertIdxByOrgId(req.body.orgId);
    let vhost = req.body.vhost;
    let iothubPassphrase = uuidv4();
    let rabbitmqPassphrase = uuidv4();
    let expireDayNumber = parseInt(req.body.expireDay);
    let today = new Date();
    let certCommonName = `"${setting.CERT_COMMON_NAME} Device Cert"`;
    let certOrganizationName = setting.CERT_ORANIZATION_NAME;
    if (!vhost) return responseError(res, 'vhost error');

    pg.getAccountIdByAccountName(accountName)
        .then(queryResult => {
            if (!queryResult.status) throw new Error(queryResult.message);
            accountId = queryResult.result.rows[0].accountid;
            return certCtrl.generateDeviceCert(accountId, accountName, serialNo, fileName, status, orgId, caIdx, iothubPassphrase, rabbitmqPassphrase, today, expireDayNumber, certCommonName, certOrganizationName, vhost)
        })
        .then(genDeviceCertResult => {
            if (!genDeviceCertResult.status) throw new Error(genDeviceCertResult.message);
            return res.send({ serialNo: genDeviceCertResult.serialNo });
        })
        .catch(error => {
            logger.error('api post device cert: ', error.message);
            responseError(res, error.message);
        })
});

// API: /cert/server
/**
    @api {post} /cert/server Create server cert
    @apiVersion 0.1.0
    @apiDescription Create server cert
    @apiGroup Cert
    @apiHeaderExample {json} Header-Example:
        {
            "X-Cert-Token": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhY2NvdW50TmFtZSI6InRvbS5jaG91QGFkdmFudGVjaC5jb20udHciLCJpYXQiOjE2ODY2MTk2MjgsImV4cCI6MTY4NjYxOTgwOH0.2lAyJ84lDZznnmWcU0lXaL_WSIwT1DMSCBcQjYygjbc"
        }

    @apiParamExample Request-Example:
        http://4.193.252.254:3000/v1.0/cert/server

    @apiSuccess {String} serialNo the serialNo of the server

    @apiSuccessExample {json} Success-Response:
        HTTP/1.1 200 OK
        {
            "serialNo": "server"
        }

*/
router.post('/server', (req, res) => {
    let accountId;
    let accountName = common.getUserNameFromJwtToken(req);
    let serialNo = 'server';
    let status = common.CERT_STATUS.ACTIVE;
    let orgId = common.SERVER_ORG_ID;
    let caIdx = setting.SERVER_INTERMEDIATE_ID;
    let fileName = 'server';
    let passphrase = uuidv4();
    let today = new Date();
    let certCommonName = `"${setting.CERT_COMMON_NAME} Server Cert"`;
    let certOrganizationName = setting.CERT_ORANIZATION_NAME;

    pg.getAccountIdByAccountName(accountName)
        .then(queryResult => {
            if (!queryResult.status) throw new Error(queryResult.message);
            accountId = queryResult.result.rows[0].accountid;
            return certCtrl.generateServerCert(accountId, accountName, serialNo, fileName, status, orgId, caIdx, passphrase, today, certCommonName, certOrganizationName)
        })
        .then(genServerCertResult => {
            if (!genServerCertResult.status) throw new Error(genServerCertResult.message);
            return res.send({ serialNo: genServerCertResult.serialNo });
        })
        .catch(error => {
            logger.error('api post server cert error: ', error.message);
            responseError(res, error.message);
        })
});

// API: /root/list
/**
    @api {get} /root/list Get root cert list
    @apiVersion 0.1.0
    @apiDescription Get root cert list
    @apiGroup Cert
    @apiHeaderExample {json} Header-Example:
        {
            "X-Cert-Token": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhY2NvdW50TmFtZSI6InRvbS5jaG91QGFkdmFudGVjaC5jb20udHciLCJpYXQiOjE2ODY2MTk2MjgsImV4cCI6MTY4NjYxOTgwOH0.2lAyJ84lDZznnmWcU0lXaL_WSIwT1DMSCBcQjYygjbc"
        }

    @apiParamExample Request-Example:
        http://4.193.252.254:3000/v1.0/root/list

    @apiSuccess {Object[]} list the list of the root cert
    @apiSuccess {Number} list.id the id of the root cert
    @apiSuccess {Number} list.status the status of the root cert (0: active, 1: expired, 2: retired, 3: new)
    @apiSuccess {Number} list.type the type of the root cert (0: azure key-vault, 1: wise-paas key-vault, 2: local db)
    @apiSuccess {String} list.fileName the fileName of the root cert
    @apiSuccess {String} list.expiryTime the expiryTime of the root cert
    @apiSuccess {Boolean} list.keyVaultCertIsEnabled the keyVaultCertIsEnabled of the root cert
    @apiSuccess {Boolean} list.keyVaultSecretIsEnabled the keyVaultSecretIsEnabled of the root cert
    @apiSuccess {Boolean} list.isUpload the isUpload of the root cert
    @apiSuccess {Boolean} list.iotHubIsRegister the iotHubIsRegister of the root cert
    @apiSuccess {String} list.iotHubRegisterTime the iotHubRegisterTime of the root cert
    @apiSuccess {Boolean} list.rabbitMQIsRegister the rabbitMQIsRegister of the root cert
    @apiSuccess {String} list.rabbitMQRegisterTime the rabbitMQRegisterTime of the root cert
    @apiSuccess {Boolean} list.isDeleted the isDeleted of the root cert
    @apiSuccess {Number} list.creatorId the creatorId of the root cert
    @apiSuccess {String} list.creatorName the creator name of the root cert
    @apiSuccess {String} list.createdTime the createdTime of the root cert
    @apiSuccess {Number} list.updatorId the updatorId of the root cert
    @apiSuccess {String} list.updatorName the updator name of the root cert
    @apiSuccess {String} list.updatedTime the updatedTime of the root cert
    @apiSuccess {Number} list.deletedId the deletedId of the root cert
    @apiSuccess {String} list.deletedName the deleted name of the root cert
    @apiSuccess {Number} list.deletedTime the deletedTime of the root cert

    @apiSuccessExample {json} Success-Response:
        HTTP/1.1 200 OK
        {
            "list": [
                {
                    "id": 34,
                    "status": 1,
                    "type": 0,
                    "fileName": "root.ca",
                    "expiryTime": "2024-04-25T00:00:00.000Z",
                    "keyVaultCertIsEnabled": true,
                    "keyVaultSecretIsEnabled": true,
                    "isUpload": true,
                    "iotHubIsRegister": true,
                    "iotHubRegisterTime": "2023-04-26T08:35:13.000Z",
                    "rabbitMQIsRegister": false,
                    "rabbitMQRegisterTime": null,
                    "isDeleted": true,
                    "creatorId": 0,
                    "creatorName": "admin",
                    "createdTime": "2023-04-26T08:35:01.635Z",
                    "updatorId": 0,
                    "updatorName": "admin",
                    "updatedTime": "2023-04-26T08:35:14.161Z",
                    "deletedId": null,
                    "deletedName": null,
                    "deletedTime": null
                },
                ...
            ]
        }
*/
router.get('/root/list', (req, res) => {
    let accountName = common.getUserNameFromJwtToken(req);

    pg.getAccountIdByAccountName(accountName)
        .then(queryResult => {
            if (!queryResult.status) throw new Error(queryResult.message);

            return pg.getRootCertList()
        })
        .then(queryResult => {
            if (!queryResult.status) {
                return res.send([]);
            }
            let list = [];
            for (let info of queryResult.result.rows) {
                list.push({
                    id: info.id,
                    status: info.status,
                    type: info.type,
                    fileName: info.file_name,
                    expiryTime: info.expiry_time,
                    keyVaultCertIsEnabled: info.key_vault_cert_is_enabled,
                    keyVaultSecretIsEnabled: info.key_vault_secret_is_enabled,
                    isUpload: info.is_upload,
                    iotHubIsRegister: info.is_register_iothub,
                    iotHubRegisterTime: info.register_iothub_time,
                    rabbitMQIsRegister: info.is_register_rabbitmq,
                    rabbitMQRegisterTime: info.register_rabbitmq_time,
                    isDeleted: info.is_deleted,
                    creatorId: info.creator_id,
                    creatorName: info.creator_name,
                    createdTime: info.created_time,
                    updatorId: info.updator_id,
                    updatorName: info.updator_name,
                    updatedTime: info.updated_time,
                    deletedId: info.deleted_id,
                    deletedName: info.deleted_name,
                    deletedTime: info.deleted_time
                })
            }
            return res.send({ list: list })
        })
        .catch(error => {
            logger.error('api get root cert list: ', error.message);
            responseError(res, error.message);
        })
})

// API: /intermediate/list
/**
    @api {get} /intermediate/list Get intermediate cert list
    @apiVersion 0.1.0
    @apiDescription Get intermediate cert info
    @apiGroup Cert
    @apiHeaderExample {json} Header-Example:
        {
            "X-Cert-Token": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhY2NvdW50TmFtZSI6InRvbS5jaG91QGFkdmFudGVjaC5jb20udHciLCJpYXQiOjE2ODY2MTk2MjgsImV4cCI6MTY4NjYxOTgwOH0.2lAyJ84lDZznnmWcU0lXaL_WSIwT1DMSCBcQjYygjbc"
        }

    @apiParamExample Request-Example:
        http://4.193.252.254:3000/v1.0/intermediate/list

    @apiSuccess {Object[]} list the list of the intermediate cert
    @apiSuccess {Number} list.id the id of the intermediate cert
    @apiSuccess {Number} list.status the status of the intermediate cert (0: active, 1: expired, 2: retired, 3: new)
    @apiSuccess {Number} list.type the type of the intermediate cert (0: azure key-vault, 1: wise-paas key-vault, 2: local db)
    @apiSuccess {String} list.fileName the fileName of the intermediate cert
    @apiSuccess {Number} list.fileIndex the file index of the intermediate cert
    @apiSuccess {String} list.rootCertName the root cert name of the root cert
    @apiSuccess {String} list.expiryTime the expiryTime of the intermediate cert
    @apiSuccess {Boolean} list.keyVaultCertIsEnabled the keyVaultCertIsEnabled of the intermediate cert
    @apiSuccess {Boolean} list.keyVaultSecretIsEnabled the keyVaultSecretIsEnabled of the intermediate cert
    @apiSuccess {Boolean} list.keyVaultIsUpload the keyVaultIsUpload of the intermediate cert
    @apiSuccess {Boolean} list.iotHubIsRegister the iotHubIsRegister of the intermediate cert
    @apiSuccess {String} list.iotHubRegisterTime the iotHubRegisterTime of the intermediate cert
    @apiSuccess {Boolean} list.rabbitMQIsRegister the rabbitMQIsRegister of the intermediate cert
    @apiSuccess {String} list.rabbitMQRegisterTime the rabbitMQRegisterTime of the intermediate cert
    @apiSuccess {Boolean} list.isDeleted the isDeleted of the intermediate cert
    @apiSuccess {Number} list.creatorId the creatorId of the intermediate cert
    @apiSuccess {String} list.creatorName the creator name of the intermediate cert
    @apiSuccess {String} list.createdTime the createdTime of the intermediate cert
    @apiSuccess {Number} list.updatorId the updatorId of the intermediate cert
    @apiSuccess {String} list.updatorName the updator name of the intermediate cert
    @apiSuccess {String} list.updatedTime the updatedTime of the intermediate cert
    @apiSuccess {Number} list.deletedId the deletedId of the intermediate cert
    @apiSuccess {String} list.deletedName the deleted name of the intermediate cert
    @apiSuccess {Number} list.deletedTime the deletedTime of the intermediate cert

    @apiSuccessExample {json} Success-Response:
        HTTP/1.1 200 OK
        {
            "list": [
                {
                    "id": 137,
                    "status": 1,
                    "type": 0,
                    "fileName": "intermediate",
                    "fileIndex": 1,
                    "rootCertName": "root-1",
                    "expiryTime": "2024-04-25T00:00:00.000Z",
                    "keyVaultCertIsEnabled": true,
                    "keyVaultSecretIsEnabled": true,
                    "keyVaultIsUpload": true,
                    "iotHubIsRegister": true,
                    "iotHubRegisterTime": "2023-04-26T02:14:03.000Z",
                    "rabbitMQIsRegister": false,
                    "rabbitMQRegisterTime": null,
                    "isDeleted": true,
                    "creatorId": 0,
                    "creatorName": "admin",
                    "createdTime": "2023-04-26T08:35:01.635Z",
                    "updatorId": 0,
                    "updatorName": "admin",
                    "updatedTime": "2023-04-26T08:35:14.161Z",
                    "deletedId": null,
                    "deletedName": null,
                    "deletedTime": null
                },
                ...
            ]
        }
*/
router.get('/intermediate/list', (req, res) => {
    let accountName = common.getUserNameFromJwtToken(req);

    pg.getAccountIdByAccountName(accountName)
        .then(queryResult => {
            if (!queryResult.status) throw new Error(queryResult.message);

            return pg.getIntermediateCertList()
        })
        .then(queryResult => {
            if (!queryResult.status) {
                return res.send([]);
            }
            let list = [];
            for (let info of queryResult.result.rows) {
                list.push({
                    id: info.id,
                    status: info.status,
                    type: info.type,
                    fileName: info.file_name,
                    fileIndex: info.file_index,
                    rootCertName: info.root_cert_name,
                    expiryTime: info.expiry_time,
                    keyVaultCertIsEnabled: info.key_vault_cert_is_enabled,
                    keyVaultSecretIsEnabled: info.key_vault_secret_is_enabled,
                    isUpload: info.is_upload,
                    iotHubIsRegister: info.is_register_iothub,
                    iotHubRegisterTime: info.register_iothub_time,
                    rabbitMQIsRegister: info.is_register_rabbitmq,
                    rabbitMQRegisterTime: info.register_rabbitmq_time,
                    isDeleted: info.is_deleted,
                    creatorId: info.creator_id,
                    creatorName: info.creator_name,
                    createdTime: info.created_time,
                    updatorId: info.updator_id,
                    updatorName: info.updator_name,
                    updatedTime: info.updated_time,
                    deletedId: info.deleted_id,
                    deletedName: info.deleted_name,
                    deletedTime: info.deleted_time
                })
            }
            return res.send({ list: list })
        })
        .catch(error => {
            logger.error('api get intermediate cert list: ', error.message);
            responseError(res, error.message);
        })
})

// API: /intermediate/:id
/**
    @api {get} /intermediate/:id Get intermediate cert
    @apiVersion 0.1.0
    @apiDescription Get intermediate cert
    @apiGroup Cert
    @apiHeaderExample {json} Header-Example:
        {
            "X-Cert-Token": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhY2NvdW50TmFtZSI6InRvbS5jaG91QGFkdmFudGVjaC5jb20udHciLCJpYXQiOjE2ODY2MTk2MjgsImV4cCI6MTY4NjYxOTgwOH0.2lAyJ84lDZznnmWcU0lXaL_WSIwT1DMSCBcQjYygjbc"
        }

    @apiParam {Number} id the id of the intermediate
    @apiParamExample Request-Example:
        http://4.193.252.254:3000/v1.0/cert/intermediate/:id

    @apiSuccess {String} intermediateFileName the name of the intermediate cert
    @apiSuccess {Base64} certificate the Certificate of the server cert pem

    @apiSuccessExample {json} Success-Response:
        HTTP/1.1 200 OK
        {
            "intermediateFileName": "intermediate",
            "certificate": "LS0tLS1CRUdJTiBDRVJUSUZJQ0FURS0tLS0tCk1JSUZaakNDQTA2Z0F3SUJBZ0lCQXpBTkJna3Foa2lHOXcwQkFRc0ZBREJBTVNjd0pRWURWUVFEREI1WFNWTkYKTFVWa1oyVXpOalVnVW05dmRDQkRaWEowSUdadmNpQmtaWFl4RlRBVEJnTlZCQW9NREZkSlUwVXRSV1JuWlRNMgpOVEFlRncweU16QTJNRFV4TVRJMk5EVmFGdzB5TkRBMk1EUXhNVEkyTkRWYU1FZ3hGVEFUQmdOVkJBb01ERmRKClUwVXRSV1JuWlRNMk5URXZNQzBHQTFVRUF3d21WMGxUUlMxRlpHZGxNelkxSUVsdWRHVnliV1ZrYVdGMFpTQkQKWlhKMElHWnZjaUJrWlhZd2dnSWlNQTBHQ1NxR1NJYjNEUUVCQVFVQUE0SUNEd0F3Z2dJS0FvSUNBUURVM3Nzcwp2cnMzc2gxd0tuTjNoaUJhRjQyTmxLRCtiOVdLZFhQNWo4YjBUcDdvUGo4TjVBZDIvbUczUnJkS3Z5c05ma0E0Ck9HQ2F0WHRlSi9zYngxZnRGdWNZK2JKenNVOWNuQ1pKVXlXWHNSTWFmOFJoeE82ditlTGRIRHB1Q0VVY0p5WnkKZjQ2UFFtNmJwMXJlZUJNNmhpQWo2Z0pkQVhYSTNJNDFScFVGRi9LdjJQeG55MnVlMkZZOWdDY0phVjZvWEVzaAo0VnNyUU5JblM0V2tlc2JhNTNmUS91OTF1d0hJTzNYQ012a002RXdsSlcwN1VRRUFaZGpTbzR0QUFvbmx4TnJkCi9xRHdXMjJOcUZPMGIrSERiOCtPYkF3TWZFVVc5UWhKVUZhVm1Oc0doNVF2QzRjaGZzQStZMHJwY3gvclNYL0UKU3JDRGZyMG1aTjhWa0RHcDNpc3RvWlBteVlSc3E3bCsraUQ1Q2ZjbFd5Q3k2S2RTN2FpSHBsOWtVZXB2ZjRKKwpYWjdtVVVKbEY4NFdDdnlMZ0hVajRTNTR2Q3FYMGk5Y2ZNdWlFYmxuNm9IcmNYV3ZLbDBvNUVQWWRGT0x5QlZFCjZRR3dITFFrNktHYVdLdDYrUGpIVm1BZmMrb1AvYTdFYmh1ZTg5a1Q4cm1zdHE5V2g3R1gwbHFFZzAxamlTcWMKRnRzSGluWm54K2lMTTR1dUhSTmwvSkhaUXNZQjRJT1AyZlpIOEh2RG1zbHFxVlJkaSttOTYxRVkvWlVvdUo5NwoyMWJ5UVl0Z0RJTmEzeDVBVGJCeGx0QW5aQ1FXZXRMZ3JFSXdvOWRVMkhUajN1QjNmU3owNkMrRmI1dFN5emtBCnRERy9xSXM2SlBYaTlDelRtNm5HVTN1eTgyWGdZYW9pa2s5R0l3SURBUUFCbzJNd1lUQWRCZ05WSFE0RUZnUVUKTS9JYUdiT3dGVWltanJyU092NDFERUVQaldJd0h3WURWUjBqQkJnd0ZvQVUyYzVkd1RkYlNiNTZoSHJhOUxTYgphSlRrbjFjd0R3WURWUjBUQVFIL0JBVXdBd0VCL3pBT0JnTlZIUThCQWY4RUJBTUNBWVl3RFFZSktvWklodmNOCkFRRUxCUUFEZ2dJQkFDUlA4V1c3RGVtQ1lvcUZxMVBNajZQTHgxWWJhRkhYTXRXSFpqTXRHQUUvampheUJab1oKaUE5ZVplQWpraFJpQmkwMlRFVXdXVHoxcDJsWStjVW9rSGhTaU1HeFlWOFU1ZVNNYitPN2k4eGRIZGIya2JGagpFTTNrUncrcFhsc2NlcloxRTFxMU91SUlxTnBocW9PNkJIaU1Za2tSQVVDeElab3VHZFJlaWY0OUIyY2JySC9zCkxDWVdQbWEwQUllV3pyYzVNaFNFT1Iwc255VU9EMStHM2R6OFpCSnlBVFRTcWR4ZmI0SW1Ba2M2SGh0Wmw0aDAKMStnMHBUUTk4aDJkYWNWQitPZVpMcTdUM0J6WGsvYS9TMGF1b29zOHd2L2JYU1pOQVBKajRwanorRm1JR0ZrKwpiR2NnYWN1L1c4bTI5cVJlYkppZDB4eHlWRSs1b2V1MHNDbHpoYXlTV1RNdUlKY2JMSDlyM3JRKytoTWhxVWVwCklvemQrbUdhN2s0blY0TFoyTG03ZDBKUjFaSml0cVN5ZTFmdFFYVmQ1SUY3UjdiT1hNSExaTExPaVZFRTBHT0MKbUVvYjREekx6Y0QwRGlrSkZOZy8xNG5jV3h2bDN6Z3BELzNMYkI1VmhacmpvNFYxMjljNVZiSmF3UzhQQVNFKwpRaUlXU1hsa2FnblAxUEpkUEdwK1ZYT1FRT0FwRVB5NVpPTlYvcTlIVXVxNFJQLzZITDYxUjEwZGg5dDIzSFJECnl6TzNydFBhNkEvcG5QNHpVc0ZuT1dZVE91YTBNdHdmdXgwdFcyNC8zR2wvdnlvVVZReHlxL3pmbjVobHJVNW4Ka3NhaStQZDd5cndzU0xlN3RLYWlYaXNSWG5vK2VFWHpkT1pSakRkT2d0SU1jWUN6aXV4Q2lITVYKLS0tLS1FTkQgQ0VSVElGSUNBVEUtLS0tLQ=="
        }
*/
router.get('/intermediate/:id', (req, res) => {
    let id = parseInt(req.params.id);
    let accountName = common.getUserNameFromJwtToken(req);
    logger.info(`Get Intermediate Cert User: ${accountName}, id: ${id}`)

    certCtrl.getIntermediateCert(id)
        .then(queryResult => {
            if (!queryResult.status) throw new Error(queryResult.message);
            return res.send({
                intermediateFileName: queryResult.intermediateCertInfo.fileName,
                certificate: (queryResult.intermediateCertInfo.certContent === '') ? queryResult.intermediateCertInfo.certContent : Buffer.from(queryResult.intermediateCertInfo.certContent).toString('base64')
            })
        })
        .catch(error => {
            logger.error('api get intermediate cert info: ', error.message);
            responseError(res, error.message);
        })
});

// API: /cert/device/:serialNo
/**
    @api {get} /cert/device/:serialNo Get the device's all cert files
    @apiVersion 0.1.0
    @apiDescription Get the device's all cert files
    @apiGroup Cert
    @apiHeaderExample {json} Header-Example:
        {
            "X-Cert-Token": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhY2NvdW50TmFtZSI6InRvbS5jaG91QGFkdmFudGVjaC5jb20udHciLCJpYXQiOjE2ODY2MTk2MjgsImV4cCI6MTY4NjYxOTgwOH0.2lAyJ84lDZznnmWcU0lXaL_WSIwT1DMSCBcQjYygjbc"
        }

    @apiParam {String} serialNo the serialNo address of the device
    @apiParamExample Request-Example:
        http://4.193.252.254:3000/v1.0/cert/device/00D0CD000067

    @apiSuccess {String} caName the name of the ca cert
    @apiSuccess {String} iothubCaName the device cert name of the iothub
    @apiSuccess {String} rabbitmqCaName the device cert name of the rabbitmq
    @apiSuccess {Number} status the status of the device cert (0: not use, 1: not expired, 2: expired)
    @apiSuccess {String} caCertificateValidity the expiry time of the intermediate cert
    @apiSuccess {String} deviceCertificateValidity the expiry time of the device cert
    @apiSuccess {Base64} ca the CA of the intermediate cert pem
    @apiSuccess {Base64} iothubCertificate the device certificate of the iothub
    @apiSuccess {Base64} iothubPrivateKey the device privatekey of the iothub
    @apiSuccess {Base64} rabbitmqCertificate the device certificate of the rabbitmq
    @apiSuccess {Base64} rabbitmqPrivateKey the device privatekey of the rabbitmq
    @apiSuccess {String} createdDate the CreatedDate of the device

    @apiSuccessExample {json} Success-Response:
        HTTP/1.1 200 OK
        {
            "caName": "ca",
            "iothubCaName": "device-iothub-00D0CD000063",
            "rabbitmqCaName": "device-rabbitmq-00D0CD000063",
            "status": 1,
            "caCertificateValidity": "2024-04-26T03:10:22.000Z",
            "deviceCertificateValidity": "2024-02-21T03:10:22.000Z",
            "ca": "LS0tLS1CRUdJTiBDRVJUSUZJQ0FURS0tLS0tCk1JSUZWakNDQXo2Z0F3SUJBZ0lCQlRBTkJna3Foa2lHOXcwQkFRc0ZBREE0TVI4d0hRWURWUVFEREJaWFNWTkYKTFVWa1oyVXpOalVnVW05dmRDQkRaWEowTVJVd0V3WURWUVFLREF4WFNWTkZMVVZrWjJVek5qVXdIaGNOTWpNdwpOVEExTURnME5URTNXaGNOTWpRd05UQTBNRGcwTlRFM1dqQkFNUlV3RXdZRFZRUUtEQXhYU1ZORkxVVmtaMlV6Ck5qVXhKekFsQmdOVkJBTU1IbGRKVTBVdFJXUm5aVE0yTlNCSmJuUmxjbTFsWkdsaGRHVWdRMlZ5ZERDQ0FpSXcKRFFZSktvWklodmNOQVFFQkJRQURnZ0lQQURDQ0Fnb0NnZ0lCQU1wSnYwOGx5SkRjMXgxZHM4bWdvUnBhVXYzcwptRmVwT1ROT1RpbXNBcWhWVFNqdDdnTC9MdGtIOVBjWElJN2ZGZVNWMENDQVlTVjhuR0dtSWpMVkZWMGdPVnJjCkNxWHdwcXMwR296Z2J2VnMyTjUyQis4a0xOY0psM1VlYnZOOGlHYjQ0akE5QVprR0JwdkZ3Z1lrNCsrZHpNOVAKdlJ6Mk42bzg1S0daQ282VnpBNWMxYURhNmVqVWVFRVFZTWJKaWo2VittdG1uQnZBTXlLdStYMjhUeGtHN2s3egpaNkhxb1RBb3hDSFNjZTY1M0s5WDZTRFdGY2JwRCt1SWlvU2kreFZrQjR1ZmxCT0ZlV1pqZUhqdVE2V1oxZmZjCldINDBuRFFzVHN2RS9HNU8ybXNGYmFFeWZjSC8yRCtGdEFCcWVReGZiN3lRSU9ocFlQZklnd1ZJS3dNaU53cVMKaVB6MG9BZVpHK0JWNFlnQkJiRmV5eW9zSDNTcnFsQURHSG9oK0pqQVZCUzhqUmI1ZFl4Wi9vNC96WkR4M1ZEbwo3NmZOTDdObUd1OUxyUVFza3R3RDRsL0g0MFdOZ1lGeU8zVVVIZUh2dFFhRnRKV0V3RmtKdmorUDd6a1NpVzRLCkhIdU4ya2JPS2E3RWU3TzRYUnBTOU1TVVZtbEwxYmVGUjlmMXUyS2drVWVSSEpIUGZEOTNaRkh4R0ZuNUpJWjgKN0hWWkpsUEs3aGlTYk4vNVczV3ZhWmFMZU51NG5Tejh1bGFBT1o5d3Q1aFhoVDJ6L2xNZ0QzOFM4bjdZN0g3NApNMm5ZYjY5NDdDZlhxaEtkeEhUKzRWcWh6em4vQ09KOTMrYk1jSVBFRytscGxHRXN3QTdJR2FaVTlCeHFuUHRBCk1wdGVBcHpBbEJIektxTVRBZ01CQUFHall6QmhNQjBHQTFVZERnUVdCQlNYanhkcWl4Vmd0NFpIaXdvOFJwSVkKQTJPVnNUQWZCZ05WSFNNRUdEQVdnQlI1MytqZFpDSWh4TzVaT0l6R2ZhMDZOVW8vQ2pBUEJnTlZIUk1CQWY4RQpCVEFEQVFIL01BNEdBMVVkRHdFQi93UUVBd0lCaGpBTkJna3Foa2lHOXcwQkFRc0ZBQU9DQWdFQUY1ZHFGemZlCnliZUUwa0E0MkFQUjlVWFppVjN6Z084SlNzSXNhOVNmaWdyZ3ZyZ3g0eW15R3VPSm00ZVFpbFVpQ1J1Q0x3V0EKTndhaFFJZWxXVDg0SWp3Ty9BWldVZGU0UldBa1YxdHJUODU5bXNKd3FXWFR6NDI1b090aG56Wlo1MEtnYkZuawp0UzlXaFZVY0drLy9PSjBLTWlTUXRuNE1DbHBvcHo5L3hreHB2YjlNaitaNWNKOER2cDkwcnBKbWhKbExDNzBkCnlFNEU0ZVpKSXJMQks1amdtMnZ0Ti9FYnlxaW53cnB3clZ3OWpXSzZPTVRqQTJUNWF4THliSkhKQTNlTDBrVkcKMy9uV0F1RmhldlJFMW9hZjh3L3ZUd0pRNWc5UGJ3SFdIUDR2bENUbGpNa2xxQ0xZVlBNVFBtVDk4aHdWd1JYdgo1Y0E3L2MxWGdUcC9iV3VhTzQ3blowQUh2MElwalU0NXpKQ1R6QkYvbXg0dDQwQk5aN0lacGRLUHpzOHNzNzVhClJ6UFBNeGV6aHg2bU5XRXdIaGkvQXM2NXRvcGRnNS95QU0vMFl2cEUzSk5Zd3A2NzEyS3NCcWM1YUZuYzBZb2gKMjNieGx3OFFwc1Y4RThrMmdKazFDcnUzTDhEYmVSNnk5YnFoMWR3bENxR2NpM3dvVTNHZllkOHlOZ3BZVFFVcgphRDFWMlh4VVY5RnZ6MFRFTnRJQmttUFQ1aUVGNzhvcHFnZlRKR3hGcW9CbmVGdVUrUEF2aVcyb1pnWUZKT1dGCjNNZzdrd2RJdmY2Tk1ZcGxkSnBxbXZoQkY2WVd5cjJpUE9RMlorNHJQYkhuWE5yaUxDVHk0RnNkbEtxNnQ2ZXQKVUZCZWhKbEZNUnBFTHdnUkMxRzlqVWRKc29FL1lBczA2TUU9Ci0tLS0tRU5EIENFUlRJRklDQVRFLS0tLS0KLS0tLS1CRUdJTiBDRVJUSUZJQ0FURS0tLS0tCk1JSUZZVENDQTBtZ0F3SUJBZ0lVWnlWZjJGckhXcXdOTVJDYkJTTzhkY0dWMFdZd0RRWUpLb1pJaHZjTkFRRUwKQlFBd09ERWZNQjBHQTFVRUF3d1dWMGxUUlMxRlpHZGxNelkxSUZKdmIzUWdRMlZ5ZERFVk1CTUdBMVVFQ2d3TQpWMGxUUlMxRlpHZGxNelkxTUI0WERUSXpNRFV3TlRBNE5EVXhNVm9YRFRJME1EVXdOREE0TkRVeE1Wb3dPREVmCk1CMEdBMVVFQXd3V1YwbFRSUzFGWkdkbE16WTFJRkp2YjNRZ1EyVnlkREVWTUJNR0ExVUVDZ3dNVjBsVFJTMUYKWkdkbE16WTFNSUlDSWpBTkJna3Foa2lHOXcwQkFRRUZBQU9DQWc4QU1JSUNDZ0tDQWdFQWx4aWFVY1c1TTFKSQpoL3ptbFlyUTIzR1lRQkZzZTg3cW5zRGJYOEVSRUNVM3Z6dkpESmMxVGQ3MUJQMTdGRWlLOGE5SGlIOVUvQnRECmNSbVV0bkhjNG1HSGI1S2NTNlpQZ2MrSi91Q2VPY3JlS3o2OFFsWWVMR05STTJmV2ZOcW9qNUlzRk9kZmoxVEoKQWNocUozcFJ1YnJ5T0VoZ0RFbEczOXRhclV3K1BQazFMSXhIcHFVTzlidEhFS29XdG5SZ1JIRTk0ckJ2K3pMcAplbXIxbUg2N3UweWFpVWNWUFk5QUk5enpMcDIvOG4yaWN2MFdId2M1dnJIcDU4R29Vb2tSQUNlRyt1a0o1K3RVCjJRVEllWU9rMVdpRkM0SzdxMnNhUGZrNkRFdVVhdHJTcXhOTmMyeVUxZWJuNTEzb2o5YStrMkdNRjNTNUkwczMKV0tzNExuTW9kU3dqUXQ5S3p5R01IR2J6OXpmS3JzOTNCWlJRMkFXQWZJRjlWMVE2N0RsdytCVG9ML2c5VkhKTwpldnN1eGEwZ0RUNVR2Q1psQ3FKbmlzUnVSYmVjRHh1RTZIaUhXNnVpeTVxZWM0V1A5SktZV0tsc1BEcnBpcGo3CjkxWnpHSDdNSlFmd3ZPZTBrKzRONUV4eEVjemtIdmhPbjhYWS9NaEJYS0w4aXJLSGpZSlZxQjVRc1k0VmZGWUYKMmprRXlUL01LRjJBZzYydG1VTU1IV1kzL2xSUTczQUx0R3FtU1Y5UnBjT0tEZ1Z0TDMzcUx2Q2xIamVtb1NrYQp5WG9uMVczS1pRSFlvY0lmVXhVazFRRUZsMFZDUHVTZ1pEZk56bXVCQndzbWIxRks4bERsMldqWWNXU3ptZGZ6ClNvSG9xS2xLcEhvbURjN3JITzJGaUlBT1BFM1RIaU1DQXdFQUFhTmpNR0V3SFFZRFZSME9CQllFRkhuZjZOMWsKSWlIRTdsazRqTVo5clRvMVNqOEtNQjhHQTFVZEl3UVlNQmFBRkhuZjZOMWtJaUhFN2xrNGpNWjlyVG8xU2o4SwpNQThHQTFVZEV3RUIvd1FGTUFNQkFmOHdEZ1lEVlIwUEFRSC9CQVFEQWdHR01BMEdDU3FHU0liM0RRRUJDd1VBCkE0SUNBUUF6UW5RWVlNTkZmNEFOQkVnUFFqQkxtcjQ3Ym1GR1RUanFnM1JmWkZrVit0NklUQnpjUEZoRXc4bHQKa2NSUU1IMHRtamFTMGRaVWRLcmJsT0w5QlMxUG5ER2tBdHN0aU5rZ0M3R2g3eVQ0WFFraDB4ekdzWTE3Y3F0awpLWnhLVTZZUStjZmRNazk3aUcvL2xRaDI0NlpOdzJMaXJKQUpDUWNXL2dZWnVCaW1IQnoxaUIyWUdwTTg5bEtXCks2V2tob1BJVE40OGhZUG1tQkMvU0E0dDRqUWVoMkdlaVRzcS9JNk8yQnZtWkQyMVZDT1ZxL3ZpN25QYlQxYm0Kem9yQXpmWHczd3dxSDh5MFdObHltTXNGUm9HYjRaNTg3aXByWUpqeUt3dUt0TUgyMHBVYVFKeUNyNUgrTnlMYQorN0diT0xlYzMvRkcvZ21pZkgrNm1UbDljZlc0UVFvSUMweDVURklGNy9KNk9jVU4vNERjUDFBUFltdEJQTXJUClZubmFuaVlIbDdxY1BMVTRja29uMmxmTkxCYlA1N2J1NHdrbUc4OWNybHJlYnFCZ2ZNc0pWTEVnODFHTEl4Nk0KZ1k1cnlrSVR3ekpEMEc4Q0hsRDJOM0FEMjg3QTZkM0ZveW0vME01bk1zRmFGNlExWGNoVnBTVmlaUlBvZWgvYQpPWDJKclhsS2J5V0VqSVBnZmpubytxN0liUHhNTllKQVFoYUkySVBNdE0rQjhtTStzZHNWMTlmUWFTNXdJd0s2CmRvbzJ1cHpiYWpZdVQySStHZG5YOHBycmRIQ2hzd09uNlFvYmdqNmI0SDgwSWFydmk1RG8rZWpxRTBJbkR2THYKYnhMWlE3c0tGM2RkTk5FVkxjVERSNlNTUmY2cW5ybU4wT3B1d0ZTYURZZkxybFVpV0E9PQotLS0tLUVORCBDRVJUSUZJQ0FURS0tLS0t",
            "iothubCertificate": "LS0tLS1CRUdJTiBDRVJUSUZJQ0FURS0tLS0tCk1JSUZyekNDQTVlZ0F3SUJBZ0lCRERBTkJna3Foa2lHOXcwQkFRc0ZBREJBTVJVd0V3WURWUVFLREF4WFNWTkYKTFVWa1oyVXpOalV4SnpBbEJnTlZCQU1NSGxkSlUwVXRSV1JuWlRNMk5TQkpiblJsY20xbFpHbGhkR1VnUTJWeQpkREFlRncweU16QTBNamN3TnpBME1EbGFGdzB5TkRBeU1qRXdOekEwTURsYU1DNHhGVEFUQmdOVkJBb01ERmRKClUwVXRSV1JuWlRNMk5URVZNQk1HQTFVRUF3d01NREJFTUVORU1EQXdNRFl6TUlJQ0lqQU5CZ2txaGtpRzl3MEIKQVFFRkFBT0NBZzhBTUlJQ0NnS0NBZ0VBck1RWjBRRGtxNTRMd1pXZnlZUUFjUWhkbUl5T05TTXNhSXorMFdoOApCRjhCQUt6bnorbUNYb25SdDA4Z0FMZTFPczY5d3lMRHU0Q3hYcFBRb3FYbnJ3RmZ2cXBLQjIwK0czSS9NSHE0CnZoQXFnVUJUNTdEblM3UzhCdEMrUGMxZVlkajFJVlg2QmUrQ0VTUEd2SEV0aUJBdE05eUJGRWk5ZTM1UDJ3em0KTFhZZFJzOFl1c1hmZjFDT2sreVAvYXlodktzOXgwSkwvY2NBa2pIb0hZVUtnekwrY1dFNFd0bmN5dStvYVQ0Rwp3QnVtYTlNMU1TRnpEaUVmVE5BdFZGeis4VUhBTk1tV1JCc1FpSUg1dTVTbGp4VXZSdHptdUIweXV4anJicVBRClNBTmtOR3BrZS9VSzBhNzVSUDVhMlI0OCtyTURDaU1icHJrVUxWKysxZDJ2STlnbnEvdTRXZm9VMmNYZEJDOTYKdUNYQ3pqMkNIVkRBU0RkckdsUXlvbTlla2FOMENjZVViMTZWeUFnWkxkanlDME5hYmVIQUtxT3pNNy9ZZFNzNQptS1pQNWlmVHhPZE9hL2lGbGFRdTEwRmVzNUI3VXkvOGs3MnVXRWl1T1ZpUzd3Mzk3WjBVaEV6bXFNSTRUUnhxCmFlTFpZdlFwcjJnRElablppd3N0UzNYQ2YrY2hUblJoTGd0NWtlTkM4eGcyT1pVWWlqY0FyYko3ZCtxd3BldEIKeFpOYmlEL1NDSC91bUNFLzFERjNWNU9USHZ2ZUhjaW1IaG1Sbk9pVit1Mml3TTBuTVFIZjIrUlJUdkJFR1NZZwpmYXdTMzNPV29jYWpUVDJDYzhCM1N5NTR2NnZmRUg5dDU3VEZaaG1QbXhmMFloRi9vYzAxRzNnVjdKaEtTdW5VCk5uOENBd0VBQWFPQnhUQ0J3akFKQmdOVkhSTUVBakFBTUJFR0NXQ0dTQUdHK0VJQkFRUUVBd0lGb0RBekJnbGcKaGtnQmh2aENBUTBFSmhZa1QzQmxibE5UVENCSFpXNWxjbUYwWldRZ1EyeHBaVzUwSUVObGNuUnBabWxqWVhSbApNQjBHQTFVZERnUVdCQlI3K0ZoQ0hBSDU4ZUlxeW9uOWZnaUFwUWdsa2pBZkJnTlZIU01FR0RBV2dCU2tQTndRCmRYODhIM3IzVW4yTHQrdFVuS0RlbERBT0JnTlZIUThCQWY4RUJBTUNCZUF3SFFZRFZSMGxCQll3RkFZSUt3WUIKQlFVSEF3SUdDQ3NHQVFVRkJ3TUVNQTBHQ1NxR1NJYjNEUUVCQ3dVQUE0SUNBUUFvbmNSMzdwbTd5Y01HS1ZLYgpWMHRuOVczN0lIbXFUaDE0RzJpbGlZWjZqbUxueDBOSXVhZ3ZjMERGM25Sam9sNXR5bDZSZW04OHkyQmp4OVZWCjR4NExIY25mZHJLWG1GeTBpbDVtdVBQcFpvMUdsY1ZmNU5ibHVpejdFVERNdTVkWEdEMStXR20wMTlWZVlzVkIKRi94aEpWKyt1Q2lDZjA5MDU4ZWFIaWkzVEhnd2w5c20rL0tlTWpDQnB5cUxGS1VWOXBKaHk1OCs3MjZ2ZHFUcApLUUhoR1E5TjNTVlFLcGJWT1JzNm0rMU1yK0E5UjBRYzhOUWRxanpyZE9VQnRtY3l2UkIwZm11UFd0bDVtOWFDCmxqLytKNGptdnNzR3JtMm9XRlh2THl6UFltWUhHaXRTSkxoeGdZOG4waldJZmNSZmlYWWdicGFyMkMvZFg5cVQKbUlHQXNlZnlSR3NWaFpoRitsL1Btb20wQlNERkExZDJJWUlwbHNUandhT1RiRGZlTWRrYmEzaEdSOFp2a0pXdQpvVWFQNlpuWDZSZ2Q5bUhhelQ2Z3hNM0R6bDRoOXd0QWdJWUdxMk42MXErOVFldnFNMUZwL1dSc1JoeDBkU01tCmNnVnZMdTUwYmMrakdNdDdIZHNxMk1UOVJuMzltTUZGd3lncnFXVzMrT2JSL0RhSHlBSFhoQ3dxY0FQUGIxbTgKWnVRUVJhMFRhdUpIOVcwTFVMQXZDTVZCMWpJM1RXeUVndUpseFFrWUlPVVY4T2lBMXhRNHV2cWtMbnQ5NVRHVQpVYjEvSnFVYVNHaEdJVUo0TEptWFoxUzIxSW5SK0FQR0VPNlNIT01Ta1V0L1NmcHMvQmFZdnFzTHQyNVFKbUxvCmZDVTFuZjNUcCtveDVVUHFLYjBJdDdPWWd3PT0KLS0tLS1FTkQgQ0VSVElGSUNBVEUtLS0tLQ==",
            "iothubPrivateKey": "LS0tLS1CRUdJTiBQUklWQVRFIEtFWS0tLS0tCk1JSUpRQUlCQURBTkJna3Foa2lHOXcwQkFRRUZBQVNDQ1Nvd2dna21BZ0VBQW9JQ0FRQ3N4Qm5SQU9Tcm5ndkIKbFovSmhBQnhDRjJZakk0MUl5eG9qUDdSYUh3RVh3RUFyT2ZQNllKZWlkRzNUeUFBdDdVNnpyM0RJc083Z0xGZQprOUNpcGVldkFWKytxa29IYlQ0YmNqOHdlcmkrRUNxQlFGUG5zT2RMdEx3RzBMNDl6VjVoMlBVaFZmb0Y3NElSCkk4YThjUzJJRUMwejNJRVVTTDE3ZmsvYkRPWXRkaDFHenhpNnhkOS9VSTZUN0kvOXJLRzhxejNIUWt2OXh3Q1MKTWVnZGhRcURNdjV4WVRoYTJkeks3NmhwUGdiQUc2WnIwelV4SVhNT0lSOU0wQzFVWFA3eFFjQTB5WlpFR3hDSQpnZm03bEtXUEZTOUczT2E0SFRLN0dPdHVvOUJJQTJRMGFtUjc5UXJScnZsRS9sclpIano2c3dNS0l4dW11UlF0Clg3N1YzYThqMkNlcis3aForaFRaeGQwRUwzcTRKY0xPUFlJZFVNQklOMnNhVkRLaWIxNlJvM1FKeDVSdlhwWEkKQ0JrdDJQSUxRMXB0NGNBcW83TXp2OWgxS3ptWXBrL21KOVBFNTA1citJV1ZwQzdYUVY2emtIdFRML3lUdmE1WQpTSzQ1V0pMdkRmM3RuUlNFVE9hb3dqaE5IR3BwNHRsaTlDbXZhQU1obWRtTEN5MUxkY0ovNXlGT2RHRXVDM21SCjQwTHpHRFk1bFJpS053Q3RzbnQzNnJDbDYwSEZrMXVJUDlJSWYrNllJVC9VTVhkWGs1TWUrOTRkeUtZZUdaR2MKNkpYNjdhTEF6U2N4QWQvYjVGRk84RVFaSmlCOXJCTGZjNWFoeHFOTlBZSnp3SGRMTG5pL3E5OFFmMjNudE1WbQpHWStiRi9SaUVYK2h6VFViZUJYc21FcEs2ZFEyZndJREFRQUJBb0lDQURocDhHUW0vb1JybnpzZk9JWDg3SWY4ClMxTzgwZExZSVhBaVdqTFhBMmdKL2JIU3cvOUlLS0htTHV6RWtaYXFaaXRGeHdFcElQRGhIUW5kQ291UjBRMTgKVFY5ZEM3OVJGSzZ4cDZDVThpNWQ2UU03bGlwWndhMGUzeWI2a3FScm94NGdVaXNJZ0JQZ0dZQ3ZSZjNTbHlPTwo1TFBDbFFPaW5QenVTZlVsU1NRZkpZQXhyOG1OUTJXM1VGZE5MOWVOdjJKMEtFQWdqZC9ZVTM5cGZIbm5MMytYCjd5M21xUmhCZTY5b2duMmJHMmt2bmpBblQzOHpoUFpnS25CU3FmcWFRMFZVU3dieHJIZWd2czFVWTgrMHdqcnUKbC9senVJTDJSZEtDV0o1UUwzclVZS3djOGFMb2FSZi9Jclk4dUQyZGVod0N5RU5QSTRCVmZ4a3g0b2JEVktTKwpVNzJhZ1VvMVdtc1haRDlyaU5ESHFXUCtZYXZlQ1JkMHYyN1pCZXo2SG9FTjVIUGduTzhoNmNBc2txNjd5Q2lMCllCbTJBMFJQT1ZNUzRSbkVDTVM5Ync0clRpVUkreTdkZW56dXdUaWdVNW1QbzlHMjVuY2dWSlJiRWs0VTJ1R2YKSzRYUGZtb1pKbkhZc3Jra3ArOWlvRm5FNFJIcnozd0F2b0Y5TzQxTUxmOXZraXUrTlNRZXNkeUZrbTJOdHlJcQpJNTNaSUcwdy9wRldaTVNZYUNpdkJlNStaTlBpckdyc2hqMHVaZEh2WHk3UVZVVjNzblBWYWJHS2luZmI1b1VMCmliRkVMV3VLdmoxdk9jbFBNcFRyOUJ2b2dJdjJmZUZ0VGlCZnRtVzVJL2dvUXJEOTRwYS8vN3hxOXRmOFhaL1gKUFR2OGEvWkR5bHB1RTlqT3JaWkJBb0lCQVFEWDlsN3djc2NJeWZkRVNNQTAyUUtFZDEyY2RhWnNLOTI1ZFo0egpTWmhOQ1JuL2NrSHk5MC9IM3c0RDdsL1pJNndWckR6QnlhZ2l4Y29hbGtCTzBzeTVQWXgxR3dhTUdiamdEZkU4CnlNR2p6VUNlby93b0tjUkJCR3AxTGdWV3ltSUdFTTNFNWxJWXI4OFIxODFueXV1NkhiSVdISnJDaDNxNHJQNDAKWEdOYldhWFR5Yi9Fam1UUEttUkhXTG5YSDZqQUtYRTdOMXkvUjlTUEs0bWgrL1FHWlM2bzVjUlVmREZZc08xVwpMZkdraVVxRGxZT0VYS3dxSFNjZ2oxeTRhRGczdnFVNFFTL1pGQ2hoWnVaMHFTL3pja2p2cUJPL21NSUwwemgyClUxVEI5Q01rR2dJSHU0L204elBYVnllbnBpbnVJeThCUVJOekphQ1g1MTJlbU9wTEFvSUJBUURNeTU2YUtxQXEKWHVHSENzSHNqNUlHQ3JQUVdsYU1xcjZMRlU5dVJuZTJEZkRYVlIxc0dVQWtEYkdkV2FpWk9sM0wzY3BFMkF5UgovWThEcWw2R2Jvb0NkcG9UblhiNVRScnNWVUc0cThNYVQ4YU1iZlVBRWM0cFhCRnVYR1d2a0pXR0dDRlc3d095CjBmSWFXK0lYOHB2THR3dHZBUWxrR2pzRm15ZFo5ak1peXJYdC85c05ONGdFY2JBT1lzVDUxS0VWOFFNQzQ0N3kKZktGSjFvUW4wUFJsUTFLK04xMC8wOXFSL3FqNmN3WXJzdzBJN3o2R204MGoxVG5xNktLSXN3SjdaSkNaSFhxcApCMFRVY3EwdHZDaXoxSFdpZ0x0L09ER3M4K0IreW1yTlFGeDBzUEhBR1hRQk93Z2VNcXh3SkluLy9KejdJbW9GCkgyY3M2SEZ0T1lRZEFvSUJBUUMzSnI1RmRWSE81bG5KazFsT2VHeG1JMFZFbDVKWVVxdHJ5WkF0TnREdkpEVGsKS3VZN1EvcHBLNFliVjJINktRS2NMc0lvSnZsczVBa09telpXb3ZmMGNYcFpKbDViR3NWclh1ZWtBUzRYMk01Zwp1L254cGRwR3VaUC9aTlFxVXVEbS9BRkdaMzVnYVZsWGJJbEs2UkVaZW0yNXl2Q0U0WmoyWGVBSVVBSURTdmdUCnNSbnRmRVdLWEExSFpMdlc4WWFQMFpXeC9yV3RreUYxZWhyelFWWW14bERYOUdTWXNlcTNxUFRmRFgvTlpwSEgKSGxtM08xRFhObm9rWnZEZmc2T0p3eWtqbUVVWCtMeDJQbXBicmRCNHlnZUpHQ1lIYTJuRjFaQWc2WE1NT2h4RApWYnM3QzVweTV2YWtQY25ucUVnUEtjK0haTVUxOWtkSURIT2RPVm9aQW9JQkFGUy9Maks5ME9tM3Vid1lSNGVOCklmQStIWXJxMTBYK29qc0w1b0xMeGw0Z0Jyb1ZEc2ZjNng0QVRLL0FtblJPSXVKcU5YbW5yZ3Y3MFdMQzdiclQKbzJqQmk2RHlXSGx4M3VKTnBaUzEvMWEwRElXd091SjhlOFBCeGJUVnAzNnZaakRIYTRSK0JCbkxwMVFoRWI2MwpOcUZtYmVUUm1RRkRtWWtJVzVCdXdWcDBhRFRFMi9Ec09lMGMzcTRWVVUzUkg1ZmsxRW90d01tM3FVYlU3bnRMCmpOY2F0UExpRmtTRGRyOVRrcm1SUDh4MW03OUd3YWtTY0NHVDZ4TzZrUWZnaS9aajl6SmxjSXpoNVNuRkNzVVMKU0FXaXRjczVXbDJhODNPT3VDZS91OUtULzY2S1NvQWtDRTA2RUhIdXBrMEIwZG1NdjZsczVGS2FYQ2ZKU0tiYQpWa0VDZ2Y4WDhIc1NjTFZZVlUvTTB0YzF1a1pUNG5QR2lXMWpEMHN6Wm5NdHdmYjJxcHZXZTVndzc1ajNma0V5CkpDWVY5dCtHMnFZR2dJeFlSU09IeEgwbFBqVEt2SFhnVi9IWHUrVXBIVUg0SVQ4emh1ZmtpZ2dVNmYrOStjc0YKMUVrTDg0Z1dFTW13UVg1cHpXYkdtZDZzNnNFTHF1OGVmUUVqYkU2K21FWkowMHgxYTUxYkdDNnJtVmRxNmc3aQpuQnR4clNlekw2MnN5ZFpKVmpnb21Kc2k5WkNWajd5UkFkYzZ6aU15eWlxZ1dNSFdzN0xhMXJFRkU5aVVtS3I5CjlkRDNzWTNKTCtONi9EcUtGTENBU2ZlSTB4QUpFQm9Vai96eDB0YWh5dWxNSHpwN1ZTb3c1MkNVcm5SN2tJclIKT1FpVkJWTFNSYUFUUWdLL1V6L0swUGUvQ2hBPQotLS0tLUVORCBQUklWQVRFIEtFWS0tLS0t",
            "rabbitmqCertificate": "LS0tLS1CRUdJTiBDRVJUSUZJQ0FURS0tLS0tCk1JSUZyekNDQTVlZ0F3SUJBZ0lCRERBTkJna3Foa2lHOXcwQkFRc0ZBREJBTVJVd0V3WURWUVFLREF4WFNWTkYKTFVWa1oyVXpOalV4SnpBbEJnTlZCQU1NSGxkSlUwVXRSV1JuWlRNMk5TQkpiblJsY20xbFpHbGhkR1VnUTJWeQpkREFlRncweU16QTBNamN3TnpBME1EbGFGdzB5TkRBeU1qRXdOekEwTURsYU1DNHhGVEFUQmdOVkJBb01ERmRKClUwVXRSV1JuWlRNMk5URVZNQk1HQTFVRUF3d01NREJFTUVORU1EQXdNRFl6TUlJQ0lqQU5CZ2txaGtpRzl3MEIKQVFFRkFBT0NBZzhBTUlJQ0NnS0NBZ0VBck1RWjBRRGtxNTRMd1pXZnlZUUFjUWhkbUl5T05TTXNhSXorMFdoOApCRjhCQUt6bnorbUNYb25SdDA4Z0FMZTFPczY5d3lMRHU0Q3hYcFBRb3FYbnJ3RmZ2cXBLQjIwK0czSS9NSHE0CnZoQXFnVUJUNTdEblM3UzhCdEMrUGMxZVlkajFJVlg2QmUrQ0VTUEd2SEV0aUJBdE05eUJGRWk5ZTM1UDJ3em0KTFhZZFJzOFl1c1hmZjFDT2sreVAvYXlodktzOXgwSkwvY2NBa2pIb0hZVUtnekwrY1dFNFd0bmN5dStvYVQ0Rwp3QnVtYTlNMU1TRnpEaUVmVE5BdFZGeis4VUhBTk1tV1JCc1FpSUg1dTVTbGp4VXZSdHptdUIweXV4anJicVBRClNBTmtOR3BrZS9VSzBhNzVSUDVhMlI0OCtyTURDaU1icHJrVUxWKysxZDJ2STlnbnEvdTRXZm9VMmNYZEJDOTYKdUNYQ3pqMkNIVkRBU0RkckdsUXlvbTlla2FOMENjZVViMTZWeUFnWkxkanlDME5hYmVIQUtxT3pNNy9ZZFNzNQptS1pQNWlmVHhPZE9hL2lGbGFRdTEwRmVzNUI3VXkvOGs3MnVXRWl1T1ZpUzd3Mzk3WjBVaEV6bXFNSTRUUnhxCmFlTFpZdlFwcjJnRElablppd3N0UzNYQ2YrY2hUblJoTGd0NWtlTkM4eGcyT1pVWWlqY0FyYko3ZCtxd3BldEIKeFpOYmlEL1NDSC91bUNFLzFERjNWNU9USHZ2ZUhjaW1IaG1Sbk9pVit1Mml3TTBuTVFIZjIrUlJUdkJFR1NZZwpmYXdTMzNPV29jYWpUVDJDYzhCM1N5NTR2NnZmRUg5dDU3VEZaaG1QbXhmMFloRi9vYzAxRzNnVjdKaEtTdW5VCk5uOENBd0VBQWFPQnhUQ0J3akFKQmdOVkhSTUVBakFBTUJFR0NXQ0dTQUdHK0VJQkFRUUVBd0lGb0RBekJnbGcKaGtnQmh2aENBUTBFSmhZa1QzQmxibE5UVENCSFpXNWxjbUYwWldRZ1EyeHBaVzUwSUVObGNuUnBabWxqWVhSbApNQjBHQTFVZERnUVdCQlI3K0ZoQ0hBSDU4ZUlxeW9uOWZnaUFwUWdsa2pBZkJnTlZIU01FR0RBV2dCU2tQTndRCmRYODhIM3IzVW4yTHQrdFVuS0RlbERBT0JnTlZIUThCQWY4RUJBTUNCZUF3SFFZRFZSMGxCQll3RkFZSUt3WUIKQlFVSEF3SUdDQ3NHQVFVRkJ3TUVNQTBHQ1NxR1NJYjNEUUVCQ3dVQUE0SUNBUUFvbmNSMzdwbTd5Y01HS1ZLYgpWMHRuOVczN0lIbXFUaDE0RzJpbGlZWjZqbUxueDBOSXVhZ3ZjMERGM25Sam9sNXR5bDZSZW04OHkyQmp4OVZWCjR4NExIY25mZHJLWG1GeTBpbDVtdVBQcFpvMUdsY1ZmNU5ibHVpejdFVERNdTVkWEdEMStXR20wMTlWZVlzVkIKRi94aEpWKyt1Q2lDZjA5MDU4ZWFIaWkzVEhnd2w5c20rL0tlTWpDQnB5cUxGS1VWOXBKaHk1OCs3MjZ2ZHFUcApLUUhoR1E5TjNTVlFLcGJWT1JzNm0rMU1yK0E5UjBRYzhOUWRxanpyZE9VQnRtY3l2UkIwZm11UFd0bDVtOWFDCmxqLytKNGptdnNzR3JtMm9XRlh2THl6UFltWUhHaXRTSkxoeGdZOG4waldJZmNSZmlYWWdicGFyMkMvZFg5cVQKbUlHQXNlZnlSR3NWaFpoRitsL1Btb20wQlNERkExZDJJWUlwbHNUandhT1RiRGZlTWRrYmEzaEdSOFp2a0pXdQpvVWFQNlpuWDZSZ2Q5bUhhelQ2Z3hNM0R6bDRoOXd0QWdJWUdxMk42MXErOVFldnFNMUZwL1dSc1JoeDBkU01tCmNnVnZMdTUwYmMrakdNdDdIZHNxMk1UOVJuMzltTUZGd3lncnFXVzMrT2JSL0RhSHlBSFhoQ3dxY0FQUGIxbTgKWnVRUVJhMFRhdUpIOVcwTFVMQXZDTVZCMWpJM1RXeUVndUpseFFrWUlPVVY4T2lBMXhRNHV2cWtMbnQ5NVRHVQpVYjEvSnFVYVNHaEdJVUo0TEptWFoxUzIxSW5SK0FQR0VPNlNIT01Ta1V0L1NmcHMvQmFZdnFzTHQyNVFKbUxvCmZDVTFuZjNUcCtveDVVUHFLYjBJdDdPWWd3PT0KLS0tLS1FTkQgQ0VSVElGSUNBVEUtLS0tLQ==",
            "rabbitmqPrivateKey": "LS0tLS1CRUdJTiBQUklWQVRFIEtFWS0tLS0tCk1JSUpRQUlCQURBTkJna3Foa2lHOXcwQkFRRUZBQVNDQ1Nvd2dna21BZ0VBQW9JQ0FRQ3N4Qm5SQU9Tcm5ndkIKbFovSmhBQnhDRjJZakk0MUl5eG9qUDdSYUh3RVh3RUFyT2ZQNllKZWlkRzNUeUFBdDdVNnpyM0RJc083Z0xGZQprOUNpcGVldkFWKytxa29IYlQ0YmNqOHdlcmkrRUNxQlFGUG5zT2RMdEx3RzBMNDl6VjVoMlBVaFZmb0Y3NElSCkk4YThjUzJJRUMwejNJRVVTTDE3ZmsvYkRPWXRkaDFHenhpNnhkOS9VSTZUN0kvOXJLRzhxejNIUWt2OXh3Q1MKTWVnZGhRcURNdjV4WVRoYTJkeks3NmhwUGdiQUc2WnIwelV4SVhNT0lSOU0wQzFVWFA3eFFjQTB5WlpFR3hDSQpnZm03bEtXUEZTOUczT2E0SFRLN0dPdHVvOUJJQTJRMGFtUjc5UXJScnZsRS9sclpIano2c3dNS0l4dW11UlF0Clg3N1YzYThqMkNlcis3aForaFRaeGQwRUwzcTRKY0xPUFlJZFVNQklOMnNhVkRLaWIxNlJvM1FKeDVSdlhwWEkKQ0JrdDJQSUxRMXB0NGNBcW83TXp2OWgxS3ptWXBrL21KOVBFNTA1citJV1ZwQzdYUVY2emtIdFRML3lUdmE1WQpTSzQ1V0pMdkRmM3RuUlNFVE9hb3dqaE5IR3BwNHRsaTlDbXZhQU1obWRtTEN5MUxkY0ovNXlGT2RHRXVDM21SCjQwTHpHRFk1bFJpS053Q3RzbnQzNnJDbDYwSEZrMXVJUDlJSWYrNllJVC9VTVhkWGs1TWUrOTRkeUtZZUdaR2MKNkpYNjdhTEF6U2N4QWQvYjVGRk84RVFaSmlCOXJCTGZjNWFoeHFOTlBZSnp3SGRMTG5pL3E5OFFmMjNudE1WbQpHWStiRi9SaUVYK2h6VFViZUJYc21FcEs2ZFEyZndJREFRQUJBb0lDQURocDhHUW0vb1JybnpzZk9JWDg3SWY4ClMxTzgwZExZSVhBaVdqTFhBMmdKL2JIU3cvOUlLS0htTHV6RWtaYXFaaXRGeHdFcElQRGhIUW5kQ291UjBRMTgKVFY5ZEM3OVJGSzZ4cDZDVThpNWQ2UU03bGlwWndhMGUzeWI2a3FScm94NGdVaXNJZ0JQZ0dZQ3ZSZjNTbHlPTwo1TFBDbFFPaW5QenVTZlVsU1NRZkpZQXhyOG1OUTJXM1VGZE5MOWVOdjJKMEtFQWdqZC9ZVTM5cGZIbm5MMytYCjd5M21xUmhCZTY5b2duMmJHMmt2bmpBblQzOHpoUFpnS25CU3FmcWFRMFZVU3dieHJIZWd2czFVWTgrMHdqcnUKbC9senVJTDJSZEtDV0o1UUwzclVZS3djOGFMb2FSZi9Jclk4dUQyZGVod0N5RU5QSTRCVmZ4a3g0b2JEVktTKwpVNzJhZ1VvMVdtc1haRDlyaU5ESHFXUCtZYXZlQ1JkMHYyN1pCZXo2SG9FTjVIUGduTzhoNmNBc2txNjd5Q2lMCllCbTJBMFJQT1ZNUzRSbkVDTVM5Ync0clRpVUkreTdkZW56dXdUaWdVNW1QbzlHMjVuY2dWSlJiRWs0VTJ1R2YKSzRYUGZtb1pKbkhZc3Jra3ArOWlvRm5FNFJIcnozd0F2b0Y5TzQxTUxmOXZraXUrTlNRZXNkeUZrbTJOdHlJcQpJNTNaSUcwdy9wRldaTVNZYUNpdkJlNStaTlBpckdyc2hqMHVaZEh2WHk3UVZVVjNzblBWYWJHS2luZmI1b1VMCmliRkVMV3VLdmoxdk9jbFBNcFRyOUJ2b2dJdjJmZUZ0VGlCZnRtVzVJL2dvUXJEOTRwYS8vN3hxOXRmOFhaL1gKUFR2OGEvWkR5bHB1RTlqT3JaWkJBb0lCQVFEWDlsN3djc2NJeWZkRVNNQTAyUUtFZDEyY2RhWnNLOTI1ZFo0egpTWmhOQ1JuL2NrSHk5MC9IM3c0RDdsL1pJNndWckR6QnlhZ2l4Y29hbGtCTzBzeTVQWXgxR3dhTUdiamdEZkU4CnlNR2p6VUNlby93b0tjUkJCR3AxTGdWV3ltSUdFTTNFNWxJWXI4OFIxODFueXV1NkhiSVdISnJDaDNxNHJQNDAKWEdOYldhWFR5Yi9Fam1UUEttUkhXTG5YSDZqQUtYRTdOMXkvUjlTUEs0bWgrL1FHWlM2bzVjUlVmREZZc08xVwpMZkdraVVxRGxZT0VYS3dxSFNjZ2oxeTRhRGczdnFVNFFTL1pGQ2hoWnVaMHFTL3pja2p2cUJPL21NSUwwemgyClUxVEI5Q01rR2dJSHU0L204elBYVnllbnBpbnVJeThCUVJOekphQ1g1MTJlbU9wTEFvSUJBUURNeTU2YUtxQXEKWHVHSENzSHNqNUlHQ3JQUVdsYU1xcjZMRlU5dVJuZTJEZkRYVlIxc0dVQWtEYkdkV2FpWk9sM0wzY3BFMkF5UgovWThEcWw2R2Jvb0NkcG9UblhiNVRScnNWVUc0cThNYVQ4YU1iZlVBRWM0cFhCRnVYR1d2a0pXR0dDRlc3d095CjBmSWFXK0lYOHB2THR3dHZBUWxrR2pzRm15ZFo5ak1peXJYdC85c05ONGdFY2JBT1lzVDUxS0VWOFFNQzQ0N3kKZktGSjFvUW4wUFJsUTFLK04xMC8wOXFSL3FqNmN3WXJzdzBJN3o2R204MGoxVG5xNktLSXN3SjdaSkNaSFhxcApCMFRVY3EwdHZDaXoxSFdpZ0x0L09ER3M4K0IreW1yTlFGeDBzUEhBR1hRQk93Z2VNcXh3SkluLy9KejdJbW9GCkgyY3M2SEZ0T1lRZEFvSUJBUUMzSnI1RmRWSE81bG5KazFsT2VHeG1JMFZFbDVKWVVxdHJ5WkF0TnREdkpEVGsKS3VZN1EvcHBLNFliVjJINktRS2NMc0lvSnZsczVBa09telpXb3ZmMGNYcFpKbDViR3NWclh1ZWtBUzRYMk01Zwp1L254cGRwR3VaUC9aTlFxVXVEbS9BRkdaMzVnYVZsWGJJbEs2UkVaZW0yNXl2Q0U0WmoyWGVBSVVBSURTdmdUCnNSbnRmRVdLWEExSFpMdlc4WWFQMFpXeC9yV3RreUYxZWhyelFWWW14bERYOUdTWXNlcTNxUFRmRFgvTlpwSEgKSGxtM08xRFhObm9rWnZEZmc2T0p3eWtqbUVVWCtMeDJQbXBicmRCNHlnZUpHQ1lIYTJuRjFaQWc2WE1NT2h4RApWYnM3QzVweTV2YWtQY25ucUVnUEtjK0haTVUxOWtkSURIT2RPVm9aQW9JQkFGUy9Maks5ME9tM3Vid1lSNGVOCklmQStIWXJxMTBYK29qc0w1b0xMeGw0Z0Jyb1ZEc2ZjNng0QVRLL0FtblJPSXVKcU5YbW5yZ3Y3MFdMQzdiclQKbzJqQmk2RHlXSGx4M3VKTnBaUzEvMWEwRElXd091SjhlOFBCeGJUVnAzNnZaakRIYTRSK0JCbkxwMVFoRWI2MwpOcUZtYmVUUm1RRkRtWWtJVzVCdXdWcDBhRFRFMi9Ec09lMGMzcTRWVVUzUkg1ZmsxRW90d01tM3FVYlU3bnRMCmpOY2F0UExpRmtTRGRyOVRrcm1SUDh4MW03OUd3YWtTY0NHVDZ4TzZrUWZnaS9aajl6SmxjSXpoNVNuRkNzVVMKU0FXaXRjczVXbDJhODNPT3VDZS91OUtULzY2S1NvQWtDRTA2RUhIdXBrMEIwZG1NdjZsczVGS2FYQ2ZKU0tiYQpWa0VDZ2Y4WDhIc1NjTFZZVlUvTTB0YzF1a1pUNG5QR2lXMWpEMHN6Wm5NdHdmYjJxcHZXZTVndzc1ajNma0V5CkpDWVY5dCtHMnFZR2dJeFlSU09IeEgwbFBqVEt2SFhnVi9IWHUrVXBIVUg0SVQ4emh1ZmtpZ2dVNmYrOStjc0YKMUVrTDg0Z1dFTW13UVg1cHpXYkdtZDZzNnNFTHF1OGVmUUVqYkU2K21FWkowMHgxYTUxYkdDNnJtVmRxNmc3aQpuQnR4clNlekw2MnN5ZFpKVmpnb21Kc2k5WkNWajd5UkFkYzZ6aU15eWlxZ1dNSFdzN0xhMXJFRkU5aVVtS3I5CjlkRDNzWTNKTCtONi9EcUtGTENBU2ZlSTB4QUpFQm9Vai96eDB0YWh5dWxNSHpwN1ZTb3c1MkNVcm5SN2tJclIKT1FpVkJWTFNSYUFUUWdLL1V6L0swUGUvQ2hBPQotLS0tLUVORCBQUklWQVRFIEtFWS0tLS0t",
            "createdDate": "2023-04-27T07:04:08.461Z"
        }
*/
router.get('/device/:serialNo', (req, res) => {
    let serialNo = req.params.serialNo;

    certCtrl.getCaCertAndDeviceCert(serialNo)
        .then(certs => {
            if (!certs.status) throw new Error(certs.message);
            return res.send({
                caName: certs.deviceCertInfo.caName,
                iothubCaName: certs.deviceCertInfo.iothubCaName,
                rabbitmqCaName: certs.deviceCertInfo.rabbitmqCaName,
                status: certs.deviceCertInfo.status,
                caCertificateValidity: certs.deviceCertInfo.intermediateExpiryTime,
                deviceCertificateValidity: certs.deviceCertInfo.expiryTime,
                ca: (certs.deviceCertInfo.caContent === '') ? certs.deviceCertInfo.caContent : Buffer.from(certs.deviceCertInfo.caContent).toString('base64'),
                iothubCertificate: (certs.deviceCertInfo.iothubCertificate === '') ? certs.deviceCertInfo.iothubCertificate : Buffer.from(certs.deviceCertInfo.iothubCertificate).toString('base64'),
                iothubPrivateKey: (certs.deviceCertInfo.iothubPrivateKey === '') ? certs.deviceCertInfo.iothubPrivateKey : Buffer.from(certs.deviceCertInfo.iothubPrivateKey).toString('base64'),
                rabbitmqCertificate: (certs.deviceCertInfo.rabbitmqCertificate === '') ? certs.deviceCertInfo.rabbitmqCertificate : Buffer.from(certs.deviceCertInfo.rabbitmqCertificate).toString('base64'),
                rabbitmqPrivateKey: (certs.deviceCertInfo.rabbitmqPrivateKey === '') ? certs.deviceCertInfo.rabbitmqPrivateKey : Buffer.from(certs.deviceCertInfo.rabbitmqPrivateKey).toString('base64'),
                createdDate: certs.deviceCertInfo.createTime
            })
        })
        .catch(error => {
            logger.error('api get device cert info: ', error.message);
            responseError(res, error.message);
        })
});

// API: /cert/ca/:orgId
/**
    @api {get} /cert/ca/:orgId Get ca cert
    @apiVersion 0.1.0
    @apiDescription Get ca cert
    @apiGroup Cert
    @apiHeaderExample {json} Header-Example:
        {
            "X-Cert-Token": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhY2NvdW50TmFtZSI6InRvbS5jaG91QGFkdmFudGVjaC5jb20udHciLCJpYXQiOjE2ODY2MTk2MjgsImV4cCI6MTY4NjYxOTgwOH0.2lAyJ84lDZznnmWcU0lXaL_WSIwT1DMSCBcQjYygjbc"
        }

    @apiParam {Number} orgId the orgId of the tenant
    @apiParamExample Request-Example:
        http://4.193.252.254:3000/v1.0/cert/ca/1

    @apiSuccess {String} caName the name of the ca cert
    @apiSuccess {Base64} caCertificate the CA of the root and intermediate cert pem

    @apiSuccessExample {json} Success-Response:
        HTTP/1.1 200 OK
        {
            "caName": "ca",
            "caCertificate": "LS0tLS1CRUdJTiBDRVJUSUZJQ0FURS0tLS0tCk1JSUZWakNDQXo2Z0F3SUJBZ0lCQlRBTkJna3Foa2lHOXcwQkFRc0ZBREE0TVI4d0hRWURWUVFEREJaWFNWTkYKTFVWa1oyVXpOalVnVW05dmRDQkRaWEowTVJVd0V3WURWUVFLREF4WFNWTkZMVVZrWjJVek5qVXdIaGNOTWpNdwpOVEExTURnME5URTNXaGNOTWpRd05UQTBNRGcwTlRFM1dqQkFNUlV3RXdZRFZRUUtEQXhYU1ZORkxVVmtaMlV6Ck5qVXhKekFsQmdOVkJBTU1IbGRKVTBVdFJXUm5aVE0yTlNCSmJuUmxjbTFsWkdsaGRHVWdRMlZ5ZERDQ0FpSXcKRFFZSktvWklodmNOQVFFQkJRQURnZ0lQQURDQ0Fnb0NnZ0lCQU1wSnYwOGx5SkRjMXgxZHM4bWdvUnBhVXYzcwptRmVwT1ROT1RpbXNBcWhWVFNqdDdnTC9MdGtIOVBjWElJN2ZGZVNWMENDQVlTVjhuR0dtSWpMVkZWMGdPVnJjCkNxWHdwcXMwR296Z2J2VnMyTjUyQis4a0xOY0psM1VlYnZOOGlHYjQ0akE5QVprR0JwdkZ3Z1lrNCsrZHpNOVAKdlJ6Mk42bzg1S0daQ282VnpBNWMxYURhNmVqVWVFRVFZTWJKaWo2VittdG1uQnZBTXlLdStYMjhUeGtHN2s3egpaNkhxb1RBb3hDSFNjZTY1M0s5WDZTRFdGY2JwRCt1SWlvU2kreFZrQjR1ZmxCT0ZlV1pqZUhqdVE2V1oxZmZjCldINDBuRFFzVHN2RS9HNU8ybXNGYmFFeWZjSC8yRCtGdEFCcWVReGZiN3lRSU9ocFlQZklnd1ZJS3dNaU53cVMKaVB6MG9BZVpHK0JWNFlnQkJiRmV5eW9zSDNTcnFsQURHSG9oK0pqQVZCUzhqUmI1ZFl4Wi9vNC96WkR4M1ZEbwo3NmZOTDdObUd1OUxyUVFza3R3RDRsL0g0MFdOZ1lGeU8zVVVIZUh2dFFhRnRKV0V3RmtKdmorUDd6a1NpVzRLCkhIdU4ya2JPS2E3RWU3TzRYUnBTOU1TVVZtbEwxYmVGUjlmMXUyS2drVWVSSEpIUGZEOTNaRkh4R0ZuNUpJWjgKN0hWWkpsUEs3aGlTYk4vNVczV3ZhWmFMZU51NG5Tejh1bGFBT1o5d3Q1aFhoVDJ6L2xNZ0QzOFM4bjdZN0g3NApNMm5ZYjY5NDdDZlhxaEtkeEhUKzRWcWh6em4vQ09KOTMrYk1jSVBFRytscGxHRXN3QTdJR2FaVTlCeHFuUHRBCk1wdGVBcHpBbEJIektxTVRBZ01CQUFHall6QmhNQjBHQTFVZERnUVdCQlNYanhkcWl4Vmd0NFpIaXdvOFJwSVkKQTJPVnNUQWZCZ05WSFNNRUdEQVdnQlI1MytqZFpDSWh4TzVaT0l6R2ZhMDZOVW8vQ2pBUEJnTlZIUk1CQWY4RQpCVEFEQVFIL01BNEdBMVVkRHdFQi93UUVBd0lCaGpBTkJna3Foa2lHOXcwQkFRc0ZBQU9DQWdFQUY1ZHFGemZlCnliZUUwa0E0MkFQUjlVWFppVjN6Z084SlNzSXNhOVNmaWdyZ3ZyZ3g0eW15R3VPSm00ZVFpbFVpQ1J1Q0x3V0EKTndhaFFJZWxXVDg0SWp3Ty9BWldVZGU0UldBa1YxdHJUODU5bXNKd3FXWFR6NDI1b090aG56Wlo1MEtnYkZuawp0UzlXaFZVY0drLy9PSjBLTWlTUXRuNE1DbHBvcHo5L3hreHB2YjlNaitaNWNKOER2cDkwcnBKbWhKbExDNzBkCnlFNEU0ZVpKSXJMQks1amdtMnZ0Ti9FYnlxaW53cnB3clZ3OWpXSzZPTVRqQTJUNWF4THliSkhKQTNlTDBrVkcKMy9uV0F1RmhldlJFMW9hZjh3L3ZUd0pRNWc5UGJ3SFdIUDR2bENUbGpNa2xxQ0xZVlBNVFBtVDk4aHdWd1JYdgo1Y0E3L2MxWGdUcC9iV3VhTzQ3blowQUh2MElwalU0NXpKQ1R6QkYvbXg0dDQwQk5aN0lacGRLUHpzOHNzNzVhClJ6UFBNeGV6aHg2bU5XRXdIaGkvQXM2NXRvcGRnNS95QU0vMFl2cEUzSk5Zd3A2NzEyS3NCcWM1YUZuYzBZb2gKMjNieGx3OFFwc1Y4RThrMmdKazFDcnUzTDhEYmVSNnk5YnFoMWR3bENxR2NpM3dvVTNHZllkOHlOZ3BZVFFVcgphRDFWMlh4VVY5RnZ6MFRFTnRJQmttUFQ1aUVGNzhvcHFnZlRKR3hGcW9CbmVGdVUrUEF2aVcyb1pnWUZKT1dGCjNNZzdrd2RJdmY2Tk1ZcGxkSnBxbXZoQkY2WVd5cjJpUE9RMlorNHJQYkhuWE5yaUxDVHk0RnNkbEtxNnQ2ZXQKVUZCZWhKbEZNUnBFTHdnUkMxRzlqVWRKc29FL1lBczA2TUU9Ci0tLS0tRU5EIENFUlRJRklDQVRFLS0tLS0KLS0tLS1CRUdJTiBDRVJUSUZJQ0FURS0tLS0tCk1JSUZZVENDQTBtZ0F3SUJBZ0lVWnlWZjJGckhXcXdOTVJDYkJTTzhkY0dWMFdZd0RRWUpLb1pJaHZjTkFRRUwKQlFBd09ERWZNQjBHQTFVRUF3d1dWMGxUUlMxRlpHZGxNelkxSUZKdmIzUWdRMlZ5ZERFVk1CTUdBMVVFQ2d3TQpWMGxUUlMxRlpHZGxNelkxTUI0WERUSXpNRFV3TlRBNE5EVXhNVm9YRFRJME1EVXdOREE0TkRVeE1Wb3dPREVmCk1CMEdBMVVFQXd3V1YwbFRSUzFGWkdkbE16WTFJRkp2YjNRZ1EyVnlkREVWTUJNR0ExVUVDZ3dNVjBsVFJTMUYKWkdkbE16WTFNSUlDSWpBTkJna3Foa2lHOXcwQkFRRUZBQU9DQWc4QU1JSUNDZ0tDQWdFQWx4aWFVY1c1TTFKSQpoL3ptbFlyUTIzR1lRQkZzZTg3cW5zRGJYOEVSRUNVM3Z6dkpESmMxVGQ3MUJQMTdGRWlLOGE5SGlIOVUvQnRECmNSbVV0bkhjNG1HSGI1S2NTNlpQZ2MrSi91Q2VPY3JlS3o2OFFsWWVMR05STTJmV2ZOcW9qNUlzRk9kZmoxVEoKQWNocUozcFJ1YnJ5T0VoZ0RFbEczOXRhclV3K1BQazFMSXhIcHFVTzlidEhFS29XdG5SZ1JIRTk0ckJ2K3pMcAplbXIxbUg2N3UweWFpVWNWUFk5QUk5enpMcDIvOG4yaWN2MFdId2M1dnJIcDU4R29Vb2tSQUNlRyt1a0o1K3RVCjJRVEllWU9rMVdpRkM0SzdxMnNhUGZrNkRFdVVhdHJTcXhOTmMyeVUxZWJuNTEzb2o5YStrMkdNRjNTNUkwczMKV0tzNExuTW9kU3dqUXQ5S3p5R01IR2J6OXpmS3JzOTNCWlJRMkFXQWZJRjlWMVE2N0RsdytCVG9ML2c5VkhKTwpldnN1eGEwZ0RUNVR2Q1psQ3FKbmlzUnVSYmVjRHh1RTZIaUhXNnVpeTVxZWM0V1A5SktZV0tsc1BEcnBpcGo3CjkxWnpHSDdNSlFmd3ZPZTBrKzRONUV4eEVjemtIdmhPbjhYWS9NaEJYS0w4aXJLSGpZSlZxQjVRc1k0VmZGWUYKMmprRXlUL01LRjJBZzYydG1VTU1IV1kzL2xSUTczQUx0R3FtU1Y5UnBjT0tEZ1Z0TDMzcUx2Q2xIamVtb1NrYQp5WG9uMVczS1pRSFlvY0lmVXhVazFRRUZsMFZDUHVTZ1pEZk56bXVCQndzbWIxRks4bERsMldqWWNXU3ptZGZ6ClNvSG9xS2xLcEhvbURjN3JITzJGaUlBT1BFM1RIaU1DQXdFQUFhTmpNR0V3SFFZRFZSME9CQllFRkhuZjZOMWsKSWlIRTdsazRqTVo5clRvMVNqOEtNQjhHQTFVZEl3UVlNQmFBRkhuZjZOMWtJaUhFN2xrNGpNWjlyVG8xU2o4SwpNQThHQTFVZEV3RUIvd1FGTUFNQkFmOHdEZ1lEVlIwUEFRSC9CQVFEQWdHR01BMEdDU3FHU0liM0RRRUJDd1VBCkE0SUNBUUF6UW5RWVlNTkZmNEFOQkVnUFFqQkxtcjQ3Ym1GR1RUanFnM1JmWkZrVit0NklUQnpjUEZoRXc4bHQKa2NSUU1IMHRtamFTMGRaVWRLcmJsT0w5QlMxUG5ER2tBdHN0aU5rZ0M3R2g3eVQ0WFFraDB4ekdzWTE3Y3F0awpLWnhLVTZZUStjZmRNazk3aUcvL2xRaDI0NlpOdzJMaXJKQUpDUWNXL2dZWnVCaW1IQnoxaUIyWUdwTTg5bEtXCks2V2tob1BJVE40OGhZUG1tQkMvU0E0dDRqUWVoMkdlaVRzcS9JNk8yQnZtWkQyMVZDT1ZxL3ZpN25QYlQxYm0Kem9yQXpmWHczd3dxSDh5MFdObHltTXNGUm9HYjRaNTg3aXByWUpqeUt3dUt0TUgyMHBVYVFKeUNyNUgrTnlMYQorN0diT0xlYzMvRkcvZ21pZkgrNm1UbDljZlc0UVFvSUMweDVURklGNy9KNk9jVU4vNERjUDFBUFltdEJQTXJUClZubmFuaVlIbDdxY1BMVTRja29uMmxmTkxCYlA1N2J1NHdrbUc4OWNybHJlYnFCZ2ZNc0pWTEVnODFHTEl4Nk0KZ1k1cnlrSVR3ekpEMEc4Q0hsRDJOM0FEMjg3QTZkM0ZveW0vME01bk1zRmFGNlExWGNoVnBTVmlaUlBvZWgvYQpPWDJKclhsS2J5V0VqSVBnZmpubytxN0liUHhNTllKQVFoYUkySVBNdE0rQjhtTStzZHNWMTlmUWFTNXdJd0s2CmRvbzJ1cHpiYWpZdVQySStHZG5YOHBycmRIQ2hzd09uNlFvYmdqNmI0SDgwSWFydmk1RG8rZWpxRTBJbkR2THYKYnhMWlE3c0tGM2RkTk5FVkxjVERSNlNTUmY2cW5ybU4wT3B1d0ZTYURZZkxybFVpV0E9PQotLS0tLUVORCBDRVJUSUZJQ0FURS0tLS0t"
        }
*/
router.get('/ca/:orgId', (req, res) => {
    let orgId = req.params.orgId;
    if (!orgId || isNaN(orgId)) return responseError(res, 'orgId error');
    let idx = common.getIntermediateCertIdxByOrgId(orgId);

    certCtrl.getCaCert(idx)
        .then(queryResult => {
            if (!queryResult.status) throw new Error(queryResult.message);
            return res.send({
                caName: queryResult.certInfo.fileName,
                caCertificate: (queryResult.certInfo.certContent === '') ? queryResult.certInfo.certContent : Buffer.from(queryResult.certInfo.certContent).toString('base64')
            })
        })
        .catch(error => {
            logger.error('api get ca cert info error: ', error.message);
            responseError(res, error.message);
        })
});

// API: /cert/server
/**
    @api {get} /cert/server Get RabbitMQ server cert
    @apiVersion 0.1.0
    @apiDescription Get RabbitMQ server cert
    @apiGroup Cert
    @apiHeaderExample {json} Header-Example:
        {
            "X-Cert-Token": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhY2NvdW50TmFtZSI6InRvbS5jaG91QGFkdmFudGVjaC5jb20udHciLCJpYXQiOjE2ODY2MTk2MjgsImV4cCI6MTY4NjYxOTgwOH0.2lAyJ84lDZznnmWcU0lXaL_WSIwT1DMSCBcQjYygjbc"
        }

    @apiParamExample Request-Example:
        http://4.193.252.254:3000/v1.0/cert/server

    @apiSuccess {String} serverCaName the name of the ca cert
    @apiSuccess {String} serverCertificateValidity the expire date of the server cert
    @apiSuccess {Base64} certificate the Certificate of the server cert pem
    @apiSuccess {Base64} privateKey the PrivateKey of the server key pem
    @apiSuccess {String} createdDate the CreatedDate of the server pem

    @apiSuccessExample {json} Success-Response:
        HTTP/1.1 200 OK
        {
            "serverCaName": "server",
            "serverCertificateValidity": "2024-06-04T03:10:22.000Z",
            "certificate": "LS0tLS1CRUdJTiBDRVJUSUZJQ0FURS0tLS0tCk1JSUdKakNDQkE2Z0F3SUJBZ0lCRGpBTkJna3Foa2lHOXcwQkFRc0ZBREJJTVJVd0V3WURWUVFLREF4WFNWTkYKTFVWa1oyVXpOalV4THpBdEJnTlZCQU1NSmxkSlUwVXRSV1JuWlRNMk5TQkpiblJsY20xbFpHbGhkR1VnUTJWeQpkQ0JtYjNJZ1pHVjJNQjRYRFRJek1EWXdOakF4TVRNeE9Gb1hEVEkwTURZd05EQXhNVE14T0Zvd0tERVZNQk1HCkExVUVDZ3dNVjBsVFJTMUZaR2RsTXpZMU1ROHdEUVlEVlFRRERBWnpaWEoyWlhJd2dnSWlNQTBHQ1NxR1NJYjMKRFFFQkFRVUFBNElDRHdBd2dnSUtBb0lDQVFEd3lQTGZyQ0JlaUdjRkgwVE5YK3pra3pyaDNpN0QwR2w5UkdsKworR0JycnFaMXN6VlUxVkM1eWgyZnNRSUR0Z28ycU1wS2RyWFkyeGJpV2Yvd1NSdlNtL2hWVTBpcEx5SUVBVjR4CkE4bnd1YTRmSWYxMWNJa21ydHowN3BGK3loVWpxZU9EZXdCcjdZQ3J0VnFaSzhBenZScTRQdG0ydGlkdEk3OWQKZkxzUTlKcVErYWk1SDNmRWhGQXowZ2cxYzdJbXE5ZTNWbEl1RHNYYVIyQ0NKaGpweHZsWXEzRW1kS081NUVuZQovamR5K3hjMnVGS2JBcy9pQ3FjYWlaUU1Gc1NnWGVQQzVWckxua2N1UUVOZ3Y1OVJ0enVjRnU4aWRYU1BRcnAwCmRyU3VnS3RGUEFmYnBLWVNMRWhGSkFKYXd0U1hRaEtNMCtWVitXYmdxZkdhQ2ZJZEJDb3lBNXlob2pMUEhrMUQKdXhSOFMwdkNrdkRnbjhnSTU2dEE3bEZQUGtaMitOSmpxR1hyNyswT1Vock13L09iMkNIWlFvdk5hM0FUeG9kQQpNaEJlMXJtQVo4SFV5MzNZbnRtV3JBSC8zamZRV2ZFdk4yQm0rdDcvOTNjV3Zhc2k4NjZtZzJERldsVUhjaFpqCmsyUzFiTWRML2xHbnd0SGVIekVCNVdUbm1VZnNaYXhWNmMvTXFRdjZUSlF4UGZoSHRpWDFtSWJTbm9aYVZSNzAKTmRNUGM4N1A4UHRCSmNpZEVXdFg5c25qd3ZaKzVMWGk0dC90Y0dZQUdpd2I5WElVTjdLaHBCdnNsc21Cbkk4NApIL0lRdVQzdk9OTlRtV05tQlMzZlViMVlVRDl1TlNBd2ErS1VQWlV1WHd0a3RPUjBuK1FWQi9EOVA1L0RLa2k1CjdGMUZZd0lEQVFBQm80SUJPVENDQVRVd0NRWURWUjBUQkFJd0FEQVJCZ2xnaGtnQmh2aENBUUVFQkFNQ0JrQXcKTXdZSllJWklBWWI0UWdFTkJDWVdKRTl3Wlc1VFUwd2dSMlZ1WlhKaGRHVmtJRk5sY25abGNpQkRaWEowYVdacApZMkYwWlRBZEJnTlZIUTRFRmdRVWpzMzFHcUR2ck0rLytyUTQwOUhXSnB0cWRVa3dhQVlEVlIwakJHRXdYNEFVCm5OUGhsRUkwY1hsT1NTc1RTdmM1d3U0azhWaWhSS1JDTUVBeEp6QWxCZ05WQkFNTUhsZEpVMFV0UldSblpUTTIKTlNCU2IyOTBJRU5sY25RZ1ptOXlJR1JsZGpFVk1CTUdBMVVFQ2d3TVYwbFRSUzFGWkdkbE16WTFnZ0VCTUE0RwpBMVVkRHdFQi93UUVBd0lGb0RBVEJnTlZIU1VFRERBS0JnZ3JCZ0VGQlFjREFUQXlCZ05WSFJFRUt6QXBod1FVCjFJRElnaUZ5WVdKaWFYUnRjUzFrWlhZdVpXUm5aVE0yTlM1M2FYTmxMWEJoWVhNdWFXOHdEUVlKS29aSWh2Y04KQVFFTEJRQURnZ0lCQUp6SzlzV1QrTUFZZnVPL3Y1cEpmeHBkcUZPWm9OMFR2TEE1YTRidjg4aW14TUdqSUpGegpXSW5jeERCZ1VhcEJTaEx2bWp4QW1xenAremlzVi81WUtlNCsrUGh6NHVOYlIzMkhycGtqNXNvZVoyb1VaWW9MClNlTDlJQnRIcHRBbDg0cEdQVjBsRDh2NlJPZkdzckJyQmdQWmk2WkxWUDJzMkIxYWpzV3RVWGZSZHkxMDFPUXkKZlpGVjdhVFBjdzhVbkN5RmwvQlgvdW9rc3dDblRGVGJvd25UazlvQ0dpcWp6MVgyck1WMFIzZEJiU1h6WCs0LwpvbEpPN3gzMURyS2xjMjBKOHE4MjZGc1lpSzlXamdRcFQvcVk5Q1ZBSWxpT0Z5UncvVGpHS0VsV3UzQjJnaFhLCktuWVRQcXZ4MkQwOUh1WHhZYmpyNDhWWFhyRmpSaTdvMkZ6TWNQN2FhVmcvWE5WTm1obk96VEl6SDlnMzhJcHcKQXpOMExJQlFGenhZL0FjVkpGeTZNRWNsWVIwT1Fybzgrc2o3QS90d25Ebjlzb29GVjYzSHY4Z3FueTJFdzhEQQp1RDJ3OGJxbDZlM0ZFcmNnSHhiT2tjanJVVVRuNFQrelkyMUxvaHArRWhuTmRsWmk2Qm5kUUFlSnkwZjlPN2s2CnJMNjVLblY3b1FIalNCRUFlR3k3UVAyOStQaFh3MlcrOGlUS3NPcGRHWStCVlVjMXg4a3pPQVdnVW5DVEZhaTAKelk1aEJlTytqbVMrTHo3bmVRRi9pVHVDZm5VaTlQMVJ2UXdnNGt5ZFlOOG1SeGZxNTJCdlR5ZmVsNzlBYjUyaQpYS0dGR3pHUnVTamFHTTdCSnNBa290R3J1UU91cGtYM0ZQcEx3YWVjaHI5OU5FbjVRaWNPZ2lxVQotLS0tLUVORCBDRVJUSUZJQ0FURS0tLS0t",
            "privateKey": "LS0tLS1CRUdJTiBQUklWQVRFIEtFWS0tLS0tCk1JSUpRZ0lCQURBTkJna3Foa2lHOXcwQkFRRUZBQVNDQ1N3d2dna29BZ0VBQW9JQ0FRRHd5UExmckNCZWlHY0YKSDBUTlgremtrenJoM2k3RDBHbDlSR2wrK0dCcnJxWjFzelZVMVZDNXloMmZzUUlEdGdvMnFNcEtkclhZMnhiaQpXZi93U1J2U20vaFZVMGlwTHlJRUFWNHhBOG53dWE0ZklmMTFjSWttcnR6MDdwRit5aFVqcWVPRGV3QnI3WUNyCnRWcVpLOEF6dlJxNFB0bTJ0aWR0STc5ZGZMc1E5SnFRK2FpNUgzZkVoRkF6MGdnMWM3SW1xOWUzVmxJdURzWGEKUjJDQ0poanB4dmxZcTNFbWRLTzU1RW5lL2pkeSt4YzJ1RktiQXMvaUNxY2FpWlFNRnNTZ1hlUEM1VnJMbmtjdQpRRU5ndjU5UnR6dWNGdThpZFhTUFFycDBkclN1Z0t0RlBBZmJwS1lTTEVoRkpBSmF3dFNYUWhLTTArVlYrV2JnCnFmR2FDZklkQkNveUE1eWhvakxQSGsxRHV4UjhTMHZDa3ZEZ244Z0k1NnRBN2xGUFBrWjIrTkpqcUdYcjcrME8KVWhyTXcvT2IyQ0haUW92TmEzQVR4b2RBTWhCZTFybUFaOEhVeTMzWW50bVdyQUgvM2pmUVdmRXZOMkJtK3Q3Lwo5M2NXdmFzaTg2Nm1nMkRGV2xVSGNoWmprMlMxYk1kTC9sR253dEhlSHpFQjVXVG5tVWZzWmF4VjZjL01xUXY2ClRKUXhQZmhIdGlYMW1JYlNub1phVlI3ME5kTVBjODdQOFB0QkpjaWRFV3RYOXNuand2Wis1TFhpNHQvdGNHWUEKR2l3YjlYSVVON0tocEJ2c2xzbUJuSTg0SC9JUXVUM3ZPTk5UbVdObUJTM2ZVYjFZVUQ5dU5TQXdhK0tVUFpVdQpYd3RrdE9SMG4rUVZCL0Q5UDUvREtraTU3RjFGWXdJREFRQUJBb0lDQURjdE5VckFQT0tzeXo3SFBaTDZpbVNPCndJMkZ4cDJrb3FmTUI0akxEZjFmRmxJZWNQZ3hzY0FCYXV4dk9aRDBKRDhHU3VUcGN4NXdoanYwZDh2dVZPdmMKUmZuM2pjMEhPZnBFL2ZxcGJaczJVWXBjMWFJVjJiZjlsakNpZ3NEVk9pYmtCWGpadE8wR2pkZkxSU21ZZHdEawpNcjFKMmNZZTA4WVV6UU4xVThDODdMYVFIM1BjbkN0eVRwYXhhS1FuRVFuL2t2MDJVTHF4TS9HakxhQmxib3dUCnhvdmxMWmFzWCtCM1NkNUp6eGNRSnUrcEtYVFFIaWNrWGNxZEFFb001WjRDSmZGQmNaNzdkRUJMQmFXa0E3Uk0KRXVMZjlvaWs5Y0xtZmFlMmxBencrMDV3UlRTMTlFQngyVlhPdktOanhpZXJRbWozSGJTbjVFVlRiRVBxUjRxZwo0Uk9yVEJDV0Z0NENFMldvbEdGSlYyY3JmemthTzl1cjVkRFI1dk9IdHNGelZuYlR5b01KbndGTUNiRlp6bnFmCmJrMkl1bG05WnhTTnEvUnV1dGhjaDVYdldxbmZnVFJHYlArdzdzbE5jSXZQSldQYUdjOUJybFRlaU9lamdMYVQKN3k0QldiRGd2amF2ZjZIT3lmY3pWOFF1MnU4UytuV2I0MksvZmc3VjJHSWR5NzJNVGhCY0FxYzRJVEtuSDIyego3c1F4K2Q3WG54RDlIQkYrRUFzMTZVcmcwUjdHNjNKaGRIbk9BTVAxN3JFMVV5RVljeTFROU93Q1l0NDhzWXZsCkZHRGEwaEN6d3pFZVErKzB1ZkdTKzlkUXh2L3Y4S3dyVEc2YnV5YkxtVXRXc2RGMEgzcWwzTkhmVkNHNnVIRHkKNVozSG50S0UwOG9Ob2prUEJHR0JBb0lCQVFENk0wbmZmcFlMblZKZlBhUDh2bW5sQStGaENaYlFMMnJONU9HQgphRXFpZkEvdzl3SWJJT05USUFyYjBSeExQU1c4U1RtQ0Q2eTBGSVZqYWtoaERtZGVsYVZvSUYzN2EvT1ZIOUJlCjN4NnhVM2oxSVVpWk1vcWxxaTZkWVVqTlRxcFYrQ0oxeHBNUXdCTlRQK3NRV0NiL2RYR3cyZ0R1eExGT2F3NXIKeVVPS1hvZm5STHkrYW5QT0xtUzhkU3RtclB0SmJHZUhvTWlhdjBCTXRoaXhNUTdlenMzV2NGeWJySUwyamNScwpVa25NUUUwazFHWCtPWGNBNFZJR3lBTDUraGdyK05NMjZnRWUrWVBCcG8yRHo0UjQwMldZaGxSZFdNemV0TjNmCkFaSDZ6WjJIdVpPUG8xU0VocjdXTXFpSkdYeWtvM21iTUtUTiswdVdxeS84SVNMaEFvSUJBUUQyWGNuVG1Ia2YKNGlqVUxLUWtUbFhPRkppUUQxN3NZMHgwR0M2dGxtTTgzMWwxMXk5VVQvOU5rYjdJT3FvOXZGb2UxSjVubTU4SQphbHBpSm1BeUhYNm9DbkxkUVY3cFB1ODg2U2s5R3N1eGV0OUttOU1nTGVmZFlPUFFzbEhlb0kxbXdwWG9sVWlDCkgyRHFEcXE1RGlpc1JaOGtROE9qVHFnV2VhenNQejZyUmRvVFVxU0ZnajhDK1o4UHVOV2crOGZyR1BHQVBrcGIKRndtNzBldUtEN2xkSFMySkdyT1ZBL241ZVhXaU9FcmJmcXdrRzFYbUN4dUNROXFVQWJyMmZyRFR4b1loVXR4NApaTkw1NFlIdEpQOVU4eVFONXd4cGkxMEx1K1dHRVdmclIzMlBhZk9HTjByUWF6U25oNXh6V1pVNkcvSTh0SEhpCkFYMkV2eEx2U2pUREFvSUJBQko3UVdTeDdCRjFrSVVhZjRlRzVUbVdmTXAzTTkyeTh2ZThoVy9TclZpdFExd3cKVXNhQU9tcUVmbWpZWEhldVQ2QkY1R3FZRDlESmgwVGRyL1VEWkYxWFBuMmZqbkdvK3JnMFBtY1RvaWZGRzdVMwp2UzRienFRSUd5Tmk4VWJCSGRIMTMwM0YyazB0Y3YvK1E3WFVYU1VYbnN0S2Z6RWo5Rmp2allRbXZNZDJ6aUVtCk1hNzdIQXpKM29VUlBxQjUvS0hpMFE3eXNIN0Z5OUVlemxvZ1hwSFV3dDJwTlI0R3N6SFZMUUkzWGQ0cGpjay8KcXowSkw2SXdBcWdmbENDMCtaNGQ1alF6T3R2MzRHU29rZUYvcmJCakpTa01HeVUrRHZ3UWJpY3Y3WUdTT0tXeQo3cFI0b3lDYTkzUEpFQ3Y0WnYyZVdiZzk4cDZJaG4vZHExQzdmZUVDZ2dFQkFLYWJob0d4K3plMG1pZmlpSjZFCjIwSWlhNG9BMnhEQmxsSnNpQ1NjTDBCYlN3U0dJVnZEUGNRWGJBMjhucVJoWEJDOWVPSllPNVJWV0FwSUtZVzYKckl5M2hEWmNudkxkdkt4VWdhN3hFQTlXS09zcnRmdHRFQUNHSllwZERVQ2hFdjhMV0pXUlh4ZWdZTW5vWVV3RQpaejBaV0NZT0xaK2k4Y2xCUDlBRWRUMGVYL3Z4UjVHQ0kxcS90UEhNN2F1UW1nSkRQQTZlRVdySWlheWFxYzhVCkV5Y0ZOR1lqeUk1ZHdnOFVOSmtmdUgvM2lqSmd5aFpvTEpKTGtPWEd4Y2tzcENpVGVPSFFSNGlqcG9tV0YyZG8KUGNRVktheTlNNGVzMTUrMzBlQjRwTzVYeW5IU0ZQNFBKbWtNRnUrMHBmamIvQzd2OTBGV1JpMnhGRkZSWmx5cwpza0VDZ2dFQUVXcDBYc21ja2ZPcVBmKzY1UVNGaW52Y0JnY3BZdndNT3MzSzV4aTFGK3BPVjhBM282ODlyd21qClNNdDF6U0dIb2I5T1RMWkViRjhRTGVPOXl2SmtIQWVlS085R3RYYlZCS0R5My9DWUljMTBEV29FY1c5ejlDNSsKZ2ZJSUluS2xuMHgvZkN5NnpQY0o1SVVYU3drL0E3VHJMWk1TQkc0K1g3NzRKVHdLakFaQVZmV29LMllmQlpPdAp4clExcTlCNnMvOGcyM1l6T0pIbTdkVllyOXMwWDlrdCtIWm83SkJjMVBOaldhL3c3QjlOMFZXZmFiUlFWbURnClpEY3ErWkZWRUNWSGxPbnpINlRBdDlSd3ZyM2NoS3hpUWtBR2lHOVpFTjIxSGkzWWpKL1AxSDRpdXdPZDlGdFYKbFpKb0wwOGZkcXhiTUx3MDdGQnY1djVIelNzTjlRPT0KLS0tLS1FTkQgUFJJVkFURSBLRVktLS0tLQ==",
            "createdDate": "2023-06-06T01:13:18.104Z"
        }
*/
router.get('/server', (req, res) => {
    let accountName = common.getUserNameFromJwtToken(req);
    logger.info(`Get Server Cert User: ${accountName}`)

    certCtrl.getServerCert()
        .then(result => {
            if (!result.status) throw new Error(result.message);
            return res.send({
                serverCaName: result.serverCertInfo.fileName,
                status: result.serverCertInfo.status,
                serverCertificateValidity: result.serverCertInfo.expiryTime,
                certificate: (result.serverCertInfo.certContent === '') ? result.serverCertInfo.certContent : Buffer.from(result.serverCertInfo.certContent).toString('base64'),
                privateKey: (result.serverCertInfo.keyContent === '') ? result.serverCertInfo.keyContent : Buffer.from(result.serverCertInfo.keyContent).toString('base64'),
                createdDate: result.serverCertInfo.createTime
            })
        })
        .catch(error => {
            logger.error('api get server cert info: ', error.message);
            responseError(res, error.message);
        })
});

// API: /cert/all
/**
    @api {get} /cert/all Get all root and intermediate cert
    @apiVersion 0.1.0
    @apiDescription Get all cert
    @apiGroup Cert
    @apiHeaderExample {json} Header-Example:
        {
            "X-Cert-Token": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhY2NvdW50TmFtZSI6InRvbS5jaG91QGFkdmFudGVjaC5jb20udHciLCJpYXQiOjE2ODY2MTk2MjgsImV4cCI6MTY4NjYxOTgwOH0.2lAyJ84lDZznnmWcU0lXaL_WSIwT1DMSCBcQjYygjbc"
        }

    @apiParamExample Request-Example:
        http://4.193.252.254:3000/v1.0/cert/all

    @apiSuccess {String} allCaName the name of the all cert
    @apiSuccess {Base64} certificate the Certificate of the all cert pem

    @apiSuccessExample {json} Success-Response:
        HTTP/1.1 200 OK
        {
            "allCaName": "all",
            "certificate": "LS0tLS1CRUdJTiBDRVJUSUZJQ0FURS0tLS0tCk1JSUZjVENDQTFtZ0F3SUJBZ0lVS2w5c1htUS9qb3VJZnNxMzJ3VXZlS0dSbTdRd0RRWUpLb1pJaHZjTkFRRUwKQlFBd1FERW5NQ1VHQTFVRUF3d2VWMGxUUlMxRlpHZGxNelkxSUZKdmIzUWdRMlZ5ZENCbWIzSWdaR1YyTVJVdwpFd1lEVlFRS0RBeFhTVk5GTFVWa1oyVXpOalV3SGhjTk1qTXdOakExTVRFeU5UUXdXaGNOTWpRd05qQTBNVEV5Ck5UUXdXakJBTVNjd0pRWURWUVFEREI1WFNWTkZMVVZrWjJVek5qVWdVbTl2ZENCRFpYSjBJR1p2Y2lCa1pYWXgKRlRBVEJnTlZCQW9NREZkSlUwVXRSV1JuWlRNMk5UQ0NBaUl3RFFZSktvWklodmNOQVFFQkJRQURnZ0lQQURDQwpBZ29DZ2dJQkFMVXJyRzMxbkJ1dUh0N2diRTJSVXJ3RDkyUHBnQkdQcFkzSFpDMG1aYkFFVUpsenNDb3VRa1RiCllMamNxL2Q2enI1clRZR1dMWlJCYXQzTnNwengrQ1FramVEbm9ZWGdxM2dBN3BxODBRN0dKdXovTGM4d0dRLzcKYkhqbG9walRrTGhXU0IwVHk0Ritxc3lweTFGcktiZ0hJYU9ZWHgyZkRYaVVGRThGV01TK2hDeTg0N2RwNFg1aApIUThZOU16M2lPcVFaczhBOTdCS2ZqenRtVnNJS3R6NzFQOGVuS3ZvTXFrYURxSFNCU2M2dmZyS1R6em8wQW45CkpoZTJPcERvcURNR0NtMXNPR04zV1FNR3ljaTdaUzFEVjhaTzFQWmhFM25USFZmalVxMGo2Q1ZqWnRVa1VrR1UKeXlhbzhCVE8wZmdSRTBybThUT2ZTU3RtTVI0c2VNcWFXajlHNFpwMzZBWVNybCtDd1BYUDRrczJ1MFJnVFU3VwpJQ0w5WnhGcmtkZ3pwZzRQVE9zRmYxdytySWJQNldTY0tXODBDOFgyRTFLT1hlSnNiNGZVMjZRUVZSYm8yZXIxCkh3TW53ZjhkbVVVRUlQbTZqL2lobFc0bEprd2ppOGdqZ2pmbkJZRjVycXg5Tm0yVHRINE1OZkZXdW82dHc2VEgKVjlyVktaUWRBZWRRL3dwcjdhc3BQZVVuRHlnblZSNEtzb2NiRlZjbFp4dDIwSm41VXJvMENaalJlNUh2YzZNNwpSSTZyenlBV2ZSdVRJV3hPZ2hUbUI1dnNhWlhGbVFFVTBwZXZIUk5ML3gxK1E0dkF4eExmVCtweUVnRUtpOWp5CktlNjlPT2pGSEpSbWViMW50Q0xmaGFqYUVoYUNvZWhNVWJwZUZPN1M2QjV6MUw3cGFUNDVBZ01CQUFHall6QmgKTUIwR0ExVWREZ1FXQkJUWnpsM0JOMXRKdm5xRWV0cjB0SnRvbE9TZlZ6QWZCZ05WSFNNRUdEQVdnQlRaemwzQgpOMXRKdm5xRWV0cjB0SnRvbE9TZlZ6QVBCZ05WSFJNQkFmOEVCVEFEQVFIL01BNEdBMVVkRHdFQi93UUVBd0lCCmhqQU5CZ2txaGtpRzl3MEJBUXNGQUFPQ0FnRUFYMWIwNTdhcnNXdE9wcnROZE5wMFlHRkk1c1BYYWNEY1hoTUQKY0lDWVdXcGs2WTVKTVRPa1lBcjZaSHBCTVRzNXJIekZvdzNueFJHeTN3b2QwYWR5WURxZ0t5dmpUSjgyRWlYQwp4am1DVlhkM0xBUndHdE8xK09YU1RwbU9VTFByVmdDMFk2NEp4QzdxM2l6WlNlWGlVVFczeFA3MVg1U0d3VEJPCitiTVZIbjNVbEtjdm1qK0d2WGRYZ2l4NUpIUzFvdHZ4bmlMSmFROWhXUmU1dlVuWU50YzNkcnlReSs2bjZpOWYKT1RvN1RDTnZHWk5xV0IxckI3MFgyMVJhNlJkSVIxZzNlblBicERxSzRhaXhzL3o3MDBEazR0UTlWWVQ3a1BaegpsbnlvSkJjNW5IOWRPbWdieUxqeVV2QWVnZ3lUY2lFVHNaQmQ3UkRsMnZLMnRDZzZGeVZkOHI1TnZJb3hRUHNmCk9HM2RrOE1YT0lxQmUwRmVHejI4bHlFSFNLamFjRFh2aVh3bkJwSGJnbW5jMkVSTHJXUTc1ZWxSenk1a2o4NTUKbzRnVVdrMlEyeUhka2FaeDRUNmZzV1J2NE02TUVhTlVFd2pKYlhRVTdUM0RMbWo3bk9VSlNGT3YvdE02OEwzbwp5eWUxYUt3YUw2cEtRVUtIR1ppN01oQVY0OWlvQTVJN05PaVR4UWgxSzRWUTdzdXNYaHduYUJZRkpDUUt6cW1ZCjNFZkxtcGgwNnVCTnB2NDlYY1JQTWIyV2VObWlPTlFOQWlpMTZ0MWt1cXhzTEd5U250OHlnZkRCNkRkcVJVcUoKMEpaQUNnemUzVlNTU0hJdktDeUpZS2xTTG5ZUm1XbmpTV0xjVE1NYjZwNmFVWmpyRUppVXJaam53eDNjL29PcAp0OFlsQUU0PQotLS0tLUVORCBDRVJUSUZJQ0FURS0tLS0tCi0tLS0tQkVHSU4gQ0VSVElGSUNBVEUtLS0tLQpNSUlGY1RDQ0ExbWdBd0lCQWdJVUZEK2o3aU0vYTdIZUxEbWtRQldReUJzUE5Bd3dEUVlKS29aSWh2Y05BUUVMCkJRQXdRREVuTUNVR0ExVUVBd3dlVjBsVFJTMUZaR2RsTXpZMUlGSnZiM1FnUTJWeWRDQm1iM0lnWkdWMk1SVXcKRXdZRFZRUUtEQXhYU1ZORkxVVmtaMlV6TmpVd0hoY05Nak13TmpBMk1EZ3hNalU0V2hjTk1qUXdOakExTURneApNalU0V2pCQU1TY3dKUVlEVlFRRERCNVhTVk5GTFVWa1oyVXpOalVnVW05dmRDQkRaWEowSUdadmNpQmtaWFl4CkZUQVRCZ05WQkFvTURGZEpVMFV0UldSblpUTTJOVENDQWlJd0RRWUpLb1pJaHZjTkFRRUJCUUFEZ2dJUEFEQ0MKQWdvQ2dnSUJBTkZIaHRoVlpvOThWYVFlV1BPUGQydkwyK3lraUpMRExlWHZBMzQvcks5S0lJVnpxR2g3d3ZWNQoyeStFemlqd3NPOXZaREQ0ZEh0amxOMXFjT09ienArSzhiZ1J5MEo1cUJsQW84bnBvRmpBQmVqa0x2UnA2cEhYCndHb0JOR1p0RURqVEtiUHZJeDMxQUdMQUEwLy9wWFIzZXZOVzVKOHdUSlp4OGg4d0Z2RS9LZi8yMnlrSWFsZHQKbmxvN1FTVi8wdU1yZ0txeU14QXlZZ2dOaDBWTXFYaTVRYjRldG5IQ0xzbk1jMFNvejBNckpTSytxR1ErWlp0Vgo5djNkMGprelZoZHFaVCtCMmorY2VtZE5vTGttb2I1VGJIejladTk4ZXBNOURuTVNSaHlob1JhazhybWduSEJOCm00VTgwYVRMUk5hOW9PbE9US2E2and0R3BkMnM3V3FhUWpLZWMwQzVWYjhVZkVoVG5RTnA0emVDRDZ1bmFmaEkKSktQbkQvcnN2YXBOUEVNOTMyb2NRa2tIb1NmdEcrTGZBVnFFYlVzYWhmQlpvNGcvS0dNd1Fxa0VnRlBuMEwybAp5OFI1KzFwbDRNL2lHcWVMenl2eDYrckZjY0sxN0I5M0JOTDJ2RmVoa3pkbEV5ZThSQnQzYjRWcnJlUVVTQVlBCkhETGdISDFLNlVhMVBRR2lGSGd6TWhIRHFhRHp4ZEhxVGtQTUFGakd5OWRmeW9nQmdydzd4Q2ZiV3h0d0xMU0MKTjVzbEFaZVRMV01XYzhNTEhFM2hpQnNhN0J4YUZvYUtjajc3OEl3eHFRT0wrTnZZL1U1SzdySWFGdENzVjlJLwpGc09SelM5dXdYR0lZUEI0OGIzYWhJQUMyQkhRK1VZd1pzb0dDcnlUNnhKUlRxbGZGbS9oQWdNQkFBR2pZekJoCk1CMEdBMVVkRGdRV0JCU1NpM0N6TnVvMG1UNHJPMWc2eUJqc0hrNVFrREFmQmdOVkhTTUVHREFXZ0JTU2kzQ3oKTnVvMG1UNHJPMWc2eUJqc0hrNVFrREFQQmdOVkhSTUJBZjhFQlRBREFRSC9NQTRHQTFVZER3RUIvd1FFQXdJQgpoakFOQmdrcWhraUc5dzBCQVFzRkFBT0NBZ0VBSDlxMnluVTNXUHltei81akJFQVBaRVM3L05ocTVMUVljc0t4Cm1YRzRGK3l1TzB1TFRzV1cwWnUzYWdJM0FpRUZFYUZLNCtwNDhyVjRacVUrdVFnS0JDUVBaQ1lMMmR3UE9yTk0KdzBhUkY3aEJoT1JzNjFJUHlpZEJYQWo5bnRUbGU4aExOZnhqWUpuZlpJYkVmdFlZa3AxblVOVGRodHdidWtDTQpkeUxNTEU5WVBBSUsveGJnNmlUTHF6ZVZZYXVIZWtiMDlIdk9VZTFvcUZpRjVLU0pjRE9KL1YydFNXeE96NkViClhKM0xQUGlCa25NRW9rYzIzeWhZbFRvelNZZEJtckMzWVgvdWJFN044MEFLaUsrcXlrVGVqbWVYMkc2akxFZ3oKTXlDdFJSRk4zbG5MNVJzVVVRM05rbTNxdG01c1FjWndOYnpwZ0FGaTdENVZXSDFRbjA3MHpxYWxZMXVndEEvQwpZUWV6NGJxYjVTQmlRTXo1dVpNMStHUS9MT0d4S2NCUTBaVGRnNDJKbTg5MjZpdGhpa3krRFlJNmxnWFJyM1FGCjNqWlVZQ0FVejB2RjkwcXJzc3AzMnp5eE95NnJTbFFTc0VQdXFDUTFjWHIxSDUvMHArM2NWeXZPWVJOY3poZlcKUGd0MytCcUc5RklHakEwZzNhZTZ6TUVPbzMxRkg4Z1dGblZ3WGpHTHZaZmF6MjNuR1V2NTZOSW9tNnVoVGwvWApKZ0lhUXBoam1Qd2VYWEl4bTlLKzBLTW9rTmlMZnJmM1NycjI4TVdZdXpkN2xkTEVqVkc2UklvSDh4UzloN2lPCk8wdERoQTcwUGJrWlNmQndlZTE5cEUxRXpXUFlIaUFzYjBPMWp2dzFrc3NZSnVWNFN5bXo2RWVPZ0FzRkQyZzUKOVpLUXB5TT0KLS0tLS1FTkQgQ0VSVElGSUNBVEUtLS0tLQotLS0tLUJFR0lOIENFUlRJRklDQVRFLS0tLS0KTUlJRlpqQ0NBMDZnQXdJQkFnSUJBVEFOQmdrcWhraUc5dzBCQVFzRkFEQkFNU2N3SlFZRFZRUUREQjVYU1ZORgpMVVZrWjJVek5qVWdVbTl2ZENCRFpYSjBJR1p2Y2lCa1pYWXhGVEFUQmdOVkJBb01ERmRKVTBVdFJXUm5aVE0yCk5UQWVGdzB5TXpBMk1EVXhNVEkyTkRCYUZ3MHlOREEyTURReE1USTJOREJhTUVneEZUQVRCZ05WQkFvTURGZEoKVTBVdFJXUm5aVE0yTlRFdk1DMEdBMVVFQXd3bVYwbFRSUzFGWkdkbE16WTFJRWx1ZEdWeWJXVmthV0YwWlNCRApaWEowSUdadmNpQmtaWFl3Z2dJaU1BMEdDU3FHU0liM0RRRUJBUVVBQTRJQ0R3QXdnZ0lLQW9JQ0FRQ2RkNW1KCit2dlJkNXVZaCsrSFVmZ0lGQ0I0cHMwRXNkanp3dDNRY3FPNjZud0c4eFZ3MFdOOHg1bzJUYzBBQ21TUXhGMkIKbndwV3VUM1g3Z0FZcGtxVk5UWE00ZjBGVzhEc3ZGMHMrQkU5MStESVgvYUV6dmU2R1hCeWFvN1NkVERveENJSwpoRXlBTG93ZXNZbFBuRlVkUVRhMm1KaUdrY3VPR0ZocXdYcmoySjdReG8veTlWMWZ2ZG1qZW4wdDZXL1l4eS9UCnNYN01kYXlZeWRwakx1NlV4ZjBrKzkwMzdZVEhLaTBKc3kwMUhHUGZXNUJKWS9BTEpTU0FCdTRNN1gzWS9vZDgKRlhpeGxPOVlKcnJQa3cwZzhsRVFKeFppTUhuWTdPZG5ydnZONHBQNUx3NVJlQjVhcjJqUWE2dDEzSVVKZHJKcQp2alNUZy8vQ1hWSVkrN0U1TW94a0UyVkdwSjBvSkZwSGltL0Q2MGE4UW9vd0xRT3RpWm5MdzJXRmN2ZWhIYXNZCkJBR1VVZHl3QThYZkZ4TnBnc1ZiTERZV2dLQnljTlIxZTk0c1pjZ0d3dnl2eDJlN0o1bWJ3d0pNUzI0cEVhNmIKcnYzUlFHWENScnZBVlBBWmNWbG9YY2JieVNkR0ZYZUQ4dkszRVIyNXJ6dXVEVFRwczJkTk41V005eXpUbnFaNgpiZmlpSGw5QnF4Ri8zZmh1T3ZlRk9KS29kSFhRVVozR25KbSt1MEM4K093Q3ZMV3JCaXltNisrM0NsK0xOVFdICjRMdTlkYVZ0clVTc09KdTVZalZyYnIzWTE5UmFacW1mZmVXdThLYVZVK0ZacGRQWWJ6ZktDM050UGoyR0lVa0oKd1ZNWTlselN4S1FlNTJnMzR6UG9EQklYVTZabll3ZzZDMEZnY1FJREFRQUJvMk13WVRBZEJnTlZIUTRFRmdRVQpuTlBobEVJMGNYbE9TU3NUU3ZjNXd1NGs4Vmd3SHdZRFZSMGpCQmd3Rm9BVTJjNWR3VGRiU2I1NmhIcmE5TFNiCmFKVGtuMWN3RHdZRFZSMFRBUUgvQkFVd0F3RUIvekFPQmdOVkhROEJBZjhFQkFNQ0FZWXdEUVlKS29aSWh2Y04KQVFFTEJRQURnZ0lCQUpQZ0lJYkc0Yk8ydCtYc3RoNVpXd0czQmp5KzRtOWZoRVVhVWo3Q3oyVnc3VXM5UmJIbwo0ZFY3U2tDSm8vZ2JENXhCNVlXZ25DWmZRYWJ3ZEpJRm4xOFV2SzhNL2tGZ09qYkw0SnZBKzFZNkZqUlUwL3hOCkZxbHovSHpXTzY3RjBXR3lWeTB2UnJDUVM1TU41SHJ2a2pvODZtZDNRY3RiOXJINjRjSGhJTFYraCtZWTVIMVIKbGYrWjVmR214TTBmbnY1TzFEOS94YTNreE11Rm9ZNlBnbDh0UFlHd1A2TzdjbmhHTlFha0NHTjNtU2VsOWlNcQprbWFuN3JoQVJWODZ6TWtYcU5JWW9FSDNScy9lc0JIZXNMNDhuQ3NYNGN2SW9oWG1MWEdCL1FMT2gvRWpmanExCnpwL1VHd1cvRFRzaXhMWGNNUWkwTWxXVjdVdWtXSU4zQjEySUdHWkNNS2U4dFlxN0EzRjh5YXhmeWdPWE1jbkgKa3VJU1NqNE9nTm9rT2JBMFVZZXE2QjNXdEwwOXJ1N0FhbUVtL2VhMHIvd0xGNEdGTFZ0Slc0ZjQwSGhWSXlJNQpXREZkYVk1M0N4a2Q3WnFPOWNyNmdRRVZkb0ptL0NFTzJlM3djT2liVDBnZHFWL1M1SGNYRFNwcUEzQjhqOEViCmduRk5RU01WOHNmWit5VlRHa2hGOWVkZDdFYzBpM0o2OFBhbTU3NUxhMUdYTk9nR3ZNZnJ1cEZ1Yk5SWWh3dkMKcnFqN3NNanVzcGtTS1hxZjEvTDRPdnlVSFh6SWlkVklMTkVwdzhGNzFNZFJnOGhZQU9MeGQvWHgzY2ZVb1FNcwpSdFVpSlF1b0V5amxVV084RnFHWGs0NGQ2VERDOVpFTEkveHZUUUVFMlBwRXhYSWNiTENvZWd6TAotLS0tLUVORCBDRVJUSUZJQ0FURS0tLS0tCi0tLS0tQkVHSU4gQ0VSVElGSUNBVEUtLS0tLQpNSUlGWmpDQ0EwNmdBd0lCQWdJQkFqQU5CZ2txaGtpRzl3MEJBUXNGQURCQU1TY3dKUVlEVlFRRERCNVhTVk5GCkxVVmtaMlV6TmpVZ1VtOXZkQ0JEWlhKMElHWnZjaUJrWlhZeEZUQVRCZ05WQkFvTURGZEpVMFV0UldSblpUTTIKTlRBZUZ3MHlNekEyTURVeE1USTJORE5hRncweU5EQTJNRFF4TVRJMk5ETmFNRWd4RlRBVEJnTlZCQW9NREZkSgpVMFV0UldSblpUTTJOVEV2TUMwR0ExVUVBd3dtVjBsVFJTMUZaR2RsTXpZMUlFbHVkR1Z5YldWa2FXRjBaU0JEClpYSjBJR1p2Y2lCa1pYWXdnZ0lpTUEwR0NTcUdTSWIzRFFFQkFRVUFBNElDRHdBd2dnSUtBb0lDQVFETExTUC8KemNsT1picjFGMkcwQ01VOEVUYXpCSkQ1L08wbjY4UTdYWXVLMTNSYnJHclJ2S2ZOd2p5M3c0RG5WYVJtdW9KVAozMi9SQk9tdE5TckR1KzlrVDJHVXY2MW1IMTJkVGxnUXViRFcyVHZxdFVNMTBCL0tFUkFkbWFNZm42QUwyWmRvCk16NzBHb2FBcllEaUR6UmYrbllRa0svd2FzaFhCcjhBRllMaHRzUWNUSU5lajVPeUhDZDFuWUdCQktHUWh0ai8KMzEwd2x1RWZhMjdmQ01Jbko5L2ZpNzRBdlN6cHN1YU5FVWNGVmZvRXFKckROMXlyRGRvNUN1U2kyV3ZmdVdvMwo0Y3lNQm1vZTFZVHZsbFNzRGxiNzBnSEY3MUNNUDRBcURQWmpvZExEZlNZc3NGWVhaeE0vZjhNY3NNQ3Vwb1ZMCjRZRUlMNEJnU3p3Ym9Qdk1NTVpvZHp4bSs4VDJ6QkRidkZaZzRDa1h4a2lJRlRQdDEvL3hMbEUvYUlPdnV1OFUKSHRhUWIvQ2JpazFDclFHVngwcEJzcDFyWkhDTlNoYzNHZlMzUHQ2NE5yNkhHVU9uMmpQandGRU9KWEJueWN6VQpmUGVCSlVuakZOYlBVTEtoWEpGdG1TU1E5NWhIU2FtR0pXV2hJTWx6WHppSlhxaFcrRXJMbm5aQkJ0ZDI1N0ljCkVETmovS3F1STNSNTBET0NkS0lybnFRYVRDMXh3eWd6VXdPNWw4RGFTZXA4Q3JpY1BXSmFKZERPdUVrMUxUdDcKdkwxSzdxWEorcFJ4bFcyT05YcGNxbFdrWldKMnNQTmtpb3E5aHRHOXJ2T1I5ZDlKUUh3d0l2aEFDK3p3NmZTVwp1QWNyMGFWaGtpRFRMdWdWWE8xdnFzZmNJczNoR0t5Smd0ZHVPd0lEQVFBQm8yTXdZVEFkQmdOVkhRNEVGZ1FVClVrdUZwTnQyZmpZc28yc05WNWp1U3lFWHlZNHdId1lEVlIwakJCZ3dGb0FVMmM1ZHdUZGJTYjU2aEhyYTlMU2IKYUpUa24xY3dEd1lEVlIwVEFRSC9CQVV3QXdFQi96QU9CZ05WSFE4QkFmOEVCQU1DQVlZd0RRWUpLb1pJaHZjTgpBUUVMQlFBRGdnSUJBQzJrSnZSaytCKzNOMHlqcUZxbTJEaXBRRjBJcHd6Y1lCaERlNnFMcklLNkRjZzhDdHh4CktjVGUyT3VzUVl4dFAvOXFFbmNZaDRLNnNtZkluMXpBamNPaGsvZlFvZURwRWxhbFcvV1hJaXJUVEoyTmVKRzUKdnBydCtlaWlRSlMxOC8vb2k1SjNVenQ0YkNDVzUwZHV3WGlnc01qRGFjZ1ZPSGJmeWR6clNNNTNmY3NmNm14eQo1ZVFMek5uSTY2NFV0WnZ6UWx6eGJONEpiakU4NC9kSU5hK24wOEdXWFA5emVFYjJJVU83Mlp6QzZlVzFySnJoCnBiVWIyamhMM1pmY3BhRHB0bzR3UnQ0cU9CenEySlZvbTlmSDJuZnkvYllTRXJVM2NjTlh5blNZU0Y2ZWZjSUEKQmJSb0FCcW9YSG1yMEZVWmt5Wlo4UXMvQXJ3YXZwamxvMmZ1RlJRTDNKVXlabUhNMkxWYmRzWWROajAvcGpMcwo5S1IrSWhUMjJBK2IyZUdraFppY096RlNCUkNoQ21NZThCMkN3eVBRd0ZlZ0ZvS3hrbGFKMjlIblM5UDFvNFI3CkxRTkdmYlpwa3l2bTkzTWtPTkFkSnlwNU8zUVI4Q05YSUxadDh4RFRmWHhEekMzUnE4YUgvTDJuM0o0M2FFSzgKWnRuVzQxRUFqVExZemxwMzY0QTFWWFBTTW9wRVV6VDRob1haUTBGQWRiV2JyWmN0TEsrVmFFQVBDbENWZWZlQgoraWRBL0pUSnRoMXlnUHB6VXh1SndhWUVTNjNidEpPVXQvclZldG05SUNJZFZiTHppVURuZytMeUU5cndxVnczCkEzQlhHc2duM3BBWWl6T3JDdldobTZ1Qjc0d2ovbklRcFM5N2hkVFVFbGh3SDZyQXQ2TVljQmZuCi0tLS0tRU5EIENFUlRJRklDQVRFLS0tLS0KLS0tLS1CRUdJTiBDRVJUSUZJQ0FURS0tLS0tCk1JSUZaakNDQTA2Z0F3SUJBZ0lCQXpBTkJna3Foa2lHOXcwQkFRc0ZBREJBTVNjd0pRWURWUVFEREI1WFNWTkYKTFVWa1oyVXpOalVnVW05dmRDQkRaWEowSUdadmNpQmtaWFl4RlRBVEJnTlZCQW9NREZkSlUwVXRSV1JuWlRNMgpOVEFlRncweU16QTJNRFV4TVRJMk5EVmFGdzB5TkRBMk1EUXhNVEkyTkRWYU1FZ3hGVEFUQmdOVkJBb01ERmRKClUwVXRSV1JuWlRNMk5URXZNQzBHQTFVRUF3d21WMGxUUlMxRlpHZGxNelkxSUVsdWRHVnliV1ZrYVdGMFpTQkQKWlhKMElHWnZjaUJrWlhZd2dnSWlNQTBHQ1NxR1NJYjNEUUVCQVFVQUE0SUNEd0F3Z2dJS0FvSUNBUURVM3Nzcwp2cnMzc2gxd0tuTjNoaUJhRjQyTmxLRCtiOVdLZFhQNWo4YjBUcDdvUGo4TjVBZDIvbUczUnJkS3Z5c05ma0E0Ck9HQ2F0WHRlSi9zYngxZnRGdWNZK2JKenNVOWNuQ1pKVXlXWHNSTWFmOFJoeE82ditlTGRIRHB1Q0VVY0p5WnkKZjQ2UFFtNmJwMXJlZUJNNmhpQWo2Z0pkQVhYSTNJNDFScFVGRi9LdjJQeG55MnVlMkZZOWdDY0phVjZvWEVzaAo0VnNyUU5JblM0V2tlc2JhNTNmUS91OTF1d0hJTzNYQ012a002RXdsSlcwN1VRRUFaZGpTbzR0QUFvbmx4TnJkCi9xRHdXMjJOcUZPMGIrSERiOCtPYkF3TWZFVVc5UWhKVUZhVm1Oc0doNVF2QzRjaGZzQStZMHJwY3gvclNYL0UKU3JDRGZyMG1aTjhWa0RHcDNpc3RvWlBteVlSc3E3bCsraUQ1Q2ZjbFd5Q3k2S2RTN2FpSHBsOWtVZXB2ZjRKKwpYWjdtVVVKbEY4NFdDdnlMZ0hVajRTNTR2Q3FYMGk5Y2ZNdWlFYmxuNm9IcmNYV3ZLbDBvNUVQWWRGT0x5QlZFCjZRR3dITFFrNktHYVdLdDYrUGpIVm1BZmMrb1AvYTdFYmh1ZTg5a1Q4cm1zdHE5V2g3R1gwbHFFZzAxamlTcWMKRnRzSGluWm54K2lMTTR1dUhSTmwvSkhaUXNZQjRJT1AyZlpIOEh2RG1zbHFxVlJkaSttOTYxRVkvWlVvdUo5NwoyMWJ5UVl0Z0RJTmEzeDVBVGJCeGx0QW5aQ1FXZXRMZ3JFSXdvOWRVMkhUajN1QjNmU3owNkMrRmI1dFN5emtBCnRERy9xSXM2SlBYaTlDelRtNm5HVTN1eTgyWGdZYW9pa2s5R0l3SURBUUFCbzJNd1lUQWRCZ05WSFE0RUZnUVUKTS9JYUdiT3dGVWltanJyU092NDFERUVQaldJd0h3WURWUjBqQkJnd0ZvQVUyYzVkd1RkYlNiNTZoSHJhOUxTYgphSlRrbjFjd0R3WURWUjBUQVFIL0JBVXdBd0VCL3pBT0JnTlZIUThCQWY4RUJBTUNBWVl3RFFZSktvWklodmNOCkFRRUxCUUFEZ2dJQkFDUlA4V1c3RGVtQ1lvcUZxMVBNajZQTHgxWWJhRkhYTXRXSFpqTXRHQUUvampheUJab1oKaUE5ZVplQWpraFJpQmkwMlRFVXdXVHoxcDJsWStjVW9rSGhTaU1HeFlWOFU1ZVNNYitPN2k4eGRIZGIya2JGagpFTTNrUncrcFhsc2NlcloxRTFxMU91SUlxTnBocW9PNkJIaU1Za2tSQVVDeElab3VHZFJlaWY0OUIyY2JySC9zCkxDWVdQbWEwQUllV3pyYzVNaFNFT1Iwc255VU9EMStHM2R6OFpCSnlBVFRTcWR4ZmI0SW1Ba2M2SGh0Wmw0aDAKMStnMHBUUTk4aDJkYWNWQitPZVpMcTdUM0J6WGsvYS9TMGF1b29zOHd2L2JYU1pOQVBKajRwanorRm1JR0ZrKwpiR2NnYWN1L1c4bTI5cVJlYkppZDB4eHlWRSs1b2V1MHNDbHpoYXlTV1RNdUlKY2JMSDlyM3JRKytoTWhxVWVwCklvemQrbUdhN2s0blY0TFoyTG03ZDBKUjFaSml0cVN5ZTFmdFFYVmQ1SUY3UjdiT1hNSExaTExPaVZFRTBHT0MKbUVvYjREekx6Y0QwRGlrSkZOZy8xNG5jV3h2bDN6Z3BELzNMYkI1VmhacmpvNFYxMjljNVZiSmF3UzhQQVNFKwpRaUlXU1hsa2FnblAxUEpkUEdwK1ZYT1FRT0FwRVB5NVpPTlYvcTlIVXVxNFJQLzZITDYxUjEwZGg5dDIzSFJECnl6TzNydFBhNkEvcG5QNHpVc0ZuT1dZVE91YTBNdHdmdXgwdFcyNC8zR2wvdnlvVVZReHlxL3pmbjVobHJVNW4Ka3NhaStQZDd5cndzU0xlN3RLYWlYaXNSWG5vK2VFWHpkT1pSakRkT2d0SU1jWUN6aXV4Q2lITVYKLS0tLS1FTkQgQ0VSVElGSUNBVEUtLS0tLQotLS0tLUJFR0lOIENFUlRJRklDQVRFLS0tLS0KTUlJRlpqQ0NBMDZnQXdJQkFnSUJCREFOQmdrcWhraUc5dzBCQVFzRkFEQkFNU2N3SlFZRFZRUUREQjVYU1ZORgpMVVZrWjJVek5qVWdVbTl2ZENCRFpYSjBJR1p2Y2lCa1pYWXhGVEFUQmdOVkJBb01ERmRKVTBVdFJXUm5aVE0yCk5UQWVGdzB5TXpBMk1EVXhNVEkyTkRkYUZ3MHlOREEyTURReE1USTJORGRhTUVneEZUQVRCZ05WQkFvTURGZEoKVTBVdFJXUm5aVE0yTlRFdk1DMEdBMVVFQXd3bVYwbFRSUzFGWkdkbE16WTFJRWx1ZEdWeWJXVmthV0YwWlNCRApaWEowSUdadmNpQmtaWFl3Z2dJaU1BMEdDU3FHU0liM0RRRUJBUVVBQTRJQ0R3QXdnZ0lLQW9JQ0FRQ3lwNmJHCjI0RlF1WE53VG12NWpmTDRUQ3lPN1M1N3dsWlVZcjRZQjhDY3RVNjZyMGFya3dKTGc1NUhDbGF0aHo4Z05yWWYKOWp6SUNlaEZjZjJ6alluaW5IQXZPWk5DcjVwT0pFSXpZbWFKWVQzWTYzVnBCZWdOaE5uU212bjZ0UUZTc0NwagpUT1prdW5SN25wVkxsTWNRakNnL203NmJMVVNvQkkzTUdkeVZTVUpFU2ZJQ1ByOHhLNDZCSW10Y2d1ZGpva2N5CkdiSnFVenpEb0hRRXJEd0o3dW45TWJpTktRenNMVW8vdkQ1Sjcxc1VyV2QzWGdXWkVhRzdCUis3MG9PRkVUL1cKWEdIeUVxekJWTk1hZTdVeHFuWTZFcENxamxYbW1WclJ6Q2s3Qm8wWmczSUhKd1FXcFp5Rit3QWNzM0doeDNqQgpPTVE2OVJuMjVUYnRTWHgyeUNVaFk2OGYvOERvYUROSlZtT1pOS2t4M3A1L1VHN2lubnFsRnBGTC80SGVMUnBLCnRtMmVWTmpiUURzQkRmOGF2QWJjcytyb2Z5bVJJL2h2bkZ5VGtYMVJYVnU0Y05kdW5BZEVyd0ZaaTVqWE0wbWIKRGpRenR0YzFnQlRCcEY4aHdac01sd2dxZkYwZGpxY2Z5aE1INjBZcVk4U0VwN255VjJVSFcwOXZ5UkdwdllTaQplajBkNTgyMWRWN2hiRmdyNU1aQUY3MitNcDV1RzNjTDQyK2JNaVo5K3c5UUdLRW9VbllYdWFHWERrVDVZemlTCnBKSzZCamluMW0za1VGWmwrbkFBRkN4VWd0Y2h2ek1iOGRYczZ0Ukx5cnFGbkVrK0lGcnhaQW9kMDRpRlhHTnEKUVdKRTVKeVhqY0ZlajlmRmh6U20zY1RrYlZBcWM3aVNnOVhGRFFJREFRQUJvMk13WVRBZEJnTlZIUTRFRmdRVQppeG12Z1EzVEdaSjNuMzJKQVFUMzluL0FHa0V3SHdZRFZSMGpCQmd3Rm9BVTJjNWR3VGRiU2I1NmhIcmE5TFNiCmFKVGtuMWN3RHdZRFZSMFRBUUgvQkFVd0F3RUIvekFPQmdOVkhROEJBZjhFQkFNQ0FZWXdEUVlKS29aSWh2Y04KQVFFTEJRQURnZ0lCQUtQU2ZnR3h0UDlNR3RSbFdlb0NCdmRqUEpUdTNJRmxBWFFQTVJoWDFFbnNLNWQ2WWpmVQpiQ1JPNVpNaWVueTNVMC8xNVFlRVNwanpTMXYrbEloNkkvZXd6S1djQ2lTdVNFTzd3Z1phT2ZDRWZ5NDg4VWVXCjBhbFFheTJVQU43dWFmRStubXJaVy9VOEkrdnR1VXVqR2FNREdtTlZyZ2lRQTZXV0lMQytHaXhzdk5OSzhnSngKMmgzd3lUTkl5M1FDb1pIOUc3SElScGIwMWtPWXROb2tYdUQraDJSQ2kxQW5jNVhHR3J3SlRZTy8vQXVsVWt5Qgp0RkRzUVowbE96b3F1N1pUK1JlQkQ5U2tIQlNHeTVrK2ozREJUL0k5MUU2L1B0SXVwVWJ1WTFzbVI4WXI1cnNYCmdFUVpCUE80aVdBZkVhKzBramc3S2VuMlRGcHZsSTdKMkxXczl2TlhkV0xyZzJKZ1RGajViK3JBb2pySUhzVVIKN2RCRnhTTXVrdjlPS2xvRlBGM1BoZVNNWEhsVnhoM0FyZFVPL0FKRUVoV0JXRW9XZEltRXZhNXBhemNObFEzLwpRZU1PQ2syeUp3dUhaVno5RXl4YnpWRHFHV25kR2pPeENKZ1pBS2ZaSmFQdGNHSVRlQlNia0lvcjF2bkNxcCsxCjdIUVFxQ0dsRE5MQUkwbzhZY0M3WUJwN0ZxZEw4VjFoWVZweGVNUkYyTUdHajl4UGFxK0pYNmQvNzZuUWV0ai8KbmtqSjZ4VkZGZzZsNzZBSTBxUS9TYjU0cjM4U2dONmFmTjFNYlNDQTBTbmtBYi92V1JnOTcrVW9RNkMxTnZOaQozRzU5NHVFMmtBcXBiYmJYeGFvNjgrb3lXQWVkTm5UbWhhSVJ3aWdReW9yVzJSSVlhYldpcEY4WQotLS0tLUVORCBDRVJUSUZJQ0FURS0tLS0tCi0tLS0tQkVHSU4gQ0VSVElGSUNBVEUtLS0tLQpNSUlGWmpDQ0EwNmdBd0lCQWdJQkJUQU5CZ2txaGtpRzl3MEJBUXNGQURCQU1TY3dKUVlEVlFRRERCNVhTVk5GCkxVVmtaMlV6TmpVZ1VtOXZkQ0JEWlhKMElHWnZjaUJrWlhZeEZUQVRCZ05WQkFvTURGZEpVMFV0UldSblpUTTIKTlRBZUZ3MHlNekEyTURVeE1USTJORGxhRncweU5EQTJNRFF4TVRJMk5EbGFNRWd4RlRBVEJnTlZCQW9NREZkSgpVMFV0UldSblpUTTJOVEV2TUMwR0ExVUVBd3dtVjBsVFJTMUZaR2RsTXpZMUlFbHVkR1Z5YldWa2FXRjBaU0JEClpYSjBJR1p2Y2lCa1pYWXdnZ0lpTUEwR0NTcUdTSWIzRFFFQkFRVUFBNElDRHdBd2dnSUtBb0lDQVFETWVRV0YKbTJzbStWL3JpaUdObnFEemVVUEROUHE0L2NuZGg3aEZMc0NSRUlWRllqUDFyeU5ZOXNkM0hZMGxvWEg3SGFlaQpzOXVzdHJXTEhULzNiNkUrNWdWZXZlVWdJSzFqZlVXcnVSZ0o3ajl5WkNRVk9KSDlFaDg4bkRsWW9nUGJHOWhoCmFvYTgrMWxVRjdmZlJXcXZoZ1VscTZxOFo5MVltelgzREQwT09NZi9uTDNRaWU1eFFoblpKb2VXL0tLa0RIOTEKeG1GSlQzMk4zZ0hIMjNOeDZFaGJsRWdQVHdsekhEWVduN0xnMzV3OTVWUDVHL3FQckdzZUl4YVZLTEZpRjI3ZworNEpBSzQ4K2hkODZwWlRLOXVXWldpN2RHYTA2a1YxU2d6ejNkSnllWVlyQ0VkcjFlb0M3TmMrSUFNRGEzdmVoCk1SY0lrek5TWUZOR1hjbmhZQjZ5RmdDZnVpeDViWTY1em1QVXlIajNXejlNV0g1d0IxNDBIVG1YRS9SUy9wZUwKVWsvNVQ1R3RpK29NTzRWUVgxN2JjcjI2UXFHM0drWDFqVUNGNlBxcmdUWWlZSllsR0JOZFkwUExiTHdESFN3dwpRenh6N3dKYjI3djdIRXRlTHQzeDkxUnMwY1ZWUUFod2JzQzFPTWZ6QU1aVWl5WXRFL0FMeWFVSkpYVTczVWRFCnNaZ1lFUmdEbjkwSTJvVzA1c0F5ZDNLZEJhYUdkL3NhQzFLUnpMSUpoSjZ4bWlxUStUbXhaTGluelZVRk5kY2EKSkNvSXFsaHpTNGxDNE5EUkNqTHVUVWpLZWVweWV5QkVpOVNqQndoU1d5djdyK1NCWVh0d1FtOHBBeUQ3L1FVYgpZZUhqMjlJNXpyTXZyakVNd2VNVDd3dzlZMWJualYrdm42VEtsd0lEQVFBQm8yTXdZVEFkQmdOVkhRNEVGZ1FVCjJSaVRkY29TaWZoMVdIWlN5cm5xSGI4T1BJNHdId1lEVlIwakJCZ3dGb0FVMmM1ZHdUZGJTYjU2aEhyYTlMU2IKYUpUa24xY3dEd1lEVlIwVEFRSC9CQVV3QXdFQi96QU9CZ05WSFE4QkFmOEVCQU1DQVlZd0RRWUpLb1pJaHZjTgpBUUVMQlFBRGdnSUJBRGJLTlN4YXRFWXh1L0VXNk1RTVpwb2lERk55WGJHcC83ekVIVVE1ejdld0Y3cldKY3BhCktHa3pJVUlPSVRkbDlCaHhJNVlKOCtaYVdycHVCZUdvRkFWVDBqMjk4NnJSYkl2VHJXbm02NzNZSkJqVmdaMVcKZlJqNzI0RVhiUXFJeXBCZkREWFowRHNTMEgwZ2FwdUxaZzZYbGxIaEpsUklUMUJlTE5vTlNGajFMQ1ZHMm5peQpZa01MWGMyYVNObi85RWtoRnA5TkZ4NExVa3EvaGg3ejF0d0pweE43Ky9WaXQ2eDNWTVE3cWlrZmFJc3cyUy9WCjlxVTBsRm1HdDVKbmxZaEloNVphT0NZTDlYKzV0M1ZKekNQZk1PYnkzL2hQakZqN1UySlIrRkdhc2lYeFFVMnYKWmlJMDJjMEl4TTY5REJCV0JWT0dBdC9TaTFrU0pETmlyN2ZVbEZGM2dKT3JBUzNBNG5kWlFmSkJubXVNbmp3LwowVkFxZGsrbEhnUU9tWWt2eHowYmxsZDZ5cER5cENCeU5FRG8wNGY1d0xKZk8rUDNKRS9oM0w3T3Nkd0t3VklsCjIrWU5iREF3bjMwNkJIWnFDc0tQbTBrYk9xTDhjTmxRajc5dXFOVkJvMld6RjV6MmtSUFppZ3Fib3hIS1k4MVgKamt3SlhIbzF1MWpvN1RjbUJSMitlTjZ1enJ4dzREVDVKWEJSS1Vjc2dLVkZuR3NqY3FPdUJQbVlaZlprVTJtQwpFNm9VZHp3UFRmOFFlVEtwNjRjZzlacWMxVnhoWFUyWDYvTG5qSWE2YytySXIvTlZnekJBTDZGYUFjTnE1NUt2CmVVUk9mQnkySW1oakkvU1FtdFlCQUlPNTQzZERZNmRmd1lpcEh0QVViTzBjTUQ3SHZVRXZxb2gxCi0tLS0tRU5EIENFUlRJRklDQVRFLS0tLS0KLS0tLS1CRUdJTiBDRVJUSUZJQ0FURS0tLS0tCk1JSUZaakNDQTA2Z0F3SUJBZ0lCQlRBTkJna3Foa2lHOXcwQkFRc0ZBREJBTVNjd0pRWURWUVFEREI1WFNWTkYKTFVWa1oyVXpOalVnVW05dmRDQkRaWEowSUdadmNpQmtaWFl4RlRBVEJnTlZCQW9NREZkSlUwVXRSV1JuWlRNMgpOVEFlRncweU16QTJNRFl3TlRFNE5UUmFGdzB5TkRBMk1EVXdOVEU0TlRSYU1FZ3hGVEFUQmdOVkJBb01ERmRKClUwVXRSV1JuWlRNMk5URXZNQzBHQTFVRUF3d21WMGxUUlMxRlpHZGxNelkxSUVsdWRHVnliV1ZrYVdGMFpTQkQKWlhKMElHWnZjaUJrWlhZd2dnSWlNQTBHQ1NxR1NJYjNEUUVCQVFVQUE0SUNEd0F3Z2dJS0FvSUNBUUNYNk9PSgo5UlFmS0JTNk1lVEVycWtTV210bVhPY1JRZVZtckVtRkQwN0ttNUVxVzVmaGtsMURLcElUaHZaSmVQdHFiMlh4CnM4TGRJQ05OVHNoaEE5YXFKVnpkRzFJcnVlY1hiR0t4VFVaT0l4bUlTRFM2cDRuTXViOVVpVlJWc0tPeHdkaUMKUTNLbHlrMFl6VFpHWlhwWEhkRi9oYmN4MTBoaXVQU0dTTFV2Zk82M2lKQVVNbDZFTTgwd0pXeGFCaVRGc3EyTgpqWDlseDJCL09udXhuS2NlU085S3p2ZzdIWDdud0xCdllvQVFtSndhS0dMK1UyZFZvcDJTNm1UMXJoUnNSUGs5CnVlSjNHcDhkZ0dQWnBPQkc4ZThSdDRwVE9CTVR5N04wSGlJL203eUJRbmgvVUNPWGs4d3ZYLy92dE9rK096N2kKdFl3ODhKYmpta1d1YkxBc2cwYkszanZYanRlSC83UXlhYTlnYy9iL0kwWmxyMmlUakU1UWtEZE4rajVkSkxVSgowcGFwL3FzcXJsNlFma0M4a2N4cmRaUzBoTjBTR08yWm9LQTY0VGVGSXg4OXBrdTZVYTgra29uL1ltNGxydGZBCkZuaDkydmM0ZnV3cUMvSDFDdGJ4WW9Ock9WeGs3QVZuZStmS1VoMjhFaXJEckdFUHJScDZLWHN1WXR3cm9Xam8KRXQ3NFRCZEtJeFpVcS8yQjAxb3pSWmFlaEoyQmE2a1FZZExHei9URHN2T3lIWXg0djVjQTRNc3NUSEZXN25IOAplL1h6NHJnMGFrdVpuRVNPbHVnRVdjOG1ISUNtUklFZytYeTFuQ2thVkhRUzBJdVRad2lacityemN2emVyZ2hjCkRyK3hxWGFxLzdTSmpmaHJxMWx0NEJzbzR6VXlndlBhZ20xY2xRSURBUUFCbzJNd1lUQWRCZ05WSFE0RUZnUVUKN2pCUzZHVHRHeDhKdHgyQUI4OWdhMmRLRmNFd0h3WURWUjBqQkJnd0ZvQVVvVU9YSllweitYTmw5UzA1cnhCZgpSbmVFOHE0d0R3WURWUjBUQVFIL0JBVXdBd0VCL3pBT0JnTlZIUThCQWY4RUJBTUNBWVl3RFFZSktvWklodmNOCkFRRUxCUUFEZ2dJQkFJa3B4ckZXekJhOXdPaFVXelNzbXdxVTBnU3djVXZPYlJlWWZybS9TZXd5KzBHbEtjWlgKRjRaODVCblhsUFg4NXNNV1VHY3hIZ3UxYWZaaDd3TVJQS3lsWE1wZ2F0YWE1Tnl3YmhRZHFIZDhsK3Rpd3JqMgpOOVJRNnNzYVlraE9qTlZNYndsbk1kRVJJUzVsOXJhcXlGYlhMZktJczBhcXVXNmxZTWpieUdsR3drMHcrMzR6ClpkOElZcXRRLzdIWVVEQ3NBenJVUHJoMTFrT0FlNDI2Tjc0RTdCakQvUjFnRUZXMnQ3NHUvYnIzS3ZTejZNSTAKeGdraEVzcnN5Nk9XRTlWeWNuYmVhQ2tJVC9pNk5xZVRKVWRnVU1UTCtodTNMWWtvT3FxN3R0M2xCL3VFdUZCaQpNOWZDdXBqMG5hQU5BT2pNZHFuWEZEN3lFcThYR3J0VzNpKzRDTFpWSnVUYWRtaENKVTNoUXZDbklTdmhPcWRWCk5Haml1Skh4czd5c0I1aFdlTEE4b2JZVGg1TndsSjNKYmNFaU9naHR1bnpnZ1ZDYVh5bGRka25TNE51eFZWeFYKckZQRFZaTXJKNVZaaE5jSlFibm5QQnVhWXdyOERDbTVjdjZLZGV5TnQ4bDdkdEVTdnB1QUVEWW1qOFAybi9oZQpWVmtPaUV5NEtITlRRRUNDeGg2aGEwQjNTWnJlS2dabnFwTWVncWhvbXhUcGNWekFiNTNyanJMVmhoMUtHbEQ4CnllSEMzcVpvSnV3T0dKZU5KN1dpSVVtRStYbGNOc0dpeENiVkZDK0JzTGx2SHFnNjZWUlh5Z0ZrbHFvR0RMVlIKWWIwVnRJc1VlbS9wenhyN2ZSNWlVQmM4YWloTnZQeCtjZmhJWXlXV3JoRTZETU04UHNWYlFNTEIKLS0tLS1FTkQgQ0VSVElGSUNBVEUtLS0tLQo="
        }
*/
router.get('/all', (req, res) => {
    let accountName = common.getUserNameFromJwtToken(req);
    logger.info('Get All Cert User: ', accountName);

    certCtrl.getAllRootAndIntermediateCert()
        .then(result => {
            if (!result.status) throw new Error(result.message);
            return res.send({
                allCaName: result.certInfo.fileName,
                certificate: (result.certInfo.certContent === '') ? result.certInfo.certContent : Buffer.from(result.certInfo.certContent).toString('base64')
            })
        })
        .catch(error => {
            logger.error('api get all cert info: ', error.message);
            responseError(res, error.message);
        })
});

// API: /cert/root/register
/**
    @api {post} /cert/root/register Register root cert to iothub and rabbitmq
    @apiVersion 0.1.0
    @apiDescription Register root cert of iothub and rabbitmq
    @apiGroup Cert
    @apiHeaderExample {json} Header-Example:
        {
            "X-Cert-Token": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhY2NvdW50TmFtZSI6InRvbS5jaG91QGFkdmFudGVjaC5jb20udHciLCJpYXQiOjE2ODY2MTk2MjgsImV4cCI6MTY4NjYxOTgwOH0.2lAyJ84lDZznnmWcU0lXaL_WSIwT1DMSCBcQjYygjbc"
        }

    @apiBody {Number} id the id of the root cert
    @apiBody {String} subject the subject of the iothub and rabbitmq
    @apiParamExample Request-Example:
        http://4.193.252.254:3000/v1.0/cert/root/register
    @apiParamExample {json} Request-Example:
        {
            "id":3,
            "subject": "WISE-Edge365 Root Cert 3"
        }

    @apiSuccess {Number} id the id of the root certs

    @apiSuccessExample {json} Success-Response:
        HTTP/1.1 200 OK
        {
            "id": 3
        }

*/
router.post('/root/register', (req, res) => {
    let accountId;
    let accountName = common.getUserNameFromJwtToken(req);
    let rootIdx = parseInt(req.body.id);
    let subject = req.body.subject;
    let status = common.CERT_STATUS.NEW;

    pg.getAccountIdByAccountName(accountName)
        .then(queryResult => {
            if (!queryResult.status) throw new Error(queryResult.message);
            accountId = queryResult.result.rows[0].accountid;

            return certCtrl.checkRootCertRegisterExists(status)
        }).then(isExists => {
            if (isExists.status) throw new Error(isExists.message);
            if (!isExists.status && isExists.message) throw new Error(isExists.message);
            return certCtrl.registerRootCertAndUpdateResult(rootIdx, status, subject, accountId, accountName)
        })
        .then(registerResult => {
            if (!registerResult.status) throw new Error(registerResult.message);
            return res.send({ id: registerResult.id })
        })
        .catch(error => {
            logger.error('api post root cert register: ', error.message);
            responseError(res, error.message);
        })
})

// API: /cert/intermediate/register
/**
    @api {post} /cert/intermediate/register Register intermediate cert to iothub and rabbitmq
    @apiVersion 0.1.0
    @apiDescription Register intermediate cert of iothub and rabbitmq
    @apiGroup Cert
    @apiHeaderExample {json} Header-Example:
        {
            "X-Cert-Token": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhY2NvdW50TmFtZSI6InRvbS5jaG91QGFkdmFudGVjaC5jb20udHciLCJpYXQiOjE2ODY2MTk2MjgsImV4cCI6MTY4NjYxOTgwOH0.2lAyJ84lDZznnmWcU0lXaL_WSIwT1DMSCBcQjYygjbc"
        }

    @apiBody {Number} id the id of the intermediate cert
    @apiBody {String} subject the subject of the iothub and rabbitmq
    @apiParamExample Request-Example:
        http://4.193.252.254:3000/v1.0/cert/intermediate/register
    @apiParamExample {json} Request-Example:
        {
            "idx":3,
            "subject": "WISE-Edge365 Root Cert 3"
        }

    @apiSuccess {Number} id the id of the root certs

    @apiSuccessExample {json} Success-Response:
        HTTP/1.1 200 OK
        {
            "idx": 3
        }

*/
router.post('/intermediate/register', (req, res) => {
    let accountId;
    let accountName = common.getUserNameFromJwtToken(req);
    let intermediateIdx = parseInt(req.body.idx);
    let subject = req.body.subject;
    let status = common.CERT_STATUS.NEW;

    pg.getAccountIdByAccountName(accountName)
        .then(queryResult => {
            if (!queryResult.status) throw new Error(queryResult.message);
            accountId = queryResult.result.rows[0].accountid;

            return certCtrl.checkIntermediateCertRegisterExists(status)
        })
        .then(isExists => {
            if (isExists.status) throw new Error(isExists.message);
            if (!isExists.status && isExists.message) throw new Error(isExists.message);
            return certCtrl.registerIntermediateCertAndUpdateResult(intermediateIdx, status, subject, accountId, accountName)
        })
        .then(registerResult => {
            if (!registerResult.status) throw new Error(registerResult.message);
            return res.send({ idx: registerResult.idx })
        })
        .catch(error => {
            logger.error('api post intermediate cert register: ', error.message);
            responseError(res, error.message);
        })
})

// API: /cert/root/:id
/**
    @api {delete} /cert/root/:id Delete root cert
    @apiVersion 0.1.0
    @apiDescription Delete root cert
    @apiGroup Cert
    @apiHeaderExample {json} Header-Example:
        {
            "X-Cert-Token": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhY2NvdW50TmFtZSI6InRvbS5jaG91QGFkdmFudGVjaC5jb20udHciLCJpYXQiOjE2ODY2MTk2MjgsImV4cCI6MTY4NjYxOTgwOH0.2lAyJ84lDZznnmWcU0lXaL_WSIwT1DMSCBcQjYygjbc"
        }

    @apiParam {Number} id the id of the root cert
    @apiParamExample Request-Example:
        http://4.193.252.254:3000/v1.0/cert/root/3

    @apiSuccess {Number} id the id of the root

    @apiSuccessExample {json} Success-Response:
        HTTP/1.1 200 OK
        {
            "id": 3
        }

*/
router.delete('/root/:id', (req, res) => {
    let accountId;
    let name = common.CERT_NAME.ROOT;
    let accountName = common.getUserNameFromJwtToken(req);
    let rootId = parseInt(req.params.id);

    pg.getAccountIdByAccountName(accountName)
        .then(queryResult => {
            if (!queryResult.status) throw new Error(queryResult.message);
            accountId = queryResult.result.rows[0].accountid;

            return pg.getRootCertById(rootId);
        })
        .then(queryResult => {
            if (!queryResult.status) throw new Error(queryResult.message);
            return certCtrl.removeCertAndUpdateResult(name, accountId, accountName, queryResult.result.rows[0])
        })
        .then(removeResult => {
            if (!removeResult.status) throw new Error(removeResult.message);
            if (removeResult.result.rowCount !== 1) throw new Error('Remove and update the root cert info has failed');
            return res.send({ id: rootId });
        })
        .catch(error => {
            logger.error('api delete root cert: ', error.message);
            responseError(res, error.message);
        })
})

// API: /cert/intermediate/:id
/**
    @api {delete} /cert/intermediate/:id Delete intermediate cert
    @apiVersion 0.1.0
    @apiDescription Delete intermediate cert
    @apiGroup Cert
    @apiHeaderExample {json} Header-Example:
        {
            "X-Cert-Token": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhY2NvdW50TmFtZSI6InRvbS5jaG91QGFkdmFudGVjaC5jb20udHciLCJpYXQiOjE2ODY2MTk2MjgsImV4cCI6MTY4NjYxOTgwOH0.2lAyJ84lDZznnmWcU0lXaL_WSIwT1DMSCBcQjYygjbc"
        }

    @apiParam {Number} id the id of the intermediate cert
    @apiParamExample Request-Example:
        http://4.193.252.254:3000/v1.0/cert/intermediate/3

    @apiSuccess {Number} id the id of the intermediate

    @apiSuccessExample {json} Success-Response:
        HTTP/1.1 200 OK
        {
            "id": 3
        }

*/
router.delete('/intermediate/:id', (req, res) => {
    let accountId;
    let name = common.CERT_NAME.INTERMEDIATE;
    let accountName = common.getUserNameFromJwtToken(req);
    let intermediateId = parseInt(req.params.id);

    pg.getAccountIdByAccountName(accountName)
        .then(queryResult => {
            if (!queryResult.status) throw new Error(queryResult.message);
            accountId = queryResult.result.rows[0].accountid;

            return pg.getIntermediateCertById(intermediateId);
        })
        .then(queryResult => {
            if (!queryResult.status) throw new Error(queryResult.message);
            return certCtrl.removeCertAndUpdateResult(name, accountId, accountName, queryResult.result.rows[0])
        })
        .then(removeResult => {
            if (!removeResult.status) throw new Error(removeResult.message);
            if (removeResult.result.rowCount !== 1) throw new Error('Remove and update the intermediate cert info has failed');
            return res.send({ id: intermediateId });
        })
        .catch(error => {
            logger.error('api delete intermediate cert: ', error.message);
            responseError(res, error.message);
        })
})

// API: /cert/device/:serialNo
/**
    @api {delete} /cert/device/:serialNo Delete device cert
    @apiVersion 0.1.0
    @apiDescription Delete device cert
    @apiGroup Cert
    @apiHeaderExample {json} Header-Example:
        {
            "X-Cert-Token": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhY2NvdW50TmFtZSI6InRvbS5jaG91QGFkdmFudGVjaC5jb20udHciLCJpYXQiOjE2ODY2MTk2MjgsImV4cCI6MTY4NjYxOTgwOH0.2lAyJ84lDZznnmWcU0lXaL_WSIwT1DMSCBcQjYygjbc"
        }

    @apiParam {String} serialNo the serialNo of the device
    @apiParamExample Request-Example:
        http://4.193.252.254:3000/v1.0/cert/device/00D0CD000066

    @apiSuccess {String} serialNo the serialNo of the device

    @apiSuccessExample {json} Success-Response:
        HTTP/1.1 200 OK
        {
            "serialNo": "00D0CD000066"
        }

*/
router.delete('/device/:serialNo', (req, res) => {
    let accountId;
    let type;
    let name = common.CERT_NAME.DEVICE;
    let accountName = common.getUserNameFromJwtToken(req);
    let serialNo = req.params.serialNo;

    pg.getAccountIdByAccountName(accountName)
        .then(queryResult => {
            if (!queryResult.status) throw new Error(queryResult.message);
            accountId = queryResult.result.rows[0].accountid;

            if (setting.EDITION === setting.BI_EDITION_NAME.azureAKS) {
                type = common.CERT_TYPE.AZURE_KEY_VAULT;
            } else {
                type = common.CERT_TYPE.LOCAL_DB;
            }

            return pg.getDeviceCertBySerialNo(serialNo, type);
        })
        .then(queryResult => {
            if (!queryResult.status) throw new Error(queryResult.message);
            let arr = [];
            for (let info of queryResult.result.rows) {
                arr.push(certCtrl.removeCertAndUpdateResult(name, accountId, accountName, info))
            }
            return Promise.all(arr);
        })
        .then(results => {
            for (let removeResult of results) {
                if (!removeResult.status) throw new Error(removeResult.message);
                if (removeResult.result.rowCount !== 1) throw new Error('Remove and update the device cert info has failed');
            }
            return res.send({ serialNo: serialNo });
        })
        .catch(error => {
            logger.error('api delete device cert: ', error.message);
            responseError(res, error.message);
        })
})

// API: /cert/server/:id
/**
    @api {delete} /cert/server/:id Delete RabbitMQ server cert
    @apiVersion 0.1.0
    @apiDescription Delete RabbitMQ server cert
    @apiGroup Cert
    @apiHeaderExample {json} Header-Example:
        {
            "X-Cert-Token": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhY2NvdW50TmFtZSI6InRvbS5jaG91QGFkdmFudGVjaC5jb20udHciLCJpYXQiOjE2ODY2MTk2MjgsImV4cCI6MTY4NjYxOTgwOH0.2lAyJ84lDZznnmWcU0lXaL_WSIwT1DMSCBcQjYygjbc"
        }

    @apiParam {Number} id the id of the server
    @apiParamExample Request-Example:
        http://4.193.252.254:3000/v1.0/cert/server/310

    @apiSuccess {Number} id the id of the server

    @apiSuccessExample {json} Success-Response:
        HTTP/1.1 200 OK
        {
            "id": 310
        }

*/
router.delete('/server/:id', (req, res) => {
    let accountId;
    let type;
    let tableName = 'device';
    let certName = common.CERT_NAME.SERVER;
    let orgId = -1;
    let accountName = common.getUserNameFromJwtToken(req);
    let id = parseInt(req.params.id);

    pg.getAccountIdByAccountName(accountName)
        .then(queryResult => {
            if (!queryResult.status) throw new Error(queryResult.message);
            accountId = queryResult.result.rows[0].accountid;

            if (setting.EDITION === setting.BI_EDITION_NAME.azureAKS) {
                type = common.CERT_TYPE.AZURE_KEY_VAULT;
            } else {
                type = common.CERT_TYPE.LOCAL_DB;
            }

            return pg.getServerCertById(id, certName, orgId, type);
        })
        .then(queryResult => {
            if (!queryResult.status) throw new Error(queryResult.message);
            let arr = [];
            for (let info of queryResult.result.rows) {
                arr.push(certCtrl.removeCertAndUpdateResult(tableName, accountId, accountName, info))
            }
            return Promise.all(arr);
        })
        .then(results => {
            for (let removeResult of results) {
                if (!removeResult.status) throw new Error(removeResult.message);
                if (removeResult.result.rowCount !== 1) throw new Error('Remove and update the server cert info has failed');
            }
            return res.send({ id: id });
        })
        .catch(error => {
            logger.error('api delete server cert: ', error.message);
            responseError(res, error.message);
        })
})

module.exports = router;
