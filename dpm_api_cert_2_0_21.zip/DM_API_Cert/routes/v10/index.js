const express = require('express');
const router = express.Router();

// const setting = require('../../conf/setting');
const db = require('../../lib/db');
const logger = require('../../lib/logger').getLogger('web');
const sso = require('../../lib/sso');
// const dns = require('dns');
// const common = require('../../lib/common')
////////////////////////////////////////////////////

// function responseError(res, msg) {
//     res.status(400).json({ "code": 400, "result": msg });
// }

function rejectUserLogin(res, msg) {
    res.status(400).json({ 'result': msg });
}

// API: /v1.1/userInfo
/**
    @api {post} /userInfo Post SSO account info
    @apiVersion 0.1.1
    @apiName Post SSO account info
    @apiGroup User
    @apiPermission anyone

    @apiHeaderExample Header-Example:
        Accept:application/json
        Content-Type:application/json
        Authorization: {EIToken}

    @apiParam {Number} EIToken SSO EIToken

    @apiSuccess {Number} id the id of user
    @apiSuccess {Number} name the name of user

    @apiSuccessExample {json} Success-Response:
        HTTP/1.1 200 OK
        {
            "id":1,
            "name":"xxx@advantech.com.tw"
        }
*/
router.post('/userInfo', function (req, res) {
    //Here already pass common check
    let token = req.headers['authorization'];

    //get user info from token
    sso.getUserInfoByEIToken(token, function (err, result) {
        if (err) {
            console.log('Error: ' + err);
            res.sendStatus(401); //auth with SSO failed
            return;
        }

        let userName = result.username;
        //let userfirstName = result.firstName;
        //let userlastName = result.lastName;

        //get user id, creator id from DB, and store in session
        db.getCustomerInfoByName(userName, function (err, result) {
            if (err || result.rows.length === 0) {
                logger.error(err);
                rejectUserLogin(res, 'Error: Get User Info failed');
                return;
            }
            //store data in https session
            if (typeof req.session.user_id === 'undefined' || typeof req.session.company_id === 'undefined' ||
                typeof req.session.creator_id === 'undefined') {
                req.session.regenerate(function () {
                    req.session.user = userName;
                    //set user info
                    req.session.user_id = result.rows[0].accountid;
                    req.session.company_id = result.rows[0].creator;
                    req.session.creator_id = result.rows[0].creator;
                    //req.session.role = result.rows[0].role;
                    res.json({ 'name': userName, 'id': result.rows[0].accountid });
                });
            } else {
                //Updates the .maxAge property in session
                req.session.touch();
                res.json({ 'name': userName, 'id': result.rows[0].accountid });
            }
        });
    });
});

module.exports = router;
