// The ecosystem.config.js file is used to create PM2 services in a standardized format
module.exports = {
    apps: [{
        name: 'cert app',
        script: 'npm run start_local',
        env: {
            NODE_ENV: 'development'
        },
        env_production: {
            NODE_ENV: 'production'
        }
    }]
}
