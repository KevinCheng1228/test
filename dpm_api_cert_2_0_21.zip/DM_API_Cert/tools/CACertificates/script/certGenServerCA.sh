#!/bin/bash
home_dir="$1"
cd "${home_dir}"

# create server ca
# $2: common name (not use)
# $3: organization name
# $4: root password
# $5: expire days
# $6: intermediate password
# $7: common name (for server)
# $8: intermediate_ca number
# $9: server password
# $10: rabbitmq ip
# $11: rabbitmq dns
# $12: extension name (for server)
./certGen.sh create_server_certificate_from_intermediate "$2" "$3" "$4" "$5" "$6" "$7" "$8" "$9" "$10" "$11" "$12"

# gen keyvault file
cat ./server_ca/server-$8.cert.pem ./server_ca/server-$8.pkcs8.pem > ./keyvault/outbound/server-$8.keyvault.pem
