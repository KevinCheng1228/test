#!/bin/bash
home_dir="$1"
cd "${home_dir}"

# create intermediate ca
# $2: common name
# $3: organization name
# $4: root password
# $5: expire days
# $6: intermediate password
# $7: index
./certGen.sh generate_intermediate_ca "$2" "$3" "$4" "$5" "$6" "$7"

# gen keyvault file
cat ./intermediate_ca/intermediate-$7.cert.pem ./intermediate_ca/intermediate-$7.pkcs8.pem > ./keyvault/outbound/intermediate-$7.keyvault.pem
