'use strict';
const logger = require('../lib/logger').getLogger('setting');

//////////////////////////////////////////////////////////////////////
// Default values setting, real value is obtained by VCAP_SERVICE
//////////////////////////////////////////////////////////////////////
let APP_VERSION = '2.00.000-b01'; //'dm-1.00.001';
let APP_API_VERSION = 'v1.1'; //'dm-1.00.001';
let DUMPDB_VERSION = '';
let APP_NAME = 'api-cert';
let DOMAIN_NAME = '.wise-paas.com';
let ORG_ID = 'bd2f4130-750a-43d9-beee-5991c2d404ff';
let ORG = 'adviiot-ene';
//isensingSW space: M+ 080.003
let SPACE_ID = '033d5201-cef0-4649-a43b-125094dcc660';
let SPACE = 'devices';
let SESSION_COOKIE_NAME = 'DPMsid';
let JWT_COOKIE_NAME = 'DpmToken';

//////////////////////////////////
//for Cert
//////////////////////////////////
//Key-vaule
let KEY_VAULT_URL = process.env.KEY_VAULT_URL;

//Certificates
let CERT_ORANIZATION_NAME = process.env.CERT_ORANIZATION_NAME || 'WISE-Edge365';
let CERT_COMMON_NAME = process.env.CERT_COMMON_NAME || 'WISE-Edge365';

//Azure iothub
let AZURE_SUBSCRIPTION_ID = process.env.AZURE_SUBSCRIPTION_ID;
let AZURE_RESOURCE_GROUP_NAME = process.env.AZURE_RESOURCE_GROUP_NAME;
let AZURE_RESOURCE_NAME = process.env.AZURE_RESOURCE_NAME;

//Cert Expiry Day
let ROOT_EXPIRY_DAY_NUMBER = 9125; // 25 year
let INTERMEDIATE_EXPIRY_DAY_NUMBER = 2555; // 7 year
let DEVICE_EXPIRY_DAY_NUMBER = 365; // 1 year
let SERVER_INTERMEDIATE_ID = 5 // intermediate index 5

//Services related URL
let SSO_API_BASE_URL = 'https://portal-sso' + DOMAIN_NAME + '/v2.0';
let RABBITMQ_API_BASE_URL = 'https://api-management' + DOMAIN_NAME + '/mp/v2.1';
let DCCS_API_BASE_URL = 'https://api-dccs' + DOMAIN_NAME + '/v1';
let LICENSE_URL = '';
let WISEMPLUS_PROFILE_URL = '';
let API_HUB_BASE_URL = 'http://pivot-pivot-api-hub/graphql';
let API_ALARM_URL;

//WISE.M+ setting
let MPLUS_API_BASE_URL = 'https://api-portal-wise-mplus-' + ORG + '-' + SPACE + DOMAIN_NAME;

let POSTGRESQL_HOST = 'ei-postgres.eastasia.cloudapp.azure.com';
let POSTGRESQL_PORT = 5432;
const POSTGRESQL_DEFAULT_SCHEMA = 'pgsrpschema';//db default schema name
//isensingSw space
let POSTGRESQL_DB_NAME = 'd684fcd9-5c1b-4177-bf80-9c9e6045a156';
let POSTGRESQL_USER_NAME = '55dc93f2-d0b4-4b87-862e-f03df77e1fd2';
let POSTGRESQL_USER_PASSWORD = 'fnohp429a02r5i94ls1202dkrm';

//IoT Hub default value, real value is obtained by VCAP_SERVICE
let RABBITMQ_PORT = 1883;
let RABBITMQ_SSL_PORT = 8883;
let RABBITMQ_HOST = 'wise-msghub.eastasia.cloudapp.azure.com';
let RABBITMQ_VHOST = '3Ke5G572xnyY';
//isensingSw space
let RABBITMQ_USER_NAME = '5271f470-50e1-4929-a1ad-89576d97b066:022152d3-7fb5-4059-841d-06bde679713a';
let RABBITMQ_USER_PASSWORD = 'hk0A2MzR94qb332AqwsmRMrDc';
let RABBITMQ_SERVICE_INSTANCE_GUID = '5271f470-50e1-4929-a1ad-89576d97b066';

let RABBITMQ_WEBSOCKET_PORT = 15675;

const RABBITMQ_DEVICE_KEY_EXPIRY_MONTH = 6;

let PROGRAM_ENV = 'development';
let IS_OPEN_CORS = true;

let ETCD_HOST = 'rtm-ifp-etcd';

//////////////////////////////////
//for K8s
//////////////////////////////////
let DOMAIN = '.wise-paas.com.cn';
let DOMAIN_INTERNAL = '.en.internal';
let DATACENTER = 'hz';
let CLUSTER = 'eks002';
let EDITION = 'standard';
let WORKSPACE = '91d90025-c420-46ed-a858-ad8e2cf3779b';
let NAMESPACE = 'isensing'; //app name space
let EXTERNAL_URL = ''; //add for get base host uri
let APP_ID = 'eab8b2ac-4d98-4231-9a5b-6b64fd720e50'; //env variable: appID in WISE-PaaS

let MQTT_ACK_TIMEOUT = 60; //second
let MQTT_ACK_TIMEOUT_INTERVAL = 10; //second

//ManageBackend setting
let MANAGE_BACKEND_API_BASE_URL = 'https://api-manage-' + ORG + '-' + SPACE + DOMAIN_NAME;
let MQTT_WEBSOCKET_PROXY_URL = 'mqtt-proxy-' + ORG + '-' + SPACE + DOMAIN_NAME;

//DBMaster API
let DBMASTER_API_URL = 'https://api-dbmaster-wise-mplus-isensing-eks002.hz.wise-paas.com.cn';

//AppHub Repo API
let APPHUB_DEFAULT_USER = 'Advantech.iiot@advantech.com'
let APPHUB_DEFAULT_PWD = '!QAZ2wsx'
let APPHUB_REPO_API_URL = 'https://portal-apphub-repo-develop-eks002.hz.wise-paas.com.cn';

let MYDEVICES = {
    en: 'MyDevices',
    zh_cn: 'MyDevices',
    zh_tw: 'MyDevices',
    ja: 'MyDevices'
};

let IS_SUPPORT_IOTHUB = false;

//crypto aes key and iv
let CRYPTO_AES_KEY = '5201489546548987' + process.env.workspace;
let CRYPTO_AES_IV = '1987987191987956' + process.env.workspace;

//////////////////////////////////////////////////////////////////////
// Run time update default values in Production env
//////////////////////////////////////////////////////////////////////
// if ((process.env.NODE_ENV !== undefined && process.env.NODE_ENV === 'production') ||
//     (process.env.APP_ENV !== undefined && process.env.APP_ENV === 'production')) {
PROGRAM_ENV = 'production';
DUMPDB_VERSION = process.env.DUMPDB_VERSION;
logger.info('DUMPDB_VERSION:' + DUMPDB_VERSION);
IS_OPEN_CORS = process.env.IS_OPEN_CORS === 'true';
logger.info('IS_OPEN_CORS:' + IS_OPEN_CORS);
DATACENTER = process.env.datacenter;
logger.info('DATACENTER:' + DATACENTER);
DOMAIN_NAME = '.' + (process.env.EXTERNAL_URL || (DATACENTER + DOMAIN));
logger.info('DOMAIN_NAME: ' + DOMAIN_NAME);
if (process.env.INTERNAL_URL) DOMAIN_INTERNAL = '.' + process.env.INTERNAL_URL;
logger.info('DOMAIN_INTERNAL: ' + DOMAIN_INTERNAL);
CLUSTER = process.env.cluster;
logger.info('CLUSTER:' + CLUSTER);
EDITION = process.env.bi_edition !== undefined ? process.env.bi_edition : process.env.mplus_edition || 'standard';
logger.info('EDITION:' + EDITION);
WORKSPACE = process.env.workspace;
logger.info('WORKSPACE:' + WORKSPACE);
NAMESPACE = process.env.namespace;
logger.info('NAMESPACE:' + NAMESPACE);
APP_ID = process.env.appID !== undefined ? process.env.appID : APP_ID;
// cert
ROOT_EXPIRY_DAY_NUMBER = Number(process.env.ROOT_EXPIRY_DAY_NUMBER) || ROOT_EXPIRY_DAY_NUMBER;
logger.info('ROOT_EXPIRY_DAY_NUMBER:' + ROOT_EXPIRY_DAY_NUMBER);
INTERMEDIATE_EXPIRY_DAY_NUMBER = Number(process.env.INTERMEDIATE_EXPIRY_DAY_NUMBER) || INTERMEDIATE_EXPIRY_DAY_NUMBER;
logger.info('INTERMEDIATE_EXPIRY_DAY_NUMBER:' + INTERMEDIATE_EXPIRY_DAY_NUMBER);
DEVICE_EXPIRY_DAY_NUMBER = Number(process.env.DEVICE_EXPIRY_DAY_NUMBER) || DEVICE_EXPIRY_DAY_NUMBER;
logger.info('DEVICE_EXPIRY_DAY_NUMBER:' + DEVICE_EXPIRY_DAY_NUMBER);
SERVER_INTERMEDIATE_ID = Number(process.env.SERVER_INTERMEDIATE_ID) || SERVER_INTERMEDIATE_ID;
logger.info('SERVER_INTERMEDIATE_ID:' + SERVER_INTERMEDIATE_ID);

IS_SUPPORT_IOTHUB = !!JSON.parse(process.env.VCAP_SERVICES)[process.env.iothub_service_name || 'iothub']
logger.info('IS_SUPPORT_IOTHUB:' + IS_SUPPORT_IOTHUB);
EXTERNAL_URL = process.env.EXTERNAL_URL;
logger.info('EXTERNAL_URL:' + EXTERNAL_URL);

//https://api-sso-ensaas.hz.wise-paas.com.cn/v4.0
SSO_API_BASE_URL = process.env.SSO_API_URL || ('http://api.sso.ensaas' + DOMAIN_INTERNAL + '/v4.0');
logger.info('SSO_API_BASE_URL:' + SSO_API_BASE_URL);

//https://api-dccs-ensaas.hz.wise-paas.com.cn/v1
DCCS_API_BASE_URL = process.env.DCCS_API_URL || ('http://api.dccs.ensaas' + DOMAIN_INTERNAL + '/v1');
logger.info('DCCS_API_BASE_URL:' + DCCS_API_BASE_URL);

//https://api-portal-deviceon-bi-isensing-eks002.hz.wise-paas.com.cn
MPLUS_API_BASE_URL = 'http://api-portal-deviceon-bi' + (process.env.HOST_URL || ('.' + NAMESPACE + '.' + CLUSTER + DOMAIN_INTERNAL));
if (IS_SUPPORT_IOTHUB) MPLUS_API_BASE_URL = 'http://api-portal' + (process.env.HOST_URL || ('.' + NAMESPACE + '.' + CLUSTER + DOMAIN_INTERNAL));
logger.info('MPLUS_API_BASE_URL:' + MPLUS_API_BASE_URL);

API_ALARM_URL = 'http://api-alarm' + (process.env.HOST_URL || ('.' + NAMESPACE + '.' + CLUSTER + DOMAIN_INTERNAL));
if (IS_SUPPORT_IOTHUB) API_ALARM_URL = 'http://api-alarm' + (process.env.HOST_URL || ('.' + NAMESPACE + '.' + CLUSTER + DOMAIN_INTERNAL));
logger.info('API_ALARM_URL:' + API_ALARM_URL);

//https://api-manage-isensing-eks002.hz.wise-paas.com.cn/v1.0
MANAGE_BACKEND_API_BASE_URL = 'http://api-manage' + (process.env.HOST_URL || ('.' + NAMESPACE + '.' + CLUSTER + DOMAIN_INTERNAL)) + '/v1.0';
if (IS_SUPPORT_IOTHUB) MANAGE_BACKEND_API_BASE_URL = 'http://api-manage' + (process.env.HOST_URL || ('.' + NAMESPACE + '.' + CLUSTER + DOMAIN_INTERNAL));
logger.info('MANAGE_BACKEND_API_BASE_URL:' + MANAGE_BACKEND_API_BASE_URL);

if (process.env.API_HUB_URL) API_HUB_BASE_URL = process.env.API_HUB_URL;
logger.info('API_HUB_BASE_URL:' + API_HUB_BASE_URL);

ETCD_HOST = process.env.ETCD_HOST || ETCD_HOST;
logger.info('ETCD_HOST:' + ETCD_HOST);
// APP_VERSION = process.env.mplus_version;
// logger.info('APP_VERSION:'+APP_VERSION);

LICENSE_URL = process.env.LICENSE_API_URL || 'http://api.license.ensaas.en.internal/v1';

WISEMPLUS_PROFILE_URL = 'http://api-profile-proxy-mplus:80';
logger.info('WISEMPLUS_PROFILE_URL:' + WISEMPLUS_PROFILE_URL);

MQTT_ACK_TIMEOUT = parseInt(process.env.MQTT_ACK_TIMEOUT || MQTT_ACK_TIMEOUT);
MQTT_ACK_TIMEOUT_INTERVAL = parseInt(process.env.MQTT_ACK_TIMEOUT_INTERVAL || MQTT_ACK_TIMEOUT_INTERVAL);
MQTT_WEBSOCKET_PROXY_URL = 'mqtt-proxy-' + NAMESPACE + '-' + CLUSTER + DOMAIN_NAME;

DBMASTER_API_URL = 'http://api-dbmaster-wise-mplus:80';
logger.info('DBMASTER_API_URL:' + DBMASTER_API_URL);

if (process.env.APPHUB_DEFAULT_ACCOUNT) {
    APPHUB_DEFAULT_USER = JSON.parse(process.env.APPHUB_DEFAULT_ACCOUNT).user
    APPHUB_DEFAULT_PWD = JSON.parse(process.env.APPHUB_DEFAULT_ACCOUNT).pwd
}
APPHUB_REPO_API_URL = 'http://apphub-repo:80';
if (NAMESPACE === 'isensing') {
    APPHUB_REPO_API_URL = 'http://apphub-repo.develop.svc.cluster.local:80'
} else if (NAMESPACE === 'mplus') {
    APPHUB_REPO_API_URL = 'https://portal-apphub-repo-develop-eks002.hz.wise-paas.com.cn';
}
logger.info('APPHUB_REPO_API_URL:' + APPHUB_REPO_API_URL);
// } else {
//     //Develop env
//     IS_SUPPORT_IOTHUB = true;
//     DATACENTER = 'hz';//process.env.datacenter;
//     logger.info('DATACENTER:' + DATACENTER);
//     DOMAIN_NAME = '.' + DATACENTER + DOMAIN;
//     logger.info('DOMAIN_NAME: ' + DOMAIN_NAME);
//     CLUSTER = 'eks002';//process.env.cluster;
//     logger.info('CLUSTER:' + CLUSTER);
//     WORKSPACE = '91d90025-c420-46ed-a858-ad8e2cf3779b';//process.env.workspace;
//     logger.info('WORKSPACE:' + WORKSPACE);
//     NAMESPACE = 'isensing';//process.env.namespace;
//     logger.info('NAMESPACE:' + NAMESPACE);
//     logger.info('IS_SUPPORT_IOTHUB:' + IS_SUPPORT_IOTHUB);
//     //for get base host uri
//     //EXTERNAL_URL = 'bi.wise-deviceon.advantech.com';
//     EXTERNAL_URL = process.env.EXTERNAL_URL;
//     logger.info('EXTERNAL_URL:' + EXTERNAL_URL);
//     EDITION = 'azure-aks';

//     if (IS_SUPPORT_IOTHUB){
//         SSO_API_BASE_URL = 'https://sso.bi.wise-deviceon.advantech.com/v4.0';
//         DBMASTER_API_URL = 'http://localhost:1234';
//     }else{
//         //https://api-sso-ensaas.hz.wise-paas.com.cn/v4.0
//         SSO_API_BASE_URL = 'https://api-sso-ensaas' + DOMAIN_NAME + '/v4.0';
//     }
//     logger.info('SSO_API_BASE_URL: ' + SSO_API_BASE_URL);

//     // RABBITMQ_API_BASE_URL = 'https://api-management' + DOMAIN_NAME + '/mp/v2';
//     // logger.info('RABBITMQ_API_BASE_URL: ' + RABBITMQ_API_BASE_URL);
//     if (IS_SUPPORT_IOTHUB){
//         DCCS_API_BASE_URL = 'http://api-dccs-dataconnect.bi.wise-deviceon.advantech.com/v1';
//     }else{
//         DCCS_API_BASE_URL = 'https://api-dccs-ensaas' + DOMAIN_NAME + '/v1';
//     }
//     logger.info('DCCS_API_BASE_URL: ' + DCCS_API_BASE_URL);

//     if (IS_SUPPORT_IOTHUB){
//         MPLUS_API_BASE_URL = 'https://api-portal.bi.wise-deviceon.advantech.com'
//     }else{
//         //https://api-portal-deviceon-bi-isensing-eks002.hz.wise-paas.com.cn
//         MPLUS_API_BASE_URL = 'https://api-portal-deviceon-bi-' + NAMESPACE + '-' + CLUSTER + DOMAIN_NAME;
//     }
//     logger.info('MPLUS_API_BASE_URL: ' + MPLUS_API_BASE_URL);

//     //https://api-manage-isensing-eks002.hz.wise-paas.com.cn/v1.0
//     MANAGE_BACKEND_API_BASE_URL = 'https://api-manage-' + NAMESPACE + '-' + CLUSTER + DOMAIN_NAME + '/v1.0';
//     if (IS_SUPPORT_IOTHUB) MANAGE_BACKEND_API_BASE_URL = 'https://api-manage.bi.wise-deviceon.advantech.com';
//     logger.info('MANAGE_BACKEND_API_BASE_URL:' + MANAGE_BACKEND_API_BASE_URL);

//     //http://api-license-ensaas.hz.wise-paas.com.cn/v1
//     LICENSE_URL = 'http://api-license-ensaas' + DOMAIN_NAME + '/v1';

//     //https://api-profile-proxy-mplus-isensing-eks002.hz.wise-paas.com.cn
//     WISEMPLUS_PROFILE_URL = 'https://api-profile-proxy-mplus-' + NAMESPACE + '-' + CLUSTER + DOMAIN_NAME;

//}

let VCAP_SERVICES = JSON.parse(process.env.VCAP_SERVICES);
POSTGRESQL_HOST = VCAP_SERVICES[process.env.postgresql_service_name][0].credentials.host;
POSTGRESQL_PORT = VCAP_SERVICES[process.env.postgresql_service_name][0].credentials.port;
POSTGRESQL_DB_NAME = VCAP_SERVICES[process.env.postgresql_service_name][0].credentials.database;
POSTGRESQL_USER_NAME = VCAP_SERVICES[process.env.postgresql_service_name][0].credentials.username;
POSTGRESQL_USER_PASSWORD = VCAP_SERVICES[process.env.postgresql_service_name][0].credentials.password;

let MONGODB_HOST = VCAP_SERVICES[process.env.mongodb_service_name][0].credentials.host;
let MONGODB_PORT = VCAP_SERVICES[process.env.mongodb_service_name][0].credentials.port;
let MONGODB_USER_NAME = VCAP_SERVICES[process.env.mongodb_service_name][0].credentials.username;
let MONGODB_USER_PASSWORD = VCAP_SERVICES[process.env.mongodb_service_name][0].credentials.password;
let MONGODB_DATABASE = VCAP_SERVICES[process.env.mongodb_service_name][0].credentials.database;

RABBITMQ_HOST = VCAP_SERVICES[process.env.rabbitmq_service_name][0].credentials.hostname;
RABBITMQ_PORT = VCAP_SERVICES[process.env.rabbitmq_service_name][0].credentials.protocols.mqtt.port;
RABBITMQ_USER_NAME = VCAP_SERVICES[process.env.rabbitmq_service_name][0].credentials.protocols.mqtt.username;
RABBITMQ_USER_PASSWORD = VCAP_SERVICES[process.env.rabbitmq_service_name][0].credentials.protocols.mqtt.password;
RABBITMQ_SERVICE_INSTANCE_GUID = VCAP_SERVICES[process.env.rabbitmq_service_name][0].serviceInstanceId;
RABBITMQ_VHOST = VCAP_SERVICES[process.env.rabbitmq_service_name][0].credentials.vhost;

if (process.env.NODE_ENV === undefined && process.env.APP_ENV === undefined){
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0'; // for self-sign certification (ex: dbMaster)
    //develop env
    PROGRAM_ENV = 'development';
    DBMASTER_API_URL = process.env.DBMASTER_API_URL;
    POSTGRESQL_HOST = VCAP_SERVICES[process.env.postgresql_service_name][0].credentials.externalHosts; //use externalHosts in dev
    MONGODB_HOST = VCAP_SERVICES[process.env.mongodb_service_name][0].credentials.externalHosts;
    RABBITMQ_HOST = VCAP_SERVICES[process.env.rabbitmq_service_name][0].credentials.externalHosts;
}

//////////////////////////////////////////////////////////////////////

module.exports = {
    SPACE_ID: SPACE_ID,
    CLUSTER: CLUSTER,
    DATACENTER: DATACENTER,
    WORKSPACE: WORKSPACE,
    NAMESPACE: NAMESPACE,
    SPACE: SPACE,
    ORG: ORG,
    ORG_ID: ORG_ID,
    APP_ID: APP_ID,
    APP_NAME: APP_NAME,
    APP_VERSION: APP_VERSION,
    APP_API_VERSION: APP_API_VERSION,
    DUMPDB_VERSION: DUMPDB_VERSION,
    IS_OPEN_CORS: IS_OPEN_CORS,
    PROGRAM_ENV: PROGRAM_ENV,
    DOMAIN_NAME: DOMAIN_NAME,
    POSTGRESQL_DEFAULT_SCHEMA: POSTGRESQL_DEFAULT_SCHEMA,
    POSTGRESQL_DB_NAME: POSTGRESQL_DB_NAME,
    POSTGRESQL_USER_NAME: POSTGRESQL_USER_NAME,
    POSTGRESQL_USER_PASSWORD: POSTGRESQL_USER_PASSWORD,
    POSTGRESQL_HOST: POSTGRESQL_HOST,
    POSTGRESQL_PORT: POSTGRESQL_PORT,

    MONGODB_HOST: MONGODB_HOST,
    MONGODB_PORT: MONGODB_PORT,
    MONGODB_USER_NAME: MONGODB_USER_NAME,
    MONGODB_USER_PASSWORD: MONGODB_USER_PASSWORD,
    MONGODB_DATABASE: MONGODB_DATABASE,

    AZURE_SUBSCRIPTION_ID: AZURE_SUBSCRIPTION_ID,
    AZURE_RESOURCE_GROUP_NAME: AZURE_RESOURCE_GROUP_NAME,
    AZURE_RESOURCE_NAME: AZURE_RESOURCE_NAME,

    CERT_ORANIZATION_NAME: CERT_ORANIZATION_NAME,
    CERT_COMMON_NAME: CERT_COMMON_NAME,

    ROOT_EXPIRY_DAY_NUMBER: ROOT_EXPIRY_DAY_NUMBER,
    INTERMEDIATE_EXPIRY_DAY_NUMBER: INTERMEDIATE_EXPIRY_DAY_NUMBER,
    DEVICE_EXPIRY_DAY_NUMBER: DEVICE_EXPIRY_DAY_NUMBER,
    SERVER_INTERMEDIATE_ID: SERVER_INTERMEDIATE_ID,

    KEY_VAULT_URL: KEY_VAULT_URL,
    SSO_API_BASE_URL: SSO_API_BASE_URL,
    LICENSE_URL: LICENSE_URL,
    WISEMPLUS_PROFILE_URL: WISEMPLUS_PROFILE_URL,

    RABBITMQ_PORT: RABBITMQ_PORT,
    RABBITMQ_SSL_PORT: RABBITMQ_SSL_PORT,
    RABBITMQ_HOST: RABBITMQ_HOST,
    RABBITMQ_VHOST: RABBITMQ_VHOST,
    RABBITMQ_USER_NAME: RABBITMQ_USER_NAME,
    RABBITMQ_USER_PASSWORD: RABBITMQ_USER_PASSWORD,

    RABBITMQ_WEBSOCKET_PORT: RABBITMQ_WEBSOCKET_PORT,

    RABBITMQ_API_BASE_URL: RABBITMQ_API_BASE_URL,
    RABBITMQ_SERVICE_INSTANCE_GUID: RABBITMQ_SERVICE_INSTANCE_GUID,
    RABBITMQ_DEVICE_KEY_EXPIRY_MONTH: RABBITMQ_DEVICE_KEY_EXPIRY_MONTH,
    MQTT_ACK_TIMEOUT: MQTT_ACK_TIMEOUT,
    MQTT_ACK_TIMEOUT_INTERVAL: MQTT_ACK_TIMEOUT_INTERVAL,

    DCCS_API_BASE_URL: DCCS_API_BASE_URL,

    MPLUS_API_BASE_URL: MPLUS_API_BASE_URL,
    DBMASTER_API_URL: DBMASTER_API_URL,
    APPHUB_DEFAULT_USER: APPHUB_DEFAULT_USER,
    APPHUB_DEFAULT_PWD: APPHUB_DEFAULT_PWD,
    APPHUB_REPO_API_URL: APPHUB_REPO_API_URL,

    MANAGE_BACKEND_API_BASE_URL: MANAGE_BACKEND_API_BASE_URL,
    MQTT_WEBSOCKET_PROXY_URL: MQTT_WEBSOCKET_PROXY_URL,

    ETCD_HOST: ETCD_HOST,

    API_HUB_BASE_URL: API_HUB_BASE_URL,
    API_ALARM_URL: API_ALARM_URL,

    BI_EDITION_NAME: {
        standard: 'standard',
        azureAKS: 'azure-aks',
        onPremises: 'on-premises',
        aliyunOSS: 'aliyun_oss'
    },
    AUTH_FUNCTION: {
        Create: 1,
        Edit: 2,
        Delete: 4,
        View: 8
    },
    AUTH_MODULE: {
        User: 1,
        Organization: 2,
        Device: 3,
        Object: 4,
        Dashboard: 5,
        Value_Alarm: 6,
        Log: 7,
        SystemSetting: 8
    },
    SSORole: {
        Admin: 'admin',
        Tenant: 'tenant',
        Developer: 'developer',
        Srp: 'srpUser'
    },
    Role: { //wiseM+的角色
        SpaceManager: 0,
        Admin: 1,
        Engineer: 2,
        Operator: 3,
        Viewer: 4
    },
    DFS_FUNCTION: {
        IOCfg: 1,
        FOTA: 2,
        COTA: 4,
        RS485: 8
    },
    MYDEVICES: MYDEVICES,
    GrpRole: {
        Manager: 1,
        Operator: 2,
        //Backup: 2,
        Viewer: 3
    },
    IS_SUPPORT_IOTHUB: IS_SUPPORT_IOTHUB,
    EXTERNAL_URL: EXTERNAL_URL, //for get base host uri
    EDITION: EDITION,
    SESSION_COOKIE_NAME: SESSION_COOKIE_NAME,
    JWT_COOKIE_NAME: JWT_COOKIE_NAME,
    CRYPTO_AES_KEY: CRYPTO_AES_KEY,
    CRYPTO_AES_IV: CRYPTO_AES_IV
};
