const path = require('path');
const fs = require('fs').promises;
const { spawn } = require('child_process');
const { v4: uuidv4 } = require('uuid');
const pg = require('../lib/db');
const crypt = require('../lib/crypt');
const common = require('../lib/common');
const setting = require('../conf/setting');
const azureKeyVault = require('../lib/azure_key_vault');
const azureIotHub = require('../lib/azure_arm-iot-hub');
const logger = require('../lib/logger').getLogger('certCtrl');

const existsSync = require('fs').existsSync;

// path for openSSL command
const rootCertPath = path.join(__dirname, '..', '/tools', '/CACertificates', '/certs');
const rootKeyPath = path.join(__dirname, '..', '/tools', '/CACertificates', '/private');
const intermediateCertPath = path.join(__dirname, '..', '/tools', '/CACertificates', '/intermediate_ca');
const intermediateCertPathForMqtt = path.join(__dirname, '..', '/tools', '/CACertificatesForRabbitMQ', '/intermediate_ca');
const devicePath = path.join(__dirname, '..', '/tools', '/CACertificates', '/device_ca');
const serverPath = path.join(__dirname, '..', '/tools', '/CACertificates', '/server_ca');
// store download pkcs8 cert file(cert+ key) from keyVault
const keyVaultInboundPath = path.join(__dirname, '..', '/tools', '/CACertificates', '/keyvault', '/inbound');
// store generated pkcs8 cert file(cert+ key) before save into keyVault
const keyVaultOutboundPath = path.join(__dirname, '..', '/tools', '/CACertificates', '/keyvault', '/outbound');
const scriptPath = path.join(__dirname, '..', '/tools', '/CACertificates', '/script');
const caToolRootPath = path.join(__dirname, '..', '/tools', '/CACertificates');
const devicePathForMqtt = path.join(__dirname, '..', '/tools', '/CACertificatesForRabbitMQ', '/device_ca');
const keyVaultOutboundPathForMqtt = path.join(__dirname, '..', '/tools', '/CACertificatesForRabbitMQ', '/keyvault', '/outbound');
const scriptPathForMqtt = path.join(__dirname, '..', '/tools', '/CACertificatesForRabbitMQ', '/script');
const caToolRootPathForMqtt = path.join(__dirname, '..', '/tools', '/CACertificatesForRabbitMQ');

function getRootCertFilePath() {
    let rootScriptFile = path.join(scriptPath, 'certGenRootCA.sh');
    let rootCertFileNameWithPath = path.join(rootCertPath, 'root.ca.cert.pem');
    let rootKeyFileNameWithPath = path.join(rootKeyPath, 'root.ca.key.pem');
    let rootNewKeyFileNameWithPath = path.join(rootKeyPath, 'root.ca.pkcs8.pem');
    let rootOutboundFileNameWithKeyVaultPath = path.join(keyVaultOutboundPath, 'root.ca.keyvault.pem');
    return {
        rootScriptFile,
        rootCertFileNameWithPath,
        rootKeyFileNameWithPath,
        rootNewKeyFileNameWithPath,
        rootOutboundFileNameWithKeyVaultPath
    }
}

function getIntermediateCertFilePath(intermediatePath, keyVaultOutboundPath, certNumber) {
    let intermediateScriptFile = path.join(scriptPath, 'certGenIntermediateCA.sh');
    let intermediateOriCertFileNameWithPath = path.join(intermediatePath, 'intermediate.cert.pem');
    let intermediateOriKeyFileNameWithPath = path.join(intermediatePath, 'intermediate.key.pem');
    let intermediateCertFileNameWithPath = path.join(intermediatePath, `intermediate-${certNumber}.cert.pem`);
    let intermediateKeyFileNameWithPath = path.join(intermediatePath, `intermediate-${certNumber}.key.pem`);
    let intermediateNewKeyFileNameWithPath = path.join(intermediatePath, `intermediate-${certNumber}.pkcs8.pem`);
    let intermediateNewChainFileNameWithPath = path.join(intermediatePath, `chain-${certNumber}.ca.cert.pem`);
    let intermediateOutboundFileNameWithKeyVaultPath = path.join(keyVaultOutboundPath, `intermediate-${certNumber}.keyvault.pem`);
    let intermediateCertInboundFileNameWithKeyVaultPath = path.join(keyVaultInboundPath, `intermediate-${certNumber}.cert.pem`);
    let intermediateKeyInboundFileNameWithKeyVaultPath = path.join(keyVaultInboundPath, `intermediate-${certNumber}.key.pem`);
    return {
        intermediateScriptFile,
        intermediateOriCertFileNameWithPath,
        intermediateOriKeyFileNameWithPath,
        intermediateCertFileNameWithPath,
        intermediateKeyFileNameWithPath,
        intermediateNewKeyFileNameWithPath,
        intermediateNewChainFileNameWithPath,
        intermediateOutboundFileNameWithKeyVaultPath,
        intermediateCertInboundFileNameWithKeyVaultPath,
        intermediateKeyInboundFileNameWithKeyVaultPath
    }
}

function getDeviceCertFilePath(scriptPath, devicePath, keyvaultPath, serialNo) {
    let deviceScriptFile = path.join(scriptPath, 'certGenDeviceCA.sh');
    let deviceCertFileNameWithPath = path.join(devicePath, `device-${serialNo}.cert.pem`);
    let deviceKeyFileNameWithPath = path.join(devicePath, `device-${serialNo}.key.pem`);
    let deviceNewKeyFileNameWithPath = path.join(devicePath, `device-${serialNo}.pkcs8.pem`);
    let deviceOutboundFileNameWithKeyVaultPath = path.join(keyvaultPath, `device-${serialNo}.keyvault.pem`);
    return {
        deviceScriptFile,
        deviceCertFileNameWithPath,
        deviceKeyFileNameWithPath,
        deviceNewKeyFileNameWithPath,
        deviceOutboundFileNameWithKeyVaultPath
    }
}

// for rabbitMQ
function getServerCertFilePath(idx) {
    let serverScriptFile = path.join(scriptPath, 'certGenServerCA.sh');
    let serverCertFileNameWithPath = path.join(serverPath, `server-${idx}.cert.pem`);
    let serverKeyFileNameWithPath = path.join(serverPath, `server-${idx}.key.pem`);
    let serverNewKeyFileNameWithPath = path.join(serverPath, `server-${idx}.pkcs8.pem`);
    let serverOutboundFileNameWithKeyVaultPath = path.join(keyVaultOutboundPath, `server-${idx}.keyvault.pem`);
    return {
        serverScriptFile,
        serverCertFileNameWithPath,
        serverKeyFileNameWithPath,
        serverNewKeyFileNameWithPath,
        serverOutboundFileNameWithKeyVaultPath
    }
}

// for rabbitMQ
function generateServerCert(accountId, accountName, serialNo, fileName, status, orgId, caIdx, passphrase, today, certCommonName, certOrganizationName) {
    return new Promise((resolve, reject) => {
        let rabbtimqIp;
        let expireDayNumber;
        let rabbitmqDns = setting.RABBITMQ_HOST;
        let extensionName = common.CERT_EXTENSION_NAME.SERVER;
        let certName = `cert-${setting.NAMESPACE}-${serialNo}-${Date.now()}`;
        let secretName = `secret-${setting.NAMESPACE}-${serialNo}-${Date.now()}`;
        let rootCertInfo = {};
        let intermediateCertInfo = {};
        let intermediatePath = getIntermediateCertFilePath(intermediateCertPath, keyVaultOutboundPath, caIdx);
        let serverPath = getServerCertFilePath(caIdx);
        let fileArr = [
            intermediatePath.intermediateCertFileNameWithPath,
            intermediatePath.intermediateKeyFileNameWithPath,
            intermediatePath.intermediateNewChainFileNameWithPath,
            serverPath.serverCertFileNameWithPath,
            serverPath.serverKeyFileNameWithPath,
            serverPath.serverNewKeyFileNameWithPath,
            serverPath.serverOutboundFileNameWithKeyVaultPath
        ];

        common.getMqttHostIP()
            .then(mqttResult => {
                if (!mqttResult.status) throw new Error(mqttResult.message);
                rabbtimqIp = mqttResult.result;

                return removeFile(fileArr)
            })
            .then(() => {
                return pg.getRootIdFromIntermediateIdx(caIdx, status)
            })
            .then(queryResult => {
                if (!queryResult.status) throw new Error(queryResult.message);
                rootCertInfo.id = queryResult.result.rows[0].rootId;
                return checkServerCertExists(status, queryResult.result.rows[0].intermediateId)
            })
            .then(checkResult => {
                if (!checkResult.status) throw new Error(checkResult.message);
                if (checkResult.status && checkResult.message) throw new Error('The server cert exists');

                let promiseArr = [];
                // get root cert for chain.cert.pem
                promiseArr.push(getRootCert(rootCertInfo.id, status));
                // intermediate cert and key
                promiseArr.push(getIntermediateCertAndPassphrase(caIdx, status));
                return Promise.all(promiseArr);
            })
            .then(certs => {
                if (!certs[0].status) throw new Error(certs[0].message);
                if (!certs[1].status) throw new Error(certs[1].message);
                rootCertInfo.certContent = certs[0].result.certContent;
                intermediateCertInfo.id = certs[1].result.id;
                expireDayNumber = certs[1].result.expireDayNumber;
                intermediateCertInfo.fileName = certs[1].result.fileName;
                intermediateCertInfo.fileIndex = certs[1].result.fileIndex;
                intermediateCertInfo.password = certs[1].result.passphrase;
                intermediateCertInfo.certContent = certs[1].result.certContent;
                intermediateCertInfo.keyContent = certs[1].result.keyContent;
                return Promise.all([
                    fs.writeFile(intermediatePath.intermediateCertFileNameWithPath, intermediateCertInfo.certContent),
                    fs.writeFile(intermediatePath.intermediateKeyFileNameWithPath, intermediateCertInfo.keyContent),
                    fs.writeFile(intermediatePath.intermediateNewChainFileNameWithPath, intermediateCertInfo.certContent + '\n' + rootCertInfo.certContent)
                ])
            })
            .then(() => {
                if (!existsSync(intermediatePath.intermediateCertFileNameWithPath)) throw new Error('The intermdaite cert file has not been found');
                if (!existsSync(intermediatePath.intermediateKeyFileNameWithPath)) throw new Error('The intermdaite key file has not been found');
                if (!existsSync(intermediatePath.intermediateNewChainFileNameWithPath)) throw new Error('The intermdaite chain cert file has not been found');

                logger.info('-----start generate server cert: sh ', serverPath.serverScriptFile,
                    caToolRootPath,
                    certCommonName,
                    certOrganizationName,
                    'root',
                    expireDayNumber,
                    intermediateCertInfo.password,
                    serialNo,
                    intermediateCertInfo.fileIndex,
                    passphrase,
                    rabbtimqIp,
                    rabbitmqDns,
                    extensionName,
                    '-----')

                // create server cert cert and key
                return runCommand('sh', [
                    serverPath.serverScriptFile,
                    caToolRootPath,
                    certCommonName,
                    certOrganizationName,
                    'root',
                    expireDayNumber,
                    intermediateCertInfo.password,
                    serialNo,
                    intermediateCertInfo.fileIndex,
                    passphrase,
                    rabbtimqIp,
                    rabbitmqDns,
                    extensionName
                ])
            })
            .then(result => {
                if (!result.status) throw new Error(result.message);
                logger.info(`-----server cert cn ${serialNo} output: ${result.output} -----`)
                logger.info(`-----end generate server cert cn ${serialNo}-----`);
                return Promise.all([
                    // read server cert and key file
                    fs.readFile(serverPath.serverCertFileNameWithPath),
                    fs.readFile(serverPath.serverKeyFileNameWithPath),
                    fs.readFile(serverPath.serverNewKeyFileNameWithPath),
                    fs.readFile(serverPath.serverOutboundFileNameWithKeyVaultPath)
                ])
            })
            .then(results => {
                // check device cert and key file
                if (!results[0]) throw new Error('Create server cert pem has failed');
                if (!results[1]) throw new Error('Create server key pem has failed');
                if (!results[2]) throw new Error('Create server key pkcs8 pem has failed');
                if (!results[3]) throw new Error('Create server key-vault pem has failed');

                return fs.readFile(serverPath.serverOutboundFileNameWithKeyVaultPath, { encoding: 'utf8' })
            })
            .then(data => {
                if (!data) throw new Error('The server key of the key-vault has not been found');
                return storeCertAndPassphrase(certName, secretName, data, passphrase)
            })
            .then(storeResult => {
                if(!storeResult.status) throw new Error(storeResult.message);
                // prepare parameter
                let serverCertParameter = prepareCertParamsForDB({
                    fileName: fileName,
                    type: storeResult.result.type,
                    today: today,
                    expireDayNumber: expireDayNumber,
                    name: storeResult.result.name,
                    isEnabled: storeResult.result.isEnabled,
                    version: storeResult.result.version,
                    secretName: storeResult.result.secretName,
                    secretVersion: storeResult.result.secretVersion,
                    secretIsEnabled: storeResult.result.secretIsEnabled,
                    certFile: storeResult.result.certFile,
                    keyFile: storeResult.result.keyFile,
                    passphrase: storeResult.result.passphrase,
                    isUpload: true,
                    userId: accountId,
                    userName: accountName
                })

                serverCertParameter.orgId = orgId;
                serverCertParameter.serialNo = serialNo;
                serverCertParameter.status = common.CERT_STATUS.ACTIVE;
                serverCertParameter.intermediateCertId = intermediateCertInfo.id;

                // insert db
                return pg.createDeviceCertInformation(serverCertParameter)
            })
            .then(queryResult => {
                if (!queryResult.status) throw new Error(queryResult.message);
                if (queryResult.result.rowCount !== 1) throw new Error('Fail to insert Server cert information');
                return removeFile(fileArr)
            })
            .then(() => {
                return resolve({ status: true, serialNo: serialNo });
            })
            .catch(error => {
                logger.error('generateServerCert error: ', error);
                return resolve({ status: false, message: error.message });
            })
    });
}

function generateRootCert(accountId, accountName, fileName, today, passphrase, expireDayNumber, certCommonName, certOrganizationName) {
    return new Promise((resolve, reject) => {
        let rootId;
        let certName = `cert-${setting.NAMESPACE}-root-${Date.now()}`;
        let secretName = `secret-${setting.NAMESPACE}-root-${Date.now()}`;
        let rootCertPath = getRootCertFilePath();
        let fileArr = [
            rootCertPath.rootCertFileNameWithPath,
            rootCertPath.rootKeyFileNameWithPath,
            rootCertPath.rootNewKeyFileNameWithPath,
            rootCertPath.rootOutboundFileNameWithKeyVaultPath
        ];

        checkRootCertExists(common.CERT_STATUS.NEW)
            .then(result => {
                if (!result.status) throw new Error(result.message);
                logger.info('-----start generate root cert-----');

                let rootParams = [
                    rootCertPath.rootScriptFile,
                    caToolRootPath,
                    certCommonName,
                    certOrganizationName,
                    passphrase,
                    expireDayNumber
                ]
                // create Root cert and key
                return runCommand('sh', rootParams);
            })
            .then(result => {
                if (!result.status) throw new Error(result.message);
                logger.info(`-----root cert output: ${result.output} -----`);
                logger.info('-----end generate root cert-----');

                return Promise.all([
                    // read device cert and key file
                    fs.readFile(rootCertPath.rootCertFileNameWithPath),
                    fs.readFile(rootCertPath.rootKeyFileNameWithPath),
                    fs.readFile(rootCertPath.rootNewKeyFileNameWithPath),
                    fs.readFile(rootCertPath.rootOutboundFileNameWithKeyVaultPath)
                ])
            })
            .then(results => {
                // check device cert and key file
                if (!results[0]) return reject(new Error('Create root cert pem has failed'));
                if (!results[1]) return reject(new Error('Create root key pem has failed'));
                if (!results[2]) return reject(new Error('Create root key pkcs8 pem has failed'));
                if (!results[3]) return reject(new Error('Create root key-vault pem has failed'));

                return fs.readFile(rootCertPath.rootOutboundFileNameWithKeyVaultPath, { encoding: 'utf8' })
            })
            .then(data => {
                if (!data) return reject(new Error('The cert of the key-vault has not been found'));
                return storeCertAndPassphrase(certName, secretName, data, passphrase)
            })
            .then(storeResult => {
                if (!storeResult.status) throw new Error(storeResult.message);
                // prepare parameter
                let rootCertParameter = prepareCertParamsForDB({
                    fileName: fileName,
                    type: storeResult.result.type,
                    today: today,
                    expireDayNumber: expireDayNumber,
                    name: storeResult.result.name,
                    isEnabled: storeResult.result.isEnabled,
                    version: storeResult.result.version,
                    secretName: storeResult.result.secretName,
                    secretVersion: storeResult.result.secretVersion,
                    secretIsEnabled: storeResult.result.secretIsEnabled,
                    certFile: storeResult.result.certFile,
                    keyFile: storeResult.result.keyFile,
                    passphrase: storeResult.result.passphrase,
                    isUpload: true,
                    userId: accountId,
                    userName: accountName
                })
                // insert db
                return pg.createRootCertInformation(rootCertParameter)
            })
            .then(queryResult => {
                if (!queryResult.status) throw new Error(queryResult.message);
                if (queryResult.result.rowCount !== 1) return reject(new Error('Fail to insert root cert data'));
                rootId = queryResult.result.rows[0].id;
                return removeFile(fileArr);
            })
            .then(() => {
                return resolve({ status: true, id: rootId });
            })
            .catch(error => {
                logger.error('generateRootCert error: ', error.message);
                return resolve({ status: false, message: error.message });
            })
    })
}

function generateIntermediateCert(accountId, accountName, fileName, rooCaIdx, status, passphrase, today, certCommonName, certOrganizationName, fileIndex = null) {
    return new Promise((resolve, reject) => {
        let caIdx;
        let intermediateId;
        let IntermediatePath;
        let expireDayNumber = setting.INTERMEDIATE_EXPIRY_DAY_NUMBER;
        let certName = `cert-${setting.NAMESPACE}-intermediate-${Date.now()}`;
        let secretName = `secret-${setting.NAMESPACE}-intermediate-${Date.now()}`;
        let rootCertInfo = {};
        let rootCertPath = getRootCertFilePath();
        let fileArr = [
            rootCertPath.rootCertFileNameWithPath,
            rootCertPath.rootKeyFileNameWithPath,
            rootCertPath.rootNewKeyFileNameWithPath,
            rootCertPath.rootOutboundFileNameWithKeyVaultPath
        ];

        // remove root cert and key file
        removeFile(fileArr)
            .then(() => {
                if (fileIndex) {
                    return { status: true, index: fileIndex };
                } else {
                    return getIntermediateIndex(status, common.MAX_INTERMEDIATE_CERT_NUMBER)
                }
            })
            .then(result => {
                if (!result.status) throw new Error(result.message);
                if (result.index === -1) throw new Error('The intermediate cert index quota out of range');
                caIdx = result.index;
                IntermediatePath = getIntermediateCertFilePath(intermediateCertPath, keyVaultOutboundPath, caIdx);
                fileArr.push(IntermediatePath.intermediateCertFileNameWithPath);
                fileArr.push(IntermediatePath.intermediateKeyFileNameWithPath);
                fileArr.push(IntermediatePath.intermediateNewKeyFileNameWithPath);
                fileArr.push(IntermediatePath.intermediateOutboundFileNameWithKeyVaultPath);

                return getRootCertAndPassphrase(rooCaIdx, status)
            })
            .then(cert => {
                if (!cert.status) throw new Error(cert.message);
                expireDayNumber = (expireDayNumber > cert.result.expireDayNumber) ? cert.result.expireDayNumber : expireDayNumber;
                rootCertInfo.fileName = cert.result.fileName;
                rootCertInfo.password = cert.result.passphrase;
                rootCertInfo.certContent = cert.result.certContent;
                rootCertInfo.keyContent = cert.result.keyContent;

                return Promise.all([
                    fs.writeFile(rootCertPath.rootCertFileNameWithPath, rootCertInfo.certContent),
                    fs.writeFile(rootCertPath.rootKeyFileNameWithPath, rootCertInfo.keyContent)
                ])
            })
            .then(() => {
                if (!existsSync(rootCertPath.rootCertFileNameWithPath)) return reject(new Error('Root Cert Not Found.'));
                if (!existsSync(rootCertPath.rootKeyFileNameWithPath)) return reject(new Error('Root Key Not Found.'));

                logger.info(`-----start generate Intermediate idx ${caIdx} cert, root id ${rooCaIdx} -----`);
                // create intermediate cert cert and key
                let intermediateParams = [
                    IntermediatePath.intermediateScriptFile,
                    caToolRootPath,
                    certCommonName,
                    certOrganizationName,
                    rootCertInfo.password,
                    expireDayNumber,
                    passphrase,
                    caIdx
                ];
                return runCommand('sh', intermediateParams);
            })
            .then(result => {
                if (!result.status) throw new Error(result.message);
                logger.info(`-----Intermediate cert id ${caIdx}, root id ${rooCaIdx} output: ${result.output} -----`);
                logger.info(`-----end generate Intermediate cert id ${caIdx}, root id ${rooCaIdx}-----`);

                return Promise.all([
                    // read device cert and key file
                    fs.readFile(IntermediatePath.intermediateCertFileNameWithPath),
                    fs.readFile(IntermediatePath.intermediateKeyFileNameWithPath),
                    fs.readFile(IntermediatePath.intermediateNewKeyFileNameWithPath),
                    fs.readFile(IntermediatePath.intermediateOutboundFileNameWithKeyVaultPath)
                ])
            })
            .then(results => {
                // check device cert and key file
                if (!results[0]) return reject(new Error('Create the intermediate cert pem has failed'))
                if (!results[1]) return reject(new Error('Create the intermediate key pem has failed'))
                if (!results[2]) return reject(new Error('Create the intermediate key pkcs8 pem has failed'))
                if (!results[3]) return reject(new Error('Create the intermediate key-vault pem has failed'))

                return fs.readFile(IntermediatePath.intermediateOutboundFileNameWithKeyVaultPath, { encoding: 'utf8' })
            }).then(data => {
                if (!data) return reject(new Error('The intermediate cert file has not been found'));
                return storeCertAndPassphrase(certName, secretName, data, passphrase)
            }).then(storeResult => {
                if (!storeResult.status) throw new Error(storeResult.message);
                // prepare parameter
                let intermediateCertParameter = prepareCertParamsForDB({
                    fileName: fileName,
                    type: storeResult.result.type,
                    today: today,
                    expireDayNumber: expireDayNumber,
                    name: storeResult.result.name,
                    isEnabled: storeResult.result.isEnabled,
                    version: storeResult.result.version,
                    secretName: storeResult.result.secretName,
                    secretVersion: storeResult.result.secretVersion,
                    secretIsEnabled: storeResult.result.secretIsEnabled,
                    certFile: storeResult.result.certFile,
                    keyFile: storeResult.result.keyFile,
                    passphrase: storeResult.result.passphrase,
                    isUpload: true,
                    userId: accountId,
                    userName: accountName
                })

                intermediateCertParameter.rootCertId = rooCaIdx;
                intermediateCertParameter.fileIndex = caIdx;

                // insert db
                return pg.createIntermediateCertInformation(intermediateCertParameter)
            }).then(queryResult => {
                if (!queryResult.status) throw new Error(queryResult.message);
                if (queryResult.result.rowCount !== 1) return reject(new Error('Fail to insert Intermediate cert information'));
                intermediateId = queryResult.result.rows[0].id;
                return removeFile(fileArr)
            }).then(() => {
                return resolve({ status: true, id: intermediateId });
            }).catch(error => {
                logger.error('generateIntermediateCert error: ', error);
                return resolve({ status: false, message: error.message });
            })
    })
}

function generateDeviceCert(accountId, accountName, serialNo, fileName, status, orgId, caIdx, iothubPassphrase, rabbitmqPassphrase, today, expireDayNumber, certCommonName, certOrganizationName, vhost) {
    return new Promise((resolve, reject) => {
        let rabbtimqIp;
        let rabbitmqDns = setting.RABBITMQ_HOST;
        let extensionName = common.CERT_EXTENSION_NAME.DEVICE;
        let uuid = uuidv4();
        let intermediateId = uuid;
        let iothubCommonName = serialNo;
        let rabbitmqCommonName = vhost + ':' + serialNo;
        let rabbitmqFileName = 'device-' + rabbitmqCommonName;
        let iothubCertName = `azure-cert-${setting.NAMESPACE}-${serialNo}-${Date.now()}`;
        let iothubSecretName = `azure-secrect-${setting.NAMESPACE}-${serialNo}-${Date.now()}`;
        let rabbitmqCertName = `mqtt-cert-${setting.NAMESPACE}-${serialNo}-${Date.now()}`;
        let rabbitmqSecretName = `mqtt-secrect-${setting.NAMESPACE}-${serialNo}-${Date.now()}`;
        let rootCertInfo = {};
        let intermediateCertInfo = {};
        let intermediatePath = getIntermediateCertFilePath(intermediateCertPath, keyVaultOutboundPath, intermediateId);
        let intermediatePathForMqtt = getIntermediateCertFilePath(intermediateCertPathForMqtt, keyVaultOutboundPathForMqtt, intermediateId);
        let iothubDevicePath = getDeviceCertFilePath(scriptPath, devicePath, keyVaultOutboundPath, iothubCommonName);
        let rabbitmqDevicePath = getDeviceCertFilePath(scriptPathForMqtt, devicePathForMqtt, keyVaultOutboundPathForMqtt, rabbitmqCommonName);
        let fileArr = [
            // iothub
            intermediatePath.intermediateCertFileNameWithPath,
            intermediatePath.intermediateKeyFileNameWithPath,
            intermediatePath.intermediateNewChainFileNameWithPath,
            iothubDevicePath.deviceCertFileNameWithPath,
            iothubDevicePath.deviceKeyFileNameWithPath,
            iothubDevicePath.deviceNewKeyFileNameWithPath,
            iothubDevicePath.deviceOutboundFileNameWithKeyVaultPath,
            // mqtt
            intermediatePathForMqtt.intermediateCertFileNameWithPath,
            intermediatePathForMqtt.intermediateKeyFileNameWithPath,
            intermediatePathForMqtt.intermediateNewChainFileNameWithPath,
            rabbitmqDevicePath.deviceCertFileNameWithPath,
            rabbitmqDevicePath.deviceKeyFileNameWithPath,
            rabbitmqDevicePath.deviceNewKeyFileNameWithPath,
            rabbitmqDevicePath.deviceOutboundFileNameWithKeyVaultPath
        ]

        common.getMqttHostIP()
            .then(mqttResult => {
                if (!mqttResult.status) throw new Error(mqttResult.message);
                rabbtimqIp = mqttResult.result;

                return checkDeviceCertExists(status, serialNo)
            })
            .then(result => {
                if (!result.status) throw new Error(result.message);
                if (result.status && result.isExists) throw new Error('The device cert exists');

                return removeFile(fileArr)
            })
            .then(() => {
                return pg.getRootIdFromIntermediateIdx(caIdx, status)
            })
            .then(queryResult => {
                if (!queryResult.status) throw new Error(queryResult.message);
                rootCertInfo.id = queryResult.result.rows[0].rootId;
                let promiseArr = [];
                // get root cert for chain.cert.pem
                promiseArr.push(getRootCert(rootCertInfo.id, status));
                // intermediate cert and key
                promiseArr.push(getIntermediateCertAndPassphrase(caIdx, status));
                return Promise.all(promiseArr);
            })
            .then(certs => {
                // The expiry date of the device cert is not later than the expiry date of the intermediate cert
                if (!certs[0].status) throw new Error(certs[0].message);
                if (!certs[1].status) throw new Error(certs[1].message);
                if (expireDayNumber > certs[1].result.expireDayNumber) {
                    expireDayNumber = certs[1].result.expireDayNumber
                }
                rootCertInfo.certContent = certs[0].result.certContent;
                intermediateCertInfo.id = certs[1].result.id;
                intermediateCertInfo.fileName = certs[1].result.fileName;
                intermediateCertInfo.fileIndex = certs[1].result.fileIndex;
                intermediateCertInfo.password = certs[1].result.passphrase;
                intermediateCertInfo.certContent = certs[1].result.certContent;
                intermediateCertInfo.keyContent = certs[1].result.keyContent;
                return Promise.all([
                    // iothub
                    fs.writeFile(intermediatePath.intermediateCertFileNameWithPath, intermediateCertInfo.certContent),
                    fs.writeFile(intermediatePath.intermediateKeyFileNameWithPath, intermediateCertInfo.keyContent),
                    fs.writeFile(intermediatePath.intermediateNewChainFileNameWithPath, intermediateCertInfo.certContent + '\n' + rootCertInfo.certContent),
                    // mqtt
                    fs.writeFile(intermediatePathForMqtt.intermediateCertFileNameWithPath, intermediateCertInfo.certContent),
                    fs.writeFile(intermediatePathForMqtt.intermediateKeyFileNameWithPath, intermediateCertInfo.keyContent),
                    fs.writeFile(intermediatePathForMqtt.intermediateNewChainFileNameWithPath, intermediateCertInfo.certContent + '\n' + rootCertInfo.certContent)
                ])
            })
            .then(() => {
                // iothub
                if (!existsSync(intermediatePath.intermediateCertFileNameWithPath)) throw new Error('The intermediate cert of the iothub has not been found');
                if (!existsSync(intermediatePath.intermediateKeyFileNameWithPath)) throw new Error('The intermediate key of the iothub has not been found');
                if (!existsSync(intermediatePath.intermediateNewChainFileNameWithPath)) throw new Error('The chain cert of the iothub has not been found');
                // mqtt
                if (!existsSync(intermediatePathForMqtt.intermediateCertFileNameWithPath)) throw new Error('The intermediate cert of the rabbitmq has not been found');
                if (!existsSync(intermediatePathForMqtt.intermediateKeyFileNameWithPath)) throw new Error('The intermediate key of the rabbitmq has not been found');
                if (!existsSync(intermediatePathForMqtt.intermediateNewChainFileNameWithPath)) throw new Error('The chain cert of the rabbitmq has not been found');

                let iothubParams = [
                    iothubDevicePath.deviceScriptFile,
                    caToolRootPath,
                    certCommonName,
                    certOrganizationName,
                    'root',
                    expireDayNumber,
                    intermediateCertInfo.password,
                    iothubCommonName,
                    intermediateId,
                    iothubPassphrase,
                    rabbtimqIp,
                    rabbitmqDns,
                    extensionName
                ]
                let rabbitmqParams = [
                    rabbitmqDevicePath.deviceScriptFile,
                    caToolRootPathForMqtt,
                    certCommonName,
                    certOrganizationName,
                    'root',
                    expireDayNumber,
                    intermediateCertInfo.password,
                    rabbitmqCommonName,
                    intermediateId,
                    rabbitmqPassphrase,
                    rabbtimqIp,
                    rabbitmqDns,
                    extensionName
                ]
                logger.info('-----start generate iothub device cert', iothubParams, '-----');
                logger.info('-----start generate rabbitmq device cert', rabbitmqParams, '-----');

                let certArr = []
                certArr.push(runCommand('sh', iothubParams));
                certArr.push(runCommand('sh', rabbitmqParams));

                return Promise.all(certArr)
            })
            .then(results => {
                if (!results[0].status) throw new Error(results[0].message);
                logger.info(`-----iothub device cert cn ${iothubCommonName} output: ${results[0].output} -----`);
                logger.info(`-----end generate iothub device cert cn ${iothubCommonName}-----`);

                if (!results[1].status) throw new Error(results[1].message);
                logger.info(`-----rabbitmq device cert cn ${rabbitmqCommonName} output: ${results[1].output} -----`);
                logger.info(`-----end generate rabbitmq device cert cn ${rabbitmqCommonName}-----`);

                return Promise.all([
                // read device cert and key file
                    // iothub
                    fs.readFile(iothubDevicePath.deviceCertFileNameWithPath),
                    fs.readFile(iothubDevicePath.deviceKeyFileNameWithPath),
                    fs.readFile(iothubDevicePath.deviceNewKeyFileNameWithPath),
                    fs.readFile(iothubDevicePath.deviceOutboundFileNameWithKeyVaultPath),
                    // mqtt
                    fs.readFile(rabbitmqDevicePath.deviceCertFileNameWithPath),
                    fs.readFile(rabbitmqDevicePath.deviceKeyFileNameWithPath),
                    fs.readFile(rabbitmqDevicePath.deviceNewKeyFileNameWithPath),
                    fs.readFile(rabbitmqDevicePath.deviceOutboundFileNameWithKeyVaultPath)
                ])
            }).then(results => {
                // check device cert and key file
                if (!results[0]) throw new Error('Create iothub device cert pem has failed');
                if (!results[1]) throw new Error('Create iothub device key pem has failed');
                if (!results[2]) throw new Error('Create iothub device key pkcs8 pem has failed');
                if (!results[3]) throw new Error('Create iothub device key-vault pem has failed');
                if (!results[4]) throw new Error('Create rabbitmq device cert pem has failed');
                if (!results[5]) throw new Error('Create rabbitmq device key pem has failed');
                if (!results[6]) throw new Error('Create rabbitmq device key pkcs8 pem has failed');
                if (!results[7]) throw new Error('Create rabbitmq device key-vault pem has failed');

                let arr = [];
                arr.push(fs.readFile(iothubDevicePath.deviceOutboundFileNameWithKeyVaultPath, { encoding: 'utf8' }));
                arr.push(fs.readFile(rabbitmqDevicePath.deviceOutboundFileNameWithKeyVaultPath, { encoding: 'utf8' }));
                return Promise.all(arr)
            }).then(data => {
                if (!data[0]) throw new Error('The iothub device cert file of the key-vault has not been found');
                if (!data[1]) throw new Error('The rabbitmq device cert file of the key-vault has not been found');

                let arr = [];
                arr.push(storeCertAndPassphrase(iothubCertName, iothubSecretName, data[0], iothubPassphrase));
                arr.push(storeCertAndPassphrase(rabbitmqCertName, rabbitmqSecretName, data[1], rabbitmqPassphrase))
                return Promise.all(arr)
            }).then(results => {
                if (!results[0].status) throw new Error(results[0].message);
                if (!results[1].status) throw new Error(results[1].message);
                // prepare cert basic parameter
                let deviceCertParameter = prepareCertParamsForDB({
                    fileName: fileName,
                    type: results[0].result.type,
                    today: today,
                    expireDayNumber: expireDayNumber,
                    name: results[0].result.name,
                    isEnabled: results[0].result.isEnabled,
                    version: results[0].result.version,
                    secretName: results[0].result.secretName,
                    secretVersion: results[0].result.secretVersion,
                    secretIsEnabled: results[0].result.secretIsEnabled,
                    certFile: results[0].result.certFile,
                    keyFile: results[0].result.keyFile,
                    passphrase: results[0].result.passphrase,
                    isUpload: true,
                    userId: accountId,
                    userName: accountName
                })

                deviceCertParameter.orgId = orgId;
                deviceCertParameter.serialNo = serialNo;
                deviceCertParameter.status = common.CERT_STATUS.ACTIVE;
                deviceCertParameter.intermediateCertId = intermediateCertInfo.id;

                // rabbitmq cert
                deviceCertParameter.rabbitmqFileName = rabbitmqFileName;
                deviceCertParameter.rabbitmqCertName = results[1].result.name
                deviceCertParameter.rabbitmqIsEnabled = results[1].result.isEnabled;
                deviceCertParameter.rabbitmqVersion = results[1].result.version;
                deviceCertParameter.rabbitmqSecretName = results[1].result.secretName;
                deviceCertParameter.rabbitmqSecretVersion = results[1].result.secretVersion;
                deviceCertParameter.rabbitmqSecretIsEnabled = results[1].result.secretIsEnabled;
                deviceCertParameter.rabbitmqCertFile = results[1].result.certFile;
                deviceCertParameter.rabbitmqKeyFile = results[1].result.keyFile;
                deviceCertParameter.rabbitmqPassphrase = results[1].result.passphrase;
                deviceCertParameter.rabbitmqVhost = vhost;

                // insert db
                return pg.createDeviceCertInformation(deviceCertParameter)
            }).then(queryResult => {
                if (!queryResult.status) throw new Error(queryResult.message);
                if (queryResult.result.rowCount !== 1) throw new Error('Fail to insert Device cert information');

                return removeFile(fileArr)
            }).then(() => {
                return resolve({ status: true, serialNo: serialNo });
            }).catch(error => {
                removeFile(fileArr);
                logger.error('generateDeviceCert error: ', error);
                return resolve({ status: false, message: error.message });
            })
    })
}

async function registerRootCertAndUpdateResult(id, status, subject, accoundId, accountName) {
    try {
        if (setting.EDITION === setting.BI_EDITION_NAME.azureAKS) {
            let iotHubFileName = `root${Date.now()}`;
            // get cert key-vault info form pg
            let queryResult = await pg.getRootCertInfoWithAzureKeyVault(id, status);

            if (!queryResult.status) throw new Error(queryResult.message);
            if (queryResult.result.rows[0].certName === '' && queryResult.result.rows[0].certVersion === '') throw new Error('The root cert is not uploaded');
            if (common.getTimeDiffOfDay(new Date(), new Date(queryResult.result.rows[0].expiryTime)) <= 0) throw new Error('The root cert has expired');

            // get key-vault cert
            let certKeyVaultResult = await azureKeyVault.getAzureKeyVaultCertificate(queryResult.result.rows[0].certName, queryResult.result.rows[0].certVersion);
            if (!certKeyVaultResult.status) throw new Error(certKeyVaultResult.message);
            if (!certKeyVaultResult.result.cer || certKeyVaultResult.result.cer === undefined) throw new Error('The root cert of the key vault has not been found');

            // register iot-hub
            let iotHubResult = await azureIotHub.registerIotHobCert({
                certName: iotHubFileName,
                certSubject: subject,
                certExpiry: queryResult.result.rows[0].expiryTime,
                certIsVerified: true,
                certCreateTime: new Date(),
                certContent: certKeyVaultResult.result.cer.toString('base64')
            });
            if (!iotHubResult.status) throw new Error(iotHubResult.message);
            if (!iotHubResult.result.id) throw new Error('Registering the root cert to the iothub has failed');

            let updateResult = await pg.updateRootCertInformation({
                id: id,
                status: common.CERT_STATUS.ACTIVE,
                iotHubName: iotHubResult.result.name,
                eTag: iotHubResult.result.etag,
                isRegister: true,
                registerTime: iotHubResult.result.properties.created,
                accoundId: accoundId,
                accountName: accountName,
                updateTime: new Date()
            })
            if (!updateResult.status) throw new Error(updateResult.message);
        }
        return { status: true, id: id };
    } catch(error) {
        logger.error('registerRootCertAndUpdateResult: ', error);
        return { status: false, message: error.message };
    }
}

async function registerIntermediateCertAndUpdateResult(idx, status, subject, accoundId, accountName) {
    try {
        if (setting.EDITION === setting.BI_EDITION_NAME.azureAKS) {
            let iotHubFileName = `intermediate${Date.now()}`;
            // get intermediate key-vault info form pg
            let queryResult = await pg.getIntermediateCertInfoWithAzureKeyVault(idx, status);

            if (!queryResult.status) throw new Error(queryResult.message);
            if (queryResult.result.rows[0].certName === '' && queryResult.result.rows[0].certVersion === '') throw new Error('The intermediate cert is not uploaded');
            if (common.getTimeDiffOfDay(new Date(), new Date(queryResult.result.rows[0].expiryTime)) <= 0) throw new Error('The intermediate cert has expired');

            // get key-vault cert
            let certKeyVaultResult = await azureKeyVault.getAzureKeyVaultCertificate(queryResult.result.rows[0].certName, queryResult.result.rows[0].certVersion);
            if (!certKeyVaultResult.status) throw new Error(certKeyVaultResult.message);
            if (!certKeyVaultResult.result.cer || certKeyVaultResult.result.cer === undefined) throw new Error('The intermediate cert of the key vault has not been found');

            // register iot-hub
            let iotHubResult = await azureIotHub.registerIotHobCert({
                certName: iotHubFileName,
                certSubject: subject,
                certExpiry: queryResult.result.rows[0].expiryTime,
                certIsVerified: true,
                certCreateTime: new Date(),
                certContent: certKeyVaultResult.result.cer.toString('base64')
            });
            if (!iotHubResult.status) throw new Error(iotHubResult.message);
            if (!iotHubResult.result.id) throw new Error('Registering the intermediate cert to the iothub has failed');

            let updateResult = await pg.updateIntermediateCertInformation({
                idx: idx,
                oriStatus: status,
                status: common.CERT_STATUS.ACTIVE,
                iotHubName: iotHubResult.result.name,
                eTag: iotHubResult.result.etag,
                isRegister: true,
                registerTime: iotHubResult.result.properties.created,
                accoundId: accoundId,
                accountName: accountName,
                updateTime: new Date()
            })
            if (!updateResult.status) throw new Error(updateResult.message);
        }
        return { status: true, idx: idx };
    } catch(error) {
        logger.error('registerIntermediateCertAndUpdateResult: ', error);
        return { status: false, message: error.message };
    }
}

async function getCaCertAndDeviceCert(serialNo) {
    let deviceCertInfo = {
        caName: 'ca',
        iothubCaName: '',
        rabbitmqCaName: '',
        caContent: '',
        iothubCertificate: '',
        iothubPrivateKey: '',
        rabbitmqCertificate: '',
        rabbitmqPrivateKey: ''
    };
    try {
        if (setting.EDITION === setting.BI_EDITION_NAME.azureAKS) {
            let queryResult = await pg.getDeviceCertWithAzureKeyVaultWithLastTime(serialNo);
            if (!queryResult.status) throw new Error(queryResult.message);

            deviceCertInfo.status = queryResult.result.rows[0].status;
            deviceCertInfo.iothubCaName = 'iothub-' + queryResult.result.rows[0].fileName.trim();
            deviceCertInfo.rabbitmqCaName = 'rabbitmq-' + queryResult.result.rows[0].fileName.trim();
            deviceCertInfo.createTime = queryResult.result.rows[0].createTime;
            deviceCertInfo.expiryTime = queryResult.result.rows[0].expiryTime;
            deviceCertInfo.intermediateExpiryTime = queryResult.result.rows[0].intermediateExpiryTime;

            // key-vault
            if (queryResult.result.rows[0].iothubDeviceCertEnabled === true && queryResult.result.rows[0].deviceRabbitmqCertEnabled === true) {
                let keyVaultArr = [];
                keyVaultArr.push(azureKeyVault.getAzureKeyVaultSecret(queryResult.result.rows[0].iothubCertName));
                keyVaultArr.push(azureKeyVault.getAzureKeyVaultSecret(queryResult.result.rows[0].rabbitmqCertName));
                let certKeyVaultResult = await Promise.all(keyVaultArr)
                if (!certKeyVaultResult[0].status) throw new Error(certKeyVaultResult[0].message);
                if (!certKeyVaultResult[1].status) throw new Error(certKeyVaultResult[1].message);
                if (!certKeyVaultResult[0].result.value || certKeyVaultResult[0].result.value === undefined) throw new Error('The iothub device cert or secret of the key-vault has not been found');
                if (!certKeyVaultResult[1].result.value || certKeyVaultResult[1].result.value === undefined) throw new Error('The rabbitmq device cert or secret of the key-vault has not been found');
                // parse cert
                let iothubCert = parseKeyVaultCert(certKeyVaultResult[0].result.value);
                let rabbitmqCert = parseKeyVaultCert(certKeyVaultResult[1].result.value);
                deviceCertInfo.iothubCertificate = iothubCert.certContent;
                deviceCertInfo.iothubPrivateKey = iothubCert.keyContent;
                deviceCertInfo.rabbitmqCertificate = rabbitmqCert.certContent;
                deviceCertInfo.rabbitmqPrivateKey = rabbitmqCert.keyContent;

                // root and intermediate cert
                if (queryResult.result.rows[0].rootCertEnabled === true && queryResult.result.rows[0].intermediateCertEnabled === true) {
                    let rootAndIntermediateCert = await Promise.all([
                        azureKeyVault.getAzureKeyVaultCertificate(queryResult.result.rows[0].rootCertName),
                        azureKeyVault.getAzureKeyVaultCertificate(queryResult.result.rows[0].intermediateCertName)
                    ])
                    if (!rootAndIntermediateCert[0].status) throw new Error(rootAndIntermediateCert[0].message);
                    if (!rootAndIntermediateCert[1].status) throw new Error(rootAndIntermediateCert[1].message);
                    deviceCertInfo.caContent = translateCertFormat(rootAndIntermediateCert[1].result.cer).certContent + '\n' + translateCertFormat(rootAndIntermediateCert[0].result.cer).certContent;
                }
            }
        } else {
            // get cert info from db
            let queryResult = await pg.getDeviceCertFromDBWithLastTime(serialNo)
            if (!queryResult.status) throw new Error(queryResult.message);

            deviceCertInfo.status = queryResult.result.rows[0].status;
            deviceCertInfo.fileName = queryResult.result.rows[0].fileName;
            deviceCertInfo.createTime = queryResult.result.rows[0].createTime;
            deviceCertInfo.expiryTime = queryResult.result.rows[0].expiryTime;
            deviceCertInfo.intermediateExpiryTime = queryResult.result.rows[0].intermediateExpiryTime;

            if (queryResult.result.rows[0].certFile !== '' && queryResult.result.rows[0].keyFile !== '') {
                deviceCertInfo.certContent = crypt.decrypt(queryResult.result.rows[0].certFile);
                deviceCertInfo.keyContent = crypt.decrypt(queryResult.result.rows[0].keyFile);
            }
            if (queryResult.result.rows[0].rootCertFile !== '' && queryResult.result.rows[0].intermediateFile !== '') {
                let rootCert = crypt.decrypt(queryResult.result.rows[0].rootCertFile);
                let intermediateCert = crypt.decrypt(queryResult.result.rows[0].intermediateFile);
                deviceCertInfo.caContent = rootCert + '\n' + intermediateCert;
            }
        }
        return { status: true, deviceCertInfo: deviceCertInfo };
    } catch (error) {
        logger.error('getCaCertAndDeviceCert error: ', error);
        return { status: false, message: error.message };
    }
}

// for RabbitMQ server
async function getServerCert() {
    let orgId = -1;
    let name = 'server';
    let serverCertInfo = {
        fileName: '',
        certContent: '',
        keyContent: ''
    };
    try {
        if (setting.EDITION === setting.BI_EDITION_NAME.azureAKS) {
            let queryResult = await pg.getServerCertWithAzureKeyVault(orgId, name)
            if (!queryResult.status) throw new Error(queryResult.message);

            serverCertInfo.status = queryResult.result.rows[0].status;
            serverCertInfo.fileName = queryResult.result.rows[0].fileName;
            serverCertInfo.createTime = queryResult.result.rows[0].createTime;
            serverCertInfo.expiryTime = queryResult.result.rows[0].expiryTime;

            // key-vault
            if (queryResult.result.rows[0].deviceCertEnabled === true) {
                let certKeyVaultResult = await azureKeyVault.getAzureKeyVaultSecret(queryResult.result.rows[0].certName);
                if (!certKeyVaultResult.status) throw new Error(certKeyVaultResult.message);
                if (!certKeyVaultResult.result.value || certKeyVaultResult.result.value === undefined) throw new Error('The device cert or secret of the key-vault has not been found');
                // parse cert
                let cert = parseKeyVaultCert(certKeyVaultResult.result.value);
                if (!cert.status) throw new Error(cert.message);
                serverCertInfo.certContent = cert.certContent;
                serverCertInfo.keyContent = cert.keyContent;
            }
        } else {
            // get cert info from db
            let queryResult = await pg.getServerCertFromDB(orgId, name)
            if (!queryResult.status) throw new Error(queryResult.message);

            serverCertInfo.status = queryResult.result.rows[0].status;
            serverCertInfo.fileName = queryResult.result.rows[0].fileName;
            serverCertInfo.createTime = queryResult.result.rows[0].createTime;
            serverCertInfo.expiryTime = queryResult.result.rows[0].expiryTime;

            if (queryResult.result.rows[0].certFile !== '' && queryResult.result.rows[0].keyFile !== '') {
                serverCertInfo.certContent = crypt.decrypt(queryResult.result.rows[0].certFile);
                serverCertInfo.keyContent = crypt.decrypt(queryResult.result.rows[0].keyFile);
            }
        }
        return { status: true, serverCertInfo: serverCertInfo };
    } catch (error) {
        logger.error('getDeviceCert error: ', error);
        return { status: false, message: error.message };
    }
}

async function getCaCert(idx) {
    let certInfo = {
        fileName: 'ca',
        certContent: ''
    };
    try {
        if (setting.EDITION === setting.BI_EDITION_NAME.azureAKS) {
            let queryResult = await pg.getCaWithAzureKeyVault(idx)
            if (!queryResult.status) throw new Error(queryResult.message);

            // root and intermediate cert
            let rootAndIntermediateCert = await Promise.all([
                azureKeyVault.getAzureKeyVaultCertificate(queryResult.result.rows[0].rootCertName),
                azureKeyVault.getAzureKeyVaultCertificate(queryResult.result.rows[0].intermediateCertName)
            ])
            if (!rootAndIntermediateCert[0].status) throw new Error(rootAndIntermediateCert[0].message);
            if (!rootAndIntermediateCert[1].status) throw new Error(rootAndIntermediateCert[1].message);
            certInfo.certContent = translateCertFormat(rootAndIntermediateCert[1].result.cer).certContent + '\n' + translateCertFormat(rootAndIntermediateCert[0].result.cer).certContent;
        } else {
            // get cert info from db
            let queryResult = await pg.getCaWithDB(idx)
            if (!queryResult.status) throw new Error(queryResult.message);

            let rootCert = crypt.decrypt(queryResult.result.rows[0].rootCertFile);
            let intermediateCert = crypt.decrypt(queryResult.result.rows[0].intermediateFile);
            certInfo.certContent = rootCert + '\n' + intermediateCert;
        }
        return { status: true, certInfo: certInfo };
    } catch (error) {
        logger.error('getCaCert error: ', error);
        return { status: false, message: error.message };
    }
}

async function getAllRootAndIntermediateCert() {
    let certInfo = {
        fileName: 'all',
        certContent: ''
    };
    try {
        if (setting.EDITION === setting.BI_EDITION_NAME.azureAKS) {
            let queryResult = await pg.getRootAndIntermediateCertFromKeyVault();
            if (!queryResult.status) throw new Error(queryResult.message);
            // get key-vault value
            let arrCert = queryResult.result.rows.map(cert => azureKeyVault.getAzureKeyVaultCertificate(cert.certName))
            let certInfoResult = await Promise.all(arrCert);

            certInfoResult.forEach(cert => {
                let parseCert = translateCertFormat(cert.result.cer);
                certInfo.certContent += parseCert.certContent + '\n';
            })
        } else {
            // get cert info from db
            let queryResult = await pg.getRootAndIntermediateCertFromDB()
            if (!queryResult.status) throw new Error(queryResult.message);

            queryResult.result.rows.forEach(cert => {
                certInfo.certContent += crypt.decrypt(cert.certFile) + '\n';
            })
        }
        return { status: true, certInfo: certInfo };
    } catch (error) {
        logger.error('getAllRootAndIntermediateCert: ', error);
        return { status: false, message: error.message };
    }
}

async function getRootCert(id, status) {
    try {
        let rootCertInfo = {
            fileName: '',
            certContent: ''
        }
        if (setting.EDITION === setting.BI_EDITION_NAME.azureAKS) {
            // get cert key-vault info form pg
            let queryResult = await pg.getRootCertInfoWithAzureKeyVault(id, status);
            if (!queryResult.status) throw new Error(queryResult.message);

            if (queryResult.result.rows[0].certName === '' && queryResult.result.rows[0].certVersion === '') throw new Error('The root cert is not uploaded');
            if (common.getTimeDiffOfDay(new Date(), new Date(queryResult.result.expiryTime)) <= 0) throw new Error('The root cert has expired');

            // key-vault
            let certKeyVaultResult = await Promise.all([
                azureKeyVault.getAzureKeyVaultCertificate(queryResult.result.rows[0].certName)
            ])
            if (!certKeyVaultResult[0].status) throw new Error(certKeyVaultResult[0].message);
            if (!certKeyVaultResult[0].result.cer || certKeyVaultResult[0].result.cer === undefined) throw new Error('The cert of the key-vault has not been found');

            rootCertInfo.fileName = queryResult.result.rows[0].fileName;
            let cert = translateCertFormat(certKeyVaultResult[0].result.cer);
            if (!cert.status) throw new Error(cert.message);
            rootCertInfo.certContent = cert.certContent;
        } else {
            // get cert info form db
            let queryResult = await pg.getRootCertInfoFromDB(id, status);
            if (!queryResult.status) throw new Error(queryResult.message);
            if (queryResult.result.rows[0].certFile === '') throw new Error('The root cert info of the db has not been found');
            if (common.getTimeDiffOfDay(new Date(), new Date(queryResult.result.expiryTime)) <= 0) throw new Error('The root cert of the db has expired');

            rootCertInfo.fileName = queryResult.result.rows[0].fileName;
            rootCertInfo.certContent = crypt.decrypt(queryResult.result.rows[0].certFile);
        }
        return { status: true, result: rootCertInfo };
    } catch(error) {
        logger.error('getRootCert error: ', error);
        return { status: false, message: error.message };
    }
}

async function getRootCertAndPassphrase(id, status) {
    try {
        let rootCertInfo = {
            fileName: '',
            certContent: '',
            keyContent: '',
            passphrase: ''
        }
        if (setting.EDITION === setting.BI_EDITION_NAME.azureAKS) {
            // get cert key-vault info form pg
            let queryResult = await pg.getRootCertInfoWithAzureKeyVault(id, status);
            if (!queryResult.status) throw new Error(queryResult.message);

            if (queryResult.result.rows[0].certName === '' && queryResult.result.rows[0].certVersion === '') throw new Error('The root cert is not uploaded');
            if (queryResult.result.rows[0].secretName === '' && queryResult.result.rows[0].secretVersion === '') throw new Error('The root secret is not uploaded');
            if (common.getTimeDiffOfDay(new Date(), new Date(queryResult.result.expiryTime)) <= 0) throw new Error('The root cert has expired');

            // key-vault
            let certKeyVaultResult = await Promise.all([
                azureKeyVault.getAzureKeyVaultSecret(queryResult.result.rows[0].certName),
                azureKeyVault.getAzureKeyVaultSecret(queryResult.result.rows[0].secretName)
            ])
            if (!certKeyVaultResult[0].status) throw new Error(certKeyVaultResult[0].message);
            if (!certKeyVaultResult[1].status) throw new Error(certKeyVaultResult[1].message);
            if (!certKeyVaultResult[0].result.value || certKeyVaultResult[0].result.value === undefined ||
                !certKeyVaultResult[1].result.value || certKeyVaultResult[1].result.value === undefined) throw new Error('Root Cert Or Secret Not Found');

            rootCertInfo.expireDayNumber = queryResult.result.rows[0].expireDayNumber;
            rootCertInfo.fileName = queryResult.result.rows[0].fileName;

            let cert = parseKeyVaultCert(certKeyVaultResult[0].result.value);
            if (!cert.status) throw new Error(cert.message);
            rootCertInfo.certContent = cert.certContent;
            rootCertInfo.keyContent = cert.keyContent;
            rootCertInfo.passphrase = certKeyVaultResult[1].result.value;
        } else {
            // get cert from db
            let queryResult = await pg.getRootCertInfoFromDB(id, status);
            if (!queryResult.status) throw new Error(queryResult.message);
            if (queryResult.result.rows[0].certFile === '') throw new Error('The root cert of the db has not been found');
            if (queryResult.result.rows[0].keyFile === '') throw new Error('The root key of the db has not been found');
            if (queryResult.result.rows[0].passphrase === '') throw new Error('The root passphrase of the db has not been found');
            if (common.getTimeDiffOfDay(new Date(), new Date(queryResult.result.expiryTime)) <= 0) throw new Error('The root cert is not uploaded');

            rootCertInfo.fileName = queryResult.result.rows[0].fileName;
            rootCertInfo.expireDayNumber = queryResult.result.rows[0].expireDayNumber;
            rootCertInfo.certContent = crypt.decrypt(queryResult.result.rows[0].certFile);
            rootCertInfo.keyContent = crypt.decrypt(queryResult.result.rows[0].keyFile);
            rootCertInfo.passphrase = crypt.decrypt(queryResult.result.rows[0].passphrase);
        }
        return { status: true, result: rootCertInfo };
    } catch(error) {
        logger.error('getRootCertAndPassphrase error: ', error);
        return { status: false, message: error.message };
    }
}

async function getIntermediateCert(id) {
    try {
        let intermediateCertInfo = {
            fileName: '',
            certContent: ''
        }
        if (setting.EDITION === setting.BI_EDITION_NAME.azureAKS) {
            // get cert key-vault info form pg
            let queryResult = await pg.getIntermediateCertInfoWithAzureKeyVaultById(id);
            if (!queryResult.status) throw new Error(queryResult.message);

            if (queryResult.result.rows[0].certName === '' && queryResult.result.rows[0].certVersion === '') throw new Error('The intermediate cert is not uploaded');
            if (common.getTimeDiffOfDay(new Date(), new Date(queryResult.result.rows[0].expiryTime)) <= 0) throw new Error('The intermediate cert has expired');

            // key-vault
            let certKeyVaultResult = await Promise.all([
                azureKeyVault.getAzureKeyVaultCertificate(queryResult.result.rows[0].certName)
            ])
            if (!certKeyVaultResult[0].status) throw new Error(certKeyVaultResult[0].message);
            if (!certKeyVaultResult[0].result.cer || certKeyVaultResult[0].result.cer === undefined) throw new Error('The intermediate cert of the key-vault has not been found');

            intermediateCertInfo.fileName = queryResult.result.rows[0].fileName + '-' + queryResult.result.rows[0].fileIndex;
            let cert = translateCertFormat(certKeyVaultResult[0].result.cer);
            intermediateCertInfo.certContent = cert.certContent;
        } else {
            // get cert info form db
            let queryResult = await pg.getIntermediateCertInfoFromDBById(id);
            if (!queryResult.status) throw new Error(queryResult.message);
            if (queryResult.result.rows[0].certFile === '') throw new Error('The intermediate cert of the db has not been found');
            if (common.getTimeDiffOfDay(new Date(), new Date(queryResult.result.rows[0].expiryTime)) <= 0) throw new Error('The intermediate cert has expired');

            intermediateCertInfo.fileName = queryResult.result.rows[0].fileName + '-' + queryResult.result.rows[0].fileIndex;
            intermediateCertInfo.certContent = crypt.decrypt(queryResult.result.rows[0].certFile);
        }
        return { status: true, intermediateCertInfo: intermediateCertInfo };
    } catch(error) {
        logger.error('getIntermediateCert error: ', error.message);
        return { status: false, message: error.message };
    }
}

async function getIntermediateCertAndPassphrase(index, status) {
    try {
        let intermediateCertInfo = {
            fileName: '',
            certContent: '',
            keyContent: '',
            passphrase: ''
        }
        if (setting.EDITION === setting.BI_EDITION_NAME.azureAKS) {
            // get cert key-vault info form pg
            let queryResult = await pg.getIntermediateCertInfoWithAzureKeyVault(index, status);
            if (!queryResult.status) throw new Error(queryResult.message);
            if (queryResult.result.rows[0].certName === '' && queryResult.result.rows[0].certVersion === '') throw new Error('The intermediate cert is not uploaded');
            if (queryResult.result.rows[0].secretName === '' && queryResult.result.rows[0].secretVersion === '') throw new Error('The intermediate secret is not uploaded');
            if (common.getTimeDiffOfDay(new Date(), new Date(queryResult.result.expiryTime)) <= 0) throw new Error('The intermediate cert has expired');

            // key-vault
            let certKeyVaultResult = await Promise.all([
                azureKeyVault.getAzureKeyVaultSecret(queryResult.result.rows[0].certName),
                azureKeyVault.getAzureKeyVaultSecret(queryResult.result.rows[0].secretName)
            ])
            if (!certKeyVaultResult[0].status) throw new Error(certKeyVaultResult[0].message);
            if (!certKeyVaultResult[1].status) throw new Error(certKeyVaultResult[1].message);
            if (!certKeyVaultResult[0].result.value || certKeyVaultResult[0].result.value === undefined ||
                !certKeyVaultResult[1].result.value || certKeyVaultResult[1].result.value === undefined) throw new Error('The cert and secret of the key-vault has not been found');

            intermediateCertInfo.id = queryResult.result.rows[0].id;
            intermediateCertInfo.fileName = queryResult.result.rows[0].fileName;
            intermediateCertInfo.fileIndex = queryResult.result.rows[0].fileIndex;
            intermediateCertInfo.expireDayNumber = queryResult.result.rows[0].expireDayNumber;

            // parse cert
            let cert = parseKeyVaultCert(certKeyVaultResult[0].result.value);
            if (!cert.status) throw new Error(cert.message);
            intermediateCertInfo.certContent = cert.certContent;
            intermediateCertInfo.keyContent = cert.keyContent;
            intermediateCertInfo.passphrase = certKeyVaultResult[1].result.value;
        } else {
            // get cert info form db
            let queryResult = await pg.getIntermediateCertInfoFromDB(index, status);
            if (!queryResult.status) throw new Error(queryResult.message);
            if (queryResult.result.rows[0].certFile === '') throw new Error('The intermediate cert of the db has not been found');
            if (queryResult.result.rows[0].keyFile === '') throw new Error('The intermediate key of the db has not been found');
            if (queryResult.result.rows[0].passphrase === '') throw new Error('The intermediate secret of the db has not been found');
            if (common.getTimeDiffOfDay(new Date(), new Date(queryResult.result.expiryTime)) <= 0) throw new Error('The intermediate cert of the db has expired');

            intermediateCertInfo.id = queryResult.result.rows[0].id;
            intermediateCertInfo.fileName = queryResult.result.rows[0].fileName;
            intermediateCertInfo.fileIndex = queryResult.result.rows[0].fileIndex;
            intermediateCertInfo.expireDayNumber = queryResult.result.rows[0].expireDayNumber;
            intermediateCertInfo.certContent = crypt.decrypt(queryResult.result.rows[0].certFile);
            intermediateCertInfo.keyContent = crypt.decrypt(queryResult.result.rows[0].keyFile);
            intermediateCertInfo.passphrase = crypt.decrypt(queryResult.result.rows[0].passphrase);
        }
        return { status: true, result: intermediateCertInfo };
    } catch(error) {
        logger.error('getIntermediateCertAndPassphrase error: ', error);
        return { status: false, message: error.message };
    }
}

async function checkRootCertExists(status) {
    try {
        let queryResult;
        if (setting.EDITION === setting.BI_EDITION_NAME.azureAKS) {
            queryResult = await pg.getRootCertCountFromAzure(status);
        } else {
            queryResult = await pg.getRootCertCountFromDB(status);
        }

        if (!queryResult.status) {
            throw new Error(queryResult.message);
        } else {
            if (queryResult.result.rows[0].count > 0) {
                throw new Error('The root cert exists');
            }
            return { status: true };
        }
    } catch (error) {
        return { status: false, message: error.message };
    }
}

async function getIntermediateIndex(status, maxIndexRange) {
    try {
        let index;
        let queryResult;
        if (setting.EDITION === setting.BI_EDITION_NAME.azureAKS) {
            queryResult = await pg.getIntermediateCertCountFromAzure(status);
        } else {
            queryResult = await pg.getIntermediateCertCountFromDB(status);
        }
        if (!queryResult.status) throw new Error(queryResult.message);

        if ([common.CERT_STATUS.NEW, common.CERT_STATUS.ACTIVE].includes(status) && queryResult.result.rows[0].count >= maxIndexRange) {
            index = -1
        } else {
            index = queryResult.result.rows[0].count + 1;
        }
        return { status: true, index: index };
    } catch (error) {
        logger.error('getIntermediateIndex error: ', error);
        return { status: false, message: error.message };
    }
}

async function checkDeviceCertExists(status, serialNo) {
    try {
        let queryResult;
        if (setting.EDITION === setting.BI_EDITION_NAME.azureAKS) {
            queryResult = await pg.getDeviceCertCountFromAzure(status, serialNo);
        } else {
            queryResult = await pg.getDeviceCertCountFromDB(status, serialNo);
        }
        if (!queryResult.status) throw new Error(queryResult.message);
        if (queryResult.result.rows[0].count > 0) {
            return { status: true, isExists: true };
        }
        return { status: true, isExists: false };
    } catch (error) {
        logger.error('checkDeviceCertExists: ', error);
        return { status: false, message: error.message };
    }
}

async function checkServerCertExists(status, intermediateId) {
    try {
        let queryResult;
        if (setting.EDITION === setting.BI_EDITION_NAME.azureAKS) {
            queryResult = await pg.getServerCertCountFromAzure(status, intermediateId);
        } else {
            queryResult = await pg.getServerCertCountFromDB(status, intermediateId);
        }
        if (!queryResult.status) throw new Error(queryResult.message);
        if (queryResult.result.rows[0].count > 0) {
            return { status: true, message: 'The server cert exists' };
        }
        return { status: true, isExists: false };
    } catch (error) {
        logger.error('checkServerCertExists error: ', error);
        return { status: false, message: error.message };
    }
}

async function checkRootCertRegisterExists(status) {
    try {
        let isRegister;
        if (setting.EDITION === setting.BI_EDITION_NAME.azureAKS) {
            isRegister = await pg.getRootCertRegisterIotHubAndRabbitMQCount(status);
        } else {
            isRegister = await pg.getRootCertRegisterRabbitMQCount(status);
        }
        if (isRegister.result.rows[0].count > 0) {
            return { status: true, message: 'The root cert is registered' };
        }
        return { status: false };
    } catch (error) {
        logger.error('checkRootCertRegisterExists: ', error);
        return { status: false, message: error.message };
    }
}

async function checkIntermediateCertRegisterExists(status) {
    try {
        let queryResult;
        if (setting.EDITION === setting.BI_EDITION_NAME.azureAKS) {
            queryResult = await pg.getIntermediateCertRegisterIotHubAndRabbitMQCount(status);
        } else {
            queryResult = await pg.getIntermediateCertRegisterRabbitMQCount(status);
        }
        if (!queryResult.status) throw new Error(queryResult.message);
        if (queryResult.result.rows[0].count > 0) {
            return { result: true, message: 'The intermediate cert is registered' }
        }
        return { status: false };
    } catch (error) {
        logger.error('checkIntermediateCertRegisterExists: ', error);
        return { status: false, message: error.message };
    }
}

async function storeCertAndPassphrase(certName, secretName, cert, passphrase) {
    try {
        let storeCertResult = {
            passphrase: '',
            name: '',
            isEnabled: false,
            version: '',
            certFile: '',
            keyFile: '',
            secretName: '',
            secretVersion: '',
            secretIsEnabled: false
        };
        if (setting.EDITION === setting.BI_EDITION_NAME.azureAKS) {
            // azure key vault cert
            let azureKeyVaultResult = await azureKeyVault.importAzureKeyVaultCertificate(certName, cert);
            if (!azureKeyVaultResult.status) throw new Error(azureKeyVaultResult.message);
            if (!azureKeyVaultResult.result.name) throw new Error('The import of the certificate into azure key-vault has failed');
            storeCertResult.type = common.CERT_TYPE.AZURE_KEY_VAULT;
            storeCertResult.name = azureKeyVaultResult.result.name;
            storeCertResult.isEnabled = azureKeyVaultResult.result.policy.enabled;
            storeCertResult.version = azureKeyVaultResult.result.properties.version;

            // azure key vault secret
            let azureKeyVaultSecretResult = await azureKeyVault.setAzureKeyVaultSecret(secretName, passphrase);
            if (!azureKeyVaultSecretResult.result) throw new Error(azureKeyVaultSecretResult.message);
            if (!azureKeyVaultSecretResult.result.name) throw new Error('The import of the passphrase into azure key-vault has failed');
            storeCertResult.passphrase = '';
            storeCertResult.secretName = azureKeyVaultSecretResult.result.name;
            storeCertResult.secretVersion = azureKeyVaultSecretResult.result.properties.version;
            storeCertResult.secretIsEnabled = azureKeyVaultSecretResult.result.properties.enabled;
        } else {
            let certResult = parseKeyVaultCert(cert);
            if (!certResult.status) throw new Error(certResult.message);
            storeCertResult.type = common.CERT_TYPE.LOCAL_DB;
            storeCertResult.passphrase = crypt.encrypt(passphrase.toString());
            storeCertResult.certFile = crypt.encrypt(certResult.certStr.certContent.toString());
            storeCertResult.keyFile = crypt.encrypt(certResult.certStr.keyContent.toString());
        }
        return ({ status: true, result: storeCertResult });
    } catch (error) {
        logger.error('storeCertAndPassphrase error: ', error);
        return ({ status: false, message: error.message });
    }
}

// mark cert as "Expired" and "delete" in DB, and delete device cert in key vault
async function removeCertAndUpdateResult(name, accountId, accountName, cert) {
    try {
        let isUpload = false;
        let expired = common.CERT_STATUS.EXPIRED;
        let checkList = {
            // The root and intermediate cert are not actually deleted in the Key Vault
            // Set isUpload to false for root and intermediate cert(not really delete)
            isUpload: ([common.CERT_NAME.ROOT, common.CERT_NAME.INTERMEDIATE].includes(name)) ? isUpload : cert.is_upload,
            isKeyVaultCert: cert.key_vault_cert_is_enabled,
            isKeyVaultPassphrase: cert.key_vault_secret_is_enabled,
            isDBCert: !(cert.cert_file !== '' && cert.key_file !== ''),
            isDBPassphrase: !(cert.passphrase !== ''),
            isRabbitmqKeyVaultCert: cert.rabbitmq_key_vault_cert_is_enabled,
            isRabbitmqKeyVaultPassphrase: cert.rabbitmq_key_vault_secret_is_enabled,
            isRabbitmqDBCert: !(cert.rabbitmq_cert_file !== '' && cert.rabbitmq_key_file !== ''),
            isRabbitmqDBPassphrase: !(cert.rabbitmq_passphrase !== ''),
            isRegisterIothub: cert.is_register_iothub,
            isRegisterRabbitMQ: cert.is_register_rabbitmq
        };

        let certInfo = {
            id: cert.id,
            status: cert.status,
            keyVaultCertName: cert.key_vault_cert_name,
            keyVaultCertVersion: cert.key_vault_cert_version,
            keyVaultPassphraseName: cert.key_vault_secret_name,
            keyVaultPassphraseVersion: cert.key_vault_secret_version,
            rabbitmqKeyVaultCertName: cert.rabbitmq_key_vault_cert_name,
            rabbitmqKeyVaultCertVersion: cert.rabbitmq_key_vault_cert_version,
            rabbitmqKeyVaultPassphraseName: cert.rabbitmq_key_vault_secret_name,
            rabbitmqKeyVaultPassphraseVersion: cert.rabbitmq_key_vault_secret_version,
            ithubName: cert.iothub_name,
            iothubEtag: cert.iothub_etag
        }

        // check
        let certIsExistsResult = checkCertInfoExistsFromDB(checkList);
        if (!certIsExistsResult.status) throw new Error(certIsExistsResult.message);
        // delete cert from iothub, rabbitmq(TODO), key-vault
        let isDeleted = await removeCertServices(certInfo, certIsExistsResult.result);
        if (!isDeleted.status) throw new Error(isDeleted.message);
        // update result
        let updateCertResult = await updateCertStatus(name,
            {
                id: certInfo.id,
                status: certInfo.status,
                expired: expired,
                isIothubCert: (certIsExistsResult.result.iothubCert) ? !certIsExistsResult.result.iothubCert : false,
                isIothubSecret: (certIsExistsResult.result.iothubPassphrase) ? !certIsExistsResult.result.iothubPassphrase : false,
                isRabbitmqCert: (certIsExistsResult.result.rabbitmqCert) ? !certIsExistsResult.result.rabbitmqCert : false,
                isRabbitmqSecret: (certIsExistsResult.result.rabbitmqPassphrase) ? !certIsExistsResult.result.rabbitmqPassphrase : false,
                isUpload: isUpload,
                isIothub: (certIsExistsResult.result.iotHub) ? !certIsExistsResult.result.iotHub : false,
                isRabbitMQ: (certIsExistsResult.result.rabbitMQ) ? !certIsExistsResult.result.rabbitMQ : false,
                certFile: '',
                keyFile: '',
                passphrase: '',
                rabbitmqCertFile: '',
                rabbitmqKeyFile: '',
                rabbitmqPassphrase: '',
                isDeleted: isDeleted.status,
                accountId: accountId,
                accountName: accountName,
                deleteTime: new Date()
            }
        )
        if (!updateCertResult.status) throw new Error(updateCertResult.message);
        return { status: true, result: updateCertResult.result };
    } catch (error) {
        logger.error('removeCertAndUpdateResult error: ', error);
        return { status: false, message: error.message }
    }
}

async function updateCertStatus(name, cert) {
    try {
        let updateResult;
        switch (name) {
        case common.CERT_NAME.ROOT:
            updateResult = await pg.updateRootCertWithRemoveResult(cert);
            break;
        case common.CERT_NAME.INTERMEDIATE:
            updateResult = await pg.updateIntermediateCertWithRemoveResult(cert);
            break;
        case common.CERT_NAME.DEVICE:
            updateResult = await pg.updateDeviceCertWithRemoveResult(cert);
            break;
        case common.CERT_NAME.SERVER:
            updateResult = await pg.updateDeviceCertWithRemoveResult(cert);
            break;
        default:
            updateResult.status = false;
            updateResult.message = 'The name is not correct';
            break;
        }
        if (!updateResult.status) throw new Error(updateResult.message);
        return { status: true, result: updateResult.result };
    } catch (error) {
        logger.error('updateCertStatus error: ', error);
        return { status: false, message: error.message };
    }
}

// delete cert from iothub, rabbitmq(TODO), key-vault
async function removeCertServices(certInfo, certIsExistsResult) {
    try {
        // delete key-vault iothub rabbitmq
        let removeArr = [];
        if (setting.EDITION === setting.BI_EDITION_NAME.azureAKS) {
            if (certIsExistsResult.iotHub) {
                let deleteIothubResult = await azureIotHub.deleteIotHubCert(certInfo.ithubName, certInfo.iothubEtag);
                if (deleteIothubResult.status) {
                    if (certIsExistsResult.iothubCert) {
                        removeArr.push(azureKeyVault.deleteAzureKeyVaultCertificate(certInfo.keyVaultCertName));
                    }
                    if (certIsExistsResult.iothubPassphrase) {
                        removeArr.push(azureKeyVault.deleteAzureKeyVaultSecret(certInfo.keyVaultPassphraseName));
                    }
                    if (certIsExistsResult.rabbitmqCert) {
                        removeArr.push(azureKeyVault.deleteAzureKeyVaultCertificate(certInfo.rabbitmqKeyVaultCertName));
                    }
                    if (certIsExistsResult.rabbitmqPassphrase) {
                        removeArr.push(azureKeyVault.deleteAzureKeyVaultSecret(certInfo.rabbitmqKeyVaultPassphraseName));
                    }
                    if (certIsExistsResult.rabbitMQ) {
                        // todo delete rabbitmq
                    }
                } else {
                    throw new Error(deleteIothubResult.message);
                }
            }
        } else {
            if (certIsExistsResult.rabbitMQ) {
                // todo delete rabbitmq
            }
        };
        let results = await Promise.all(removeArr);
        for (let removeResult of results) {
            if (!removeResult.status) throw new Error(removeResult.message);
        }

        return { status: true };
    } catch (error) {
        logger.error('removeCertServices: ', error);
        return { status: false, message: error.message }
    }
}

function checkCertInfoExistsFromDB(cert) {
    try {
        let result = {
            iothubCert: false,
            iothubPassphrase: false,
            rabbitmqCert: false,
            rabbitmqPassphrase: false,
            iotHub: false,
            rabbitMQ: false
        };
        if (setting.EDITION === setting.BI_EDITION_NAME.azureAKS) {
            if (cert.isUpload) {
                result.iothubCert = cert.isKeyVaultCert;
                result.iothubPassphrase = cert.isKeyVaultPassphrase;
                result.rabbitmqCert = cert.isRabbitmqKeyVaultCert;
                result.rabbitmqPassphrase = cert.isRabbitmqKeyVaultPassphrase;
            }
            result.rabbitMQ = cert.isRegisterRabbitMQ
            result.iotHub = cert.isRegisterIothub
        } else {
            if (cert.isUpload) {
                result.iothubCert = cert.isDBCert;
                result.iothubPassphrase = cert.isDBPassphrase;
                result.rabbitmqCert = cert.isRabbitmqDBCert;
                result.rabbitmqPassphrase = cert.isRabbitmqDBPassphrase;
            }
            result.rabbitMQ = cert.isRegisterRabbitMQ
        }
        return { status: true, result: result };
    } catch (error) {
        logger.error('checkCertInfoExistsFromDB: ', error);
        return { status: false, message: 'The check for the existence of the cert info has failed' }
    }
}

function newLines(str, count) {
    let reg = new RegExp(`.{1,${count}}`, 'g');
    return str.match(reg).join('\n');
}

function translateCertFormat(cer) {
    try {
        let certContent = [
            '-----BEGIN CERTIFICATE-----',
            newLines(cer.toString('base64'), 64),
            '-----END CERTIFICATE-----'
        ].join('\n');
        return { status: true, certContent };
    } catch (error) {
        logger.error('translateCertFormat error: ', error)
        return { status: false, message: 'The translation of the cert format has failed' };
    }
}

function parseKeyVaultCert(cert) {
    try {
        let beginCertStr = '-----BEGIN CERTIFICATE-----';
        let endCertStr = '-----END CERTIFICATE-----';
        let beginSecretStr = '-----BEGIN PRIVATE KEY-----'
        let endSecretStr = '-----END PRIVATE KEY-----'
        let certContent = cert.substring(cert.indexOf(beginCertStr), cert.indexOf(endCertStr) + endCertStr.length);
        let keyContent = cert.substring(cert.indexOf(beginSecretStr), cert.indexOf(endSecretStr) + endSecretStr.length);
        return { status: true, certContent, keyContent };
    } catch (error) {
        logger.error('parseKeyVaultCert error: ', error)
        return { status: false, message: 'Parse cert and key has failed' };
    }
}

function prepareCertParamsForDB(params) {
    return {
        status: common.CERT_STATUS.NEW,
        fileName: params.fileName,
        type: params.type,
        expiryTime: common.formatDateTime(common.addDays(params.today, params.expireDayNumber)),
        keyVaultCertName: params.name,
        keyVaultCertIsEnabled: params.isEnabled,
        keyVaultCertVersion: params.version,
        keyVaultSecretName: params.secretName,
        keyVaultSecretVersion: params.secretVersion,
        keyVaultSecretIsEnabled: params.secretIsEnabled,
        certFile: params.certFile,
        keyFile: params.keyFile,
        passphrase: params.passphrase,
        isUpload: params.isUpload,
        uploadTime: params.today,
        createUserId: params.userId,
        createUserName: params.userName,
        createTime: params.today
    }
}

const runCommand = (command, args) => {
    return new Promise((resolve, reject) => {
        const childProcess = spawn(command, args);
        let output = '';
        let error = '';

        childProcess.stdout.on('data', (data) => {
            output += data.toString();
        });

        childProcess.stderr.on('data', (data) => {
            error += data.toString();
        });

        childProcess.on('close', (code) => {
            if (code === 0) {
                return resolve({ status: true, output: output });
            } else {
                logger.error('runCommand error: ', error)
                return resolve({ status: false, message: 'Create cert has failed' });
            }
        });
    });
};

async function removeFile(fileArray) {
    try {
        if (fileArray.length === 0) {
            throw new Error('File is not exists');
        } else {
            let arr = []
            fileArray.forEach(file => {
                if (existsSync(file)) arr.push(fs.unlink(file));
            })
            let result = await Promise.all(arr);
            return { status: true, result: result };
        }
    } catch (error) {
        logger.error('removeFile error: ', error);
        return { status: false, message: 'Remove file has failed' };
    }
}

module.exports = {
    generateRootCert,
    generateIntermediateCert,
    generateDeviceCert,
    generateServerCert,
    registerRootCertAndUpdateResult,
    registerIntermediateCertAndUpdateResult,
    getIntermediateIndex,
    getRootCertAndPassphrase,
    getAllRootAndIntermediateCert,
    getIntermediateCertAndPassphrase,
    getIntermediateCert,
    getCaCert,
    getCaCertAndDeviceCert,
    getServerCert,
    storeCertAndPassphrase,
    prepareCertParamsForDB,
    checkRootCertExists,
    checkDeviceCertExists,
    checkRootCertRegisterExists,
    checkIntermediateCertRegisterExists,
    removeCertAndUpdateResult
}
