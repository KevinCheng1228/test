'use strict';
const express = require('express');
const cors = require('cors');
const cookieParser = require('cookie-parser'); //for parse cookie of WISE-PaaS SSO EIToken
const logger = require('./lib/logger').getLogger('app');
// const db = require('./lib/db');
const common = require('./lib/common');
const setting = require('./conf/setting');

//Help secure Express apps with various HTTP headers
const helmet = require('helmet');
const app = express();

app.use(helmet());

// let dbSchemaName = db.getDbSchemaName();

///////////////////////////////////////////////////////
//Use CORS: for static web server and api server seperation on WISE-PaaS
const corsOptions = {
    /* origin: [
        '/wise-paas\.com$/',
        'http://localhost',
        'http://localhost:3000'
    ], */
    origin: function (originHost, cb) {
        let isValid;

        try {
            //Only allow setting.DOMAIN_NAME (ex: wise-pass.com) in production environment
            if (common.isProductionEnv()) {
                //let regex = /^https\:\/\/([a-z0-9-_])+\.wise-paas\.com$/;
                //isValid = regex.test(originHost);

                let urlObj = new URL('/', originHost);
                if (urlObj.protocol === 'https:' && urlObj.hostname.endsWith(setting.DOMAIN_NAME)) {
                    isValid = true;
                } else {
                    isValid = false;
                }
            } else {
                isValid = originHost === 'http://localhost';
            }
        } catch (ex) {
            cb(null, false);
            return;
        }

        if (common.isProductionEnv() && setting.IS_OPEN_CORS) {
            cb(null, isValid);
        } else {
            cb(null, true); //for test in localhost
        }
    },
    methods: 'GET,PUT,PATCH,POST,DELETE,OPTIONS',
    allowedHeaders: ['Content-Type', 'Authorization', 'Content-Length', 'X-Forwarded-Proto'],
    credentials: true
};
app.use(cors(corsOptions));

///////////////////////////////////////////////////////
///*
//For http session stored in DB
// const session = require('express-session');
// const pgSession = require('connect-pg-simple')(session);

// function sessionErrorLog(err){
//     logger.error('pgSession: ' + err);
// }

//session configuration
// let sessionOptions = {
//     store: new pgSession({
//         //pool : pgPool ,                // Connection pool
//         //pool: db.getDbConnectionPool(),
//         conString: db.getDbConnectionString(), //'postgresql://postgres:12345@localhost:5432/myTestDB',
//         schemaName: dbSchemaName,
//         tableName: 'adv_sessions_user', // Use another table-name than the default "session" one
//         errorLog: sessionErrorLog
//     }),
//     name: setting.SESSION_COOKIE_NAME, //name of the session ID cookie to set in the response
//     secret: 'iag@advantech@2019',
//     resave: false, // don't save session if unmodified
//     saveUninitialized: false, // don't create session until something stored
//     cookie: {
//         maxAge: 30 * 60 * 1000,// 30 mins
//         //maxAge:  1000,// 10 mins
//         httpOnly: true, //clients will not allow client-side JavaScript to see the cookie
//         secure: false, //if cookie only used in https: false in debug mode
//         domain: 'localhost'
//     },
//     //proxy: true, // Crucial
//     rolling: true, //in every response, expiration is reset to the original maxAge
//     unset: 'destroy'
// };

//Enable https in production environment
// if (common.isProductionEnv()) {
//     app.set('trust proxy', 1); // trust first proxy
//     if(common.isAKSEnv()){
//         sessionOptions.cookie.secure = true; //if cookie only used in https: true in production mode
//     }else{
//         sessionOptions.cookie.secure = false; //WISE-PaaS internal use only http, can not set secure cookie
//     }
//     console.log('set cookie secure: ' + sessionOptions.cookie.secure);
//     sessionOptions.cookie.domain = setting.DOMAIN_NAME;
// }

// app.use(session(sessionOptions));

logger.info('this is app.js');

// const index = require('./routes/v10/index');
const cert = require('./routes/v10/cert');

//disable x-powered-by in http header
app.disable('x-powered-by');

app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ limit: '10mb', extended: false }));
//for parse cookie of WISE-PaaS SSO EIToken
app.use(cookieParser());
//app.use(express.static(path.join(__dirname, 'public')));

///////////////////////////////////////////////////////

//auth all requests
app.all('*', common.restrictSsoUser);

///////////////////////////////////////////////////////

//set URL routing
// app.use('/v1.0/', index);
app.use('/v1.0/cert', cert);

//for health check
// app.get('/', function (req, res) {
//     res.send('welcome');
// });

// app.get('/version', function (req, res) {
//     res.json({ APP_VERSION: setting.APP_VERSION, DUMPDB_VERSION: setting.DUMPDB_VERSION });
// });

///////////////////////////////////////////////////////

function ifRestfulRequestType(req) {
    //logger.error("Error path: " + req.path);
    try {
        let uriArray = req.path.split('/');
        let baseUri = '';
        if (uriArray.length === 0){
            baseUri = req.path;
        }else{
            baseUri = uriArray[uriArray.length - 1];
        }
        if (baseUri.indexOf('.') === -1){
            return true;
        }else{
            return false;
        }
    } catch (e) {
        return false;
    }
}

// catch 404 and forward to error handler
app.use(function (req, res, next) {
    let err = new Error('Page Not Found');
    err.status = 404;
    next(err);//forward to error handler
});

// error handler
app.use(function (err, req, res, next) {
    // set locals, only providing error in development
    //res.locals.message = err.message;
    //res.locals.error = req.app.get('env') === 'development' ? err : {};

    // render the error page
    let errCode = err.status || 500;
    res.status(errCode);

    if (!common.isProductionEnv()) {
        if (errCode !== 404) {
            logger.error(err);
        }
        if (ifRestfulRequestType(req)) {
            res.status(404).send('Not Found');
        } else {
            res.status(errCode).send(err.message);
        }
    } else {
        if (errCode !== 404) {
            logger.error(err);
        }
        if (ifRestfulRequestType(req)) {
            res.status(404).send('Not Found');
        } else {
            res.status(errCode).send('');
        }
    }
});

module.exports = app;
