# Grafana Datatable Panel

### 在 1.1.0 版本上重构 Datatable

#### 新增功能

* Export CSV 可以导出 Search 筛选后以及计算后的数据。
  * 配置 search 和计算的功能后，筛选或计算数据后，点击 Export CSV 可以导出筛选和计算后的数据。
* Row Styles 配置中新增 Thresholds 中的 cell,status 的功能。
* 可新增多个自定义列。
  * 不同类型的表格，均支持新增自定义列。
  * 新增 Add Columns 的 Tab 页，配置新增自定义列以及自定义列的信息。
  * 兼容以前版本 Time series aggregations 类型 table 新增的自定义列。
* 可新增多列状态灯。
  * Column styles 配置 tab 页中，新增 Status Lamp 配置项。
  * 已有列均可配置状态灯，配置后生成新的列来展示状态灯状态。
* String 类型支持 Value Mappings.

  * Column Styles 配置页中，选择 String 类型的，出现 Value Mappings 配置项。

#### 优化功能

* Table Transform 去掉 Time series aggregations duplicate 类型，前版本此类型变为 Time series aggregations。
* 整合 Option 和 Datatable Options 配置页的配置项，统一放置在 option 配置页中。
* 分页功能
  * 勾选 Scroll，一页滚动展示。不勾选 Scroll，Rows per page 没有设置,默认一页展示 10 条数据。
* 颜色配置项
  * 如果配置了颜色，颜色配置项才有值，去掉了配置项中的默认颜色值。color reset 按钮可将颜色清空。
* 减少 Table Setting 复杂度。
* Math
  * 新增支持 table 和 timeseries 类型数据源，更加通用。
* Search
  * 已添加的 seach 选项不可以重复添加。
* Column Styles 配置页类型
  * 类型切换的过程中当前值与类型不匹配不会出现错误，不影响后续操作。
  * 如果数据源没有接入 Array 类型数据源，按当前值创建一个数组。数组显示值支持小数点。
* Column Styles 配置页 Threshold 优化。
  * Status 类型，如果没有设置 Dispaly Title,方块上显示当前数值。
  * 增加 title 和值同时显示功能：设置了 Dispaly Title 同时又设置 Display Value 方块上可同时显示设置的 Title 和当前的 value。
* Column Styles 配置页 link 优化。
  * 增加开关，控制 link。
  * 增加 Tooltip，鼠标移动上去显示当前配置的 Tooltip。
* 插件包大大减小，性能提升。

### Screenshots

##### Paging enabled

![Default Paging](/public/plugins/advantech-datatable-panel/screenshots/datatable-basic-dark.png)

##### Scrolling enabled

![Scrolling](/public/plugins/advantech-datatable-panel/screenshots/datatable-dark-scrolling.png)

##### Light Theme with Paging

![Light Theme with Paging](/public/plugins/advantech-datatable-panel/screenshots/datatable-basic-light.png)

##### Numbered Rows and Compact Style

![Numbered and Compact Rows](/public/plugins/advantech-datatable-panel/screenshots/datatable-dark-numbered-compact.png)

#### Options

##### Options Tab

![Options](/public/plugins/advantech-datatable-panel/screenshots/datatable-options.png)

Same options as built-in table panel

##### Datatable Options Tab

![Datatable Options](/public/plugins/advantech-datatable-panel/screenshots/datatable-dt-options.png)

Table Display Options

* Font Size - set font size of table content
* Scroll - toggle for scrolling vs Paging
* Paging Options
  * Rows Per Page - number of rows to display when paging is enabled
  * Paging type - multiple navigation options
* Type Options - add Array option with "As Bar" to present progess bar. Note: The value in the array means {min,max,thresholds 1,thresholds 2}, also includes threshold setting - add String option with "As URL" & "As Icon" to create links and display icon

Column Aliasing

* Override the name displayed for a column

Column Width Hints

* Provide a width "hint" in percentage or pixels ( 100px or 10% ). Note: The table will autosize as needed, but will use the hints provided.

Column Sorting

* Sort table by any number of columns in ascending/descending order.

Table Options

* Row Numbers - toggle to show row numbers
* Length Change Enabled - top left dropdown for showing alternate page sizes
* Search Enabled - toggle to allow searching table content (regex is enabled)
* Info - Displays the "Show N of X entries" on bottom left of table
* Cell Borders - show borders around each Cell (cannot be enabled with Row Borders)
* Row Borders - show border between rows (cannot be enabled with Cell Borders)
* Compact Rows - uses less padding for denser data display
* Striped Rows - non-colored rows will be "striped" odd/even
* Order Column - Highlights the column used for sorting
* Hover - Highlights row on mouse hover (if striped enable, hover color doesn't work)
* **Status only support column header, column width, align.**
  ![Status](/public/plugins/advantech-datatable-panel/screenshots/datatableStatus.PNG)

Theme Settings

* Basic theme is currently the only option, more to be added

Waring Status Configure
![Waring Status Configure](/public/plugins/advantech-datatable-panel/screenshots/StatusSet.PNG)

#### Thresholding

##### Row-based threshold coloring

![Thresholding with Row Coloring](/public/plugins/advantech-datatable-panel/screenshots/datatable-threshold-row.png)

##### Cell based threshold coloring

![Thresholding with Cell Coloring](/public/plugins/advantech-datatable-panel/screenshots/datatable-threshold-cell.png)

##### Cell based threshold value coloring

![Thresholding with Value Coloring](/public/plugins/advantech-datatable-panel/screenshots/datatable-threshold-value.png)

##### RowColumn threshold coloring

This option sets the row color to the "highest" threshold found for all cells in row.

It also sets the color for each cell according to the threshold (you can tell which columns actually exceeded the threshold).

This means - a row can have an overall color, with each cell indicating it's real threshold color.

![Thresholding with RowColumn1](/public/plugins/advantech-datatable-panel/screenshots/datatable-threshold-rowcolumn1.png)

![Thresholding with RowColumn2](/public/plugins/advantech-datatable-panel/screenshots/datatable-threshold-rowcolumn2.png)

##### RowColumn threshold coloring including row counter

Same as above, but with row counter included

![Thresholding with RowColumn including row count](/public/plugins/advantech-datatable-panel/screenshots/datatable-threshold-rowcolumn-rownumbers.png)

---

## Features

* Feature parity with built-in Grafana Table Panel
* Row coloring uses the "highest" threshold color of all columns
* New "RowColumn" threshold color option:
  Sets color to "highest" threshold found for all cells in row.
  Also sets color for each cell according to the threshold.
  This means - a row can have an overall color, with each cell indicating it's real threshold color.
* Set font size for rows
* Scrolling
* Paging
  * Preset page sizes
  * Multiple paging types
  * Dropdown for page size
* Row Numbers reactive to filtering
* Searchable table content (filtering), regex enabled
* Columns names can be aliased
* URLs inside row text can be "clicked"
* Rows can have a click-through URL
* Multi-Column Sorting

## TODO

* [+] Column is not working
* Add Additional Themes
  * Bootstrap:
    * Requires a modified .js file since it looks for "datatables.net" - need workaround
  * Foundation:
    * Requires a modified .js file since it looks for "datatables.net" - need workaround
    * Needs a new CSS that is "dark" for Grafana - the builtin is light
      http://foundation.zurb.com/sites/download.html/#customizeFoundation
  * JQueryUI ThemeRoller
    * Requires a modified .js file since it looks for "datatables.net" - need workaround

## Building

This plugin relies on Grunt/NPM/Bower, typical build sequence:

```
npm install
bower install
grunt
```

For development, you can run:

```
grunt watch
```

The code will be parsed then copied into "dist" if "jslint" passes without errors.

### Docker Support

A docker-compose.yml file is include for easy development and testing, just run

```
docker-compose up
```

Then browse to http://localhost:3000

## External Dependencies

* Grafana 3.x/4.x/5.x

## Build Dependencies

* npm
* bower
* grunt

#### Acknowledgements

This panel is based on the "Table" panel by GrafanaLabs

#### Changelog

| Version | Changes                                                                              |
| ------- | ------------------------------------------------------------------------------------ |
| 0.0.1   | first release                                                                        |
| 0.0.2   | NEW: Added option for a cell or row to link to another page                          |
|         | NEW: Supports Clickable links inside table                                           |
|         | BUGFIX: Fixed missing CSS files                                                      |
|         | BUGFIX: CSS files now load when Grafana has a subpath                                |
|         | NEW: Added multi-column sorting - sort by any number of columns ascending/descending |
|         | NEW: Column Aliasing - modify the name of a column as sent by the datasource         |
|         | NEW: Column width hints - suggest a width for a named column                         |
| 0.0.3   | BUGFIX: Saving State should now work - wrong option was in the datatable constructor |
|         | NEW: Export options for Clipboard/CSV/PDF/Excel/Print                                |
|         | BUGFIX: Columns from datasources other than JSON can now be aliased                  |
|         | BUGFIX: No data now clears table (issue #5)                                          |
| 0.0.4   | BUGFIX: column width, title align                                                    |
