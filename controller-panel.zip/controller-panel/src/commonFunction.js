const langMappingList = [
    { name: '简体中文', value: ['zh-CN', 'zh_cn'], key: 'zh_cn' },
    { name: '繁體中文', value: ['zh-TW', 'zh_tw'], key: 'zh_tw' },
    { name: 'English', value: ['en-US', 'en', ''], key: 'en' },
    { name: '日本語', value: ['ja-JP', 'ja'], key: 'ja' },
    { name: 'Español', value: ['es-ES', 'es_es'], key: 'es_es' }, //西班牙语
    { name: '한국어', value: ['ko-KR', 'ko_kr'], key: 'ko_kr' }, //韩语
    { name: 'ไทย', value: ['th-TH', 'th_th'], key: 'th_th' }, // 泰语
    { name: 'Tiếng Việt', value: ['vi-VN', 'vi_vn'], key: 'vi_vn' }, // 越南语
    { name: 'Melayu', value: ['ms-MY', 'ms_my'], key: 'ms_my' }, // 马来语
    { name: 'Indonesia.', value: ['id-ID', 'id_id'], key: 'id_id' }, // 印度尼西亚
    { name: 'Nederlands', value: ['nl-NL', 'nl_nl'], key: 'nl_nl' }, // 荷兰语
    { name: 'Português', value: ['pt-PT', 'pt_pt'], key: 'pt_pt' }, // 葡萄牙语
    { name: 'français', value: ['fr-FR', 'fr_fr'], key: 'fr_fr' }, // 法语
    { name: 'Deutsche', value: ['de-DE', 'de_de'], key: 'de_de' }, // 德语
    { name: 'Suomalainen', value: ['fi-FI', 'fi_fi'], key: 'fi_fi' }, // 芬兰语
    { name: 'dansk', value: ['da-DK', 'da_dk'], key: 'da_dk' }, // 丹麦语
    { name: 'русский', value: ['ru-RU', 'ru_ru'], key: 'ru_ru' }, // 俄语
    { name: 'italiano', value: ['it-IT', 'it_it'], key: 'it_it' }, // 意大利语
    { name: 'Ελληνικά', value: ['el-GR', 'el_gr'], key: 'el_gr' }, // 希腊语
];
export function getLangType(lang){
    let langType = 'en';
    langMappingList.forEach(x => {
        if (-1 !== x.value.indexOf(lang)) {
            langType = x.key;
            return;
        }
    });
    return langType;
}
