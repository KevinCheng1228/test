
const { IotHubClient } = require('@azure/arm-iothub');
const { ManagedIdentityCredential } = require("@azure/identity");

const SubscriptionId = '8bbf121e-2305-44c0-b969-89038d6924ee'; //365
const credential = new ManagedIdentityCredential();

const resourceGroupName = 'SGP-RG-SN5-Prod';
const resourceName = 'azsgp-sn5-iot-1p';

const client = new IotHubClient(credential, SubscriptionId);
console.log(client.apiVersion);
console.log(client.$host);

client.certificates.listByIotHub(resourceGroupName, resourceName)
    .then(result => {
        console.log(result);
    })
    .catch(err => {
        console.error(err)
    })
