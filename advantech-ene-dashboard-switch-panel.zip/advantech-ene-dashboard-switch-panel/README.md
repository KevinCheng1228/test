# Advantech-Ene-Dashboard-switch-panel for Grafana

The Advantech Ene Dashboard switch panel allows user switch panel freely.

![Advantech-Ene-dashboard-switch-panel](http://advgitlab.eastasia.cloudapp.azure.com/Dashboard_images/dashboard-ene-switch-panel/raw/5e5a77cd092195bba6c0759e17128e1b497da0c4/img/example.PNG)

## Getting Started

### How to install
1. Download the "Advantech-Ene-Dashboard-switch-panel" to the"grafana/data/plugins" folder
2. Running ```npm install```, and ```grunt``` for developer

```
npm install
grunt
```

### Running the system
1. Open the "grafana/bin" folder
2. Run ```.\grafana-server```
3. Open browser and type localhost:3000(default)

## Introduction
- The Dashboard switch panel plugin for Grafana can turn to different panel, which can allow the user switch panel quickly.

## How to use?

### Options Tab

Users can config setting as customized.
- Width and height set up for the size of drop down menu box
- Show refresh button as user config
    * **Checked:**    It need click button after change item(default)
    * **Unchecked:**  It will refresh automatically after change drop down item
- Set default organization levels config
    * **Import Company Level:**  Import default config if it checks
    * **Level:**                 If 'Import Company Level' button is checked,Level set up the number of organization levels.

### List Tab

#### Dropdown List
1. Add dropdown list
2. Set title, dropdown type, datasource type, query and dependent item of the item list.
3. Need set up datasource type that dashboard has set and query for getting item list , if dropdown type is 'query'.
4. Subjoin different item by adding item list button, if dropdown type is 'custom'.
5. The dependent item undertake the dashboard from the upper layer.

![Option](http://advgitlab.eastasia.cloudapp.azure.com/Dashboard_images/dashboard-ene-switch-panel/raw/5e5a77cd092195bba6c0759e17128e1b497da0c4/img/options.png)

![Dropdownlist](http://advgitlab.eastasia.cloudapp.azure.com/Dashboard_images/dashboard-ene-switch-panel/raw/5e5a77cd092195bba6c0759e17128e1b497da0c4/img/changeItem.jpg)

**Note:**
*If the dropdown type is 'query' which will fill the dropdown list automatically.*

#### Checkbox List
1. Add Checkbox List
2. Set label 
3. Set panel titles of other panels to include 'label'
4. show or hide by checking or unchecking

![Checkbox](http://advgitlab.eastasia.cloudapp.azure.com/Dashboard_images/dashboard-ene-switch-panel/raw/5e5a77cd092195bba6c0759e17128e1b497da0c4/img/checkbox-show.png)   

![Checkbox](http://advgitlab.eastasia.cloudapp.azure.com/Dashboard_images/dashboard-ene-switch-panel/raw/5e5a77cd092195bba6c0759e17128e1b497da0c4/img/checkbox-hide.png)


### Templating

1. Build a dashboard
2. Set up dropdown list
3. Metrics and info of panels in dashboard require ```$``` as prefix word with variables as templating

    ![Templating Setting](http://advgitlab.eastasia.cloudapp.azure.com/Dashboard_images/dashboard-ene-switch-panel/raw/5e5a77cd092195bba6c0759e17128e1b497da0c4/img/variable-use.png)
    
4. Click refresh button to reload the page (choosable)

    **Note:**
    * If url has config, it required click refresh button to redirect the url(necessary).
    * The switch panel will set up variables at first time config, but it need reload page after save configuration.
    * Initial item of the dropdown list will be set as the first one.

![Templating Example](http://advgitlab.eastasia.cloudapp.azure.com/Dashboard_images/dashboard-ene-switch-panel/raw/5e5a77cd092195bba6c0759e17128e1b497da0c4/img/TemplatingEx1.PNG)
![Variable Change](http://advgitlab.eastasia.cloudapp.azure.com/Dashboard_images/dashboard-ene-switch-panel/raw/5e5a77cd092195bba6c0759e17128e1b497da0c4/img/TemplatingEx2.PNG)


---

## Authors
Advantech

## Change Log
Please see CHANGELOG.md for more detail