/*
 * @Author: NH
 * @Date: 2021-05-13 17:28:05
 * @LastEditTime: 2021-07-22 14:35:08
 * @Description: 
 */
import _ from 'lodash';
import $ from 'jquery';
import 'jquery.flot';
import 'jquery.flot.pie';
import { Carousel } from './carousel';

export default function link(scope, elem, attrs, ctrl) {
  elem = elem.find('.dashboard-switch-panel');

  ctrl.events.on('render', function () {
    render();
    addCarousel();
  });

  function render() {

    $('.dashboard-switch-panel').each(function () {
      let parent = $(this).closest('.react-grid-item');
      parent.css('z-index', 100 - parent.index());
    });
  }

  function addCarousel() {
    ctrl.$timeout(() => {
      let projectDOM = $('.dashboard-switch-panel #carousel-container-object');
      if (projectDOM.length) {
        if (!ctrl.projectCarousel) {
          ctrl.projectCarousel = new Carousel('.dashboard-switch-panel #carousel-container-object', ctrl.panel.carouselInterval, ctrl.panel.selectedObjItems);
          ctrl.projectCarousel.init();
        } else {
          ctrl.projectCarousel.setOptions({
            items: ctrl.panel.selectedObjItems,
            speed: ctrl.panel.carouselInterval
          });
        }
      }

      let paramtDOM = $('.dashboard-switch-panel #carousel-container-param');
      if (paramtDOM.length) {
        if (!ctrl.paramCarousel) {
          ctrl.paramCarousel = new Carousel('.dashboard-switch-panel #carousel-container-param', ctrl.panel.carouselInterval, ctrl.panel.selectedParamItems);
          ctrl.paramCarousel.init();
        } else {
          ctrl.paramCarousel.setOptions({
            items: ctrl.panel.selectedParamItems,
            speed: ctrl.panel.carouselInterval
          });
        }
      }
    });
  }
}

