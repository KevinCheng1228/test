/*
 * @Author: NH
 * @Date: 2021-10-21 09:44:21
 * @LastEditTime: 2021-10-27 09:41:30
 * @Description: 
 */
import { DashboardSwitchCtrl } from './dashboard-switch_ctrl';
import { loadPluginCss } from 'app/plugins/sdk';

loadPluginCss({
    dark: 'plugins/advantech-ene-dashboard-switch-panel/css/dashboard-switch-panel.dark.css',
    light: 'plugins/advantech-ene-dashboard-switch-panel/css/dashboard-switch-panel.light.css',
});

export { DashboardSwitchCtrl as PanelCtrl };
