<!--
 * @Author: NH
 * @Date: 2019-12-26 15:32:32
 * @LastEditTime: 2023-01-04 09:35:07
 * @Description: 
-->
# Changelog

All notable changes to this project will be documented in this file.

## [1.05.001] - Jun 04,2023

### [Update] Modify UI display according to level info

### [Update] When exporting logs, the url of api-report app changes with the hostname

## [1.04.001] - Feb 07,2022

### [New] Export function, support panel specific style -- 2022/05/13

### [New] Support export report from api-report app -- 2022/05/11

### [Update] When there is no SOE log, 'Nodata' dialog is displayed -- 2022/03/31

### [New] The panel configuration page supports multiple languages

### [New] Support query SOE info

### [New] Support export report from dashboard
