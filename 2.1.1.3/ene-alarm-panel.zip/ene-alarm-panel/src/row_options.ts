///<reference path="../node_modules/grafana-sdk-mocks/app/headers/common.d.ts" />

import _ from 'lodash';
import kbn from 'app/core/utils/kbn';
import { getMultiLang } from './multilang';

export class RowOptionsCtrl {
  panel: any;
  panelCtrl: any;
  colorModes: any;
  columnStyles: any;
  columnTypes: any;
  fontSizes: any;
  dateFormats: any;
  addColumnSegment: any;
  unitFormats: any;
  getColumnNames: any;
  activeStyleIndex: number;
  mappingTypes: any;

  /** @ngInject */
  constructor($scope) {
    $scope.rowEditor = this;
    this.activeStyleIndex = 0;
    this.panelCtrl = $scope.ctrl;
    this.panel = this.panelCtrl.panel;
    this.unitFormats = kbn.getUnitFormats();
    this.colorModes = [
      {text: 'Disabled', value: null},
      {text: 'Cell', value: 'cell'},
      {text: 'Value', value: 'value'},
      {text: 'Row', value: 'row'},
      {text: 'Status', value: 'status'},
    ];
  }
    getMultiLang(key) {
        return getMultiLang(key, this.panel.langType);
    }
  render() {
    this.panelCtrl.render();
  }

  setUnitFormat(column, subItem) {
    column.unit = subItem.value;
    this.panelCtrl.render();
  }

  addRowStyle() {
    const styles = this.panel.rowStyles;
    const stylesCount = styles.length + 1;
    this.panel.activeRowStyleIndex = styles.length;
    const newStyleRule = {
      rowBGColor: '',
      rowAlias: null,
      colNum: '1',
      rowNum: stylesCount.toString(),
      rowhtml: '',
      rowopenNewTab: false,
      thresholdConfig: {
        colorMode: null,
        thresholds: [],
        colors: [
          'rgba(245, 54, 54, 0.9)',
          'rgba(237, 129, 40, 0.89)',
          'rgba(50, 172, 45, 0.97)',
          'rgba(45, 91, 172, 0.9)',
          'rgba(247, 243, 27, 0.9)',
          'rgba(184, 27, 247, 0.9)',
        ],
      },
    };
    styles.push(newStyleRule);
    this.panelCtrl.render();
  }

  rowNumChange(style) {
    this.panelCtrl.render();
  }

  resetRowColor(style) {
    style.rowBGColor = null;
    this.panelCtrl.render();
  }

  removeRowStyle(style) {
    this.panel.rowStyles = _.without(this.panel.rowStyles, style);
    this.panel.activeRowStyleIndex = this.panel.rowStyles.length - 1;
    this.panelCtrl.render();
  }

  invertColorOrder(index) {
    const ref = this.panel.rowStyles[index].thresholdConfig.colors;
    const copy1 = ref[0];
    const copy2 = ref[1];
    const copy3 = ref[2];
    ref[0] = ref[5];
    ref[1] = ref[4];
    ref[2] = ref[3];
    ref[3] = copy3;
    ref[4] = copy2;
    ref[5] = copy1;
    this.panelCtrl.render();
  }
}

/** @ngInject */
export function rowOptionsTab($q, uiSegmentSrv) {
  'use strict';
  return {
    restrict: 'E',
    scope: true,
    templateUrl: 'public/plugins/ene-alarm-panel/partials/row_options.html',
    controller: RowOptionsCtrl,
  };
}
