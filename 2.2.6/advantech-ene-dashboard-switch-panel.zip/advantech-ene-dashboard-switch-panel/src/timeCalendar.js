/*
 * @Author: NH
 * @Date: 2021-05-13 15:09:55
 * @LastEditTime: 2021-05-21 17:37:16
 * @Description: 
 */
export const name = 'Calendar';

export const defaultDisplayOptions = {
    year: {
        en: '',
        zh_cn: '年',
        zh_tw: '年',
        ja: '年'
    },
    months: [
        {
            id: 0,
            display: {
                en: 'Jan',
                zh_cn: '一月',
                zh_tw: '一月',
                ja: '1月'
            }
        }, {
            id: 1,
            display: {
                en: 'Feb',
                zh_cn: '二月',
                zh_tw: '二月',
                ja: '2月'
            }
        }, {
            id: 2,
            display: {
                en: 'Mar',
                zh_cn: '三月',
                zh_tw: '三月',
                ja: '3月'
            }
        }, {
            id: 3,
            display: {
                en: 'Apr',
                zh_cn: '四月',
                zh_tw: '四月',
                ja: '4月'
            }
        }, {
            id: 4,
            display: {
                en: 'May',
                zh_cn: '五月',
                zh_tw: '五月',
                ja: '5月'
            }
        }, {
            id: 5,
            display: {
                en: 'Jun',
                zh_cn: '六月',
                zh_tw: '六月',
                ja: '6月'
            }
        }, {
            id: 6,
            display: {
                en: 'Jul',
                zh_cn: '七月',
                zh_tw: '七月',
                ja: '7月'
            }
        }, {
            id: 7,
            display: {
                en: 'Aug',
                zh_cn: '八月',
                zh_tw: '八月',
                ja: '8月'
            }
        }, {
            id: 8,
            display: {
                en: 'Sept',
                zh_cn: '九月',
                zh_tw: '九月',
                ja: '9月'
            }
        }, {
            id: 9,
            display: {
                en: 'Oct',
                zh_cn: '十月',
                zh_tw: '十月',
                ja: '10月'
            }
        }, {
            id: 10,
            display: {
                en: 'Nov',
                zh_cn: '十一月',
                zh_tw: '十一月',
                ja: '11月'
            }
        }, {
            id: 11,
            display: {
                en: 'Dec',
                zh_cn: '十二月',
                zh_tw: '十二月',
                ja: '12月'
            }
        }],
    weeks: [
        {
            id: 1,
            display: {
                en: 'Mon',
                zh_cn: '周一',
                zh_tw: '週一',
                ja: '月曜日'
            }
        }, {
            id: 2,
            display: {
                en: 'Tue',
                zh_cn: '周二',
                zh_tw: '週二',
                ja: '火曜日'
            }
        }, {
            id: 3,
            display: {
                en: 'Wed',
                zh_cn: '周三',
                zh_tw: '週三',
                ja: '水曜日'
            }
        }, {
            id: 4,
            display: {
                en: 'Thu',
                zh_cn: '周四',
                zh_tw: '週四',
                ja: '木曜日'
            }
        }, {
            id: 5,
            display: {
                en: 'Fri',
                zh_cn: '周五',
                zh_tw: '週五',
                ja: '金曜日'
            }
        }, {
            id: 6,
            display: {
                en: 'Sat',
                zh_cn: '周六',
                zh_tw: '週六',
                ja: '土曜日'
            }
        }, {
            id: 7,
            display: {
                en: 'Sun',
                zh_cn: '周日',
                zh_tw: '週日',
                ja: '日曜日'
            }
        }]
};
export const fromList = {
    dates: [],
    decade: [],
    century: []
}

export const toList = {
    dates: [],
    decade: [],
    century: []
}

export const defaultOptions = {
    century : 100,
    decade: 10,
    maxYear: parseInt(new Date().getFullYear()) + 100 ,
    minYear: 1900,
    from: {
        level: 1,
        date: '',
        title: '',
        year: '',
        month: '',
        day: '',
        hour: '00',
        min: '00',
        sec: '00',
        isErr:false
    }, 
    to: {
        level: 1,
        date:'',
        title: '',
        year: '',
        month: '',
        day: '',
        hour: '00',
        min: '00',
        sec: '00',
        isErr:false
    }
}