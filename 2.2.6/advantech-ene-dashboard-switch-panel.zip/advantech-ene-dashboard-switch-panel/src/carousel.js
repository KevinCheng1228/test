/*
 * @Author: NH
 * @Date: 2021-07-20 11:15:34
 * @LastEditTime: 2021-10-29 10:49:29
 * @Description: 
 */
import $ from 'jquery';

export class Carousel {
    constructor(dom, speed, items) {
        this.dom = dom;
        this.speed = speed;
        this.index = 1;
        this.len = 0;
        this.container = null;
        this.node = null;
        this.height = null;
        this.width = null;
        this.items = [].concat(items);
        this.interval = null;
    }

    init() {
        this.container = $(document).find(this.dom).find('ul.carousel-ul');
        this.stop();
        this.createItem();
        this.node = this.container.find('li.carousel-li:first');
        this.height = this.node.height();
        this.index = this.node.data('index');
        $(document).find(this.dom).find('.dropdown-label-rigth-sub').text(`${this.index + 1}/${this.len}`);
        this.container.hover(() => { this.stop() }, () => { this.start() });
        this.start();
    }

    start() {
        this.stop();
        this.interval = setTimeout(() => {
            this.container.animate({
                marginTop: -1 * this.height + 'px'
            }, 500, 'linear', () => {
                this.node = this.container.css({
                    marginTop: '0px'
                }).find('li.carousel-li:first').remove().clone(true);
                this.index = this.container.find('li.carousel-li:first').data('index');
                this.node.appendTo(this.container);
                $(document).find(this.dom).find('.dropdown-label-rigth-sub').text(`${this.index + 1}/${this.len}`);
                // this.stop();
                this.start();
            });
        }, this.speed);
    }

    stop() {
        clearTimeout(this.interval);
        this.interval = null;
        this.container.stop(true, true);
    }

    createItem() {
        let template = '';
        this.len = this.items.length;
        for (let i = 0; i < this.items.length; i++) {

            let def = 'select object';
            let items = (this.items[i] || '').split('/');
            let label = '';
            let text = '';

            let list = items.filter(x => { return !new RegExp(def, 'i').test(x) });
            if (list.length < 2) {
                label = '';
                text = list[0] || def;
            } else {
                text = list[list.length - 1];
                let temp = list.slice(0, list.length - 1);
                let len = temp.join(' / ').length;
                if ((len + 2) * 5.4 > 190) {
                    temp = [temp[0], temp[temp.length - 1]];
                    len = temp.join(' / ... / ').length;
                    if ((len + 2) * 5.4 > 190) {
                        temp = [temp[0].substr(0, 10) + '...', temp[temp.length - 1].substr(0, 10) + '...'];
                    }
                    label = temp.join(' / ... / ') + ' /';
                } else {
                    label = temp.join(' / ') + ' /';
                }
            }

            template += `<li class="carousel-li" data-index="${i}">
                <div>
                    <span class="carousel-label">${label}</span>
                    <span class="carousel-text">${text}</span>
                </div>
            </li>`;
        }
        if (template.length) {
            this.container.html('').append($(template));
        }
    }

    setOptions(options){
        this.items = [].concat(options.items);
        this.speed = options.speed;
        this.init();
    }
}