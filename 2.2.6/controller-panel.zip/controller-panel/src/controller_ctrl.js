import { MetricsPanelCtrl } from 'app/plugins/sdk';
import _ from 'lodash';
import kbn from 'app/core/utils/kbn';
import ChangeFont from 'app/core/utils/fontsize';
// import ChangeFont from './fontsize';
// import fakeData from './fakeData'
import * as commonFunction from './commonFunction';

export class ControllerCtrl extends MetricsPanelCtrl {
  constructor($scope, $injector, $rootScope) {
    super($scope, $injector);
    this.$rootScope = $rootScope;
    this.resultData = [];
    this.fontCalc = [];
    this.dictFontCalc = {};
    this.lang = commonFunction.getLangType(this.dashboard.meta.language) || 'en'; //Default
    this.styleNums = 1;
    this.defaultStyle = {
      target: '',
      data: 0,
      header: {
        content: {
          en: 'Header Example',
          zh_tw: '標題範例',
          zh_cn: '标题示例',
          jp: 'ヘッダーの例',
        },
        font: {
          size: '80%',
          sizeValue: {
            text: '80%',
            value: '80%',
            vw: '1vw',
            px: '19px',
          },
          bold: true,
          color: '#5ac8fa',
        },
        show: true,
      },
      off: {
        mappingValue: 0,
        content: {
          en: 'OFF',
          zh_tw: '關',
          zh_cn: '关',
          jp: 'オフ',
        },
        font: {
          size: '80%',
          sizeValue: {
            text: '80%',
            value: '80%',
            vw: '1vw',
            px: '19px',
          },
          bold: false,
          color: '#ffffff',
        },
      },
      on: {
        mappingValue: 1,
        content: {
          en: 'ON',
          zh_tw: '開',
          zh_cn: '开',
          jp: 'オン',
        },
        font: {
          size: '80%',
          sizeValue: {
            text: '80%',
            value: '80%',
            vw: '1vw',
            px: '19px',
          },
          bold: false,
          color: '#ffffff',
        },
      },
    };

    const panelDefaults = {
      buttonType: 'Rect',
      buttonSize: 'Normal',
      buttonAlign: 'Horizontal',
      lightColorON: '#73BF69',
      lightColorOFF: '#F2495C',
      isMultiSwitchs: false,
      numOfColumns: 1,
      numOfRows: 1,
      confirmDialog: {
        show: true,
        authentication: false,
      },
      isAdjustFontSize: false,
      styles: [
        {
          target: '',
          data: 0,
          header: {
            content: {
              en: 'Header Example',
              zh_tw: '標題範例',
              zh_cn: '标题示例',
              jp: 'ヘッダーの例',
            },
            font: {
              size: '80%',
              sizeValue: {
                text: '80%',
                value: '80%',
                vw: '1vw',
                px: '19px',
              },
              bold: true,
              color: '#5ac8fa',
            },
            show: true,
          },
          off: {
            mappingValue: 0,
            content: {
              en: 'OFF',
              zh_tw: '關',
              zh_cn: '关',
              jp: 'オフ',
            },
            font: {
              size: '80%',
              sizeValue: {
                text: '80%',
                value: '80%',
                vw: '1vw',
                px: '19px',
              },
              bold: false,
              color: '#ffffff',
            },
          },
          on: {
            mappingValue: 1,
            content: {
              en: 'ON',
              zh_tw: '開',
              zh_cn: '开',
              jp: 'オン',
            },
            font: {
              size: '80%',
              sizeValue: {
                text: '80%',
                value: '80%',
                vw: '1vw',
                px: '19px',
              },
              bold: false,
              color: '#ffffff',
            },
          },
        },
      ],
    };

    _.defaults(this.panel, panelDefaults);

    this.events.on('render', this.onRender.bind(this));
    this.events.on('data-received', this.onDataReceived.bind(this));
    this.events.on('data-error', this.onDataError.bind(this));
    this.events.on('init-edit-mode', this.onInitEditMode.bind(this));
  }

  onInitEditMode() {
    this.fontCalc = ChangeFont.defaultValues;
    this.fontCalc.forEach((item, index) => {
      this.dictFontCalc[this.fontCalc[index].text] = this.fontCalc[index];
    });
    this.addEditorTab('Options', 'public/plugins/controller-panel/partials/editor.html', 2);
  }

  onDataError(err) {
    console.log('error:' + err);
  }

  onRender() {}

  onDataReceived(dataList) {
    // dataList = fakeData
    if (!_.isEmpty(dataList) && dataList.length) {
      this.lang = commonFunction.getLangType(dataList[0].langType || this.dashboard.meta.language) || 'en';
      this.resultData = dataList;
      this.targetMatch();
      // 字體大小相容
      this.fontDefaultCheck();
    }
  }

  targetMatch() {
    this.panel.styles.forEach(style => {
      this.resultData.forEach(element => {
        if (element.target === style.target) {
          style.data = element.datapoints[0][0];
        }
      });
    });
  }

  setValue(index) {
    console.log('index', index);
    this.datasource
      .metricFindQuery_setvalue(
        this.panel.targets[index],
        this.panel.styles[index].data === this.panel.styles[index].on.mappingValue
          ? Number(this.panel.styles[index].off.mappingValue)
          : Number(this.panel.styles[index].on.mappingValue)
      )
      .then(response => {
        this.refresh();
      });
  }

  tableMaker() {
    // [0] ->  [N]
    if (this.panel.isMultiSwitchs && this.panel.numOfColumns > 0 && this.panel.numOfRows > 0) {
      this.styleNums = this.panel.numOfColumns * this.panel.numOfRows;

      // [N] ->  [N+?]
      if (this.styleNums > this.panel.styles.length) {
        for (let i = this.panel.styles.length; i < this.styleNums; i++) {
          this.panel.styles.push(_.cloneDeep(this.defaultStyle));
        }
      } else {
        // [N] ->  [N-?]
        for (let i = this.panel.styles.length; i > this.styleNums; i--) {
          this.panel.styles.pop();
        }
      }
    } else if (!this.panel.isMultiSwitchs) {
      // [N] ->  [0]
      // keep the first style
      let style = this.panel.styles[0];
      this.resetTable();
      this.panel.styles.push(style);
    }
  }

  resetTable() {
    this.styleNums = 1;
    this.panel.numOfColumns = 1;
    this.panel.numOfRows = 1;
    this.panel.styles = [];
  }

  fontDefaultCheck() {
    if (this.panel.styles.length > 0 && !this.panel.styles[0].header.hasOwnProperty('font')) {
      let posCol = ['header', 'on', 'off'];
      let defaultFont = {
        size: '80%',
        sizeValue: {
          text: '80%',
          value: '80%',
          vw: '1vw',
          px: '19px',
        },
        bold: true,
        color: '',
      };
      this.panel.styles.forEach((style, index) => {
        posCol.forEach(pos => {
          style[pos].font = _.cloneDeep(defaultFont);
          style[pos].font.bold = style[pos].bold;
          style[pos].font.color = style[pos].color;
          delete style[pos].bold;
          delete style[pos].color;
        });
      });
    }
  }

  fontSizeChange(index, pos) {
    this.panel.styles[index][pos].font.sizeValue = _.find(this.fontCalc, o => {
      return o.text == this.panel.styles[index][pos].font.size;
    });
  }
}

ControllerCtrl.templateUrl = 'partials/module.html';
