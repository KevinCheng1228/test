import { MetricsPanelCtrl } from 'app/plugins/sdk'
import kbn from 'app/core/utils/kbn'
import _ from 'lodash'
import $ from 'jquery'
import echarts from './lib/echarts'
import ChangeFont from 'app/core/utils/fontsize' // for release
// import ChangeFont from './fontsize' // for dev
import config from './config'
import fakeData from './fake-data'
import appEvents from 'app/core/app_events' // for demo

export class LogChartPanel extends MetricsPanelCtrl {
  constructor($scope, $injector, $rootScope, $filter) {
    super($scope, $injector)
    this.$rootScope = $rootScope
    this.hiddenSeries = {}
    this.dataType = 'timeseries'
    this.dictFontCalc = {}
    this.unitFormats = ''
    this.resultData = []
    this.ctrlId = Date.now()
    this.dateFormatOptions = config.dateOptions
    this.classLevelOptions = config.classLevelOptions
    this.fakeData = fakeData
    this.valueListFromDatapointsTrans = []
    this.timeLineFromDatapointsTrans = []

    // 為了讓同個 dashboard 上有同個 panel，並互相不干擾
    if (!$rootScope.MplusSwitchPanelIdArray) {
      $rootScope.MplusSwitchPanelIdArray = []
    }
    while ($rootScope.MplusSwitchPanelIdArray.indexOf(this.ctrlId) !== -1) {
      this.ctrlId = Date.now()
    }
    $rootScope.MplusSwitchPanelIdArray.push(this.ctrlId)
    console.log('$rootScope.MplusSwitchPanelIdArray', $rootScope.MplusSwitchPanelIdArray)
    $rootScope.$on('$routeChangeSuccess', function () {
      $rootScope.MplusSwitchPanelIdArray = []
    })

    // 讀取預設設定的字體大小
    this.fontCalc = ChangeFont.defaultValues
    this.fontCalc.forEach((item, index) => {
      this.dictFontCalc[this.fontCalc[index].text] = this.fontCalc[index]
    })

    // 宣告時間格式轉換用 function
    this.timestampTrans = function (date, timeFormat) {
      return $filter('date')(date, timeFormat)
    }

    // 儲存客戶設定值的變數
    var panelDefaults = {
      fontSize: '100%',
      fontWeight: 'normal',
      isBold: false,
      fontColor: "",
      isShowTooltip: true,
      currentTheme: '',
      tipBackgroundColor: '',
      nullPointMode: 'null',
      calcType: 'current',
      targetList: [],
      legendStyleList: [],
      seriesList: [],
      chartTimeLine: [],
      dateFormat: 'HH:mm',
      selectedUnit: 'mm/s',
      selectedClassLevel: 'Class I',
      customStyles: [{
        "target": "",
        "type": "log",
        "legendName": "",
        "legendSymbol": "",
        "legendAndLineColor": ""
      }],
      realAssignSetting: [],
      hasCustomStyleTarget: [],
      noCustomStyleTarget: []
    }

    // 限制只有 isWisePaas 權限才執行以下動作
    if (this.scope.$$listeners.isWisePaas) {
      _.defaults(this.panel, panelDefaults)
      this.events.on('data-received', this.onDataReceived.bind(this))
      this.events.on('data-error', this.onDataError.bind(this))
      this.events.on('init-edit-mode', this.onInitEditMode.bind(this))
      this.events.on('render', this.render.bind(this))
    }
  }

  // 初始化，製作字體 dict、unit 格式化工具、建立頁面
  onInitEditMode() {
    this.panel.fontSize = this.formatFont(this.dictFontCalc[this.formatFont(this.panel.fontSize)].text)
    this.addEditorTab('Display', 'public/plugins/ene-log-chart-panel/partials/editor.html', 2)
    this.unitFormats = kbn.getUnitFormats()
  }

  // 錯誤時觸發
  onDataError(err) {
    console.log("error:" + err)
  }

  // 接收資料時觸發
  onDataReceived(dataList) {
    // 取得目前主題
    this.getTheme()
    // dataList = this.fakeData
    if (dataList.length <= 0 || (dataList.length > 0 && dataList[0].target === undefined)) {
      var msgOption = {
        title: {
          show: true,
          textStyle: {
            color: 'grey',
            fontSize: 20
          },
          text: dataList.length < 0 ? 'No data' : 'Please use timeserise data',
          left: 'center',
          top: 'center'
        },
        xAxis: {
          show: false
        },
        yAxis: {
          show: false
        },
        series: []
      };
      var watchDrawNoData = this.$scope.$watch(() => {
        return $('#logChart' + this.ctrlId)[0]
      }, (value) => {
        if (value) {
          this.drawLogChart($('#logChart' + this.ctrlId)[0], msgOption)
          watchDrawNoData();
          this.myChart.resize();
        }
      })
      return
    }
    this.panel.legendStyleList = [] // 對右下 legend 文字及圖樣的控制
    this.panel.seriesList = [] //  對線的控制
    this.panel.chartTimeLine = [] // x 軸的時間區間
    this.panel.targetList = [] // 清空並重新將 target 建立成清單
    this.maxY = -Infinity
    this.minY = Infinity
    this.panel.realAssignSetting = [] // 實際 assgin 上去的設定
    let classLevelForUnit = this.classLevelOptions[this.panel.selectedClassLevel] // IOS10816 背景色區間選項

    // 過濾重複的 target
    _.forEach(dataList, (metric) => {
      if (this.panel.targetList.find(target => { return target == metric.target }) === undefined) {
        this.panel.targetList.push(metric.target)
      }
    })
    // 移除不在 target 清單內的 CustomStyle
    // this.removeUnincludeInTargetListsCustomStyle()

    // 取得最後針對 target 的設定
    this.panel.hasCustomStyleTarget = []
    this.panel.noCustomStyleTarget = []
    this.assignCustomStyles()

    console.log('classLevelForUnit', classLevelForUnit)
    console.log('this.panel.selectedClassLevel', this.panel.selectedClassLevel)
    console.log('classLevelForUnit[this.panel.selectedUnit].good.min', classLevelForUnit[this.panel.selectedUnit].good.min)

    // 找到不存在 style 設定的 target
    this.panel.targetList.forEach(target => {
      let targetNoAssignStyle = this.panel.hasCustomStyleTarget.find(customTarget => { return target === customTarget })
      if (!targetNoAssignStyle) {
        this.panel.noCustomStyleTarget.push(target)
      }
    })

    this.valueListFromDatapointsTrans = []
    this.timeLineFromDatapointsTrans = []

    _.forEach(dataList, (metric, index) => {
      if (!_.isNil(metric.target) && !_.isNil(metric.datapoints)) {
        let valueListFromDatapoints = [] // 從 datapoints 接收到的數值清單
        let timeLineFromDatapoints = [] // 從 datapoints 接收到的時間清單
        _.forEach(metric.datapoints, point => {
          if (point[0] < 0 && point[0] !== null) {
            appEvents.emit("alert-warning", ["Data < 0 was found. It lead to error when use in \"Log Y-Axis\"."])
          } else if (point[0] > 0) {
            this.maxY = Math.max(this.maxY, point[0])
            this.minY = Math.min(this.minY, point[0])
            valueListFromDatapoints.push(point[0])
          } else {
            valueListFromDatapoints.push(point[0])
          }
          timeLineFromDatapoints.push(this.timestampTrans(point[1], this.panel.dateFormat))
        })
        this.valueListFromDatapointsTrans.push(valueListFromDatapoints)
        this.timeLineFromDatapointsTrans.push(timeLineFromDatapoints)
      }
    })

    let nextExponent = null

    _.forEach(dataList, (metric, index) => {
      if (!_.isNil(metric.target) && !_.isNil(metric.datapoints)) {
        let valueListFromDatapoints = this.valueListFromDatapointsTrans[index] // 從 datapoints 接收到的數值清單
        let timeLineFromDatapoints = this.timeLineFromDatapointsTrans[index] // 從 datapoints 接收到的時間清單

        valueListFromDatapoints.forEach((value, index) => {
          // replace 0 to this.minY's next exponent
          if (value === 0) {
            if (nextExponent === null) {
              // nextExponent = 0
              nextExponent = Math.floor(this.dissDeviation(Math.log(this.minY) / Math.log(config.logBase[this
                .panel.selectedUnit])) - 1)
              this.minY = this.dissDeviation(Math.pow(config.logBase[this.panel.selectedUnit], nextExponent))
              valueListFromDatapoints[index] = this.minY
              // this.minY = Math.pow(config.logBase[this.panel.selectedUnit], nextExponent)
              console.log('after -- minY', this.minY)
            } else {
              console.log('value == 0 & nextExponent !== null', 'nextExponent:', nextExponent, 'this.minY:', this.minY)
              valueListFromDatapoints[index] = this.minY
            }
          }
        })

        // 先畫沒有 assign style 的 target
        this.panel.noCustomStyleTarget.forEach(target => {
          if (metric.target === target) {
            this.panel.legendStyleList.push(
              {
                name: metric.target,
                icon: config.defaultSetting.symbol,
                textStyle: {
                  color: _.isNil(this.panel.fontColor) || this.panel.fontColor === '' ? (this.panel.currentTheme === 'dark' ? '#ffffff' : '#323233') : this.panel.fontColor,
                  fontSize: (this.panel.fontSize.split("%")[0] / 100) * 12,
                  fontWeight: this.panel.isBold ? 'bold' : 'normal',
                }
              })
            this.panel.seriesList.push(
              {
                name: metric.target,
                type: 'line',
                symbol: config.defaultSetting.symbol,
                symbolSize: 8,
                data: valueListFromDatapoints,
                itemStyle: {
                  color: config.defaultSetting.color
                }
              }
            )
          }
        })

        this.panel.realAssignSetting.forEach(assignStyle => {
          if (assignStyle.target === metric.target) {
            this.panel.legendStyleList.push(
              {
                name: _.isNil(assignStyle.legendName) || assignStyle.legendName === '' ? metric.target : assignStyle.legendName,
                icon: _.isNil(assignStyle.legendSymbol) || assignStyle.legendSymbol === '' ? config.defaultSetting.symbol : assignStyle.legendSymbol,
                textStyle: {
                  // 要做 hex 或 rgb 檢查
                  color: _.isNil(this.panel.fontColor) || this.panel.fontColor === '' ? (this.panel.currentTheme === 'dark' ? '#ffffff' : '#323233') : this.panel.fontColor,
                  fontSize: (this.panel.fontSize.split("%")[0] / 100) * 12,
                  fontWeight: this.panel.isBold ? 'bold' : 'normal',
                }
              })
            this.panel.seriesList.push(
              {
                name: _.isNil(assignStyle.legendName) || assignStyle.legendName === '' ? metric.target : assignStyle.legendName,
                type: 'line',
                symbol: _.isNil(assignStyle.legendSymbol) || assignStyle.legendSymbol === '' ? config.defaultSetting.symbol : assignStyle.legendSymbol,
                symbolSize: 8,
                data: valueListFromDatapoints,
                itemStyle: {
                  color: _.isNil(assignStyle.legendAndLineColor) || assignStyle.legendAndLineColor === '' ? config.defaultSetting.color : assignStyle.legendAndLineColor
                }
              }
            )
          }
        })
        this.panel.chartTimeLine = timeLineFromDatapoints
      }
    })
    // compute the Y axis's max and min edge
    let maxExponent = Math.ceil(this.dissDeviation(Math.log(this.maxY) / Math.log(config.logBase[this.panel.selectedUnit])) + 1)
    let edgeExponent = Math.ceil(this.dissDeviation(Math.log(classLevelForUnit[this.panel.selectedUnit].unacceptable.max) / Math.log(config.logBase[this.panel.selectedUnit])))
    console.log('maxExponent', maxExponent, 'this.maxY', this.maxY, 'edgeExponent', edgeExponent)
    console.log('edgeExponent', edgeExponent, 'maxExponent', maxExponent)
    if (maxExponent <= edgeExponent) {
      console.log('this.maxY', this.maxY, 'Math.pow(config.logBase[this.panel.selectedUnit], edgeExponent)', Math.pow(config.logBase[this.panel.selectedUnit], edgeExponent))
      if (this.maxY > Math.pow(config.logBase[this.panel.selectedUnit], edgeExponent)) {
        this.maxY = Math.pow(config.logBase[this.panel.selectedUnit], edgeExponent + 1)
      } else {
        this.maxY = Math.pow(config.logBase[this.panel.selectedUnit], edgeExponent)
      }
    } else {
      this.maxY = Math.pow(config.logBase[this.panel.selectedUnit], maxExponent)
    }
    let minExponent = Math.ceil(this.dissDeviation(Math.log(this.minY) / Math.log(config.logBase[this.panel.selectedUnit])))
    let minEdgeExponent = Math.ceil(this.dissDeviation(Math.log(classLevelForUnit[this.panel.selectedUnit].good.min) / Math.log(config.logBase[this.panel.selectedUnit])))
    console.log('minEdgeExponent', minEdgeExponent, 'minExponent', minExponent)
    if (minEdgeExponent >= minExponent || nextExponent !== null ) {
      if ( nextExponent !== null && this.minY <= parseFloat(this.dissDeviation(Math.pow(config.logBase[this.panel.selectedUnit], minExponent)))) {
        this.minY = this.dissDeviation(Math.pow(config.logBase[this.panel.selectedUnit], minExponent))
      } else {
        this.minY = this.dissDeviation(Math.pow(config.logBase[this.panel.selectedUnit], minExponent - 1))
      }
    } else {
      this.minY = this.dissDeviation(Math.pow(config.logBase[this.panel.selectedUnit], minEdgeExponent))
    }
    // let maxExponent = Math.ceil(Math.log(classLevelForUnit[this.panel.selectedUnit].unacceptable.max) / Math.log(config.logBase[this.panel.selectedUnit]))
    // console.log('maxExponent', maxExponent)
    // while (Math.pow(config.logBase[this.panel.selectedUnit], maxExponent) <= this.maxY && this.maxY < Infinity) {
    //   // console.log(Math.pow(config.logBase[this.panel.selectedUnit], maxExponent), this.maxY)
    //   maxExponent++
    // }
    // this.maxY = Math.pow(config.logBase[this.panel.selectedUnit], maxExponent)
    // let minExponent = Math.floor(Math.log(classLevelForUnit[this.panel.selectedUnit].good.min) / Math.log(config.logBase[this.panel.selectedUnit]))
    // while (Math.pow(config.logBase[this.panel.selectedUnit], minExponent) >= this.minY && this.minY > 0) {
    //   // console.log(Math.pow(config.logBase[this.panel.selectedUnit], minExponent), this.minY)
    //   minExponent--
    // }
    // this.minY = Math.pow(config.logBase[this.panel.selectedUnit], minExponent)
    // console.log('maxExponent',maxExponent)
    // console.log('minExponent',minExponent)
    // Math.pow(config.logBase[this.panel.selectedUnit], minExponent)
    console.log('this.minY', this.minY)
    console.log('this.maxY', this.maxY)

    this.classMark =
      [{
        name: '',
        type: 'line',
        data: [],
        markArea: {
          silent: true,
          itemStyle: {
            normal: {
              color: ['rgba(2, 166, 79, 0.3)'],
              borderWidth: 1,
              borderType: 'dashed'
            }
          },
          data: [[{
            name: '',
            yAxis: this.minY
          }, {
            yAxis: classLevelForUnit[this.panel.selectedUnit].good.max
          }]]
        }
      }, {
        name: '',
        type: 'line',
        data: [],
        markArea: {
          silent: true,
          itemStyle: {
            normal: {
              color: ['rgba(189,227,205,0.3)'],
              borderWidth: 1,
              borderType: 'dashed'
            }
          },
          data: [
            [{
              name: '',
              yAxis: classLevelForUnit[this.panel.selectedUnit].satisfactory.min
            }, {
              yAxis: classLevelForUnit[this.panel.selectedUnit].satisfactory.max
            }]]
        }
      }, {
        name: '',
        type: 'line',
        data: [],
        markArea: {
          silent: true,
          itemStyle: {
            normal: {
              color: ['rgba(240, 152, 122, 0.3)'],
              borderWidth: 1,
              borderType: 'dashed'
            }
          },
          data: [
            [{
              name: '',
              yAxis: classLevelForUnit[this.panel.selectedUnit].unsatisfactory.min
            }, {
              yAxis: classLevelForUnit[this.panel.selectedUnit].unsatisfactory.max
            }]]
        }
      }, {
        name: '',
        type: 'line',
        data: [],
        markArea: {
          silent: true,
          itemStyle: {
            normal: {
              color: ['rgba(238,27, 36, 0.3)'],
              borderWidth: 1,
              borderType: 'dashed'
            }
          },
          data: [[{
            name: '',
            yAxis: classLevelForUnit[this.panel.selectedUnit].unacceptable.min
          }, {
            yAxis: this.maxY
          }]]
        }
      }]
    _.forEach(this.classMark, mark => {
      this.panel.seriesList.push(mark)
    })
    this.assignOptionElementAndDraw()
  }

  // reverse Custom Style setting, get the newest setting
  assignCustomStyles() {
    if (this.panel.customStyles.length > 0) {
      this.panel.customStyles.forEach(style => {
        let result = this.panel.targetList.find(target => style.target === target)
        if (result !== undefined) {
          this.panel.realAssignSetting.push(style)
          this.panel.hasCustomStyleTarget.push(style.target)
        }
      })
    }
  }

  assignOptionElementAndDraw() {
    let option = {
      tooltip: {
        trigger: 'item',
        formatter: (datas) => {
          // console.log(datas)
          let res = datas.name + '<br/>'
          res += datas.seriesName + ': ' + (datas.value === this.minY ? '0' : datas.value)
          return res
        }
        // let tooltip = '{a} <br/>{b} : {c}';
        // args.forEach(({ marker, seriesName, value }) => {
        //   console.log('tooltip value', value)
        //   tooltip = value === 0.0001 ? '{a} <br/>{b} : {c}' : '{a} <br/>{b} : {c}';
        ,
        show: this.panel.isShowTooltip
      },
      legend: {
        left: 'right',
        top: 'bottom',
        data: this.panel.legendStyleList
      },
      xAxis: {
        type: 'category',
        name: '',
        boundaryGap: false,
        splitLine: {
          show: true,
        },
        data: this.panel.chartTimeLine,
      },
      textStyle: {
        color: this.panel.currentTheme === 'dark' ? '#fff' : '#323233'
      },
      grid: {
        left: '3%',
        right: '4%',
        bottom: '12%',
        containLabel: true
      },
      yAxis: {
        type: 'log',
        name: this.panel.selectedUnit,
        boundaryGap: false,
        max: this.maxY,
        min: this.minY,
        logBase: config.logBase[this.panel.selectedUnit],
        axisLabel: {
          formatter: (value, index) => {
            // console.log('axisLabel', value);
            if (value === parseFloat(this.minY)) {
              value = 0
            }
            return value
          }
        }
      },
      series: this.panel.seriesList
    }
    var watchDrawNoData = this.$scope.$watch(() => {
      return $('#logChart' + this.ctrlId)[0]
    }, (value) => {
      if (value) {
        this.drawLogChart($('#logChart' + this.ctrlId)[0], option)
        watchDrawNoData();
        this.myChart.resize();
      }
    })
  }

  drawLogChart(panelElement, option) {
    if (!_.isNil(this.myChart) && this.myChart !== "") {
      this.myChart.clear()
    }
    this.myChart = echarts.init(panelElement)
    this.myChart.setOption(option)
  }

  addCustomStyle() {
    this.panel.customStyles.push({
      "target": "",
      "type": "log",
      "legendName": "",
      "legendSymbol": "",
      "legendAndLineColor": ""
    })
  }

  removeCustomStyle(index) {
    this.panel.customStyles.splice(index, 1)
    this.refresh()
  }

  removeUnincludeInTargetListsCustomStyle() {
    this.panel.customStyles.forEach((style, index) => {
      if (style.target !== '') {
        let result = this.panel.targetList.find(element => {
          return element == style.target
        })
        if (result === undefined) {
          this.panel.customStyles.splice(index, 1)
        }
      }
    })
  }

  render() {
    if (this.myChart) {
      this.assignOptionElementAndDraw()
      this.myChart.resize()
    }
  }

  getTheme() {
    let theme = $('.log-chart-panel-theme').css("color")
    if (theme == 'rgb(169, 169, 169)') {
      this.panel.currentTheme = 'dark'
      this.panel.tipBackgroundColor = 'rgba(50, 50, 50, 0.7)'
    } else {
      this.panel.currentTheme = 'light'
      this.panel.tipBackgroundColor = 'rgba(245, 245, 245, 0.7)'
    }
  }

  throwError(msg) {
    const error = new Error()
    error.message = msg
    error.data = msg
    throw error
  }

  formatFont(fontSize) {
    let fontPercent = ''

    if (fontSize == null || fontSize == '100%') {
      fontPercent = '100%'
    } else if (fontSize.indexOf('string') == 0) {
      fontPercent = fontSize.replace('string:', '')
    } else {
      fontPercent = fontSize
    }
    return fontPercent
  }

  dissDeviation(logValue) {
    return parseFloat(logValue).toPrecision(12)
  }

  link(scope, elem, attrs, ctrl) {

  }
}

LogChartPanel.templateUrl = 'partials/module.html'
