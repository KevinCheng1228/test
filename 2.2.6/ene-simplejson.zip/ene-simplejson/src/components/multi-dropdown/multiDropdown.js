/*
 * @Author: NH
 * @Date: 2022-08-04 09:13:50
 * @LastEditTime: 2022-08-12 09:53:30
 * @Description: 
 */
import _ from 'lodash';
import './multiDropdown.css!';

export class multiDropdownCtrl {

    constructor($scope, $element) {
        this.list = [];
        this.text = [];
        this.show = true;
        this.filter = '';
        this.$elem = $element;
        this.$scope = $scope;
        this.init = false;
        $scope.$watch('ctrl.model', this.modelChanged.bind(this));
    }


    modelChanged() {
        // if (_.isArray(this.model)) {
        //     if (!this.model.length && this.list.length) {
        //         this.model = [this.list[0]];
        //     }
        // } else if (_.isObject(this.model)) {
        //     let index = this.list.findIndex(x => { return this.model.value == x.value });
        //     if (index !== -1) {
        //         this.model = [this.list[index]];
        //     } else if (this.list.length) {
        //         this.model = [this.list[0]];
        //     }
        // }
        if(this.init){
            this.updateDisplay(this.model);
            this.onChange(this.model);
        }
    }

    updateDisplay(data) {
        if (_.isArray(data)) {
            this.text = data.map(x => { return x.text });
            this.display = this.text.join(' + ');
        } else if (_.isObject(data)) {
            this.text = data.text;
            this.display = this.text;
        }
    }

    async toggleMultiList($event) {
        $event.stopPropagation();
        this.list = await this.getOptions();
        this.show = false;
        this.close();
        this.$scope.$digest();
    }

    changeMultiDropdown(item, $event) {
        $event.stopPropagation();
        let index = this.model.findIndex(x => { return x.value === item.value });
        if (!this.multiple){
            this.model = [_.cloneDeep(item)];
        } else {
            if (index !== -1) {
                this.model = this.model.filter((x,i)=> {return index !== i});
                if (_.isEmpty(this.model)) {
                    this.model.push(_.cloneDeep(this.list[0]));
                }
            } else {
                let copy = _.cloneDeep(this.model);
                copy.push(_.cloneDeep(item));
                this.model = copy;
            }
        }
        this.show = true;
        this.init = true;
    }

    close(){
        let _this = this;
        $(document).one('click', function (e) {
            e.stopPropagation();
            if (e.target.className.indexOf('multi-') == -1) {
                _this.show = true;
                _this.$scope.$digest();
            } else {
                _this.close();
            }
        });
    }
    
    itemKeyDownHandler($event) {
    }

    changeDropdownFilter() {
        this.filter = this.display;
    }
    filterItemList() {
        let f = this.filter ? this.filter.trim() : (this.filter = '') && '';
        let res = null;
        try {
            if (!f) { res = ''; } else {
                res = f.replace(/\*.*/g, '');
            }
        } catch (e) {
            console.log(e);
        }
        return res;
    }
    checkedActive(item) {
        let bool = false;
        if (!_.isArray(this.model)) return bool;
        let index = this.model.findIndex(x => x.value === item.value);
        bool = -1 !== index ? true : false;
        return bool;
    }
}

export function multiDropdownDirective() {
    return {
        restrict: 'E',
        templateUrl: 'public/plugins/ene-simple-json-datasource/components/multi-dropdown/multiDropdown.html',
        controller: multiDropdownCtrl,
        controllerAs: 'ctrl',
        bindToController: true,
        scope: {
            model: '=',
            getOptions: '&',
            onChange: '&',
            onClose: '&',
            placeholder: '&',
            multiple: '='
        }
    }
}
