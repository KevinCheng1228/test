///<reference path="../node_modules/grafana-sdk-mocks/app/headers/common.d.ts" />
import _ from 'lodash';
import {transformers} from './transformers';
import ChangeFont from './fontsize';

export class TablePanelEditorCtrl {
  panel: any;
  panelCtrl: any;
  transformers: any;
  fontSizes: any;
  addColumnSegment: any;
  getColumnNames: any;
  canSetColumns: boolean;
  columnsHelpMessage: string;
  conditionset: any;
  filterMsg: string;
  searchName: string;
  timeToColsOptions: any;

  /** @ngInject */
  constructor($scope, private $q, private uiSegmentSrv) {
    $scope.editor = this;
    this.panelCtrl = $scope.ctrl;
    this.panel = this.panelCtrl.panel;
    this.transformers = transformers;
    this.fontSizes = ChangeFont.defaultValues;
    this.searchName = '';
    this.addColumnSegment = uiSegmentSrv.newPlusButton();
    this.updateTransformHints();
    this.conditionsetRender();

    this.timeToColsOptions = [
      {text: '1 Hour', value: 'h'},
      {text: '1 Day', value: 'd'},
      {text: '1 Week', value: 'w'},
    ];
  }

  updateTransformHints() {
    this.canSetColumns = false;
    this.columnsHelpMessage = '';

    switch (this.panel.transform) {
      case 'timeseries_aggregations': {
        this.canSetColumns = true;
        break;
      }
      case 'json': {
        this.canSetColumns = true;
        break;
      }
      case 'table': {
        this.columnsHelpMessage =
          'Columns and their order are determined by the data query';
      }
    }
  }

  conditionsetRender() {
    this.conditionset = [];
    if (this.panel.conditionset) {
      for (let i = 0; i < this.panel.conditionset.length; i++) {
        const condition = this.panel.conditionset[i];
        this.conditionset.push(condition);
      }
    }
  }

  searchNameChange() {
    if (this.searchName === '') {
      return;
    }
    const search: any = {};
    search.label = this.searchName;
    search.inputType = 'string';
    search.condition = 'has';
    search.text = '';
    this.conditionset.push(search);

    this.searchName = '';
  }

  removeSearch(search) {
    this.filterMsg = '';
    this.conditionset = _.without(this.conditionset, search);
    this.panel.conditionset = _.without(this.conditionset, search);
    this.render();
  }

  searchFilter() {
    this.filterMsg = '';
    if (this.conditionset.length === 0) {
      return;
    }
    for (let i = 0; i < this.panel.conditionset.length; i++) {
      const condition = this.panel.conditionset[i];
      if (!condition.label || !condition.condition || !condition.inputType) {
        this.filterMsg = this.panelCtrl.labelTrans[this.panelCtrl.systemLang].search_criteria_empty;
      }
      break;
    }

    if (this.filterMsg) {
      return;
    }

    this.panel.conditionset = this.conditionset;
    this.panelCtrl.pageIndex = 0;
    this.render();
  }

  getColumnOptions() {
    if (!this.panelCtrl.dataRaw) {
      return this.$q.when([]);
    }
    const columns = this.transformers[this.panel.transform].getColumns(
      this.panelCtrl.dataRaw
    );
    const segments = _.map(columns, (c: any) =>
      this.uiSegmentSrv.newSegment({value: c.text})
    );
    return this.$q.when(segments);
  }

  addColumn() {
    const columns = transformers[this.panel.transform].getColumns(this.panelCtrl.dataRaw);
    const column = _.find(columns, {text: this.addColumnSegment.value});

    if (column) {
      this.panel.columns.push(column);
      this.render();
    }

    const plusButton = this.uiSegmentSrv.newPlusButton();
    this.addColumnSegment.html = plusButton.html;
  }

  transformChanged() {
    this.panel.columns = [];
    if (this.panel.transform === 'timeseries_aggregations') {
      this.panel.columns.push({text: 'Avg', value: 'avg'});
    }
    this.updateTransformHints();
    this.render();
  }

  render() {
    this.panelCtrl.render();
  }

  removeColumn(column) {
    this.panel.columns = _.without(this.panel.columns, column);
    this.panelCtrl.render();
  }

  searchcontrol() {
    if (this.panel.searchcontrol === 'down') {
      this.panel.searchcontrol = 'up';
    } else {
      this.panel.searchcontrol = 'down';
    }

    this.conditionsetRender();
    this.render();
  }
}

/** @ngInject */
export function tablePanelEditor($q, uiSegmentSrv) {
  'use strict';
  return {
    restrict: 'E',
    scope: true,
    templateUrl: 'public/plugins/ene-report-panel/partials/editor.html',
    controller: TablePanelEditorCtrl,
  };
}
