///<reference path="../node_modules/grafana-sdk-mocks/app/headers/common.d.ts" />

import _ from 'lodash';
import kbn from 'app/core/utils/kbn';
import { getMultiLang } from './multilang';

export class ReportOptionsCtrl {
    panel: any;
    panelCtrl: any;
    langType: string;

    /** @ngInject */
    constructor($scope) {
        $scope.editor = this;

        this.panelCtrl = $scope.ctrl;
        this.panel = this.panelCtrl.panel;
        this.langType = this.panel.langType;
    }

    resetReportButton() {
        this.panel.reportBtnText = '';
        this.panel.reportBtnTextColor = '';
        this.panel.reportBtnBgColor = '';

        this.render();
    }

    getMultiLang(key) {
        this.langType = this.panelCtrl.getLangType(this.panelCtrl.dashboard.panelLanguage);
        return getMultiLang(key, this.langType);
    }

    render() {
        this.panelCtrl.render();
    }
}

/** @ngInject */
export function reportOptionsTab($q, uiSegmentSrv) {
    'use strict';
    return {
        restrict: 'E',
        scope: true,
        templateUrl: 'public/plugins/ene-alarm-panel/partials/report_options.html',
        controller: ReportOptionsCtrl,
    };
}
