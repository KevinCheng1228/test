///<reference path="../node_modules/grafana-sdk-mocks/app/headers/common.d.ts" />

import _ from 'lodash';
import kbn from 'app/core/utils/kbn';
import { getMultiLang } from './multilang';

export class RowOptionsCtrl {
    panel: any;
    panelCtrl: any;
    colorModes: any;
    columnStyles: any;
    columnTypes: any;
    fontSizes: any;
    dateFormats: any;
    addColumnSegment: any;
    unitFormats: any;
    getColumnNames: any;
    activeStyleIndex: number;
    mappingTypes: any;

    /** @ngInject */
    constructor($scope) {
        $scope.rowEditor = this;
        this.activeStyleIndex = 0;
        this.panelCtrl = $scope.ctrl;
        this.panel = this.panelCtrl.panel;
        this.unitFormats = kbn.getUnitFormats();
        this.colorModes = [
            { text: 'Disabled', value: null },
            { text: 'Cell', value: 'cell' },
            { text: 'Value', value: 'value' },
            { text: 'Row', value: 'row' },
            { text: 'Status', value: 'status' },
        ];
    }
    getMultiLang(key) {
        return getMultiLang(key, this.panel.langType);
    }
    render() {
        this.panelCtrl.render();
    }

    setUnitFormat(column, subItem) {
        column.unit = subItem.value;
        this.panelCtrl.render();
    }

    addRowStyle() {
        const styles = this.panel.rowStyles;
        const stylesCount = styles.length + 1;
        this.panel.activeRowStyleIndex = styles.length;
        const newStyleRule = {
            rowBGColor: '',
            rowAlias: null,
            colNum: '1',
            rowNum: stylesCount.toString(),
            rowhtml: '',
            rowopenNewTab: false,
            thresholdConfig: {
                colorMode: null,
                thresholds: [],
                colors: [].concat(this.panelCtrl.statusList),
            },
        };
        styles.push(newStyleRule);
        this.panelCtrl.render();
    }

    rowNumChange(style) {
        this.panelCtrl.render();
    }

    resetRowColor(style) {
        style.rowBGColor = null;
        this.panelCtrl.render();
    }

    removeRowStyle(style) {
        this.panel.rowStyles = _.without(this.panel.rowStyles, style);
        this.panel.activeRowStyleIndex = this.panel.rowStyles.length - 1;
        this.panelCtrl.render();
    }

    invertColorOrder(index) {
        const ref = this.panel.rowStyles[index].thresholdConfig.colors;
        ref.reverse();
        this.panel.rowStyles[index].thresholdConfig.colors = ref;
        this.panelCtrl.render();
    }
}

/** @ngInject */
export function rowOptionsTab($q, uiSegmentSrv) {
    'use strict';
    return {
        restrict: 'E',
        scope: true,
        templateUrl: 'public/plugins/ene-event-log-panel/partials/row_options.html',
        controller: RowOptionsCtrl,
    };
}
