///<reference path="../node_modules/grafana-sdk-mocks/app/headers/common.d.ts" />
import _ from 'lodash';
import ChangeFont from './fontsize';
import i18n from 'app/features/i18n';

export class TablePanelDisplayCtrl {
  panel: any;
  dashboard: any;
  panelCtrl: any;
  transformers: any;
  fontSizes: any;
  getColumnNames: any;
  canSetColumns: boolean;
  columnsHelpMessage: string;
  mergeError: string;
  mergeColums: any;
  mergeType: string;
  nameDisabled: boolean;
  indexDisabled: boolean;
  headerDateFormats: any;
  columnAligns: any;
  getTargetOptions: any;

  /** @ngInject */
  constructor($scope) {
    $scope.editor = this;
    this.panelCtrl = $scope.ctrl;
    this.panel = this.panelCtrl.panel;
    this.dashboard = this.panelCtrl.dashboard;
    this.fontSizes = ChangeFont.defaultValues;
    this.mergeError = '';
    this.mergeType = this.panel.mergeType || 'nameString';
    this.nameDisabled = false;
    this.indexDisabled = false;

    this.headerDateFormats = [
      {text: 'No Set', value: false},
      {text: 'YYYY-MM-DD', value: 'YYYY-MM-DD'},
      {text: 'YYYY/MM', value: 'YYYY[</br>&nbsp;]MMM'},
    ];

    this.columnAligns = [
      {text: 'Left', value: 'left'},
      {text: 'Center', value: 'center'},
      {text: 'Right', value: 'right'},
    ];

    this.getMergeColumns();

    this.getTargetOptions = () => {
      if (!this.panelCtrl.dataRaw) {
        return [];
      }
      const targets = [{text: 'NULL', value: null}];
      for (let i = 0; i < this.panelCtrl.dataRaw.length; i++) {
        const target = this.panelCtrl.dataRaw[i];
        targets.push({text: target.target, value: target.target});
      }
      return targets;
    };
  }

  getMergeColumns() {
    this.mergeColums = [];
    _.forEach(this.panel.mergeColums, merge => {
      this.mergeColums.push(merge);
    });
    this.getDisabled();
  }

  getDisabled() {
    if (this.mergeColums.length > 0) {
      if (this.panel.mergeType === 'nameString') {
        this.nameDisabled = false;
        this.indexDisabled = true;
      } else {
        this.nameDisabled = true;
        this.indexDisabled = false;
      }
    } else {
      this.nameDisabled = false;
      this.indexDisabled = false;
    }
  }

  render() {
    this.panelCtrl.render();
  }

  resetColor() {
    this.panel.tableTitlebgColorSet = null;
    this.panel.tableTitleFontColorSet = null;
    this.panel.evenRowBGColorSet = null;
    this.panel.oddRowBGColorSet = null;

    this.panel.hoverBGColorSet = null;
    this.panel.borderColor = null;
    this.panelCtrl.render();
  }

  showRowBordersChanged() {
    if (this.panel.showRowBorders) {
      this.panel.showCellBorders = false;
    }
    this.panelCtrl.render();
  }

  showCellBordersChanged() {
    if (this.panel.showCellBorders) {
      this.panel.showRowBorders = false;
    }
    this.panelCtrl.render();
  }

  changeBorderColor() {
    if (this.panel.borderColor) {
    }
    this.panelCtrl.render();
  }

  addMergeColumns(type: any) {
    const merges = this.mergeColums;

    if (type === 'index') {
      this.panel.mergeType = 'indexNum';
    } else {
      this.panel.mergeType = 'nameString';
    }

    if (merges.length > 0) {
      let noMerge = false;
      for (let i = 0; i < merges.length; i++) {
        if (!merges[i].start || !merges[i].end || !merges[i].name) {
          noMerge = true;
        }
      }
      if (noMerge) {
        return;
      }
    }
    const merge = {start: '', end: '', name: ''};
    this.mergeColums.push(merge);
    this.getDisabled();
    //this.render();
  }

  getColumnStrat() {
    if (!this.panelCtrl.table) {
      return [];
    }

    const names = [];
    if (this.panelCtrl.table.columns) {
      for (let i = 0; i < this.panelCtrl.table.columns.length; i++) {
        const column = this.panelCtrl.table.columns[i];
        if (
          column.hidden ||
          (column.style && column.style.type === 'hidden') ||
          (column.style && column.style.type === 'transparent')
        ) {
          continue;
        }
        if (this.panel.mergeType === 'nameString') {
          names.push({text: column.text, value: column.text});
        } else {
          names.push({text: i + 1 + '', value: i + 1 + '', colName: column.title});
        }
      }
    }
    return names;
  }

  getColumnEnd(merge) {
    if (!this.panelCtrl.table) {
      return [];
    }

    if (!merge.start) {
      return [];
    }

    const tableCols = [];

    for (let i = 0; i < this.panelCtrl.table.columns.length; i++) {
      const column = this.panelCtrl.table.columns[i];
      if (
        column.hidden ||
        (column.style && column.style.type === 'hidden') ||
        (column.style && column.style.type === 'transparent')
      ) {
        continue;
      }
      tableCols.push(column);
    }

    if (tableCols.length === 0) {
      return [];
    }

    let start = 0;
    if (this.panel.mergeType === 'indexNum') {
      start = parseInt(merge.start) + 1;
    } else {
      for (let t = 0; t < tableCols.length; t++) {
        if (merge.start === tableCols[t].text) {
          start = t + 1;
        }
      }
    }

    const names = [];
    for (let i = start; i < tableCols.length; i++) {
      if (this.panel.mergeType === 'nameString') {
        names.push({text: tableCols[i].text, value: tableCols[i].text});
      } else {
        names.push({text: i + '', value: i + ''});
      }
    }

    if (this.panel.mergeType === 'indexNum') {
      const num = tableCols.length;
      names.push({text: num + '', value: num + ''});
    }

    return names;
  }

  startChange(merge) {
    merge.end = '';
  }

  endChange(merge) {
    console.log(merge);
  }

  mergingColumn() {
    this.checkError();
    if (this.mergeError) {
      return;
    }

    this.panel.mergeColums = [];
    _.forEach(this.mergeColums, merge => {
      this.panel.mergeColums.push(merge);
    });

    this.render();
  }

  nameChange() {
    //this.checkError();
  }

  targetChange(merge: any) {
    for (let i = 0; i < this.panelCtrl.dataRaw.length; i++) {
      const data = this.panelCtrl.dataRaw[i];
      if (merge.target === data.target) {
        if (data.type === 'table') {
          merge.dataType = 'table';
        } else if (data.datapoints) {
          merge.dataType = 'timeseries';
        }
        break;
      }
    }
  }

  removeMerge(merge, index) {
    this.mergeColums = _.without(this.mergeColums, merge);
    i18n.deletePanelI18n(this.panel, 'mergeColums', index);
    this.getDisabled();
    this.mergingColumn();
  }

  checkError() {
    let mergeError = '';
    let startToEnd = [];

    for (let i = 0; i < this.mergeColums.length; i++) {
      const mergeCol = this.mergeColums[i];
      if (!mergeCol.start || !mergeCol.end) {
        mergeError = this.panelCtrl.labelTrans[this.panelCtrl.systemLang].merge_empty;
      }
      if (!mergeCol.name && !mergeCol.target) {
        mergeError = this.panelCtrl.labelTrans[this.panelCtrl.systemLang].merge_empty;
      }

      if (mergeError) {
        break;
      }

      let startNum = 0;
      let endNum = 0;
      for (let t = 0; t < this.panelCtrl.table.columns.length; t++) {
        const column = this.panelCtrl.table.columns[t];
        if (this.panel.mergeType === 'nameString') {
          if (mergeCol.start === column.text) {
            startNum = t;
          }
          if (mergeCol.end === column.text) {
            endNum = t;
          }
        } else {
          startNum = parseInt(mergeCol.start, 10);
          endNum = parseInt(mergeCol.end, 10);
        }
      }
      for (let j = startNum; j <= endNum; j++) {
        startToEnd.push(j);
      }
    }

    const newary = startToEnd.sort();
    for (let i = 0; i < newary.length; i++) {
      if (newary[i] == newary[i + 1]) {
        mergeError = this.panelCtrl.labelTrans[this.panelCtrl.systemLang].merge_repeat;
        break;
      }
    }

    this.mergeError = mergeError;
  }

  handleTitleFontSizeChange() {
    i18n.setPanelI18n(this.panel, 'tableTitleFont');
  }

  handleBodyFontSizeChange() {
    i18n.setPanelI18n(this.panel, 'fontSize');
  }

  handleMergeNameChange() {
    i18n.setPanelI18n(this.panel, 'mergeColums', 'name');
  }
}

/** @ngInject */
export function TablePanelDisplay($q, uiSegmentSrv) {
  'use strict';
  return {
    restrict: 'E',
    scope: true,
    templateUrl: 'public/plugins/ene-report-panel/partials/display.html',
    controller: TablePanelDisplayCtrl,
  };
}
