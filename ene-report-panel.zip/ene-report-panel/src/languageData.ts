const languageData = {
  'en-US': {
    failed_to_send: 'Failed to send',
    reset_value_title: 'Reset Value',
    reset_value_content: 'Do you want to reset the value to 0?',
    submit: 'Submit',
    cancel: 'Cancel',
  },
  'zh-CN': {
    failed_to_send: '发送失败',
    reset_value_title: '重置值',
    reset_value_content: '是否重设值为0?',
    submit: '重設',
    cancel: '取消',
  },
  'zh-TW': {
    failed_to_send: '發送失敗',
    reset_value_title: '重設值',
    reset_value_content: '是否重設值為0?',
    submit: '重設',
    cancel: '取消',
  },
  default: {
    failed_to_send: 'Failed to send',
    reset_value_title: 'Reset Value',
    reset_value_content: 'Do you want to reset the value to 0?',
    submit: 'Submit',
    cancel: 'Cancel',
  },
};

export default languageData;
