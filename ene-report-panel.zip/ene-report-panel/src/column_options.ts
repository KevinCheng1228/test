///<reference path="../node_modules/grafana-sdk-mocks/app/headers/common.d.ts" />
import _ from 'lodash';
import kbn from 'app/core/utils/kbn';
import i18n from 'app/features/i18n';
import $ from 'jquery';

export class ColumnOptionsCtrl {
  panel: any;
  dashboard: any;
  panelCtrl: any;
  colorModes: any;
  transparentColorModes: any;
  columnStyles: any;
  columnTypes: any;
  dateFormats: any;
  addColumnSegment: any;
  unitFormats: any;
  getColumnNames: any;
  activeStyleIndex: number;
  mappingTypes: any;
  columnAligns: any;
  colorMapType: any;
  iconlist: any;

  /** @ngInject */
  constructor($scope) {
    $scope.editor = this;

    this.activeStyleIndex = 0;
    this.panelCtrl = $scope.ctrl;
    this.panel = this.panelCtrl.panel;
    this.dashboard = this.panelCtrl.dashboard;
    this.unitFormats = kbn.getUnitFormats();
    this.colorModes = [
      {text: 'Disabled', value: null},
      {text: 'Cell', value: 'cell'},
      {text: 'Value', value: 'value'},
      {text: 'Row', value: 'row'},
      {text: 'Status', value: 'status'},
      {text: 'Alarm', value: 'alarm'},
    ];
    this.transparentColorModes = [
      {text: 'Disabled', value: null},
      {text: 'Row', value: 'row'},
    ];
    this.columnTypes = [
      {text: 'Number', value: 'number'},
      {text: 'String', value: 'string'},
      {text: 'Date', value: 'date'},
      {text: 'Array', value: 'array'},
      {text: 'Operation', value: 'operation'},
      {text: 'Hidden', value: 'hidden'},
      {text: 'Transparent', value: 'transparent'},
    ];
    this.dateFormats = [
      {text: 'YYYY-MM-DD HH:mm:ss', value: 'YYYY-MM-DD HH:mm:ss'},
      {text: 'YYYY-MM-DD', value: 'YYYY-MM-DD'},
      {text: 'YYYY-MM', value: 'YYYY-MM'},
    ];
    this.mappingTypes = [
      {text: 'Value to text', value: 1},
      {text: 'Range to text', value: 2},
    ];
    this.columnAligns = [
      {text: 'Left', value: 'left'},
      {text: 'Center', value: 'center'},
      {text: 'Right', value: 'right'},
    ];
    this.colorMapType = [
      {text: 'Value', value: 'value'},
      {text: 'Status', value: 'status'},
    ];

    this.iconlist = [{text: 'Reset', value: 'reset'}];

    this.getColumnNames = () => {
      if (!this.panelCtrl.table) {
        return [];
      }
      return _.map(this.panelCtrl.table.columns, (col: any) => {
        if (col.addStatusLampCol) {
          return '';
        }
        return col.text;
      });
    };

    this.onColorChange = this.onColorChange.bind(this);
  }

  render() {
    this.panelCtrl.render();
  }

  setUnitFormat(column, subItem) {
    column.unit = subItem.value;
    this.panelCtrl.render();
  }

  addColumnStyle() {
    const newStyleRule = {
      unit: 'short',
      type: 'number',
      alias: '',
      decimals: 2,
      colors: [
        'rgba(245, 54, 54, 0.9)',
        'rgba(237, 129, 40, 0.89)',
        'rgba(50, 172, 45, 0.97)',
        'rgba(45, 91, 172, 0.9)',
        'rgba(247, 243, 27, 0.9)',
        'rgba(184, 27, 247, 0.9)',
      ],
      colorMode: null,
      pattern: '',
      dateFormat: 'YYYY-MM-DD HH:mm:ss',
      thresholds: [],
      mappingType: 1,
      titleAlign: 'left',
      align: 'left',
      thresholdsDisplay: [],
      arraycolors: ['rgb(23, 180, 16)', 'rgb(255, 197, 0)', 'rgb(210, 30, 0)'],
      alarmColors: ['green', 'yellow', 'red', 'null'],
      bar: false,
      url: false,
      icon: false,
      handler: 'ResetValue',
      icontype: 'reset',
      operNum: 1,
      operationList: [
        {
          type: 'reset',
          handler: 'ResetValue',
        },
      ],
    };

    const styles = this.panel.styles;
    const stylesCount = styles.length;
    let indexToInsert = stylesCount;

    // check if last is a catch all rule, then add it before that one
    if (stylesCount > 0) {
      const last = styles[stylesCount - 1];
      if (last.pattern === '/.*/') {
        indexToInsert = stylesCount - 1;
      }
    }

    styles.splice(indexToInsert, 0, newStyleRule);
    this.activeStyleIndex = indexToInsert;
  }

  removeColumnStyle(style, index) {
    this.panel.styles = _.without(this.panel.styles, style);
    this.activeStyleIndex = this.panel.styles.length - 1;
    i18n.deletePanelI18n(this.panel, 'styles', index);
    this.panelCtrl.render();
  }

  invertColorOrder(index) {
    const ref = this.panel.styles[index].colors;
    const copy1 = ref[0];
    const copy2 = ref[1];
    const copy3 = ref[2];
    ref[0] = ref[5];
    ref[1] = ref[4];
    ref[2] = ref[3];
    ref[3] = copy3;
    ref[4] = copy2;
    ref[5] = copy1;
    this.panelCtrl.render();
  }

  invertAlarmColorOrder(event: any, colorIndex: number) {
    const target = $(event.target).parents('.alarm');
    const index = parseInt(target.attr('data'));
    const ref = this.panel.styles[index].alarmColors;
    const copy = ref[colorIndex];
    ref[colorIndex] = ref[colorIndex - 1];
    ref[colorIndex - 1] = copy;
    this.panelCtrl.render();
  }

  onColorChange(styleIndex, colorIndex) {
    return newColor => {
      this.panel.styles[styleIndex].colors[colorIndex] = newColor;
      this.render();
    };
  }

  addColorMap(style) {
    if (!style.colorMaps) {
      style.colorMaps = [];
    }
    style.colorMaps.push({value: '', text: '', type: 'value'});
    this.panelCtrl.render();
  }

  removeColorMap(style, index) {
    style.colorMaps.splice(index, 1);
    this.panelCtrl.render();
  }

  addValueMap(style) {
    if (!style.valueMaps) {
      style.valueMaps = [];
    }
    style.valueMaps.push({value: '', text: ''});
    this.panelCtrl.render();
  }

  removeValueMap(style, index) {
    style.valueMaps.splice(index, 1);
    this.panelCtrl.render();
  }

  addRangeMap(style) {
    if (!style.rangeMaps) {
      style.rangeMaps = [];
    }
    style.rangeMaps.push({from: '', to: '', text: ''});
    this.panelCtrl.render();
  }

  removeRangeMap(style, index) {
    style.rangeMaps.splice(index, 1);
    this.panelCtrl.render();
  }

  resetColumnColor(style) {
    delete style.colbgColor;
    delete style.colFontColorSet;
    this.panelCtrl.render();
  }

  linkChecked(style) {
    if (style.link) {
      style.url = false;
    }
    this.render();
  }

  asUrlChecked(style) {
    if (style.url) {
      style.link = false;
    }
    this.render();
  }

  operationChangeNum(style) {
    console.log('operationChangeNum', style);
    if (style.operNum == undefined) {
      style.operNum = 1;
      style.operationList = [
        {
          type: 'reset',
          handler: 'ResetValue',
        },
      ];
    }
    let temp = {
      type: 'reset',
      handler: 'ResetValue',
    };

    if (style.operNum < 0) style.operNum = 0;
    if (style.operNum > 3) style.operNum = 3;
    if (style.operNum > style.operationList.length) {
      let len = style.operationList.length;
      for (let i = len; i < style.operNum; i++) {
        style.operationList.push(Object.assign({}, temp));
      }
    } else if (style.operNum < style.operationList.length) {
      let len = style.operationList.length - style.operNum;
      style.operationList.splice(style.operNum, len);
    }

    this.render();
  }

  typeChange(style) {
    if (style.type === 'transparent') {
      if (style.colorMode !== 'row') {
        style.colorMode = null;
      }
    }
    this.panelCtrl.render();
  }

  handleColHeaderChange() {
    i18n.setPanelI18n(this.panel, 'styles', 'alias');
  }

  handleColPostfixChange() {
    i18n.setPanelI18n(this.panel, 'styles', 'colpostfix');
  }

  handleColThresholdDisplayChange() {
    i18n.setPanelI18n(this.panel, 'styles', 'thresholdsDisplay');
  }

  handleStyleLinkURL() {
    i18n.setPanelI18n(this.panel, 'styles', 'linkUrl');
  }

  handleLinkTooltip() {
    i18n.setPanelI18n(this.panel, 'styles', 'linkTooltip');
  }

  valueMapsI18n() {
    i18n.setPanelI18n(this.panel, 'styles', 'valueMaps');
  }

  rangeMapsI18n() {
    i18n.setPanelI18n(this.panel, 'styles', 'rangeMaps');
  }
}

/** @ngInject */
export function columnOptionsTab($q, uiSegmentSrv) {
  'use strict';
  return {
    restrict: 'E',
    scope: true,
    templateUrl: 'public/plugins/ene-report-panel/partials/column_options.html',
    controller: ColumnOptionsCtrl,
  };
}
